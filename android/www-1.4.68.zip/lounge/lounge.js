(()=>{var nu="170";var Om=0,xd=1,Hm=2;var Nf=1,iu=2,Ti=3,hi=0,en=1,Te=2,Ji=0,fr=1,yd=2,vd=3,bd=4,Vm=5,vs=100,Gm=101,Wm=102,$m=103,qm=104,Xm=200,Ym=201,Zm=202,Km=203,Lc=204,kc=205,Jm=206,jm=207,Qm=208,t0=209,e0=210,n0=211,i0=212,s0=213,r0=214,Dc=0,Uc=1,Nc=2,xr=3,zc=4,Fc=5,Bc=6,Oc=7,zf=0,o0=1,a0=2,ji=0,l0=1,c0=2,h0=3,su=4,u0=5,d0=6,f0=7;var Ff=300,yr=301,vr=302,Hc=303,Vc=304,ul=306,Ms=1e3,_s=1001,Gc=1002,In=1003,p0=1004;var Qo=1005;var Vn=1006,jl=1007;var Ai=1008;var Pi=1009,Bf=1010,Of=1011,uo=1012,ru=1013,ws=1014,li=1015,Ro=1016,ou=1017,au=1018,br=1020,Hf=35902,Vf=1021,Gf=1022,jn=1023,Wf=1024,$f=1025,pr=1026,_r=1027,lu=1028,cu=1029,qf=1030,hu=1031;var uu=1033,Pa=33776,Ia=33777,La=33778,ka=33779,Wc=35840,$c=35841,qc=35842,Xc=35843,Yc=36196,Zc=37492,Kc=37496,Jc=37808,jc=37809,Qc=37810,th=37811,eh=37812,nh=37813,ih=37814,sh=37815,rh=37816,oh=37817,ah=37818,lh=37819,ch=37820,hh=37821,Da=36492,uh=36494,dh=36495,Xf=36283,fh=36284,ph=36285,mh=36286;var Ua=2300,gh=2301,Ql=2302,_d=2400,Md=2401,wd=2402;var m0=3200,g0=3201;var Yf=0,x0=1,Zi="",me="srgb",Rr="srgb-linear",dl="linear",pe="srgb";var qs=7680;var Sd=519,y0=512,v0=513,b0=514,Zf=515,_0=516,M0=517,w0=518,S0=519,xh=35044;var Ed="300 es",Ri=2e3,Na=2001,Qi=class{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){if(this._listeners===void 0)return!1;let n=this._listeners;return n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){if(this._listeners===void 0)return;let s=this._listeners[t];if(s!==void 0){let r=s.indexOf(e);r!==-1&&s.splice(r,1)}}dispatchEvent(t){if(this._listeners===void 0)return;let n=this._listeners[t.type];if(n!==void 0){t.target=this;let s=n.slice(0);for(let r=0,o=s.length;r<o;r++)s[r].call(this,t);t.target=null}}},Qe=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],Td=1234567,ro=Math.PI/180,fo=180/Math.PI;function ci(){let i=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Qe[i&255]+Qe[i>>8&255]+Qe[i>>16&255]+Qe[i>>24&255]+"-"+Qe[t&255]+Qe[t>>8&255]+"-"+Qe[t>>16&15|64]+Qe[t>>24&255]+"-"+Qe[e&63|128]+Qe[e>>8&255]+"-"+Qe[e>>16&255]+Qe[e>>24&255]+Qe[n&255]+Qe[n>>8&255]+Qe[n>>16&255]+Qe[n>>24&255]).toLowerCase()}function Ve(i,t,e){return Math.max(t,Math.min(e,i))}function du(i,t){return(i%t+t)%t}function E0(i,t,e,n,s){return n+(i-t)*(s-n)/(e-t)}function T0(i,t,e){return i!==t?(e-i)/(t-i):0}function oo(i,t,e){return(1-e)*i+e*t}function A0(i,t,e,n){return oo(i,t,1-Math.exp(-e*n))}function R0(i,t=1){return t-Math.abs(du(i,t*2)-t)}function C0(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*(3-2*i))}function P0(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*i*(i*(i*6-15)+10))}function I0(i,t){return i+Math.floor(Math.random()*(t-i+1))}function L0(i,t){return i+Math.random()*(t-i)}function k0(i){return i*(.5-Math.random())}function D0(i){i!==void 0&&(Td=i);let t=Td+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function U0(i){return i*ro}function N0(i){return i*fo}function z0(i){return(i&i-1)===0&&i!==0}function F0(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function B0(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function O0(i,t,e,n,s){let r=Math.cos,o=Math.sin,a=r(e/2),l=o(e/2),c=r((t+n)/2),h=o((t+n)/2),u=r((t-n)/2),d=o((t-n)/2),f=r((n-t)/2),m=o((n-t)/2);switch(s){case"XYX":i.set(a*h,l*u,l*d,a*c);break;case"YZY":i.set(l*d,a*h,l*u,a*c);break;case"ZXZ":i.set(l*u,l*d,a*h,a*c);break;case"XZX":i.set(a*h,l*m,l*f,a*c);break;case"YXY":i.set(l*f,a*h,l*m,a*c);break;case"ZYZ":i.set(l*m,l*f,a*h,a*c);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function Jn(i,t){switch(t.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("Invalid component type.")}}function fe(i,t){switch(t.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("Invalid component type.")}}var Cr={DEG2RAD:ro,RAD2DEG:fo,generateUUID:ci,clamp:Ve,euclideanModulo:du,mapLinear:E0,inverseLerp:T0,lerp:oo,damp:A0,pingpong:R0,smoothstep:C0,smootherstep:P0,randInt:I0,randFloat:L0,randFloatSpread:k0,seededRandom:D0,degToRad:U0,radToDeg:N0,isPowerOfTwo:z0,ceilPowerOfTwo:F0,floorPowerOfTwo:B0,setQuaternionFromProperEuler:O0,normalize:fe,denormalize:Jn},rt=class i{constructor(t=0,e=0){i.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){let e=this.x,n=this.y,s=t.elements;return this.x=s[0]*e+s[3]*n+s[6],this.y=s[1]*e+s[4]*n+s[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(Ve(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){let n=Math.cos(e),s=Math.sin(e),r=this.x-t.x,o=this.y-t.y;return this.x=r*n-o*s+t.x,this.y=r*s+o*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},$t=class i{constructor(t,e,n,s,r,o,a,l,c){i.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,s,r,o,a,l,c)}set(t,e,n,s,r,o,a,l,c){let h=this.elements;return h[0]=t,h[1]=s,h[2]=a,h[3]=e,h[4]=r,h[5]=l,h[6]=n,h[7]=o,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){let e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,s=e.elements,r=this.elements,o=n[0],a=n[3],l=n[6],c=n[1],h=n[4],u=n[7],d=n[2],f=n[5],m=n[8],x=s[0],g=s[3],p=s[6],M=s[1],v=s[4],y=s[7],w=s[2],S=s[5],T=s[8];return r[0]=o*x+a*M+l*w,r[3]=o*g+a*v+l*S,r[6]=o*p+a*y+l*T,r[1]=c*x+h*M+u*w,r[4]=c*g+h*v+u*S,r[7]=c*p+h*y+u*T,r[2]=d*x+f*M+m*w,r[5]=d*g+f*v+m*S,r[8]=d*p+f*y+m*T,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],o=t[4],a=t[5],l=t[6],c=t[7],h=t[8];return e*o*h-e*a*c-n*r*h+n*a*l+s*r*c-s*o*l}invert(){let t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],o=t[4],a=t[5],l=t[6],c=t[7],h=t[8],u=h*o-a*c,d=a*l-h*r,f=c*r-o*l,m=e*u+n*d+s*f;if(m===0)return this.set(0,0,0,0,0,0,0,0,0);let x=1/m;return t[0]=u*x,t[1]=(s*c-h*n)*x,t[2]=(a*n-s*o)*x,t[3]=d*x,t[4]=(h*e-s*l)*x,t[5]=(s*r-a*e)*x,t[6]=f*x,t[7]=(n*l-c*e)*x,t[8]=(o*e-n*r)*x,this}transpose(){let t,e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){let e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,s,r,o,a){let l=Math.cos(r),c=Math.sin(r);return this.set(n*l,n*c,-n*(l*o+c*a)+o+t,-s*c,s*l,-s*(-c*o+l*a)+a+e,0,0,1),this}scale(t,e){return this.premultiply(tc.makeScale(t,e)),this}rotate(t){return this.premultiply(tc.makeRotation(-t)),this}translate(t,e){return this.premultiply(tc.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){let e=this.elements,n=t.elements;for(let s=0;s<9;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}},tc=new $t;function Kf(i){for(let t=i.length-1;t>=0;--t)if(i[t]>=65535)return!0;return!1}function za(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function H0(){let i=za("canvas");return i.style.display="block",i}var Ad={};function io(i){i in Ad||(Ad[i]=!0,console.warn(i))}function V0(i,t,e){return new Promise(function(n,s){function r(){switch(i.clientWaitSync(t,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:s();break;case i.TIMEOUT_EXPIRED:setTimeout(r,e);break;default:n()}}setTimeout(r,e)})}function G0(i){let t=i.elements;t[2]=.5*t[2]+.5*t[3],t[6]=.5*t[6]+.5*t[7],t[10]=.5*t[10]+.5*t[11],t[14]=.5*t[14]+.5*t[15]}function W0(i){let t=i.elements;t[11]===-1?(t[10]=-t[10]-1,t[14]=-t[14]):(t[10]=-t[10],t[14]=-t[14]+1)}var re={enabled:!0,workingColorSpace:Rr,spaces:{},convert:function(i,t,e){return this.enabled===!1||t===e||!t||!e||(this.spaces[t].transfer===pe&&(i.r=Ci(i.r),i.g=Ci(i.g),i.b=Ci(i.b)),this.spaces[t].primaries!==this.spaces[e].primaries&&(i.applyMatrix3(this.spaces[t].toXYZ),i.applyMatrix3(this.spaces[e].fromXYZ)),this.spaces[e].transfer===pe&&(i.r=mr(i.r),i.g=mr(i.g),i.b=mr(i.b))),i},fromWorkingColorSpace:function(i,t){return this.convert(i,this.workingColorSpace,t)},toWorkingColorSpace:function(i,t){return this.convert(i,t,this.workingColorSpace)},getPrimaries:function(i){return this.spaces[i].primaries},getTransfer:function(i){return i===Zi?dl:this.spaces[i].transfer},getLuminanceCoefficients:function(i,t=this.workingColorSpace){return i.fromArray(this.spaces[t].luminanceCoefficients)},define:function(i){Object.assign(this.spaces,i)},_getMatrix:function(i,t,e){return i.copy(this.spaces[t].toXYZ).multiply(this.spaces[e].fromXYZ)},_getDrawingBufferColorSpace:function(i){return this.spaces[i].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(i=this.workingColorSpace){return this.spaces[i].workingColorSpaceConfig.unpackColorSpace}};function Ci(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function mr(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}var Rd=[.64,.33,.3,.6,.15,.06],Cd=[.2126,.7152,.0722],Pd=[.3127,.329],Id=new $t().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Ld=new $t().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);re.define({[Rr]:{primaries:Rd,whitePoint:Pd,transfer:dl,toXYZ:Id,fromXYZ:Ld,luminanceCoefficients:Cd,workingColorSpaceConfig:{unpackColorSpace:me},outputColorSpaceConfig:{drawingBufferColorSpace:me}},[me]:{primaries:Rd,whitePoint:Pd,transfer:pe,toXYZ:Id,fromXYZ:Ld,luminanceCoefficients:Cd,outputColorSpaceConfig:{drawingBufferColorSpace:me}}});var Xs,yh=class{static getDataURL(t){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let e;if(t instanceof HTMLCanvasElement)e=t;else{Xs===void 0&&(Xs=za("canvas")),Xs.width=t.width,Xs.height=t.height;let n=Xs.getContext("2d");t instanceof ImageData?n.putImageData(t,0,0):n.drawImage(t,0,0,t.width,t.height),e=Xs}return e.width>2048||e.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",t),e.toDataURL("image/jpeg",.6)):e.toDataURL("image/png")}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){let e=za("canvas");e.width=t.width,e.height=t.height;let n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);let s=n.getImageData(0,0,t.width,t.height),r=s.data;for(let o=0;o<r.length;o++)r[o]=Ci(r[o]/255)*255;return n.putImageData(s,0,0),e}else if(t.data){let e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(Ci(e[n]/255)*255):e[n]=Ci(e[n]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}},$0=0,Fa=class{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:$0++}),this.uuid=ci(),this.data=t,this.dataReady=!0,this.version=0}set needsUpdate(t){t===!0&&this.version++}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];let n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let o=0,a=s.length;o<a;o++)s[o].isDataTexture?r.push(ec(s[o].image)):r.push(ec(s[o]))}else r=ec(s);n.url=r}return e||(t.images[this.uuid]=n),n}};function ec(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?yh.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var q0=0,mn=class i extends Qi{constructor(t=i.DEFAULT_IMAGE,e=i.DEFAULT_MAPPING,n=_s,s=_s,r=Vn,o=Ai,a=jn,l=Pi,c=i.DEFAULT_ANISOTROPY,h=Zi){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:q0++}),this.uuid=ci(),this.name="",this.source=new Fa(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=r,this.minFilter=o,this.anisotropy=c,this.format=a,this.internalFormat=null,this.type=l,this.offset=new rt(0,0),this.repeat=new rt(1,1),this.center=new rt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new $t,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.pmremVersion=0}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];let n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==Ff)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case Ms:t.x=t.x-Math.floor(t.x);break;case _s:t.x=t.x<0?0:1;break;case Gc:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case Ms:t.y=t.y-Math.floor(t.y);break;case _s:t.y=t.y<0?0:1;break;case Gc:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}};mn.DEFAULT_IMAGE=null;mn.DEFAULT_MAPPING=Ff;mn.DEFAULT_ANISOTROPY=1;var Me=class i{constructor(t=0,e=0,n=0,s=1){i.prototype.isVector4=!0,this.x=t,this.y=e,this.z=n,this.w=s}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,s){return this.x=t,this.y=e,this.z=n,this.w=s,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){let e=this.x,n=this.y,s=this.z,r=this.w,o=t.elements;return this.x=o[0]*e+o[4]*n+o[8]*s+o[12]*r,this.y=o[1]*e+o[5]*n+o[9]*s+o[13]*r,this.z=o[2]*e+o[6]*n+o[10]*s+o[14]*r,this.w=o[3]*e+o[7]*n+o[11]*s+o[15]*r,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);let e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,s,r,l=t.elements,c=l[0],h=l[4],u=l[8],d=l[1],f=l[5],m=l[9],x=l[2],g=l[6],p=l[10];if(Math.abs(h-d)<.01&&Math.abs(u-x)<.01&&Math.abs(m-g)<.01){if(Math.abs(h+d)<.1&&Math.abs(u+x)<.1&&Math.abs(m+g)<.1&&Math.abs(c+f+p-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;let v=(c+1)/2,y=(f+1)/2,w=(p+1)/2,S=(h+d)/4,T=(u+x)/4,R=(m+g)/4;return v>y&&v>w?v<.01?(n=0,s=.707106781,r=.707106781):(n=Math.sqrt(v),s=S/n,r=T/n):y>w?y<.01?(n=.707106781,s=0,r=.707106781):(s=Math.sqrt(y),n=S/s,r=R/s):w<.01?(n=.707106781,s=.707106781,r=0):(r=Math.sqrt(w),n=T/r,s=R/r),this.set(n,s,r,e),this}let M=Math.sqrt((g-m)*(g-m)+(u-x)*(u-x)+(d-h)*(d-h));return Math.abs(M)<.001&&(M=1),this.x=(g-m)/M,this.y=(u-x)/M,this.z=(d-h)/M,this.w=Math.acos((c+f+p-1)/2),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this.w=e[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this.w=Math.max(t.w,Math.min(e.w,this.w)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this.w=Math.max(t,Math.min(e,this.w)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},vh=class extends Qi{constructor(t=1,e=1,n={}){super(),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=1,this.scissor=new Me(0,0,t,e),this.scissorTest=!1,this.viewport=new Me(0,0,t,e);let s={width:t,height:e,depth:1};n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Vn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1},n);let r=new mn(s,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace);r.flipY=!1,r.generateMipmaps=n.generateMipmaps,r.internalFormat=n.internalFormat,this.textures=[];let o=n.count;for(let a=0;a<o;a++)this.textures[a]=r.clone(),this.textures[a].isRenderTargetTexture=!0;this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.depthTexture=n.depthTexture,this.samples=n.samples}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}setSize(t,e,n=1){if(this.width!==t||this.height!==e||this.depth!==n){this.width=t,this.height=e,this.depth=n;for(let s=0,r=this.textures.length;s<r;s++)this.textures[s].image.width=t,this.textures[s].image.height=e,this.textures[s].image.depth=n;this.dispose()}this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let n=0,s=t.textures.length;n<s;n++)this.textures[n]=t.textures[n].clone(),this.textures[n].isRenderTargetTexture=!0;let e=Object.assign({},t.texture.image);return this.texture.source=new Fa(e),this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},Qn=class extends vh{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}},Ba=class extends mn{constructor(t=null,e=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=In,this.minFilter=In,this.wrapR=_s,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}};var bh=class extends mn{constructor(t=null,e=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=In,this.minFilter=In,this.wrapR=_s,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var Re=class{constructor(t=0,e=0,n=0,s=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=s}static slerpFlat(t,e,n,s,r,o,a){let l=n[s+0],c=n[s+1],h=n[s+2],u=n[s+3],d=r[o+0],f=r[o+1],m=r[o+2],x=r[o+3];if(a===0){t[e+0]=l,t[e+1]=c,t[e+2]=h,t[e+3]=u;return}if(a===1){t[e+0]=d,t[e+1]=f,t[e+2]=m,t[e+3]=x;return}if(u!==x||l!==d||c!==f||h!==m){let g=1-a,p=l*d+c*f+h*m+u*x,M=p>=0?1:-1,v=1-p*p;if(v>Number.EPSILON){let w=Math.sqrt(v),S=Math.atan2(w,p*M);g=Math.sin(g*S)/w,a=Math.sin(a*S)/w}let y=a*M;if(l=l*g+d*y,c=c*g+f*y,h=h*g+m*y,u=u*g+x*y,g===1-a){let w=1/Math.sqrt(l*l+c*c+h*h+u*u);l*=w,c*=w,h*=w,u*=w}}t[e]=l,t[e+1]=c,t[e+2]=h,t[e+3]=u}static multiplyQuaternionsFlat(t,e,n,s,r,o){let a=n[s],l=n[s+1],c=n[s+2],h=n[s+3],u=r[o],d=r[o+1],f=r[o+2],m=r[o+3];return t[e]=a*m+h*u+l*f-c*d,t[e+1]=l*m+h*d+c*u-a*f,t[e+2]=c*m+h*f+a*d-l*u,t[e+3]=h*m-a*u-l*d-c*f,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,s){return this._x=t,this._y=e,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){let n=t._x,s=t._y,r=t._z,o=t._order,a=Math.cos,l=Math.sin,c=a(n/2),h=a(s/2),u=a(r/2),d=l(n/2),f=l(s/2),m=l(r/2);switch(o){case"XYZ":this._x=d*h*u+c*f*m,this._y=c*f*u-d*h*m,this._z=c*h*m+d*f*u,this._w=c*h*u-d*f*m;break;case"YXZ":this._x=d*h*u+c*f*m,this._y=c*f*u-d*h*m,this._z=c*h*m-d*f*u,this._w=c*h*u+d*f*m;break;case"ZXY":this._x=d*h*u-c*f*m,this._y=c*f*u+d*h*m,this._z=c*h*m+d*f*u,this._w=c*h*u-d*f*m;break;case"ZYX":this._x=d*h*u-c*f*m,this._y=c*f*u+d*h*m,this._z=c*h*m-d*f*u,this._w=c*h*u+d*f*m;break;case"YZX":this._x=d*h*u+c*f*m,this._y=c*f*u+d*h*m,this._z=c*h*m-d*f*u,this._w=c*h*u-d*f*m;break;case"XZY":this._x=d*h*u-c*f*m,this._y=c*f*u-d*h*m,this._z=c*h*m+d*f*u,this._w=c*h*u+d*f*m;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+o)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){let n=e/2,s=Math.sin(n);return this._x=t.x*s,this._y=t.y*s,this._z=t.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){let e=t.elements,n=e[0],s=e[4],r=e[8],o=e[1],a=e[5],l=e[9],c=e[2],h=e[6],u=e[10],d=n+a+u;if(d>0){let f=.5/Math.sqrt(d+1);this._w=.25/f,this._x=(h-l)*f,this._y=(r-c)*f,this._z=(o-s)*f}else if(n>a&&n>u){let f=2*Math.sqrt(1+n-a-u);this._w=(h-l)/f,this._x=.25*f,this._y=(s+o)/f,this._z=(r+c)/f}else if(a>u){let f=2*Math.sqrt(1+a-n-u);this._w=(r-c)/f,this._x=(s+o)/f,this._y=.25*f,this._z=(l+h)/f}else{let f=2*Math.sqrt(1+u-n-a);this._w=(o-s)/f,this._x=(r+c)/f,this._y=(l+h)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<Number.EPSILON?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(Ve(this.dot(t),-1,1)))}rotateTowards(t,e){let n=this.angleTo(t);if(n===0)return this;let s=Math.min(1,e/n);return this.slerp(t,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){let n=t._x,s=t._y,r=t._z,o=t._w,a=e._x,l=e._y,c=e._z,h=e._w;return this._x=n*h+o*a+s*c-r*l,this._y=s*h+o*l+r*a-n*c,this._z=r*h+o*c+n*l-s*a,this._w=o*h-n*a-s*l-r*c,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);let n=this._x,s=this._y,r=this._z,o=this._w,a=o*t._w+n*t._x+s*t._y+r*t._z;if(a<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,a=-a):this.copy(t),a>=1)return this._w=o,this._x=n,this._y=s,this._z=r,this;let l=1-a*a;if(l<=Number.EPSILON){let f=1-e;return this._w=f*o+e*this._w,this._x=f*n+e*this._x,this._y=f*s+e*this._y,this._z=f*r+e*this._z,this.normalize(),this}let c=Math.sqrt(l),h=Math.atan2(c,a),u=Math.sin((1-e)*h)/c,d=Math.sin(e*h)/c;return this._w=o*u+this._w*d,this._x=n*u+this._x*d,this._y=s*u+this._y*d,this._z=r*u+this._z*d,this._onChangeCallback(),this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){let t=2*Math.PI*Math.random(),e=2*Math.PI*Math.random(),n=Math.random(),s=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(s*Math.sin(t),s*Math.cos(t),r*Math.sin(e),r*Math.cos(e))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},P=class i{constructor(t=0,e=0,n=0){i.prototype.isVector3=!0,this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(kd.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(kd.setFromAxisAngle(t,e))}applyMatrix3(t){let e=this.x,n=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[3]*n+r[6]*s,this.y=r[1]*e+r[4]*n+r[7]*s,this.z=r[2]*e+r[5]*n+r[8]*s,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){let e=this.x,n=this.y,s=this.z,r=t.elements,o=1/(r[3]*e+r[7]*n+r[11]*s+r[15]);return this.x=(r[0]*e+r[4]*n+r[8]*s+r[12])*o,this.y=(r[1]*e+r[5]*n+r[9]*s+r[13])*o,this.z=(r[2]*e+r[6]*n+r[10]*s+r[14])*o,this}applyQuaternion(t){let e=this.x,n=this.y,s=this.z,r=t.x,o=t.y,a=t.z,l=t.w,c=2*(o*s-a*n),h=2*(a*e-r*s),u=2*(r*n-o*e);return this.x=e+l*c+o*u-a*h,this.y=n+l*h+a*c-r*u,this.z=s+l*u+r*h-o*c,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){let e=this.x,n=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[4]*n+r[8]*s,this.y=r[1]*e+r[5]*n+r[9]*s,this.z=r[2]*e+r[6]*n+r[10]*s,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){let n=t.x,s=t.y,r=t.z,o=e.x,a=e.y,l=e.z;return this.x=s*l-r*a,this.y=r*o-n*l,this.z=n*a-s*o,this}projectOnVector(t){let e=t.lengthSq();if(e===0)return this.set(0,0,0);let n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return nc.copy(this).projectOnVector(t),this.sub(nc)}reflect(t){return this.sub(nc.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(Ve(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y,s=this.z-t.z;return e*e+n*n+s*s}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){let s=Math.sin(e)*t;return this.x=s*Math.sin(n),this.y=Math.cos(e)*t,this.z=s*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){let e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),s=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=s,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let t=Math.random()*Math.PI*2,e=Math.random()*2-1,n=Math.sqrt(1-e*e);return this.x=n*Math.cos(t),this.y=e,this.z=n*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},nc=new P,kd=new Re,Ii=class{constructor(t=new P(1/0,1/0,1/0),e=new P(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(Yn.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(Yn.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){let n=Yn.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);let n=t.geometry;if(n!==void 0){let r=n.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let o=0,a=r.count;o<a;o++)t.isMesh===!0?t.getVertexPosition(o,Yn):Yn.fromBufferAttribute(r,o),Yn.applyMatrix4(t.matrixWorld),this.expandByPoint(Yn);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),ta.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),ta.copy(n.boundingBox)),ta.applyMatrix4(t.matrixWorld),this.union(ta)}let s=t.children;for(let r=0,o=s.length;r<o;r++)this.expandByObject(s[r],e);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,Yn),Yn.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(Xr),ea.subVectors(this.max,Xr),Ys.subVectors(t.a,Xr),Zs.subVectors(t.b,Xr),Ks.subVectors(t.c,Xr),Gi.subVectors(Zs,Ys),Wi.subVectors(Ks,Zs),ds.subVectors(Ys,Ks);let e=[0,-Gi.z,Gi.y,0,-Wi.z,Wi.y,0,-ds.z,ds.y,Gi.z,0,-Gi.x,Wi.z,0,-Wi.x,ds.z,0,-ds.x,-Gi.y,Gi.x,0,-Wi.y,Wi.x,0,-ds.y,ds.x,0];return!ic(e,Ys,Zs,Ks,ea)||(e=[1,0,0,0,1,0,0,0,1],!ic(e,Ys,Zs,Ks,ea))?!1:(na.crossVectors(Gi,Wi),e=[na.x,na.y,na.z],ic(e,Ys,Zs,Ks,ea))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,Yn).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(Yn).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(_i[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),_i[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),_i[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),_i[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),_i[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),_i[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),_i[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),_i[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(_i),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}},_i=[new P,new P,new P,new P,new P,new P,new P,new P],Yn=new P,ta=new Ii,Ys=new P,Zs=new P,Ks=new P,Gi=new P,Wi=new P,ds=new P,Xr=new P,ea=new P,na=new P,fs=new P;function ic(i,t,e,n,s){for(let r=0,o=i.length-3;r<=o;r+=3){fs.fromArray(i,r);let a=s.x*Math.abs(fs.x)+s.y*Math.abs(fs.y)+s.z*Math.abs(fs.z),l=t.dot(fs),c=e.dot(fs),h=n.dot(fs);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>a)return!1}return!0}var X0=new Ii,Yr=new P,sc=new P,ts=class{constructor(t=new P,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){let n=this.center;e!==void 0?n.copy(e):X0.setFromPoints(t).getCenter(n);let s=0;for(let r=0,o=t.length;r<o;r++)s=Math.max(s,n.distanceToSquared(t[r]));return this.radius=Math.sqrt(s),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){let e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){let n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;Yr.subVectors(t,this.center);let e=Yr.lengthSq();if(e>this.radius*this.radius){let n=Math.sqrt(e),s=(n-this.radius)*.5;this.center.addScaledVector(Yr,s/n),this.radius+=s}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(sc.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(Yr.copy(t.center).add(sc)),this.expandByPoint(Yr.copy(t.center).sub(sc))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}},Mi=new P,rc=new P,ia=new P,$i=new P,oc=new P,sa=new P,ac=new P,po=class{constructor(t=new P,e=new P(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,Mi)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);let n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){let e=Mi.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(Mi.copy(this.origin).addScaledVector(this.direction,e),Mi.distanceToSquared(t))}distanceSqToSegment(t,e,n,s){rc.copy(t).add(e).multiplyScalar(.5),ia.copy(e).sub(t).normalize(),$i.copy(this.origin).sub(rc);let r=t.distanceTo(e)*.5,o=-this.direction.dot(ia),a=$i.dot(this.direction),l=-$i.dot(ia),c=$i.lengthSq(),h=Math.abs(1-o*o),u,d,f,m;if(h>0)if(u=o*l-a,d=o*a-l,m=r*h,u>=0)if(d>=-m)if(d<=m){let x=1/h;u*=x,d*=x,f=u*(u+o*d+2*a)+d*(o*u+d+2*l)+c}else d=r,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;else d=-r,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;else d<=-m?(u=Math.max(0,-(-o*r+a)),d=u>0?-r:Math.min(Math.max(-r,-l),r),f=-u*u+d*(d+2*l)+c):d<=m?(u=0,d=Math.min(Math.max(-r,-l),r),f=d*(d+2*l)+c):(u=Math.max(0,-(o*r+a)),d=u>0?r:Math.min(Math.max(-r,-l),r),f=-u*u+d*(d+2*l)+c);else d=o>0?-r:r,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),s&&s.copy(rc).addScaledVector(ia,d),f}intersectSphere(t,e){Mi.subVectors(t.center,this.origin);let n=Mi.dot(this.direction),s=Mi.dot(Mi)-n*n,r=t.radius*t.radius;if(s>r)return null;let o=Math.sqrt(r-s),a=n-o,l=n+o;return l<0?null:a<0?this.at(l,e):this.at(a,e)}intersectsSphere(t){return this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){let e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){let n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){let e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,s,r,o,a,l,c=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(n=(t.min.x-d.x)*c,s=(t.max.x-d.x)*c):(n=(t.max.x-d.x)*c,s=(t.min.x-d.x)*c),h>=0?(r=(t.min.y-d.y)*h,o=(t.max.y-d.y)*h):(r=(t.max.y-d.y)*h,o=(t.min.y-d.y)*h),n>o||r>s||((r>n||isNaN(n))&&(n=r),(o<s||isNaN(s))&&(s=o),u>=0?(a=(t.min.z-d.z)*u,l=(t.max.z-d.z)*u):(a=(t.max.z-d.z)*u,l=(t.min.z-d.z)*u),n>l||a>s)||((a>n||n!==n)&&(n=a),(l<s||s!==s)&&(s=l),s<0)?null:this.at(n>=0?n:s,e)}intersectsBox(t){return this.intersectBox(t,Mi)!==null}intersectTriangle(t,e,n,s,r){oc.subVectors(e,t),sa.subVectors(n,t),ac.crossVectors(oc,sa);let o=this.direction.dot(ac),a;if(o>0){if(s)return null;a=1}else if(o<0)a=-1,o=-o;else return null;$i.subVectors(this.origin,t);let l=a*this.direction.dot(sa.crossVectors($i,sa));if(l<0)return null;let c=a*this.direction.dot(oc.cross($i));if(c<0||l+c>o)return null;let h=-a*$i.dot(ac);return h<0?null:this.at(h/o,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},qt=class i{constructor(t,e,n,s,r,o,a,l,c,h,u,d,f,m,x,g){i.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,s,r,o,a,l,c,h,u,d,f,m,x,g)}set(t,e,n,s,r,o,a,l,c,h,u,d,f,m,x,g){let p=this.elements;return p[0]=t,p[4]=e,p[8]=n,p[12]=s,p[1]=r,p[5]=o,p[9]=a,p[13]=l,p[2]=c,p[6]=h,p[10]=u,p[14]=d,p[3]=f,p[7]=m,p[11]=x,p[15]=g,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new i().fromArray(this.elements)}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){let e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){let e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){let e=this.elements,n=t.elements,s=1/Js.setFromMatrixColumn(t,0).length(),r=1/Js.setFromMatrixColumn(t,1).length(),o=1/Js.setFromMatrixColumn(t,2).length();return e[0]=n[0]*s,e[1]=n[1]*s,e[2]=n[2]*s,e[3]=0,e[4]=n[4]*r,e[5]=n[5]*r,e[6]=n[6]*r,e[7]=0,e[8]=n[8]*o,e[9]=n[9]*o,e[10]=n[10]*o,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){let e=this.elements,n=t.x,s=t.y,r=t.z,o=Math.cos(n),a=Math.sin(n),l=Math.cos(s),c=Math.sin(s),h=Math.cos(r),u=Math.sin(r);if(t.order==="XYZ"){let d=o*h,f=o*u,m=a*h,x=a*u;e[0]=l*h,e[4]=-l*u,e[8]=c,e[1]=f+m*c,e[5]=d-x*c,e[9]=-a*l,e[2]=x-d*c,e[6]=m+f*c,e[10]=o*l}else if(t.order==="YXZ"){let d=l*h,f=l*u,m=c*h,x=c*u;e[0]=d+x*a,e[4]=m*a-f,e[8]=o*c,e[1]=o*u,e[5]=o*h,e[9]=-a,e[2]=f*a-m,e[6]=x+d*a,e[10]=o*l}else if(t.order==="ZXY"){let d=l*h,f=l*u,m=c*h,x=c*u;e[0]=d-x*a,e[4]=-o*u,e[8]=m+f*a,e[1]=f+m*a,e[5]=o*h,e[9]=x-d*a,e[2]=-o*c,e[6]=a,e[10]=o*l}else if(t.order==="ZYX"){let d=o*h,f=o*u,m=a*h,x=a*u;e[0]=l*h,e[4]=m*c-f,e[8]=d*c+x,e[1]=l*u,e[5]=x*c+d,e[9]=f*c-m,e[2]=-c,e[6]=a*l,e[10]=o*l}else if(t.order==="YZX"){let d=o*l,f=o*c,m=a*l,x=a*c;e[0]=l*h,e[4]=x-d*u,e[8]=m*u+f,e[1]=u,e[5]=o*h,e[9]=-a*h,e[2]=-c*h,e[6]=f*u+m,e[10]=d-x*u}else if(t.order==="XZY"){let d=o*l,f=o*c,m=a*l,x=a*c;e[0]=l*h,e[4]=-u,e[8]=c*h,e[1]=d*u+x,e[5]=o*h,e[9]=f*u-m,e[2]=m*u-f,e[6]=a*h,e[10]=x*u+d}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(Y0,t,Z0)}lookAt(t,e,n){let s=this.elements;return Rn.subVectors(t,e),Rn.lengthSq()===0&&(Rn.z=1),Rn.normalize(),qi.crossVectors(n,Rn),qi.lengthSq()===0&&(Math.abs(n.z)===1?Rn.x+=1e-4:Rn.z+=1e-4,Rn.normalize(),qi.crossVectors(n,Rn)),qi.normalize(),ra.crossVectors(Rn,qi),s[0]=qi.x,s[4]=ra.x,s[8]=Rn.x,s[1]=qi.y,s[5]=ra.y,s[9]=Rn.y,s[2]=qi.z,s[6]=ra.z,s[10]=Rn.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,s=e.elements,r=this.elements,o=n[0],a=n[4],l=n[8],c=n[12],h=n[1],u=n[5],d=n[9],f=n[13],m=n[2],x=n[6],g=n[10],p=n[14],M=n[3],v=n[7],y=n[11],w=n[15],S=s[0],T=s[4],R=s[8],_=s[12],b=s[1],C=s[5],L=s[9],k=s[13],D=s[2],V=s[6],z=s[10],G=s[14],F=s[3],K=s[7],Q=s[11],ot=s[15];return r[0]=o*S+a*b+l*D+c*F,r[4]=o*T+a*C+l*V+c*K,r[8]=o*R+a*L+l*z+c*Q,r[12]=o*_+a*k+l*G+c*ot,r[1]=h*S+u*b+d*D+f*F,r[5]=h*T+u*C+d*V+f*K,r[9]=h*R+u*L+d*z+f*Q,r[13]=h*_+u*k+d*G+f*ot,r[2]=m*S+x*b+g*D+p*F,r[6]=m*T+x*C+g*V+p*K,r[10]=m*R+x*L+g*z+p*Q,r[14]=m*_+x*k+g*G+p*ot,r[3]=M*S+v*b+y*D+w*F,r[7]=M*T+v*C+y*V+w*K,r[11]=M*R+v*L+y*z+w*Q,r[15]=M*_+v*k+y*G+w*ot,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[4],s=t[8],r=t[12],o=t[1],a=t[5],l=t[9],c=t[13],h=t[2],u=t[6],d=t[10],f=t[14],m=t[3],x=t[7],g=t[11],p=t[15];return m*(+r*l*u-s*c*u-r*a*d+n*c*d+s*a*f-n*l*f)+x*(+e*l*f-e*c*d+r*o*d-s*o*f+s*c*h-r*l*h)+g*(+e*c*u-e*a*f-r*o*u+n*o*f+r*a*h-n*c*h)+p*(-s*a*h-e*l*u+e*a*d+s*o*u-n*o*d+n*l*h)}transpose(){let t=this.elements,e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){let s=this.elements;return t.isVector3?(s[12]=t.x,s[13]=t.y,s[14]=t.z):(s[12]=t,s[13]=e,s[14]=n),this}invert(){let t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],o=t[4],a=t[5],l=t[6],c=t[7],h=t[8],u=t[9],d=t[10],f=t[11],m=t[12],x=t[13],g=t[14],p=t[15],M=u*g*c-x*d*c+x*l*f-a*g*f-u*l*p+a*d*p,v=m*d*c-h*g*c-m*l*f+o*g*f+h*l*p-o*d*p,y=h*x*c-m*u*c+m*a*f-o*x*f-h*a*p+o*u*p,w=m*u*l-h*x*l-m*a*d+o*x*d+h*a*g-o*u*g,S=e*M+n*v+s*y+r*w;if(S===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let T=1/S;return t[0]=M*T,t[1]=(x*d*r-u*g*r-x*s*f+n*g*f+u*s*p-n*d*p)*T,t[2]=(a*g*r-x*l*r+x*s*c-n*g*c-a*s*p+n*l*p)*T,t[3]=(u*l*r-a*d*r-u*s*c+n*d*c+a*s*f-n*l*f)*T,t[4]=v*T,t[5]=(h*g*r-m*d*r+m*s*f-e*g*f-h*s*p+e*d*p)*T,t[6]=(m*l*r-o*g*r-m*s*c+e*g*c+o*s*p-e*l*p)*T,t[7]=(o*d*r-h*l*r+h*s*c-e*d*c-o*s*f+e*l*f)*T,t[8]=y*T,t[9]=(m*u*r-h*x*r-m*n*f+e*x*f+h*n*p-e*u*p)*T,t[10]=(o*x*r-m*a*r+m*n*c-e*x*c-o*n*p+e*a*p)*T,t[11]=(h*a*r-o*u*r-h*n*c+e*u*c+o*n*f-e*a*f)*T,t[12]=w*T,t[13]=(h*x*s-m*u*s+m*n*d-e*x*d-h*n*g+e*u*g)*T,t[14]=(m*a*s-o*x*s-m*n*l+e*x*l+o*n*g-e*a*g)*T,t[15]=(o*u*s-h*a*s+h*n*l-e*u*l-o*n*d+e*a*d)*T,this}scale(t){let e=this.elements,n=t.x,s=t.y,r=t.z;return e[0]*=n,e[4]*=s,e[8]*=r,e[1]*=n,e[5]*=s,e[9]*=r,e[2]*=n,e[6]*=s,e[10]*=r,e[3]*=n,e[7]*=s,e[11]*=r,this}getMaxScaleOnAxis(){let t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],s=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,s))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){let e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){let n=Math.cos(e),s=Math.sin(e),r=1-n,o=t.x,a=t.y,l=t.z,c=r*o,h=r*a;return this.set(c*o+n,c*a-s*l,c*l+s*a,0,c*a+s*l,h*a+n,h*l-s*o,0,c*l-s*a,h*l+s*o,r*l*l+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,s,r,o){return this.set(1,n,r,0,t,1,o,0,e,s,1,0,0,0,0,1),this}compose(t,e,n){let s=this.elements,r=e._x,o=e._y,a=e._z,l=e._w,c=r+r,h=o+o,u=a+a,d=r*c,f=r*h,m=r*u,x=o*h,g=o*u,p=a*u,M=l*c,v=l*h,y=l*u,w=n.x,S=n.y,T=n.z;return s[0]=(1-(x+p))*w,s[1]=(f+y)*w,s[2]=(m-v)*w,s[3]=0,s[4]=(f-y)*S,s[5]=(1-(d+p))*S,s[6]=(g+M)*S,s[7]=0,s[8]=(m+v)*T,s[9]=(g-M)*T,s[10]=(1-(d+x))*T,s[11]=0,s[12]=t.x,s[13]=t.y,s[14]=t.z,s[15]=1,this}decompose(t,e,n){let s=this.elements,r=Js.set(s[0],s[1],s[2]).length(),o=Js.set(s[4],s[5],s[6]).length(),a=Js.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),t.x=s[12],t.y=s[13],t.z=s[14],Zn.copy(this);let c=1/r,h=1/o,u=1/a;return Zn.elements[0]*=c,Zn.elements[1]*=c,Zn.elements[2]*=c,Zn.elements[4]*=h,Zn.elements[5]*=h,Zn.elements[6]*=h,Zn.elements[8]*=u,Zn.elements[9]*=u,Zn.elements[10]*=u,e.setFromRotationMatrix(Zn),n.x=r,n.y=o,n.z=a,this}makePerspective(t,e,n,s,r,o,a=Ri){let l=this.elements,c=2*r/(e-t),h=2*r/(n-s),u=(e+t)/(e-t),d=(n+s)/(n-s),f,m;if(a===Ri)f=-(o+r)/(o-r),m=-2*o*r/(o-r);else if(a===Na)f=-o/(o-r),m=-o*r/(o-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return l[0]=c,l[4]=0,l[8]=u,l[12]=0,l[1]=0,l[5]=h,l[9]=d,l[13]=0,l[2]=0,l[6]=0,l[10]=f,l[14]=m,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(t,e,n,s,r,o,a=Ri){let l=this.elements,c=1/(e-t),h=1/(n-s),u=1/(o-r),d=(e+t)*c,f=(n+s)*h,m,x;if(a===Ri)m=(o+r)*u,x=-2*u;else if(a===Na)m=r*u,x=-1*u;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return l[0]=2*c,l[4]=0,l[8]=0,l[12]=-d,l[1]=0,l[5]=2*h,l[9]=0,l[13]=-f,l[2]=0,l[6]=0,l[10]=x,l[14]=-m,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(t){let e=this.elements,n=t.elements;for(let s=0;s<16;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}},Js=new P,Zn=new qt,Y0=new P(0,0,0),Z0=new P(1,1,1),qi=new P,ra=new P,Rn=new P,Dd=new qt,Ud=new Re,gn=class i{constructor(t=0,e=0,n=0,s=i.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=s}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,s=this._order){return this._x=t,this._y=e,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){let s=t.elements,r=s[0],o=s[4],a=s[8],l=s[1],c=s[5],h=s[9],u=s[2],d=s[6],f=s[10];switch(e){case"XYZ":this._y=Math.asin(Ve(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-h,f),this._z=Math.atan2(-o,r)):(this._x=Math.atan2(d,c),this._z=0);break;case"YXZ":this._x=Math.asin(-Ve(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(a,f),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,r),this._z=0);break;case"ZXY":this._x=Math.asin(Ve(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-o,c)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-Ve(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-o,c));break;case"YZX":this._z=Math.asin(Ve(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-u,r)):(this._x=0,this._y=Math.atan2(a,f));break;case"XZY":this._z=Math.asin(-Ve(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(a,r)):(this._x=Math.atan2(-h,f),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return Dd.makeRotationFromQuaternion(t),this.setFromRotationMatrix(Dd,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return Ud.setFromEuler(this),this.setFromQuaternion(Ud,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};gn.DEFAULT_ORDER="XYZ";var mo=class{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}},K0=0,Nd=new P,js=new Re,wi=new qt,oa=new P,Zr=new P,J0=new P,j0=new Re,zd=new P(1,0,0),Fd=new P(0,1,0),Bd=new P(0,0,1),Od={type:"added"},Q0={type:"removed"},Qs={type:"childadded",child:null},lc={type:"childremoved",child:null},We=class i extends Qi{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:K0++}),this.uuid=ci(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=i.DEFAULT_UP.clone();let t=new P,e=new gn,n=new Re,s=new P(1,1,1);function r(){n.setFromEuler(e,!1)}function o(){e.setFromQuaternion(n,void 0,!1)}e._onChange(r),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new qt},normalMatrix:{value:new $t}}),this.matrix=new qt,this.matrixWorld=new qt,this.matrixAutoUpdate=i.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=i.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new mo,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return js.setFromAxisAngle(t,e),this.quaternion.multiply(js),this}rotateOnWorldAxis(t,e){return js.setFromAxisAngle(t,e),this.quaternion.premultiply(js),this}rotateX(t){return this.rotateOnAxis(zd,t)}rotateY(t){return this.rotateOnAxis(Fd,t)}rotateZ(t){return this.rotateOnAxis(Bd,t)}translateOnAxis(t,e){return Nd.copy(t).applyQuaternion(this.quaternion),this.position.add(Nd.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(zd,t)}translateY(t){return this.translateOnAxis(Fd,t)}translateZ(t){return this.translateOnAxis(Bd,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(wi.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?oa.copy(t):oa.set(t,e,n);let s=this.parent;this.updateWorldMatrix(!0,!1),Zr.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?wi.lookAt(Zr,oa,this.up):wi.lookAt(oa,Zr,this.up),this.quaternion.setFromRotationMatrix(wi),s&&(wi.extractRotation(s.matrixWorld),js.setFromRotationMatrix(wi),this.quaternion.premultiply(js.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(Od),Qs.child=t,this.dispatchEvent(Qs),Qs.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}let e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(Q0),lc.child=t,this.dispatchEvent(lc),lc.child=null),this}removeFromParent(){let t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),wi.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),wi.multiply(t.parent.matrixWorld)),t.applyMatrix4(wi),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(Od),Qs.child=t,this.dispatchEvent(Qs),Qs.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,s=this.children.length;n<s;n++){let o=this.children[n].getObjectByProperty(t,e);if(o!==void 0)return o}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);let s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Zr,t,J0),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Zr,j0,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);let e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);let e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);let e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverseVisible(t)}traverseAncestors(t){let e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);let e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].updateMatrixWorld(t)}updateWorldMatrix(t,e){let n=this.parent;if(t===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),e===!0){let s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].updateWorldMatrix(!1,!0)}}toJSON(t){let e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.visibility=this._visibility,s.active=this._active,s.bounds=this._bounds.map(a=>({boxInitialized:a.boxInitialized,boxMin:a.box.min.toArray(),boxMax:a.box.max.toArray(),sphereInitialized:a.sphereInitialized,sphereRadius:a.sphere.radius,sphereCenter:a.sphere.center.toArray()})),s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.geometryCount=this._geometryCount,s.matricesTexture=this._matricesTexture.toJSON(t),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(s.boundingSphere={center:s.boundingSphere.center.toArray(),radius:s.boundingSphere.radius}),this.boundingBox!==null&&(s.boundingBox={min:s.boundingBox.min.toArray(),max:s.boundingBox.max.toArray()}));function r(a,l){return a[l.uuid]===void 0&&(a[l.uuid]=l.toJSON(t)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(t.geometries,this.geometry);let a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){let l=a.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){let u=l[c];r(t.shapes,u)}else r(t.shapes,l)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let a=[];for(let l=0,c=this.material.length;l<c;l++)a.push(r(t.materials,this.material[l]));s.material=a}else s.material=r(t.materials,this.material);if(this.children.length>0){s.children=[];for(let a=0;a<this.children.length;a++)s.children.push(this.children[a].toJSON(t).object)}if(this.animations.length>0){s.animations=[];for(let a=0;a<this.animations.length;a++){let l=this.animations[a];s.animations.push(r(t.animations,l))}}if(e){let a=o(t.geometries),l=o(t.materials),c=o(t.textures),h=o(t.images),u=o(t.shapes),d=o(t.skeletons),f=o(t.animations),m=o(t.nodes);a.length>0&&(n.geometries=a),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),h.length>0&&(n.images=h),u.length>0&&(n.shapes=u),d.length>0&&(n.skeletons=d),f.length>0&&(n.animations=f),m.length>0&&(n.nodes=m)}return n.object=s,n;function o(a){let l=[];for(let c in a){let h=a[c];delete h.metadata,l.push(h)}return l}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){let s=t.children[n];this.add(s.clone())}return this}};We.DEFAULT_UP=new P(0,1,0);We.DEFAULT_MATRIX_AUTO_UPDATE=!0;We.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var Kn=new P,Si=new P,cc=new P,Ei=new P,tr=new P,er=new P,Hd=new P,hc=new P,uc=new P,dc=new P,fc=new Me,pc=new Me,mc=new Me,Ki=class i{constructor(t=new P,e=new P,n=new P){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,s){s.subVectors(n,e),Kn.subVectors(t,e),s.cross(Kn);let r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(t,e,n,s,r){Kn.subVectors(s,e),Si.subVectors(n,e),cc.subVectors(t,e);let o=Kn.dot(Kn),a=Kn.dot(Si),l=Kn.dot(cc),c=Si.dot(Si),h=Si.dot(cc),u=o*c-a*a;if(u===0)return r.set(0,0,0),null;let d=1/u,f=(c*l-a*h)*d,m=(o*h-a*l)*d;return r.set(1-f-m,m,f)}static containsPoint(t,e,n,s){return this.getBarycoord(t,e,n,s,Ei)===null?!1:Ei.x>=0&&Ei.y>=0&&Ei.x+Ei.y<=1}static getInterpolation(t,e,n,s,r,o,a,l){return this.getBarycoord(t,e,n,s,Ei)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,Ei.x),l.addScaledVector(o,Ei.y),l.addScaledVector(a,Ei.z),l)}static getInterpolatedAttribute(t,e,n,s,r,o){return fc.setScalar(0),pc.setScalar(0),mc.setScalar(0),fc.fromBufferAttribute(t,e),pc.fromBufferAttribute(t,n),mc.fromBufferAttribute(t,s),o.setScalar(0),o.addScaledVector(fc,r.x),o.addScaledVector(pc,r.y),o.addScaledVector(mc,r.z),o}static isFrontFacing(t,e,n,s){return Kn.subVectors(n,e),Si.subVectors(t,e),Kn.cross(Si).dot(s)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,s){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[s]),this}setFromAttributeAndIndices(t,e,n,s){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,s),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return Kn.subVectors(this.c,this.b),Si.subVectors(this.a,this.b),Kn.cross(Si).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return i.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return i.getBarycoord(t,this.a,this.b,this.c,e)}getInterpolation(t,e,n,s,r){return i.getInterpolation(t,this.a,this.b,this.c,e,n,s,r)}containsPoint(t){return i.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return i.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){let n=this.a,s=this.b,r=this.c,o,a;tr.subVectors(s,n),er.subVectors(r,n),hc.subVectors(t,n);let l=tr.dot(hc),c=er.dot(hc);if(l<=0&&c<=0)return e.copy(n);uc.subVectors(t,s);let h=tr.dot(uc),u=er.dot(uc);if(h>=0&&u<=h)return e.copy(s);let d=l*u-h*c;if(d<=0&&l>=0&&h<=0)return o=l/(l-h),e.copy(n).addScaledVector(tr,o);dc.subVectors(t,r);let f=tr.dot(dc),m=er.dot(dc);if(m>=0&&f<=m)return e.copy(r);let x=f*c-l*m;if(x<=0&&c>=0&&m<=0)return a=c/(c-m),e.copy(n).addScaledVector(er,a);let g=h*m-f*u;if(g<=0&&u-h>=0&&f-m>=0)return Hd.subVectors(r,s),a=(u-h)/(u-h+(f-m)),e.copy(s).addScaledVector(Hd,a);let p=1/(g+x+d);return o=x*p,a=d*p,e.copy(n).addScaledVector(tr,o).addScaledVector(er,a)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}},Jf={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Xi={h:0,s:0,l:0},aa={h:0,s:0,l:0};function gc(i,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?i+(t-i)*6*e:e<1/2?t:e<2/3?i+(t-i)*6*(2/3-e):i}var wt=class{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){let s=t;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=me){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,re.toWorkingColorSpace(this,e),this}setRGB(t,e,n,s=re.workingColorSpace){return this.r=t,this.g=e,this.b=n,re.toWorkingColorSpace(this,s),this}setHSL(t,e,n,s=re.workingColorSpace){if(t=du(t,1),e=Ve(e,0,1),n=Ve(n,0,1),e===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+e):n+e-n*e,o=2*n-r;this.r=gc(o,r,t+1/3),this.g=gc(o,r,t),this.b=gc(o,r,t-1/3)}return re.toWorkingColorSpace(this,s),this}setStyle(t,e=me){function n(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(t)){let r,o=s[1],a=s[2];switch(o){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(t)){let r=s[1],o=r.length;if(o===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(o===6)return this.setHex(parseInt(r,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=me){let n=Jf[t.toLowerCase()];return n!==void 0?this.setHex(n,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=Ci(t.r),this.g=Ci(t.g),this.b=Ci(t.b),this}copyLinearToSRGB(t){return this.r=mr(t.r),this.g=mr(t.g),this.b=mr(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=me){return re.fromWorkingColorSpace(tn.copy(this),t),Math.round(Ve(tn.r*255,0,255))*65536+Math.round(Ve(tn.g*255,0,255))*256+Math.round(Ve(tn.b*255,0,255))}getHexString(t=me){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=re.workingColorSpace){re.fromWorkingColorSpace(tn.copy(this),e);let n=tn.r,s=tn.g,r=tn.b,o=Math.max(n,s,r),a=Math.min(n,s,r),l,c,h=(a+o)/2;if(a===o)l=0,c=0;else{let u=o-a;switch(c=h<=.5?u/(o+a):u/(2-o-a),o){case n:l=(s-r)/u+(s<r?6:0);break;case s:l=(r-n)/u+2;break;case r:l=(n-s)/u+4;break}l/=6}return t.h=l,t.s=c,t.l=h,t}getRGB(t,e=re.workingColorSpace){return re.fromWorkingColorSpace(tn.copy(this),e),t.r=tn.r,t.g=tn.g,t.b=tn.b,t}getStyle(t=me){re.fromWorkingColorSpace(tn.copy(this),t);let e=tn.r,n=tn.g,s=tn.b;return t!==me?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(t,e,n){return this.getHSL(Xi),this.setHSL(Xi.h+t,Xi.s+e,Xi.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(Xi),t.getHSL(aa);let n=oo(Xi.h,aa.h,e),s=oo(Xi.s,aa.s,e),r=oo(Xi.l,aa.l,e);return this.setHSL(n,s,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){let e=this.r,n=this.g,s=this.b,r=t.elements;return this.r=r[0]*e+r[3]*n+r[6]*s,this.g=r[1]*e+r[4]*n+r[7]*s,this.b=r[2]*e+r[5]*n+r[8]*s,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},tn=new wt;wt.NAMES=Jf;var tg=0,Li=class extends Qi{static get type(){return"Material"}get type(){return this.constructor.type}set type(t){}constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:tg++}),this.uuid=ci(),this.name="",this.blending=fr,this.side=hi,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Lc,this.blendDst=kc,this.blendEquation=vs,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new wt(0,0,0),this.blendAlpha=0,this.depthFunc=xr,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Sd,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=qs,this.stencilZFail=qs,this.stencilZPass=qs,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(let e in t){let n=t[e];if(n===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}let s=this[e];if(s===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[e]=n}}toJSON(t){let e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});let n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==fr&&(n.blending=this.blending),this.side!==hi&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==Lc&&(n.blendSrc=this.blendSrc),this.blendDst!==kc&&(n.blendDst=this.blendDst),this.blendEquation!==vs&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==xr&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Sd&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==qs&&(n.stencilFail=this.stencilFail),this.stencilZFail!==qs&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==qs&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(r){let o=[];for(let a in r){let l=r[a];delete l.metadata,o.push(l)}return o}if(e){let r=s(t.textures),o=s(t.images);r.length>0&&(n.textures=r),o.length>0&&(n.images=o)}return n}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;let e=t.clippingPlanes,n=null;if(e!==null){let s=e.length;n=new Array(s);for(let r=0;r!==s;++r)n[r]=e[r].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}onBuild(){console.warn("Material: onBuild() has been removed.")}},ke=class extends Li{static get type(){return"MeshBasicMaterial"}constructor(t){super(),this.isMeshBasicMaterial=!0,this.color=new wt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new gn,this.combine=zf,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}};var Be=new P,la=new rt,Oe=class{constructor(t,e,n=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=xh,this.updateRanges=[],this.gpuType=li,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[t+s]=e.array[n+s];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)la.fromBufferAttribute(this,e),la.applyMatrix3(t),this.setXY(e,la.x,la.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)Be.fromBufferAttribute(this,e),Be.applyMatrix3(t),this.setXYZ(e,Be.x,Be.y,Be.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)Be.fromBufferAttribute(this,e),Be.applyMatrix4(t),this.setXYZ(e,Be.x,Be.y,Be.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)Be.fromBufferAttribute(this,e),Be.applyNormalMatrix(t),this.setXYZ(e,Be.x,Be.y,Be.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)Be.fromBufferAttribute(this,e),Be.transformDirection(t),this.setXYZ(e,Be.x,Be.y,Be.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=Jn(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=fe(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=Jn(e,this.array)),e}setX(t,e){return this.normalized&&(e=fe(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=Jn(e,this.array)),e}setY(t,e){return this.normalized&&(e=fe(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=Jn(e,this.array)),e}setZ(t,e){return this.normalized&&(e=fe(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=Jn(e,this.array)),e}setW(t,e){return this.normalized&&(e=fe(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=fe(e,this.array),n=fe(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,s){return t*=this.itemSize,this.normalized&&(e=fe(e,this.array),n=fe(n,this.array),s=fe(s,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this}setXYZW(t,e,n,s,r){return t*=this.itemSize,this.normalized&&(e=fe(e,this.array),n=fe(n,this.array),s=fe(s,this.array),r=fe(r,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==xh&&(t.usage=this.usage),t}};var Oa=class extends Oe{constructor(t,e,n){super(new Uint16Array(t),e,n)}};var Ha=class extends Oe{constructor(t,e,n){super(new Uint32Array(t),e,n)}};var Ht=class extends Oe{constructor(t,e,n){super(new Float32Array(t),e,n)}},eg=0,Hn=new qt,xc=new We,nr=new P,Cn=new Ii,Kr=new Ii,Ze=new P,ce=class i extends Qi{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:eg++}),this.uuid=ci(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(Kf(t)?Ha:Oa)(t,1):this.index=t,this}setIndirect(t){return this.indirect=t,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){let e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let r=new $t().getNormalMatrix(t);n.applyNormalMatrix(r),n.needsUpdate=!0}let s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(t),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return Hn.makeRotationFromQuaternion(t),this.applyMatrix4(Hn),this}rotateX(t){return Hn.makeRotationX(t),this.applyMatrix4(Hn),this}rotateY(t){return Hn.makeRotationY(t),this.applyMatrix4(Hn),this}rotateZ(t){return Hn.makeRotationZ(t),this.applyMatrix4(Hn),this}translate(t,e,n){return Hn.makeTranslation(t,e,n),this.applyMatrix4(Hn),this}scale(t,e,n){return Hn.makeScale(t,e,n),this.applyMatrix4(Hn),this}lookAt(t){return xc.lookAt(t),xc.updateMatrix(),this.applyMatrix4(xc.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(nr).negate(),this.translate(nr.x,nr.y,nr.z),this}setFromPoints(t){let e=this.getAttribute("position");if(e===void 0){let n=[];for(let s=0,r=t.length;s<r;s++){let o=t[s];n.push(o.x,o.y,o.z||0)}this.setAttribute("position",new Ht(n,3))}else{for(let n=0,s=e.count;n<s;n++){let r=t[n];e.setXYZ(n,r.x,r.y,r.z||0)}t.length>e.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),e.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Ii);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new P(-1/0,-1/0,-1/0),new P(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,s=e.length;n<s;n++){let r=e[n];Cn.setFromBufferAttribute(r),this.morphTargetsRelative?(Ze.addVectors(this.boundingBox.min,Cn.min),this.boundingBox.expandByPoint(Ze),Ze.addVectors(this.boundingBox.max,Cn.max),this.boundingBox.expandByPoint(Ze)):(this.boundingBox.expandByPoint(Cn.min),this.boundingBox.expandByPoint(Cn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new ts);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new P,1/0);return}if(t){let n=this.boundingSphere.center;if(Cn.setFromBufferAttribute(t),e)for(let r=0,o=e.length;r<o;r++){let a=e[r];Kr.setFromBufferAttribute(a),this.morphTargetsRelative?(Ze.addVectors(Cn.min,Kr.min),Cn.expandByPoint(Ze),Ze.addVectors(Cn.max,Kr.max),Cn.expandByPoint(Ze)):(Cn.expandByPoint(Kr.min),Cn.expandByPoint(Kr.max))}Cn.getCenter(n);let s=0;for(let r=0,o=t.count;r<o;r++)Ze.fromBufferAttribute(t,r),s=Math.max(s,n.distanceToSquared(Ze));if(e)for(let r=0,o=e.length;r<o;r++){let a=e[r],l=this.morphTargetsRelative;for(let c=0,h=a.count;c<h;c++)Ze.fromBufferAttribute(a,c),l&&(nr.fromBufferAttribute(t,c),Ze.add(nr)),s=Math.max(s,n.distanceToSquared(Ze))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let n=e.position,s=e.normal,r=e.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Oe(new Float32Array(4*n.count),4));let o=this.getAttribute("tangent"),a=[],l=[];for(let R=0;R<n.count;R++)a[R]=new P,l[R]=new P;let c=new P,h=new P,u=new P,d=new rt,f=new rt,m=new rt,x=new P,g=new P;function p(R,_,b){c.fromBufferAttribute(n,R),h.fromBufferAttribute(n,_),u.fromBufferAttribute(n,b),d.fromBufferAttribute(r,R),f.fromBufferAttribute(r,_),m.fromBufferAttribute(r,b),h.sub(c),u.sub(c),f.sub(d),m.sub(d);let C=1/(f.x*m.y-m.x*f.y);isFinite(C)&&(x.copy(h).multiplyScalar(m.y).addScaledVector(u,-f.y).multiplyScalar(C),g.copy(u).multiplyScalar(f.x).addScaledVector(h,-m.x).multiplyScalar(C),a[R].add(x),a[_].add(x),a[b].add(x),l[R].add(g),l[_].add(g),l[b].add(g))}let M=this.groups;M.length===0&&(M=[{start:0,count:t.count}]);for(let R=0,_=M.length;R<_;++R){let b=M[R],C=b.start,L=b.count;for(let k=C,D=C+L;k<D;k+=3)p(t.getX(k+0),t.getX(k+1),t.getX(k+2))}let v=new P,y=new P,w=new P,S=new P;function T(R){w.fromBufferAttribute(s,R),S.copy(w);let _=a[R];v.copy(_),v.sub(w.multiplyScalar(w.dot(_))).normalize(),y.crossVectors(S,_);let C=y.dot(l[R])<0?-1:1;o.setXYZW(R,v.x,v.y,v.z,C)}for(let R=0,_=M.length;R<_;++R){let b=M[R],C=b.start,L=b.count;for(let k=C,D=C+L;k<D;k+=3)T(t.getX(k+0)),T(t.getX(k+1)),T(t.getX(k+2))}}computeVertexNormals(){let t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new Oe(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let d=0,f=n.count;d<f;d++)n.setXYZ(d,0,0,0);let s=new P,r=new P,o=new P,a=new P,l=new P,c=new P,h=new P,u=new P;if(t)for(let d=0,f=t.count;d<f;d+=3){let m=t.getX(d+0),x=t.getX(d+1),g=t.getX(d+2);s.fromBufferAttribute(e,m),r.fromBufferAttribute(e,x),o.fromBufferAttribute(e,g),h.subVectors(o,r),u.subVectors(s,r),h.cross(u),a.fromBufferAttribute(n,m),l.fromBufferAttribute(n,x),c.fromBufferAttribute(n,g),a.add(h),l.add(h),c.add(h),n.setXYZ(m,a.x,a.y,a.z),n.setXYZ(x,l.x,l.y,l.z),n.setXYZ(g,c.x,c.y,c.z)}else for(let d=0,f=e.count;d<f;d+=3)s.fromBufferAttribute(e,d+0),r.fromBufferAttribute(e,d+1),o.fromBufferAttribute(e,d+2),h.subVectors(o,r),u.subVectors(s,r),h.cross(u),n.setXYZ(d+0,h.x,h.y,h.z),n.setXYZ(d+1,h.x,h.y,h.z),n.setXYZ(d+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)Ze.fromBufferAttribute(t,e),Ze.normalize(),t.setXYZ(e,Ze.x,Ze.y,Ze.z)}toNonIndexed(){function t(a,l){let c=a.array,h=a.itemSize,u=a.normalized,d=new c.constructor(l.length*h),f=0,m=0;for(let x=0,g=l.length;x<g;x++){a.isInterleavedBufferAttribute?f=l[x]*a.data.stride+a.offset:f=l[x]*h;for(let p=0;p<h;p++)d[m++]=c[f++]}return new Oe(d,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let e=new i,n=this.index.array,s=this.attributes;for(let a in s){let l=s[a],c=t(l,n);e.setAttribute(a,c)}let r=this.morphAttributes;for(let a in r){let l=[],c=r[a];for(let h=0,u=c.length;h<u;h++){let d=c[h],f=t(d,n);l.push(f)}e.morphAttributes[a]=l}e.morphTargetsRelative=this.morphTargetsRelative;let o=this.groups;for(let a=0,l=o.length;a<l;a++){let c=o[a];e.addGroup(c.start,c.count,c.materialIndex)}return e}toJSON(){let t={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){let l=this.parameters;for(let c in l)l[c]!==void 0&&(t[c]=l[c]);return t}t.data={attributes:{}};let e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});let n=this.attributes;for(let l in n){let c=n[l];t.data.attributes[l]=c.toJSON(t.data)}let s={},r=!1;for(let l in this.morphAttributes){let c=this.morphAttributes[l],h=[];for(let u=0,d=c.length;u<d;u++){let f=c[u];h.push(f.toJSON(t.data))}h.length>0&&(s[l]=h,r=!0)}r&&(t.data.morphAttributes=s,t.data.morphTargetsRelative=this.morphTargetsRelative);let o=this.groups;o.length>0&&(t.data.groups=JSON.parse(JSON.stringify(o)));let a=this.boundingSphere;return a!==null&&(t.data.boundingSphere={center:a.center.toArray(),radius:a.radius}),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let e={};this.name=t.name;let n=t.index;n!==null&&this.setIndex(n.clone(e));let s=t.attributes;for(let c in s){let h=s[c];this.setAttribute(c,h.clone(e))}let r=t.morphAttributes;for(let c in r){let h=[],u=r[c];for(let d=0,f=u.length;d<f;d++)h.push(u[d].clone(e));this.morphAttributes[c]=h}this.morphTargetsRelative=t.morphTargetsRelative;let o=t.groups;for(let c=0,h=o.length;c<h;c++){let u=o[c];this.addGroup(u.start,u.count,u.materialIndex)}let a=t.boundingBox;a!==null&&(this.boundingBox=a.clone());let l=t.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},Vd=new qt,ps=new po,ca=new ts,Gd=new P,ha=new P,ua=new P,da=new P,yc=new P,fa=new P,Wd=new P,pa=new P,nt=class extends We{constructor(t=new ce,e=new ke){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}getVertexPosition(t,e){let n=this.geometry,s=n.attributes.position,r=n.morphAttributes.position,o=n.morphTargetsRelative;e.fromBufferAttribute(s,t);let a=this.morphTargetInfluences;if(r&&a){fa.set(0,0,0);for(let l=0,c=r.length;l<c;l++){let h=a[l],u=r[l];h!==0&&(yc.fromBufferAttribute(u,t),o?fa.addScaledVector(yc,h):fa.addScaledVector(yc.sub(e),h))}e.add(fa)}return e}raycast(t,e){let n=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),ca.copy(n.boundingSphere),ca.applyMatrix4(r),ps.copy(t.ray).recast(t.near),!(ca.containsPoint(ps.origin)===!1&&(ps.intersectSphere(ca,Gd)===null||ps.origin.distanceToSquared(Gd)>(t.far-t.near)**2))&&(Vd.copy(r).invert(),ps.copy(t.ray).applyMatrix4(Vd),!(n.boundingBox!==null&&ps.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,ps)))}_computeIntersections(t,e,n){let s,r=this.geometry,o=this.material,a=r.index,l=r.attributes.position,c=r.attributes.uv,h=r.attributes.uv1,u=r.attributes.normal,d=r.groups,f=r.drawRange;if(a!==null)if(Array.isArray(o))for(let m=0,x=d.length;m<x;m++){let g=d[m],p=o[g.materialIndex],M=Math.max(g.start,f.start),v=Math.min(a.count,Math.min(g.start+g.count,f.start+f.count));for(let y=M,w=v;y<w;y+=3){let S=a.getX(y),T=a.getX(y+1),R=a.getX(y+2);s=ma(this,p,t,n,c,h,u,S,T,R),s&&(s.faceIndex=Math.floor(y/3),s.face.materialIndex=g.materialIndex,e.push(s))}}else{let m=Math.max(0,f.start),x=Math.min(a.count,f.start+f.count);for(let g=m,p=x;g<p;g+=3){let M=a.getX(g),v=a.getX(g+1),y=a.getX(g+2);s=ma(this,o,t,n,c,h,u,M,v,y),s&&(s.faceIndex=Math.floor(g/3),e.push(s))}}else if(l!==void 0)if(Array.isArray(o))for(let m=0,x=d.length;m<x;m++){let g=d[m],p=o[g.materialIndex],M=Math.max(g.start,f.start),v=Math.min(l.count,Math.min(g.start+g.count,f.start+f.count));for(let y=M,w=v;y<w;y+=3){let S=y,T=y+1,R=y+2;s=ma(this,p,t,n,c,h,u,S,T,R),s&&(s.faceIndex=Math.floor(y/3),s.face.materialIndex=g.materialIndex,e.push(s))}}else{let m=Math.max(0,f.start),x=Math.min(l.count,f.start+f.count);for(let g=m,p=x;g<p;g+=3){let M=g,v=g+1,y=g+2;s=ma(this,o,t,n,c,h,u,M,v,y),s&&(s.faceIndex=Math.floor(g/3),e.push(s))}}}};function ng(i,t,e,n,s,r,o,a){let l;if(t.side===en?l=n.intersectTriangle(o,r,s,!0,a):l=n.intersectTriangle(s,r,o,t.side===hi,a),l===null)return null;pa.copy(a),pa.applyMatrix4(i.matrixWorld);let c=e.ray.origin.distanceTo(pa);return c<e.near||c>e.far?null:{distance:c,point:pa.clone(),object:i}}function ma(i,t,e,n,s,r,o,a,l,c){i.getVertexPosition(a,ha),i.getVertexPosition(l,ua),i.getVertexPosition(c,da);let h=ng(i,t,e,n,ha,ua,da,Wd);if(h){let u=new P;Ki.getBarycoord(Wd,ha,ua,da,u),s&&(h.uv=Ki.getInterpolatedAttribute(s,a,l,c,u,new rt)),r&&(h.uv1=Ki.getInterpolatedAttribute(r,a,l,c,u,new rt)),o&&(h.normal=Ki.getInterpolatedAttribute(o,a,l,c,u,new P),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));let d={a,b:l,c,normal:new P,materialIndex:0};Ki.getNormal(ha,ua,da,d.normal),h.face=d,h.barycoord=u}return h}var Xt=class i extends ce{constructor(t=1,e=1,n=1,s=1,r=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:s,heightSegments:r,depthSegments:o};let a=this;s=Math.floor(s),r=Math.floor(r),o=Math.floor(o);let l=[],c=[],h=[],u=[],d=0,f=0;m("z","y","x",-1,-1,n,e,t,o,r,0),m("z","y","x",1,-1,n,e,-t,o,r,1),m("x","z","y",1,1,t,n,e,s,o,2),m("x","z","y",1,-1,t,n,-e,s,o,3),m("x","y","z",1,-1,t,e,n,s,r,4),m("x","y","z",-1,-1,t,e,-n,s,r,5),this.setIndex(l),this.setAttribute("position",new Ht(c,3)),this.setAttribute("normal",new Ht(h,3)),this.setAttribute("uv",new Ht(u,2));function m(x,g,p,M,v,y,w,S,T,R,_){let b=y/T,C=w/R,L=y/2,k=w/2,D=S/2,V=T+1,z=R+1,G=0,F=0,K=new P;for(let Q=0;Q<z;Q++){let ot=Q*C-k;for(let St=0;St<V;St++){let Vt=St*b-L;K[x]=Vt*M,K[g]=ot*v,K[p]=D,c.push(K.x,K.y,K.z),K[x]=0,K[g]=0,K[p]=S>0?1:-1,h.push(K.x,K.y,K.z),u.push(St/T),u.push(1-Q/R),G+=1}}for(let Q=0;Q<R;Q++)for(let ot=0;ot<T;ot++){let St=d+ot+V*Q,Vt=d+ot+V*(Q+1),Y=d+(ot+1)+V*(Q+1),et=d+(ot+1)+V*Q;l.push(St,Vt,et),l.push(Vt,Y,et),F+=6}a.addGroup(f,F,_),f+=F,d+=G}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}};function Mr(i){let t={};for(let e in i){t[e]={};for(let n in i[e]){let s=i[e][n];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=s.clone():Array.isArray(s)?t[e][n]=s.slice():t[e][n]=s}}return t}function ln(i){let t={};for(let e=0;e<i.length;e++){let n=Mr(i[e]);for(let s in n)t[s]=n[s]}return t}function ig(i){let t=[];for(let e=0;e<i.length;e++)t.push(i[e].clone());return t}function jf(i){let t=i.getRenderTarget();return t===null?i.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:re.workingColorSpace}var Pr={clone:Mr,merge:ln},sg=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,rg=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,xn=class extends Li{static get type(){return"ShaderMaterial"}constructor(t){super(),this.isShaderMaterial=!0,this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=sg,this.fragmentShader=rg,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=Mr(t.uniforms),this.uniformsGroups=ig(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){let e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(let s in this.uniforms){let o=this.uniforms[s].value;o&&o.isTexture?e.uniforms[s]={type:"t",value:o.toJSON(t).uuid}:o&&o.isColor?e.uniforms[s]={type:"c",value:o.getHex()}:o&&o.isVector2?e.uniforms[s]={type:"v2",value:o.toArray()}:o&&o.isVector3?e.uniforms[s]={type:"v3",value:o.toArray()}:o&&o.isVector4?e.uniforms[s]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?e.uniforms[s]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?e.uniforms[s]={type:"m4",value:o.toArray()}:e.uniforms[s]={value:o}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;let n={};for(let s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}},Va=class extends We{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new qt,this.projectionMatrix=new qt,this.projectionMatrixInverse=new qt,this.coordinateSystem=Ri}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},Yi=new P,$d=new rt,qd=new rt,Ge=class extends Va{constructor(t=50,e=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){let e=.5*this.getFilmHeight()/t;this.fov=fo*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){let t=Math.tan(ro*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return fo*2*Math.atan(Math.tan(ro*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,e,n){Yi.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),e.set(Yi.x,Yi.y).multiplyScalar(-t/Yi.z),Yi.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Yi.x,Yi.y).multiplyScalar(-t/Yi.z)}getViewSize(t,e){return this.getViewBounds(t,$d,qd),e.subVectors(qd,$d)}setViewOffset(t,e,n,s,r,o){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=this.near,e=t*Math.tan(ro*.5*this.fov)/this.zoom,n=2*e,s=this.aspect*n,r=-.5*s,o=this.view;if(this.view!==null&&this.view.enabled){let l=o.fullWidth,c=o.fullHeight;r+=o.offsetX*s/l,e-=o.offsetY*n/c,s*=o.width/l,n*=o.height/c}let a=this.filmOffset;a!==0&&(r+=t*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,e,e-n,t,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}},ir=-90,sr=1,_h=class extends We{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;let s=new Ge(ir,sr,t,e);s.layers=this.layers,this.add(s);let r=new Ge(ir,sr,t,e);r.layers=this.layers,this.add(r);let o=new Ge(ir,sr,t,e);o.layers=this.layers,this.add(o);let a=new Ge(ir,sr,t,e);a.layers=this.layers,this.add(a);let l=new Ge(ir,sr,t,e);l.layers=this.layers,this.add(l);let c=new Ge(ir,sr,t,e);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let t=this.coordinateSystem,e=this.children.concat(),[n,s,r,o,a,l]=e;for(let c of e)this.remove(c);if(t===Ri)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(t===Na)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(let c of e)this.add(c),c.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();let{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());let[r,o,a,l,c,h]=this.children,u=t.getRenderTarget(),d=t.getActiveCubeFace(),f=t.getActiveMipmapLevel(),m=t.xr.enabled;t.xr.enabled=!1;let x=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,t.setRenderTarget(n,0,s),t.render(e,r),t.setRenderTarget(n,1,s),t.render(e,o),t.setRenderTarget(n,2,s),t.render(e,a),t.setRenderTarget(n,3,s),t.render(e,l),t.setRenderTarget(n,4,s),t.render(e,c),n.texture.generateMipmaps=x,t.setRenderTarget(n,5,s),t.render(e,h),t.setRenderTarget(u,d,f),t.xr.enabled=m,n.texture.needsPMREMUpdate=!0}},Ga=class extends mn{constructor(t,e,n,s,r,o,a,l,c,h){t=t!==void 0?t:[],e=e!==void 0?e:yr,super(t,e,n,s,r,o,a,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}},Mh=class extends Qn{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;let n={width:t,height:t,depth:1},s=[n,n,n,n,n,n];this.texture=new Ga(s,e.mapping,e.wrapS,e.wrapT,e.magFilter,e.minFilter,e.format,e.type,e.anisotropy,e.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=e.generateMipmaps!==void 0?e.generateMipmaps:!1,this.texture.minFilter=e.minFilter!==void 0?e.minFilter:Vn}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new Xt(5,5,5),r=new xn({name:"CubemapFromEquirect",uniforms:Mr(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:en,blending:Ji});r.uniforms.tEquirect.value=e;let o=new nt(s,r),a=e.minFilter;return e.minFilter===Ai&&(e.minFilter=Vn),new _h(1,10,this).update(t,o),e.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(t,e,n,s){let r=t.getRenderTarget();for(let o=0;o<6;o++)t.setRenderTarget(this,o),t.clear(e,n,s);t.setRenderTarget(r)}},vc=new P,og=new P,ag=new $t,Pn=class{constructor(t=new P(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,s){return this.normal.set(t,e,n),this.constant=s,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){let s=vc.subVectors(n,e).cross(og.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(s,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){let t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){let n=t.delta(vc),s=this.normal.dot(n);if(s===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;let r=-(t.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:e.copy(t.start).addScaledVector(n,r)}intersectsLine(t){let e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){let n=e||ag.getNormalMatrix(t),s=this.coplanarPoint(vc).applyMatrix4(t),r=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}},ms=new ts,ga=new P,go=class{constructor(t=new Pn,e=new Pn,n=new Pn,s=new Pn,r=new Pn,o=new Pn){this.planes=[t,e,n,s,r,o]}set(t,e,n,s,r,o){let a=this.planes;return a[0].copy(t),a[1].copy(e),a[2].copy(n),a[3].copy(s),a[4].copy(r),a[5].copy(o),this}copy(t){let e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=Ri){let n=this.planes,s=t.elements,r=s[0],o=s[1],a=s[2],l=s[3],c=s[4],h=s[5],u=s[6],d=s[7],f=s[8],m=s[9],x=s[10],g=s[11],p=s[12],M=s[13],v=s[14],y=s[15];if(n[0].setComponents(l-r,d-c,g-f,y-p).normalize(),n[1].setComponents(l+r,d+c,g+f,y+p).normalize(),n[2].setComponents(l+o,d+h,g+m,y+M).normalize(),n[3].setComponents(l-o,d-h,g-m,y-M).normalize(),n[4].setComponents(l-a,d-u,g-x,y-v).normalize(),e===Ri)n[5].setComponents(l+a,d+u,g+x,y+v).normalize();else if(e===Na)n[5].setComponents(a,u,x,v).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),ms.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{let e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),ms.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(ms)}intersectsSprite(t){return ms.center.set(0,0,0),ms.radius=.7071067811865476,ms.applyMatrix4(t.matrixWorld),this.intersectsSphere(ms)}intersectsSphere(t){let e=this.planes,n=t.center,s=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(n)<s)return!1;return!0}intersectsBox(t){let e=this.planes;for(let n=0;n<6;n++){let s=e[n];if(ga.x=s.normal.x>0?t.max.x:t.min.x,ga.y=s.normal.y>0?t.max.y:t.min.y,ga.z=s.normal.z>0?t.max.z:t.min.z,s.distanceToPoint(ga)<0)return!1}return!0}containsPoint(t){let e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function Qf(){let i=null,t=!1,e=null,n=null;function s(r,o){e(r,o),n=i.requestAnimationFrame(s)}return{start:function(){t!==!0&&e!==null&&(n=i.requestAnimationFrame(s),t=!0)},stop:function(){i.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){i=r}}}function lg(i){let t=new WeakMap;function e(a,l){let c=a.array,h=a.usage,u=c.byteLength,d=i.createBuffer();i.bindBuffer(l,d),i.bufferData(l,c,h),a.onUploadCallback();let f;if(c instanceof Float32Array)f=i.FLOAT;else if(c instanceof Uint16Array)a.isFloat16BufferAttribute?f=i.HALF_FLOAT:f=i.UNSIGNED_SHORT;else if(c instanceof Int16Array)f=i.SHORT;else if(c instanceof Uint32Array)f=i.UNSIGNED_INT;else if(c instanceof Int32Array)f=i.INT;else if(c instanceof Int8Array)f=i.BYTE;else if(c instanceof Uint8Array)f=i.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)f=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:d,type:f,bytesPerElement:c.BYTES_PER_ELEMENT,version:a.version,size:u}}function n(a,l,c){let h=l.array,u=l.updateRanges;if(i.bindBuffer(c,a),u.length===0)i.bufferSubData(c,0,h);else{u.sort((f,m)=>f.start-m.start);let d=0;for(let f=1;f<u.length;f++){let m=u[d],x=u[f];x.start<=m.start+m.count+1?m.count=Math.max(m.count,x.start+x.count-m.start):(++d,u[d]=x)}u.length=d+1;for(let f=0,m=u.length;f<m;f++){let x=u[f];i.bufferSubData(c,x.start*h.BYTES_PER_ELEMENT,h,x.start,x.count)}l.clearUpdateRanges()}l.onUploadCallback()}function s(a){return a.isInterleavedBufferAttribute&&(a=a.data),t.get(a)}function r(a){a.isInterleavedBufferAttribute&&(a=a.data);let l=t.get(a);l&&(i.deleteBuffer(l.buffer),t.delete(a))}function o(a,l){if(a.isInterleavedBufferAttribute&&(a=a.data),a.isGLBufferAttribute){let h=t.get(a);(!h||h.version<a.version)&&t.set(a,{buffer:a.buffer,type:a.type,bytesPerElement:a.elementSize,version:a.version});return}let c=t.get(a);if(c===void 0)t.set(a,e(a,l));else if(c.version<a.version){if(c.size!==a.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,a,l),c.version=a.version}}return{get:s,remove:r,update:o}}var Ln=class i extends ce{constructor(t=1,e=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:s};let r=t/2,o=e/2,a=Math.floor(n),l=Math.floor(s),c=a+1,h=l+1,u=t/a,d=e/l,f=[],m=[],x=[],g=[];for(let p=0;p<h;p++){let M=p*d-o;for(let v=0;v<c;v++){let y=v*u-r;m.push(y,-M,0),x.push(0,0,1),g.push(v/a),g.push(1-p/l)}}for(let p=0;p<l;p++)for(let M=0;M<a;M++){let v=M+c*p,y=M+c*(p+1),w=M+1+c*(p+1),S=M+1+c*p;f.push(v,y,S),f.push(y,w,S)}this.setIndex(f),this.setAttribute("position",new Ht(m,3)),this.setAttribute("normal",new Ht(x,3)),this.setAttribute("uv",new Ht(g,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.width,t.height,t.widthSegments,t.heightSegments)}},cg=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,hg=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,ug=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,dg=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,fg=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,pg=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,mg=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,gg=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,xg=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,yg=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,vg=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,bg=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,_g=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Mg=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,wg=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Sg=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Eg=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Tg=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Ag=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Rg=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Cg=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Pg=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,Ig=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,Lg=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,kg=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Dg=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Ug=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Ng=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,zg=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Fg=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Bg="gl_FragColor = linearToOutputTexel( gl_FragColor );",Og=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,Hg=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,Vg=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,Gg=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Wg=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,$g=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,qg=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Xg=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Yg=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Zg=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Kg=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Jg=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,jg=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Qg=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,tx=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,ex=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,nx=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,ix=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,sx=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,rx=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,ox=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,ax=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,lx=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,cx=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,hx=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,ux=`#if defined( USE_LOGDEPTHBUF )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,dx=`#if defined( USE_LOGDEPTHBUF )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,fx=`#ifdef USE_LOGDEPTHBUF
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,px=`#ifdef USE_LOGDEPTHBUF
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,mx=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,gx=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,xx=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,yx=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,vx=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,bx=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,_x=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,Mx=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,wx=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Sx=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,Ex=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Tx=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Ax=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Rx=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Cx=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Px=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Ix=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Lx=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,kx=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Dx=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Ux=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Nx=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,zx=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Fx=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Bx=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Ox=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Hx=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Vx=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Gx=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Wx=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,$x=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,qx=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Xx=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Yx=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Zx=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Kx=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Jx=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,jx=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Qx=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,ty=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,ey=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,ny=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,iy=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
		
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
		
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		
		#else
		
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,sy=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,ry=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,oy=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,ay=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,ly=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,cy=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,hy=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,uy=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,dy=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,fy=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,py=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,my=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,gy=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,xy=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,yy=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,vy=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,by=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,_y=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,My=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,wy=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Sy=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Ey=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ty=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Ay=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ry=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Cy=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Py=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Iy=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ly=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,ky=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Dy=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Uy=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ny=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,zy=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Fy=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,By=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Oy=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Hy=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Kt={alphahash_fragment:cg,alphahash_pars_fragment:hg,alphamap_fragment:ug,alphamap_pars_fragment:dg,alphatest_fragment:fg,alphatest_pars_fragment:pg,aomap_fragment:mg,aomap_pars_fragment:gg,batching_pars_vertex:xg,batching_vertex:yg,begin_vertex:vg,beginnormal_vertex:bg,bsdfs:_g,iridescence_fragment:Mg,bumpmap_pars_fragment:wg,clipping_planes_fragment:Sg,clipping_planes_pars_fragment:Eg,clipping_planes_pars_vertex:Tg,clipping_planes_vertex:Ag,color_fragment:Rg,color_pars_fragment:Cg,color_pars_vertex:Pg,color_vertex:Ig,common:Lg,cube_uv_reflection_fragment:kg,defaultnormal_vertex:Dg,displacementmap_pars_vertex:Ug,displacementmap_vertex:Ng,emissivemap_fragment:zg,emissivemap_pars_fragment:Fg,colorspace_fragment:Bg,colorspace_pars_fragment:Og,envmap_fragment:Hg,envmap_common_pars_fragment:Vg,envmap_pars_fragment:Gg,envmap_pars_vertex:Wg,envmap_physical_pars_fragment:ex,envmap_vertex:$g,fog_vertex:qg,fog_pars_vertex:Xg,fog_fragment:Yg,fog_pars_fragment:Zg,gradientmap_pars_fragment:Kg,lightmap_pars_fragment:Jg,lights_lambert_fragment:jg,lights_lambert_pars_fragment:Qg,lights_pars_begin:tx,lights_toon_fragment:nx,lights_toon_pars_fragment:ix,lights_phong_fragment:sx,lights_phong_pars_fragment:rx,lights_physical_fragment:ox,lights_physical_pars_fragment:ax,lights_fragment_begin:lx,lights_fragment_maps:cx,lights_fragment_end:hx,logdepthbuf_fragment:ux,logdepthbuf_pars_fragment:dx,logdepthbuf_pars_vertex:fx,logdepthbuf_vertex:px,map_fragment:mx,map_pars_fragment:gx,map_particle_fragment:xx,map_particle_pars_fragment:yx,metalnessmap_fragment:vx,metalnessmap_pars_fragment:bx,morphinstance_vertex:_x,morphcolor_vertex:Mx,morphnormal_vertex:wx,morphtarget_pars_vertex:Sx,morphtarget_vertex:Ex,normal_fragment_begin:Tx,normal_fragment_maps:Ax,normal_pars_fragment:Rx,normal_pars_vertex:Cx,normal_vertex:Px,normalmap_pars_fragment:Ix,clearcoat_normal_fragment_begin:Lx,clearcoat_normal_fragment_maps:kx,clearcoat_pars_fragment:Dx,iridescence_pars_fragment:Ux,opaque_fragment:Nx,packing:zx,premultiplied_alpha_fragment:Fx,project_vertex:Bx,dithering_fragment:Ox,dithering_pars_fragment:Hx,roughnessmap_fragment:Vx,roughnessmap_pars_fragment:Gx,shadowmap_pars_fragment:Wx,shadowmap_pars_vertex:$x,shadowmap_vertex:qx,shadowmask_pars_fragment:Xx,skinbase_vertex:Yx,skinning_pars_vertex:Zx,skinning_vertex:Kx,skinnormal_vertex:Jx,specularmap_fragment:jx,specularmap_pars_fragment:Qx,tonemapping_fragment:ty,tonemapping_pars_fragment:ey,transmission_fragment:ny,transmission_pars_fragment:iy,uv_pars_fragment:sy,uv_pars_vertex:ry,uv_vertex:oy,worldpos_vertex:ay,background_vert:ly,background_frag:cy,backgroundCube_vert:hy,backgroundCube_frag:uy,cube_vert:dy,cube_frag:fy,depth_vert:py,depth_frag:my,distanceRGBA_vert:gy,distanceRGBA_frag:xy,equirect_vert:yy,equirect_frag:vy,linedashed_vert:by,linedashed_frag:_y,meshbasic_vert:My,meshbasic_frag:wy,meshlambert_vert:Sy,meshlambert_frag:Ey,meshmatcap_vert:Ty,meshmatcap_frag:Ay,meshnormal_vert:Ry,meshnormal_frag:Cy,meshphong_vert:Py,meshphong_frag:Iy,meshphysical_vert:Ly,meshphysical_frag:ky,meshtoon_vert:Dy,meshtoon_frag:Uy,points_vert:Ny,points_frag:zy,shadow_vert:Fy,shadow_frag:By,sprite_vert:Oy,sprite_frag:Hy},lt={common:{diffuse:{value:new wt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new $t},alphaMap:{value:null},alphaMapTransform:{value:new $t},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new $t}},envmap:{envMap:{value:null},envMapRotation:{value:new $t},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new $t}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new $t}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new $t},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new $t},normalScale:{value:new rt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new $t},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new $t}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new $t}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new $t}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new wt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new wt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new $t},alphaTest:{value:0},uvTransform:{value:new $t}},sprite:{diffuse:{value:new wt(16777215)},opacity:{value:1},center:{value:new rt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new $t},alphaMap:{value:null},alphaMapTransform:{value:new $t},alphaTest:{value:0}}},ai={basic:{uniforms:ln([lt.common,lt.specularmap,lt.envmap,lt.aomap,lt.lightmap,lt.fog]),vertexShader:Kt.meshbasic_vert,fragmentShader:Kt.meshbasic_frag},lambert:{uniforms:ln([lt.common,lt.specularmap,lt.envmap,lt.aomap,lt.lightmap,lt.emissivemap,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.fog,lt.lights,{emissive:{value:new wt(0)}}]),vertexShader:Kt.meshlambert_vert,fragmentShader:Kt.meshlambert_frag},phong:{uniforms:ln([lt.common,lt.specularmap,lt.envmap,lt.aomap,lt.lightmap,lt.emissivemap,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.fog,lt.lights,{emissive:{value:new wt(0)},specular:{value:new wt(1118481)},shininess:{value:30}}]),vertexShader:Kt.meshphong_vert,fragmentShader:Kt.meshphong_frag},standard:{uniforms:ln([lt.common,lt.envmap,lt.aomap,lt.lightmap,lt.emissivemap,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.roughnessmap,lt.metalnessmap,lt.fog,lt.lights,{emissive:{value:new wt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Kt.meshphysical_vert,fragmentShader:Kt.meshphysical_frag},toon:{uniforms:ln([lt.common,lt.aomap,lt.lightmap,lt.emissivemap,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.gradientmap,lt.fog,lt.lights,{emissive:{value:new wt(0)}}]),vertexShader:Kt.meshtoon_vert,fragmentShader:Kt.meshtoon_frag},matcap:{uniforms:ln([lt.common,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.fog,{matcap:{value:null}}]),vertexShader:Kt.meshmatcap_vert,fragmentShader:Kt.meshmatcap_frag},points:{uniforms:ln([lt.points,lt.fog]),vertexShader:Kt.points_vert,fragmentShader:Kt.points_frag},dashed:{uniforms:ln([lt.common,lt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Kt.linedashed_vert,fragmentShader:Kt.linedashed_frag},depth:{uniforms:ln([lt.common,lt.displacementmap]),vertexShader:Kt.depth_vert,fragmentShader:Kt.depth_frag},normal:{uniforms:ln([lt.common,lt.bumpmap,lt.normalmap,lt.displacementmap,{opacity:{value:1}}]),vertexShader:Kt.meshnormal_vert,fragmentShader:Kt.meshnormal_frag},sprite:{uniforms:ln([lt.sprite,lt.fog]),vertexShader:Kt.sprite_vert,fragmentShader:Kt.sprite_frag},background:{uniforms:{uvTransform:{value:new $t},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Kt.background_vert,fragmentShader:Kt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new $t}},vertexShader:Kt.backgroundCube_vert,fragmentShader:Kt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Kt.cube_vert,fragmentShader:Kt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Kt.equirect_vert,fragmentShader:Kt.equirect_frag},distanceRGBA:{uniforms:ln([lt.common,lt.displacementmap,{referencePosition:{value:new P},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Kt.distanceRGBA_vert,fragmentShader:Kt.distanceRGBA_frag},shadow:{uniforms:ln([lt.lights,lt.fog,{color:{value:new wt(0)},opacity:{value:1}}]),vertexShader:Kt.shadow_vert,fragmentShader:Kt.shadow_frag}};ai.physical={uniforms:ln([ai.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new $t},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new $t},clearcoatNormalScale:{value:new rt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new $t},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new $t},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new $t},sheen:{value:0},sheenColor:{value:new wt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new $t},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new $t},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new $t},transmissionSamplerSize:{value:new rt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new $t},attenuationDistance:{value:0},attenuationColor:{value:new wt(0)},specularColor:{value:new wt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new $t},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new $t},anisotropyVector:{value:new rt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new $t}}]),vertexShader:Kt.meshphysical_vert,fragmentShader:Kt.meshphysical_frag};var xa={r:0,b:0,g:0},gs=new gn,Vy=new qt;function Gy(i,t,e,n,s,r,o){let a=new wt(0),l=r===!0?0:1,c,h,u=null,d=0,f=null;function m(M){let v=M.isScene===!0?M.background:null;return v&&v.isTexture&&(v=(M.backgroundBlurriness>0?e:t).get(v)),v}function x(M){let v=!1,y=m(M);y===null?p(a,l):y&&y.isColor&&(p(y,1),v=!0);let w=i.xr.getEnvironmentBlendMode();w==="additive"?n.buffers.color.setClear(0,0,0,1,o):w==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,o),(i.autoClear||v)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function g(M,v){let y=m(v);y&&(y.isCubeTexture||y.mapping===ul)?(h===void 0&&(h=new nt(new Xt(1,1,1),new xn({name:"BackgroundCubeMaterial",uniforms:Mr(ai.backgroundCube.uniforms),vertexShader:ai.backgroundCube.vertexShader,fragmentShader:ai.backgroundCube.fragmentShader,side:en,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(w,S,T){this.matrixWorld.copyPosition(T.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(h)),gs.copy(v.backgroundRotation),gs.x*=-1,gs.y*=-1,gs.z*=-1,y.isCubeTexture&&y.isRenderTargetTexture===!1&&(gs.y*=-1,gs.z*=-1),h.material.uniforms.envMap.value=y,h.material.uniforms.flipEnvMap.value=y.isCubeTexture&&y.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=v.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=v.backgroundIntensity,h.material.uniforms.backgroundRotation.value.setFromMatrix4(Vy.makeRotationFromEuler(gs)),h.material.toneMapped=re.getTransfer(y.colorSpace)!==pe,(u!==y||d!==y.version||f!==i.toneMapping)&&(h.material.needsUpdate=!0,u=y,d=y.version,f=i.toneMapping),h.layers.enableAll(),M.unshift(h,h.geometry,h.material,0,0,null)):y&&y.isTexture&&(c===void 0&&(c=new nt(new Ln(2,2),new xn({name:"BackgroundMaterial",uniforms:Mr(ai.background.uniforms),vertexShader:ai.background.vertexShader,fragmentShader:ai.background.fragmentShader,side:hi,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(c)),c.material.uniforms.t2D.value=y,c.material.uniforms.backgroundIntensity.value=v.backgroundIntensity,c.material.toneMapped=re.getTransfer(y.colorSpace)!==pe,y.matrixAutoUpdate===!0&&y.updateMatrix(),c.material.uniforms.uvTransform.value.copy(y.matrix),(u!==y||d!==y.version||f!==i.toneMapping)&&(c.material.needsUpdate=!0,u=y,d=y.version,f=i.toneMapping),c.layers.enableAll(),M.unshift(c,c.geometry,c.material,0,0,null))}function p(M,v){M.getRGB(xa,jf(i)),n.buffers.color.setClear(xa.r,xa.g,xa.b,v,o)}return{getClearColor:function(){return a},setClearColor:function(M,v=1){a.set(M),l=v,p(a,l)},getClearAlpha:function(){return l},setClearAlpha:function(M){l=M,p(a,l)},render:x,addToRenderList:g}}function Wy(i,t){let e=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},s=d(null),r=s,o=!1;function a(b,C,L,k,D){let V=!1,z=u(k,L,C);r!==z&&(r=z,c(r.object)),V=f(b,k,L,D),V&&m(b,k,L,D),D!==null&&t.update(D,i.ELEMENT_ARRAY_BUFFER),(V||o)&&(o=!1,y(b,C,L,k),D!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,t.get(D).buffer))}function l(){return i.createVertexArray()}function c(b){return i.bindVertexArray(b)}function h(b){return i.deleteVertexArray(b)}function u(b,C,L){let k=L.wireframe===!0,D=n[b.id];D===void 0&&(D={},n[b.id]=D);let V=D[C.id];V===void 0&&(V={},D[C.id]=V);let z=V[k];return z===void 0&&(z=d(l()),V[k]=z),z}function d(b){let C=[],L=[],k=[];for(let D=0;D<e;D++)C[D]=0,L[D]=0,k[D]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:C,enabledAttributes:L,attributeDivisors:k,object:b,attributes:{},index:null}}function f(b,C,L,k){let D=r.attributes,V=C.attributes,z=0,G=L.getAttributes();for(let F in G)if(G[F].location>=0){let Q=D[F],ot=V[F];if(ot===void 0&&(F==="instanceMatrix"&&b.instanceMatrix&&(ot=b.instanceMatrix),F==="instanceColor"&&b.instanceColor&&(ot=b.instanceColor)),Q===void 0||Q.attribute!==ot||ot&&Q.data!==ot.data)return!0;z++}return r.attributesNum!==z||r.index!==k}function m(b,C,L,k){let D={},V=C.attributes,z=0,G=L.getAttributes();for(let F in G)if(G[F].location>=0){let Q=V[F];Q===void 0&&(F==="instanceMatrix"&&b.instanceMatrix&&(Q=b.instanceMatrix),F==="instanceColor"&&b.instanceColor&&(Q=b.instanceColor));let ot={};ot.attribute=Q,Q&&Q.data&&(ot.data=Q.data),D[F]=ot,z++}r.attributes=D,r.attributesNum=z,r.index=k}function x(){let b=r.newAttributes;for(let C=0,L=b.length;C<L;C++)b[C]=0}function g(b){p(b,0)}function p(b,C){let L=r.newAttributes,k=r.enabledAttributes,D=r.attributeDivisors;L[b]=1,k[b]===0&&(i.enableVertexAttribArray(b),k[b]=1),D[b]!==C&&(i.vertexAttribDivisor(b,C),D[b]=C)}function M(){let b=r.newAttributes,C=r.enabledAttributes;for(let L=0,k=C.length;L<k;L++)C[L]!==b[L]&&(i.disableVertexAttribArray(L),C[L]=0)}function v(b,C,L,k,D,V,z){z===!0?i.vertexAttribIPointer(b,C,L,D,V):i.vertexAttribPointer(b,C,L,k,D,V)}function y(b,C,L,k){x();let D=k.attributes,V=L.getAttributes(),z=C.defaultAttributeValues;for(let G in V){let F=V[G];if(F.location>=0){let K=D[G];if(K===void 0&&(G==="instanceMatrix"&&b.instanceMatrix&&(K=b.instanceMatrix),G==="instanceColor"&&b.instanceColor&&(K=b.instanceColor)),K!==void 0){let Q=K.normalized,ot=K.itemSize,St=t.get(K);if(St===void 0)continue;let Vt=St.buffer,Y=St.type,et=St.bytesPerElement,Mt=Y===i.INT||Y===i.UNSIGNED_INT||K.gpuType===ru;if(K.isInterleavedBufferAttribute){let ht=K.data,Nt=ht.stride,Ot=K.offset;if(ht.isInstancedInterleavedBuffer){for(let Jt=0;Jt<F.locationSize;Jt++)p(F.location+Jt,ht.meshPerAttribute);b.isInstancedMesh!==!0&&k._maxInstanceCount===void 0&&(k._maxInstanceCount=ht.meshPerAttribute*ht.count)}else for(let Jt=0;Jt<F.locationSize;Jt++)g(F.location+Jt);i.bindBuffer(i.ARRAY_BUFFER,Vt);for(let Jt=0;Jt<F.locationSize;Jt++)v(F.location+Jt,ot/F.locationSize,Y,Q,Nt*et,(Ot+ot/F.locationSize*Jt)*et,Mt)}else{if(K.isInstancedBufferAttribute){for(let ht=0;ht<F.locationSize;ht++)p(F.location+ht,K.meshPerAttribute);b.isInstancedMesh!==!0&&k._maxInstanceCount===void 0&&(k._maxInstanceCount=K.meshPerAttribute*K.count)}else for(let ht=0;ht<F.locationSize;ht++)g(F.location+ht);i.bindBuffer(i.ARRAY_BUFFER,Vt);for(let ht=0;ht<F.locationSize;ht++)v(F.location+ht,ot/F.locationSize,Y,Q,ot*et,ot/F.locationSize*ht*et,Mt)}}else if(z!==void 0){let Q=z[G];if(Q!==void 0)switch(Q.length){case 2:i.vertexAttrib2fv(F.location,Q);break;case 3:i.vertexAttrib3fv(F.location,Q);break;case 4:i.vertexAttrib4fv(F.location,Q);break;default:i.vertexAttrib1fv(F.location,Q)}}}}M()}function w(){R();for(let b in n){let C=n[b];for(let L in C){let k=C[L];for(let D in k)h(k[D].object),delete k[D];delete C[L]}delete n[b]}}function S(b){if(n[b.id]===void 0)return;let C=n[b.id];for(let L in C){let k=C[L];for(let D in k)h(k[D].object),delete k[D];delete C[L]}delete n[b.id]}function T(b){for(let C in n){let L=n[C];if(L[b.id]===void 0)continue;let k=L[b.id];for(let D in k)h(k[D].object),delete k[D];delete L[b.id]}}function R(){_(),o=!0,r!==s&&(r=s,c(r.object))}function _(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:a,reset:R,resetDefaultState:_,dispose:w,releaseStatesOfGeometry:S,releaseStatesOfProgram:T,initAttributes:x,enableAttribute:g,disableUnusedAttributes:M}}function $y(i,t,e){let n;function s(c){n=c}function r(c,h){i.drawArrays(n,c,h),e.update(h,n,1)}function o(c,h,u){u!==0&&(i.drawArraysInstanced(n,c,h,u),e.update(h,n,u))}function a(c,h,u){if(u===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,c,0,h,0,u);let f=0;for(let m=0;m<u;m++)f+=h[m];e.update(f,n,1)}function l(c,h,u,d){if(u===0)return;let f=t.get("WEBGL_multi_draw");if(f===null)for(let m=0;m<c.length;m++)o(c[m],h[m],d[m]);else{f.multiDrawArraysInstancedWEBGL(n,c,0,h,0,d,0,u);let m=0;for(let x=0;x<u;x++)m+=h[x]*d[x];e.update(m,n,1)}}this.setMode=s,this.render=r,this.renderInstances=o,this.renderMultiDraw=a,this.renderMultiDrawInstances=l}function qy(i,t,e,n){let s;function r(){if(s!==void 0)return s;if(t.has("EXT_texture_filter_anisotropic")===!0){let T=t.get("EXT_texture_filter_anisotropic");s=i.getParameter(T.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function o(T){return!(T!==jn&&n.convert(T)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function a(T){let R=T===Ro&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(T!==Pi&&n.convert(T)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE)&&T!==li&&!R)}function l(T){if(T==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";T="mediump"}return T==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=e.precision!==void 0?e.precision:"highp",h=l(c);h!==c&&(console.warn("THREE.WebGLRenderer:",c,"not supported, using",h,"instead."),c=h);let u=e.logarithmicDepthBuffer===!0,d=e.reverseDepthBuffer===!0&&t.has("EXT_clip_control"),f=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),m=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),x=i.getParameter(i.MAX_TEXTURE_SIZE),g=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),p=i.getParameter(i.MAX_VERTEX_ATTRIBS),M=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),v=i.getParameter(i.MAX_VARYING_VECTORS),y=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),w=m>0,S=i.getParameter(i.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:l,textureFormatReadable:o,textureTypeReadable:a,precision:c,logarithmicDepthBuffer:u,reverseDepthBuffer:d,maxTextures:f,maxVertexTextures:m,maxTextureSize:x,maxCubemapSize:g,maxAttributes:p,maxVertexUniforms:M,maxVaryings:v,maxFragmentUniforms:y,vertexTextures:w,maxSamples:S}}function Xy(i){let t=this,e=null,n=0,s=!1,r=!1,o=new Pn,a=new $t,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,d){let f=u.length!==0||d||n!==0||s;return s=d,n=u.length,f},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(u,d){e=h(u,d,0)},this.setState=function(u,d,f){let m=u.clippingPlanes,x=u.clipIntersection,g=u.clipShadows,p=i.get(u);if(!s||m===null||m.length===0||r&&!g)r?h(null):c();else{let M=r?0:n,v=M*4,y=p.clippingState||null;l.value=y,y=h(m,d,v,f);for(let w=0;w!==v;++w)y[w]=e[w];p.clippingState=y,this.numIntersection=x?this.numPlanes:0,this.numPlanes+=M}};function c(){l.value!==e&&(l.value=e,l.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function h(u,d,f,m){let x=u!==null?u.length:0,g=null;if(x!==0){if(g=l.value,m!==!0||g===null){let p=f+x*4,M=d.matrixWorldInverse;a.getNormalMatrix(M),(g===null||g.length<p)&&(g=new Float32Array(p));for(let v=0,y=f;v!==x;++v,y+=4)o.copy(u[v]).applyMatrix4(M,a),o.normal.toArray(g,y),g[y+3]=o.constant}l.value=g,l.needsUpdate=!0}return t.numPlanes=x,t.numIntersection=0,g}}function Yy(i){let t=new WeakMap;function e(o,a){return a===Hc?o.mapping=yr:a===Vc&&(o.mapping=vr),o}function n(o){if(o&&o.isTexture){let a=o.mapping;if(a===Hc||a===Vc)if(t.has(o)){let l=t.get(o).texture;return e(l,o.mapping)}else{let l=o.image;if(l&&l.height>0){let c=new Mh(l.height);return c.fromEquirectangularTexture(i,o),t.set(o,c),o.addEventListener("dispose",s),e(c.texture,o.mapping)}else return null}}return o}function s(o){let a=o.target;a.removeEventListener("dispose",s);let l=t.get(a);l!==void 0&&(t.delete(a),l.dispose())}function r(){t=new WeakMap}return{get:n,dispose:r}}var Wa=class extends Va{constructor(t=-1,e=1,n=1,s=-1,r=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=s,this.near=r,this.far=o,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,s,r,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2,r=n-t,o=n+t,a=s+e,l=s-e;if(this.view!==null&&this.view.enabled){let c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=c*this.view.offsetX,o=r+c*this.view.width,a-=h*this.view.offsetY,l=a-h*this.view.height}this.projectionMatrix.makeOrthographic(r,o,a,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}},ur=4,Xd=[.125,.215,.35,.446,.526,.582],bs=20,bc=new Wa,Yd=new wt,_c=null,Mc=0,wc=0,Sc=!1,ys=(1+Math.sqrt(5))/2,rr=1/ys,Zd=[new P(-ys,rr,0),new P(ys,rr,0),new P(-rr,0,ys),new P(rr,0,ys),new P(0,ys,-rr),new P(0,ys,rr),new P(-1,1,-1),new P(1,1,-1),new P(-1,1,1),new P(1,1,1)],wr=class{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,n=.1,s=100){_c=this._renderer.getRenderTarget(),Mc=this._renderer.getActiveCubeFace(),wc=this._renderer.getActiveMipmapLevel(),Sc=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(256);let r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(t,n,s,r),e>0&&this._blur(r,0,0,e),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=jd(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Jd(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(_c,Mc,wc),this._renderer.xr.enabled=Sc,t.scissorTest=!1,ya(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===yr||t.mapping===vr?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),_c=this._renderer.getRenderTarget(),Mc=this._renderer.getActiveCubeFace(),wc=this._renderer.getActiveMipmapLevel(),Sc=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;let n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:Vn,minFilter:Vn,generateMipmaps:!1,type:Ro,format:jn,colorSpace:Rr,depthBuffer:!1},s=Kd(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Kd(t,e,n);let{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Zy(r)),this._blurMaterial=Ky(r,t,e)}return s}_compileMaterial(t){let e=new nt(this._lodPlanes[0],t);this._renderer.compile(e,bc)}_sceneToCubeUV(t,e,n,s){let a=new Ge(90,1,e,n),l=[1,-1,1,1,1,1],c=[1,1,1,-1,-1,-1],h=this._renderer,u=h.autoClear,d=h.toneMapping;h.getClearColor(Yd),h.toneMapping=ji,h.autoClear=!1;let f=new ke({name:"PMREM.Background",side:en,depthWrite:!1,depthTest:!1}),m=new nt(new Xt,f),x=!1,g=t.background;g?g.isColor&&(f.color.copy(g),t.background=null,x=!0):(f.color.copy(Yd),x=!0);for(let p=0;p<6;p++){let M=p%3;M===0?(a.up.set(0,l[p],0),a.lookAt(c[p],0,0)):M===1?(a.up.set(0,0,l[p]),a.lookAt(0,c[p],0)):(a.up.set(0,l[p],0),a.lookAt(0,0,c[p]));let v=this._cubeSize;ya(s,M*v,p>2?v:0,v,v),h.setRenderTarget(s),x&&h.render(m,a),h.render(t,a)}m.geometry.dispose(),m.material.dispose(),h.toneMapping=d,h.autoClear=u,t.background=g}_textureToCubeUV(t,e){let n=this._renderer,s=t.mapping===yr||t.mapping===vr;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=jd()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Jd());let r=s?this._cubemapMaterial:this._equirectMaterial,o=new nt(this._lodPlanes[0],r),a=r.uniforms;a.envMap.value=t;let l=this._cubeSize;ya(e,0,0,3*l,2*l),n.setRenderTarget(e),n.render(o,bc)}_applyPMREM(t){let e=this._renderer,n=e.autoClear;e.autoClear=!1;let s=this._lodPlanes.length;for(let r=1;r<s;r++){let o=Math.sqrt(this._sigmas[r]*this._sigmas[r]-this._sigmas[r-1]*this._sigmas[r-1]),a=Zd[(s-r-1)%Zd.length];this._blur(t,r-1,r,o,a)}e.autoClear=n}_blur(t,e,n,s,r){let o=this._pingPongRenderTarget;this._halfBlur(t,o,e,n,s,"latitudinal",r),this._halfBlur(o,t,n,n,s,"longitudinal",r)}_halfBlur(t,e,n,s,r,o,a){let l=this._renderer,c=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let h=3,u=new nt(this._lodPlanes[s],c),d=c.uniforms,f=this._sizeLods[n]-1,m=isFinite(r)?Math.PI/(2*f):2*Math.PI/(2*bs-1),x=r/m,g=isFinite(r)?1+Math.floor(h*x):bs;g>bs&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${g} samples when the maximum is set to ${bs}`);let p=[],M=0;for(let T=0;T<bs;++T){let R=T/x,_=Math.exp(-R*R/2);p.push(_),T===0?M+=_:T<g&&(M+=2*_)}for(let T=0;T<p.length;T++)p[T]=p[T]/M;d.envMap.value=t.texture,d.samples.value=g,d.weights.value=p,d.latitudinal.value=o==="latitudinal",a&&(d.poleAxis.value=a);let{_lodMax:v}=this;d.dTheta.value=m,d.mipInt.value=v-n;let y=this._sizeLods[s],w=3*y*(s>v-ur?s-v+ur:0),S=4*(this._cubeSize-y);ya(e,w,S,3*y,2*y),l.setRenderTarget(e),l.render(u,bc)}};function Zy(i){let t=[],e=[],n=[],s=i,r=i-ur+1+Xd.length;for(let o=0;o<r;o++){let a=Math.pow(2,s);e.push(a);let l=1/a;o>i-ur?l=Xd[o-i+ur-1]:o===0&&(l=0),n.push(l);let c=1/(a-2),h=-c,u=1+c,d=[h,h,u,h,u,u,h,h,u,u,h,u],f=6,m=6,x=3,g=2,p=1,M=new Float32Array(x*m*f),v=new Float32Array(g*m*f),y=new Float32Array(p*m*f);for(let S=0;S<f;S++){let T=S%3*2/3-1,R=S>2?0:-1,_=[T,R,0,T+2/3,R,0,T+2/3,R+1,0,T,R,0,T+2/3,R+1,0,T,R+1,0];M.set(_,x*m*S),v.set(d,g*m*S);let b=[S,S,S,S,S,S];y.set(b,p*m*S)}let w=new ce;w.setAttribute("position",new Oe(M,x)),w.setAttribute("uv",new Oe(v,g)),w.setAttribute("faceIndex",new Oe(y,p)),t.push(w),s>ur&&s--}return{lodPlanes:t,sizeLods:e,sigmas:n}}function Kd(i,t,e){let n=new Qn(i,t,e);return n.texture.mapping=ul,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function ya(i,t,e,n,s){i.viewport.set(t,e,n,s),i.scissor.set(t,e,n,s)}function Ky(i,t,e){let n=new Float32Array(bs),s=new P(0,1,0);return new xn({name:"SphericalGaussianBlur",defines:{n:bs,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:fu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Ji,depthTest:!1,depthWrite:!1})}function Jd(){return new xn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:fu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Ji,depthTest:!1,depthWrite:!1})}function jd(){return new xn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:fu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Ji,depthTest:!1,depthWrite:!1})}function fu(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function Jy(i){let t=new WeakMap,e=null;function n(a){if(a&&a.isTexture){let l=a.mapping,c=l===Hc||l===Vc,h=l===yr||l===vr;if(c||h){let u=t.get(a),d=u!==void 0?u.texture.pmremVersion:0;if(a.isRenderTargetTexture&&a.pmremVersion!==d)return e===null&&(e=new wr(i)),u=c?e.fromEquirectangular(a,u):e.fromCubemap(a,u),u.texture.pmremVersion=a.pmremVersion,t.set(a,u),u.texture;if(u!==void 0)return u.texture;{let f=a.image;return c&&f&&f.height>0||h&&f&&s(f)?(e===null&&(e=new wr(i)),u=c?e.fromEquirectangular(a):e.fromCubemap(a),u.texture.pmremVersion=a.pmremVersion,t.set(a,u),a.addEventListener("dispose",r),u.texture):null}}}return a}function s(a){let l=0,c=6;for(let h=0;h<c;h++)a[h]!==void 0&&l++;return l===c}function r(a){let l=a.target;l.removeEventListener("dispose",r);let c=t.get(l);c!==void 0&&(t.delete(l),c.dispose())}function o(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:n,dispose:o}}function jy(i){let t={};function e(n){if(t[n]!==void 0)return t[n];let s;switch(n){case"WEBGL_depth_texture":s=i.getExtension("WEBGL_depth_texture")||i.getExtension("MOZ_WEBGL_depth_texture")||i.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=i.getExtension("EXT_texture_filter_anisotropic")||i.getExtension("MOZ_EXT_texture_filter_anisotropic")||i.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=i.getExtension("WEBGL_compressed_texture_s3tc")||i.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=i.getExtension("WEBGL_compressed_texture_pvrtc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=i.getExtension(n)}return t[n]=s,s}return{has:function(n){return e(n)!==null},init:function(){e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance"),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture"),e("WEBGL_render_shared_exponent")},get:function(n){let s=e(n);return s===null&&io("THREE.WebGLRenderer: "+n+" extension not supported."),s}}}function Qy(i,t,e,n){let s={},r=new WeakMap;function o(u){let d=u.target;d.index!==null&&t.remove(d.index);for(let m in d.attributes)t.remove(d.attributes[m]);for(let m in d.morphAttributes){let x=d.morphAttributes[m];for(let g=0,p=x.length;g<p;g++)t.remove(x[g])}d.removeEventListener("dispose",o),delete s[d.id];let f=r.get(d);f&&(t.remove(f),r.delete(d)),n.releaseStatesOfGeometry(d),d.isInstancedBufferGeometry===!0&&delete d._maxInstanceCount,e.memory.geometries--}function a(u,d){return s[d.id]===!0||(d.addEventListener("dispose",o),s[d.id]=!0,e.memory.geometries++),d}function l(u){let d=u.attributes;for(let m in d)t.update(d[m],i.ARRAY_BUFFER);let f=u.morphAttributes;for(let m in f){let x=f[m];for(let g=0,p=x.length;g<p;g++)t.update(x[g],i.ARRAY_BUFFER)}}function c(u){let d=[],f=u.index,m=u.attributes.position,x=0;if(f!==null){let M=f.array;x=f.version;for(let v=0,y=M.length;v<y;v+=3){let w=M[v+0],S=M[v+1],T=M[v+2];d.push(w,S,S,T,T,w)}}else if(m!==void 0){let M=m.array;x=m.version;for(let v=0,y=M.length/3-1;v<y;v+=3){let w=v+0,S=v+1,T=v+2;d.push(w,S,S,T,T,w)}}else return;let g=new(Kf(d)?Ha:Oa)(d,1);g.version=x;let p=r.get(u);p&&t.remove(p),r.set(u,g)}function h(u){let d=r.get(u);if(d){let f=u.index;f!==null&&d.version<f.version&&c(u)}else c(u);return r.get(u)}return{get:a,update:l,getWireframeAttribute:h}}function tv(i,t,e){let n;function s(d){n=d}let r,o;function a(d){r=d.type,o=d.bytesPerElement}function l(d,f){i.drawElements(n,f,r,d*o),e.update(f,n,1)}function c(d,f,m){m!==0&&(i.drawElementsInstanced(n,f,r,d*o,m),e.update(f,n,m))}function h(d,f,m){if(m===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,f,0,r,d,0,m);let g=0;for(let p=0;p<m;p++)g+=f[p];e.update(g,n,1)}function u(d,f,m,x){if(m===0)return;let g=t.get("WEBGL_multi_draw");if(g===null)for(let p=0;p<d.length;p++)c(d[p]/o,f[p],x[p]);else{g.multiDrawElementsInstancedWEBGL(n,f,0,r,d,0,x,0,m);let p=0;for(let M=0;M<m;M++)p+=f[M]*x[M];e.update(p,n,1)}}this.setMode=s,this.setIndex=a,this.render=l,this.renderInstances=c,this.renderMultiDraw=h,this.renderMultiDrawInstances=u}function ev(i){let t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,o,a){switch(e.calls++,o){case i.TRIANGLES:e.triangles+=a*(r/3);break;case i.LINES:e.lines+=a*(r/2);break;case i.LINE_STRIP:e.lines+=a*(r-1);break;case i.LINE_LOOP:e.lines+=a*r;break;case i.POINTS:e.points+=a*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",o);break}}function s(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:s,update:n}}function nv(i,t,e){let n=new WeakMap,s=new Me;function r(o,a,l){let c=o.morphTargetInfluences,h=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,u=h!==void 0?h.length:0,d=n.get(a);if(d===void 0||d.count!==u){let _=function(){T.dispose(),n.delete(a),a.removeEventListener("dispose",_)};d!==void 0&&d.texture.dispose();let f=a.morphAttributes.position!==void 0,m=a.morphAttributes.normal!==void 0,x=a.morphAttributes.color!==void 0,g=a.morphAttributes.position||[],p=a.morphAttributes.normal||[],M=a.morphAttributes.color||[],v=0;f===!0&&(v=1),m===!0&&(v=2),x===!0&&(v=3);let y=a.attributes.position.count*v,w=1;y>t.maxTextureSize&&(w=Math.ceil(y/t.maxTextureSize),y=t.maxTextureSize);let S=new Float32Array(y*w*4*u),T=new Ba(S,y,w,u);T.type=li,T.needsUpdate=!0;let R=v*4;for(let b=0;b<u;b++){let C=g[b],L=p[b],k=M[b],D=y*w*4*b;for(let V=0;V<C.count;V++){let z=V*R;f===!0&&(s.fromBufferAttribute(C,V),S[D+z+0]=s.x,S[D+z+1]=s.y,S[D+z+2]=s.z,S[D+z+3]=0),m===!0&&(s.fromBufferAttribute(L,V),S[D+z+4]=s.x,S[D+z+5]=s.y,S[D+z+6]=s.z,S[D+z+7]=0),x===!0&&(s.fromBufferAttribute(k,V),S[D+z+8]=s.x,S[D+z+9]=s.y,S[D+z+10]=s.z,S[D+z+11]=k.itemSize===4?s.w:1)}}d={count:u,texture:T,size:new rt(y,w)},n.set(a,d),a.addEventListener("dispose",_)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)l.getUniforms().setValue(i,"morphTexture",o.morphTexture,e);else{let f=0;for(let x=0;x<c.length;x++)f+=c[x];let m=a.morphTargetsRelative?1:1-f;l.getUniforms().setValue(i,"morphTargetBaseInfluence",m),l.getUniforms().setValue(i,"morphTargetInfluences",c)}l.getUniforms().setValue(i,"morphTargetsTexture",d.texture,e),l.getUniforms().setValue(i,"morphTargetsTextureSize",d.size)}return{update:r}}function iv(i,t,e,n){let s=new WeakMap;function r(l){let c=n.render.frame,h=l.geometry,u=t.get(l,h);if(s.get(u)!==c&&(t.update(u),s.set(u,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",a)===!1&&l.addEventListener("dispose",a),s.get(l)!==c&&(e.update(l.instanceMatrix,i.ARRAY_BUFFER),l.instanceColor!==null&&e.update(l.instanceColor,i.ARRAY_BUFFER),s.set(l,c))),l.isSkinnedMesh){let d=l.skeleton;s.get(d)!==c&&(d.update(),s.set(d,c))}return u}function o(){s=new WeakMap}function a(l){let c=l.target;c.removeEventListener("dispose",a),e.remove(c.instanceMatrix),c.instanceColor!==null&&e.remove(c.instanceColor)}return{update:r,dispose:o}}var $a=class extends mn{constructor(t,e,n,s,r,o,a,l,c,h=pr){if(h!==pr&&h!==_r)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&h===pr&&(n=ws),n===void 0&&h===_r&&(n=br),super(null,s,r,o,a,l,h,n,c),this.isDepthTexture=!0,this.image={width:t,height:e},this.magFilter=a!==void 0?a:In,this.minFilter=l!==void 0?l:In,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.compareFunction=t.compareFunction,this}toJSON(t){let e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}},tp=new mn,Qd=new $a(1,1),ep=new Ba,np=new bh,ip=new Ga,tf=[],ef=[],nf=new Float32Array(16),sf=new Float32Array(9),rf=new Float32Array(4);function Ir(i,t,e){let n=i[0];if(n<=0||n>0)return i;let s=t*e,r=tf[s];if(r===void 0&&(r=new Float32Array(s),tf[s]=r),t!==0){n.toArray(r,0);for(let o=1,a=0;o!==t;++o)a+=e,i[o].toArray(r,a)}return r}function $e(i,t){if(i.length!==t.length)return!1;for(let e=0,n=i.length;e<n;e++)if(i[e]!==t[e])return!1;return!0}function qe(i,t){for(let e=0,n=t.length;e<n;e++)i[e]=t[e]}function fl(i,t){let e=ef[t];e===void 0&&(e=new Int32Array(t),ef[t]=e);for(let n=0;n!==t;++n)e[n]=i.allocateTextureUnit();return e}function sv(i,t){let e=this.cache;e[0]!==t&&(i.uniform1f(this.addr,t),e[0]=t)}function rv(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if($e(e,t))return;i.uniform2fv(this.addr,t),qe(e,t)}}function ov(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(i.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if($e(e,t))return;i.uniform3fv(this.addr,t),qe(e,t)}}function av(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if($e(e,t))return;i.uniform4fv(this.addr,t),qe(e,t)}}function lv(i,t){let e=this.cache,n=t.elements;if(n===void 0){if($e(e,t))return;i.uniformMatrix2fv(this.addr,!1,t),qe(e,t)}else{if($e(e,n))return;rf.set(n),i.uniformMatrix2fv(this.addr,!1,rf),qe(e,n)}}function cv(i,t){let e=this.cache,n=t.elements;if(n===void 0){if($e(e,t))return;i.uniformMatrix3fv(this.addr,!1,t),qe(e,t)}else{if($e(e,n))return;sf.set(n),i.uniformMatrix3fv(this.addr,!1,sf),qe(e,n)}}function hv(i,t){let e=this.cache,n=t.elements;if(n===void 0){if($e(e,t))return;i.uniformMatrix4fv(this.addr,!1,t),qe(e,t)}else{if($e(e,n))return;nf.set(n),i.uniformMatrix4fv(this.addr,!1,nf),qe(e,n)}}function uv(i,t){let e=this.cache;e[0]!==t&&(i.uniform1i(this.addr,t),e[0]=t)}function dv(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if($e(e,t))return;i.uniform2iv(this.addr,t),qe(e,t)}}function fv(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if($e(e,t))return;i.uniform3iv(this.addr,t),qe(e,t)}}function pv(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if($e(e,t))return;i.uniform4iv(this.addr,t),qe(e,t)}}function mv(i,t){let e=this.cache;e[0]!==t&&(i.uniform1ui(this.addr,t),e[0]=t)}function gv(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if($e(e,t))return;i.uniform2uiv(this.addr,t),qe(e,t)}}function xv(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if($e(e,t))return;i.uniform3uiv(this.addr,t),qe(e,t)}}function yv(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if($e(e,t))return;i.uniform4uiv(this.addr,t),qe(e,t)}}function vv(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r;this.type===i.SAMPLER_2D_SHADOW?(Qd.compareFunction=Zf,r=Qd):r=tp,e.setTexture2D(t||r,s)}function bv(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture3D(t||np,s)}function _v(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTextureCube(t||ip,s)}function Mv(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture2DArray(t||ep,s)}function wv(i){switch(i){case 5126:return sv;case 35664:return rv;case 35665:return ov;case 35666:return av;case 35674:return lv;case 35675:return cv;case 35676:return hv;case 5124:case 35670:return uv;case 35667:case 35671:return dv;case 35668:case 35672:return fv;case 35669:case 35673:return pv;case 5125:return mv;case 36294:return gv;case 36295:return xv;case 36296:return yv;case 35678:case 36198:case 36298:case 36306:case 35682:return vv;case 35679:case 36299:case 36307:return bv;case 35680:case 36300:case 36308:case 36293:return _v;case 36289:case 36303:case 36311:case 36292:return Mv}}function Sv(i,t){i.uniform1fv(this.addr,t)}function Ev(i,t){let e=Ir(t,this.size,2);i.uniform2fv(this.addr,e)}function Tv(i,t){let e=Ir(t,this.size,3);i.uniform3fv(this.addr,e)}function Av(i,t){let e=Ir(t,this.size,4);i.uniform4fv(this.addr,e)}function Rv(i,t){let e=Ir(t,this.size,4);i.uniformMatrix2fv(this.addr,!1,e)}function Cv(i,t){let e=Ir(t,this.size,9);i.uniformMatrix3fv(this.addr,!1,e)}function Pv(i,t){let e=Ir(t,this.size,16);i.uniformMatrix4fv(this.addr,!1,e)}function Iv(i,t){i.uniform1iv(this.addr,t)}function Lv(i,t){i.uniform2iv(this.addr,t)}function kv(i,t){i.uniform3iv(this.addr,t)}function Dv(i,t){i.uniform4iv(this.addr,t)}function Uv(i,t){i.uniform1uiv(this.addr,t)}function Nv(i,t){i.uniform2uiv(this.addr,t)}function zv(i,t){i.uniform3uiv(this.addr,t)}function Fv(i,t){i.uniform4uiv(this.addr,t)}function Bv(i,t,e){let n=this.cache,s=t.length,r=fl(e,s);$e(n,r)||(i.uniform1iv(this.addr,r),qe(n,r));for(let o=0;o!==s;++o)e.setTexture2D(t[o]||tp,r[o])}function Ov(i,t,e){let n=this.cache,s=t.length,r=fl(e,s);$e(n,r)||(i.uniform1iv(this.addr,r),qe(n,r));for(let o=0;o!==s;++o)e.setTexture3D(t[o]||np,r[o])}function Hv(i,t,e){let n=this.cache,s=t.length,r=fl(e,s);$e(n,r)||(i.uniform1iv(this.addr,r),qe(n,r));for(let o=0;o!==s;++o)e.setTextureCube(t[o]||ip,r[o])}function Vv(i,t,e){let n=this.cache,s=t.length,r=fl(e,s);$e(n,r)||(i.uniform1iv(this.addr,r),qe(n,r));for(let o=0;o!==s;++o)e.setTexture2DArray(t[o]||ep,r[o])}function Gv(i){switch(i){case 5126:return Sv;case 35664:return Ev;case 35665:return Tv;case 35666:return Av;case 35674:return Rv;case 35675:return Cv;case 35676:return Pv;case 5124:case 35670:return Iv;case 35667:case 35671:return Lv;case 35668:case 35672:return kv;case 35669:case 35673:return Dv;case 5125:return Uv;case 36294:return Nv;case 36295:return zv;case 36296:return Fv;case 35678:case 36198:case 36298:case 36306:case 35682:return Bv;case 35679:case 36299:case 36307:return Ov;case 35680:case 36300:case 36308:case 36293:return Hv;case 36289:case 36303:case 36311:case 36292:return Vv}}var wh=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=wv(e.type)}},Sh=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=Gv(e.type)}},Eh=class{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){let s=this.seq;for(let r=0,o=s.length;r!==o;++r){let a=s[r];a.setValue(t,e[a.id],n)}}},Ec=/(\w+)(\])?(\[|\.)?/g;function of(i,t){i.seq.push(t),i.map[t.id]=t}function Wv(i,t,e){let n=i.name,s=n.length;for(Ec.lastIndex=0;;){let r=Ec.exec(n),o=Ec.lastIndex,a=r[1],l=r[2]==="]",c=r[3];if(l&&(a=a|0),c===void 0||c==="["&&o+2===s){of(e,c===void 0?new wh(a,i,t):new Sh(a,i,t));break}else{let u=e.map[a];u===void 0&&(u=new Eh(a),of(e,u)),e=u}}}var gr=class{constructor(t,e){this.seq=[],this.map={};let n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let s=0;s<n;++s){let r=t.getActiveUniform(e,s),o=t.getUniformLocation(e,r.name);Wv(r,o,this)}}setValue(t,e,n,s){let r=this.map[e];r!==void 0&&r.setValue(t,n,s)}setOptional(t,e,n){let s=e[n];s!==void 0&&this.setValue(t,n,s)}static upload(t,e,n,s){for(let r=0,o=e.length;r!==o;++r){let a=e[r],l=n[a.id];l.needsUpdate!==!1&&a.setValue(t,l.value,s)}}static seqWithValue(t,e){let n=[];for(let s=0,r=t.length;s!==r;++s){let o=t[s];o.id in e&&n.push(o)}return n}};function af(i,t,e){let n=i.createShader(t);return i.shaderSource(n,e),i.compileShader(n),n}var $v=37297,qv=0;function Xv(i,t){let e=i.split(`
`),n=[],s=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let o=s;o<r;o++){let a=o+1;n.push(`${a===t?">":" "} ${a}: ${e[o]}`)}return n.join(`
`)}var lf=new $t;function Yv(i){re._getMatrix(lf,re.workingColorSpace,i);let t=`mat3( ${lf.elements.map(e=>e.toFixed(4))} )`;switch(re.getTransfer(i)){case dl:return[t,"LinearTransferOETF"];case pe:return[t,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",i),[t,"LinearTransferOETF"]}}function cf(i,t,e){let n=i.getShaderParameter(t,i.COMPILE_STATUS),s=i.getShaderInfoLog(t).trim();if(n&&s==="")return"";let r=/ERROR: 0:(\d+)/.exec(s);if(r){let o=parseInt(r[1]);return e.toUpperCase()+`

`+s+`

`+Xv(i.getShaderSource(t),o)}else return s}function Zv(i,t){let e=Yv(t);return[`vec4 ${i}( vec4 value ) {`,`	return ${e[1]}( vec4( value.rgb * ${e[0]}, value.a ) );`,"}"].join(`
`)}function Kv(i,t){let e;switch(t){case l0:e="Linear";break;case c0:e="Reinhard";break;case h0:e="Cineon";break;case su:e="ACESFilmic";break;case d0:e="AgX";break;case f0:e="Neutral";break;case u0:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+i+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}var va=new P;function Jv(){re.getLuminanceCoefficients(va);let i=va.x.toFixed(4),t=va.y.toFixed(4),e=va.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${t}, ${e} );`,"	return dot( weights, rgb );","}"].join(`
`)}function jv(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(so).join(`
`)}function Qv(i){let t=[];for(let e in i){let n=i[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function tb(i,t){let e={},n=i.getProgramParameter(t,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){let r=i.getActiveAttrib(t,s),o=r.name,a=1;r.type===i.FLOAT_MAT2&&(a=2),r.type===i.FLOAT_MAT3&&(a=3),r.type===i.FLOAT_MAT4&&(a=4),e[o]={type:r.type,location:i.getAttribLocation(t,o),locationSize:a}}return e}function so(i){return i!==""}function hf(i,t){let e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function uf(i,t){return i.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var eb=/^[ \t]*#include +<([\w\d./]+)>/gm;function Th(i){return i.replace(eb,ib)}var nb=new Map;function ib(i,t){let e=Kt[t];if(e===void 0){let n=nb.get(t);if(n!==void 0)e=Kt[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("Can not resolve #include <"+t+">")}return Th(e)}var sb=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function df(i){return i.replace(sb,rb)}function rb(i,t,e,n){let s="";for(let r=parseInt(t);r<parseInt(e);r++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function ff(i){let t=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?t+=`
#define HIGH_PRECISION`:i.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function ob(i){let t="SHADOWMAP_TYPE_BASIC";return i.shadowMapType===Nf?t="SHADOWMAP_TYPE_PCF":i.shadowMapType===iu?t="SHADOWMAP_TYPE_PCF_SOFT":i.shadowMapType===Ti&&(t="SHADOWMAP_TYPE_VSM"),t}function ab(i){let t="ENVMAP_TYPE_CUBE";if(i.envMap)switch(i.envMapMode){case yr:case vr:t="ENVMAP_TYPE_CUBE";break;case ul:t="ENVMAP_TYPE_CUBE_UV";break}return t}function lb(i){let t="ENVMAP_MODE_REFLECTION";if(i.envMap)switch(i.envMapMode){case vr:t="ENVMAP_MODE_REFRACTION";break}return t}function cb(i){let t="ENVMAP_BLENDING_NONE";if(i.envMap)switch(i.combine){case zf:t="ENVMAP_BLENDING_MULTIPLY";break;case o0:t="ENVMAP_BLENDING_MIX";break;case a0:t="ENVMAP_BLENDING_ADD";break}return t}function hb(i){let t=i.envMapCubeUVHeight;if(t===null)return null;let e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),7*16)),texelHeight:n,maxMip:e}}function ub(i,t,e,n){let s=i.getContext(),r=e.defines,o=e.vertexShader,a=e.fragmentShader,l=ob(e),c=ab(e),h=lb(e),u=cb(e),d=hb(e),f=jv(e),m=Qv(r),x=s.createProgram(),g,p,M=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(g=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,m].filter(so).join(`
`),g.length>0&&(g+=`
`),p=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,m].filter(so).join(`
`),p.length>0&&(p+=`
`)):(g=[ff(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,m,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.batchingColor?"#define USE_BATCHING_COLOR":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.instancingMorph?"#define USE_INSTANCING_MORPH":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(so).join(`
`),p=[ff(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,m,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+c:"",e.envMap?"#define "+h:"",e.envMap?"#define "+u:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.dispersion?"#define USE_DISPERSION":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor||e.batchingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==ji?"#define TONE_MAPPING":"",e.toneMapping!==ji?Kt.tonemapping_pars_fragment:"",e.toneMapping!==ji?Kv("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",Kt.colorspace_pars_fragment,Zv("linearToOutputTexel",e.outputColorSpace),Jv(),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(so).join(`
`)),o=Th(o),o=hf(o,e),o=uf(o,e),a=Th(a),a=hf(a,e),a=uf(a,e),o=df(o),a=df(a),e.isRawShaderMaterial!==!0&&(M=`#version 300 es
`,g=[f,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+g,p=["#define varying in",e.glslVersion===Ed?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===Ed?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+p);let v=M+g+o,y=M+p+a,w=af(s,s.VERTEX_SHADER,v),S=af(s,s.FRAGMENT_SHADER,y);s.attachShader(x,w),s.attachShader(x,S),e.index0AttributeName!==void 0?s.bindAttribLocation(x,0,e.index0AttributeName):e.morphTargets===!0&&s.bindAttribLocation(x,0,"position"),s.linkProgram(x);function T(C){if(i.debug.checkShaderErrors){let L=s.getProgramInfoLog(x).trim(),k=s.getShaderInfoLog(w).trim(),D=s.getShaderInfoLog(S).trim(),V=!0,z=!0;if(s.getProgramParameter(x,s.LINK_STATUS)===!1)if(V=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,x,w,S);else{let G=cf(s,w,"vertex"),F=cf(s,S,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(x,s.VALIDATE_STATUS)+`

Material Name: `+C.name+`
Material Type: `+C.type+`

Program Info Log: `+L+`
`+G+`
`+F)}else L!==""?console.warn("THREE.WebGLProgram: Program Info Log:",L):(k===""||D==="")&&(z=!1);z&&(C.diagnostics={runnable:V,programLog:L,vertexShader:{log:k,prefix:g},fragmentShader:{log:D,prefix:p}})}s.deleteShader(w),s.deleteShader(S),R=new gr(s,x),_=tb(s,x)}let R;this.getUniforms=function(){return R===void 0&&T(this),R};let _;this.getAttributes=function(){return _===void 0&&T(this),_};let b=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return b===!1&&(b=s.getProgramParameter(x,$v)),b},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(x),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=qv++,this.cacheKey=t,this.usedTimes=1,this.program=x,this.vertexShader=w,this.fragmentShader=S,this}var db=0,Ah=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){let e=t.vertexShader,n=t.fragmentShader,s=this._getShaderStage(e),r=this._getShaderStage(n),o=this._getShaderCacheForMaterial(t);return o.has(s)===!1&&(o.add(s),s.usedTimes++),o.has(r)===!1&&(o.add(r),r.usedTimes++),this}remove(t){let e=this.materialCache.get(t);for(let n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){let e=this.materialCache,n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){let e=this.shaderCache,n=e.get(t);return n===void 0&&(n=new Rh(t),e.set(t,n)),n}},Rh=class{constructor(t){this.id=db++,this.code=t,this.usedTimes=0}};function fb(i,t,e,n,s,r,o){let a=new mo,l=new Ah,c=new Set,h=[],u=s.logarithmicDepthBuffer,d=s.vertexTextures,f=s.precision,m={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function x(_){return c.add(_),_===0?"uv":`uv${_}`}function g(_,b,C,L,k){let D=L.fog,V=k.geometry,z=_.isMeshStandardMaterial?L.environment:null,G=(_.isMeshStandardMaterial?e:t).get(_.envMap||z),F=G&&G.mapping===ul?G.image.height:null,K=m[_.type];_.precision!==null&&(f=s.getMaxPrecision(_.precision),f!==_.precision&&console.warn("THREE.WebGLProgram.getParameters:",_.precision,"not supported, using",f,"instead."));let Q=V.morphAttributes.position||V.morphAttributes.normal||V.morphAttributes.color,ot=Q!==void 0?Q.length:0,St=0;V.morphAttributes.position!==void 0&&(St=1),V.morphAttributes.normal!==void 0&&(St=2),V.morphAttributes.color!==void 0&&(St=3);let Vt,Y,et,Mt;if(K){let de=ai[K];Vt=de.vertexShader,Y=de.fragmentShader}else Vt=_.vertexShader,Y=_.fragmentShader,l.update(_),et=l.getVertexShaderID(_),Mt=l.getFragmentShaderID(_);let ht=i.getRenderTarget(),Nt=i.state.buffers.depth.getReversed(),Ot=k.isInstancedMesh===!0,Jt=k.isBatchedMesh===!0,Ee=!!_.map,ie=!!_.matcap,Ne=!!G,H=!!_.aoMap,Bn=!!_.lightMap,te=!!_.bumpMap,ee=!!_.normalMap,Dt=!!_.displacementMap,ve=!!_.emissiveMap,Lt=!!_.metalnessMap,I=!!_.roughnessMap,E=_.anisotropy>0,W=_.clearcoat>0,J=_.dispersion>0,tt=_.iridescence>0,Z=_.sheen>0,Rt=_.transmission>0,ut=E&&!!_.anisotropyMap,gt=W&&!!_.clearcoatMap,se=W&&!!_.clearcoatNormalMap,it=W&&!!_.clearcoatRoughnessMap,yt=tt&&!!_.iridescenceMap,Ut=tt&&!!_.iridescenceThicknessMap,Ft=Z&&!!_.sheenColorMap,vt=Z&&!!_.sheenRoughnessMap,ne=!!_.specularMap,Zt=!!_.specularColorMap,ge=!!_.specularIntensityMap,N=Rt&&!!_.transmissionMap,ct=Rt&&!!_.thicknessMap,X=!!_.gradientMap,j=!!_.alphaMap,mt=_.alphaTest>0,dt=!!_.alphaHash,Gt=!!_.extensions,Le=ji;_.toneMapped&&(ht===null||ht.isXRRenderTarget===!0)&&(Le=i.toneMapping);let je={shaderID:K,shaderType:_.type,shaderName:_.name,vertexShader:Vt,fragmentShader:Y,defines:_.defines,customVertexShaderID:et,customFragmentShaderID:Mt,isRawShaderMaterial:_.isRawShaderMaterial===!0,glslVersion:_.glslVersion,precision:f,batching:Jt,batchingColor:Jt&&k._colorsTexture!==null,instancing:Ot,instancingColor:Ot&&k.instanceColor!==null,instancingMorph:Ot&&k.morphTexture!==null,supportsVertexTextures:d,outputColorSpace:ht===null?i.outputColorSpace:ht.isXRRenderTarget===!0?ht.texture.colorSpace:Rr,alphaToCoverage:!!_.alphaToCoverage,map:Ee,matcap:ie,envMap:Ne,envMapMode:Ne&&G.mapping,envMapCubeUVHeight:F,aoMap:H,lightMap:Bn,bumpMap:te,normalMap:ee,displacementMap:d&&Dt,emissiveMap:ve,normalMapObjectSpace:ee&&_.normalMapType===x0,normalMapTangentSpace:ee&&_.normalMapType===Yf,metalnessMap:Lt,roughnessMap:I,anisotropy:E,anisotropyMap:ut,clearcoat:W,clearcoatMap:gt,clearcoatNormalMap:se,clearcoatRoughnessMap:it,dispersion:J,iridescence:tt,iridescenceMap:yt,iridescenceThicknessMap:Ut,sheen:Z,sheenColorMap:Ft,sheenRoughnessMap:vt,specularMap:ne,specularColorMap:Zt,specularIntensityMap:ge,transmission:Rt,transmissionMap:N,thicknessMap:ct,gradientMap:X,opaque:_.transparent===!1&&_.blending===fr&&_.alphaToCoverage===!1,alphaMap:j,alphaTest:mt,alphaHash:dt,combine:_.combine,mapUv:Ee&&x(_.map.channel),aoMapUv:H&&x(_.aoMap.channel),lightMapUv:Bn&&x(_.lightMap.channel),bumpMapUv:te&&x(_.bumpMap.channel),normalMapUv:ee&&x(_.normalMap.channel),displacementMapUv:Dt&&x(_.displacementMap.channel),emissiveMapUv:ve&&x(_.emissiveMap.channel),metalnessMapUv:Lt&&x(_.metalnessMap.channel),roughnessMapUv:I&&x(_.roughnessMap.channel),anisotropyMapUv:ut&&x(_.anisotropyMap.channel),clearcoatMapUv:gt&&x(_.clearcoatMap.channel),clearcoatNormalMapUv:se&&x(_.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:it&&x(_.clearcoatRoughnessMap.channel),iridescenceMapUv:yt&&x(_.iridescenceMap.channel),iridescenceThicknessMapUv:Ut&&x(_.iridescenceThicknessMap.channel),sheenColorMapUv:Ft&&x(_.sheenColorMap.channel),sheenRoughnessMapUv:vt&&x(_.sheenRoughnessMap.channel),specularMapUv:ne&&x(_.specularMap.channel),specularColorMapUv:Zt&&x(_.specularColorMap.channel),specularIntensityMapUv:ge&&x(_.specularIntensityMap.channel),transmissionMapUv:N&&x(_.transmissionMap.channel),thicknessMapUv:ct&&x(_.thicknessMap.channel),alphaMapUv:j&&x(_.alphaMap.channel),vertexTangents:!!V.attributes.tangent&&(ee||E),vertexColors:_.vertexColors,vertexAlphas:_.vertexColors===!0&&!!V.attributes.color&&V.attributes.color.itemSize===4,pointsUvs:k.isPoints===!0&&!!V.attributes.uv&&(Ee||j),fog:!!D,useFog:_.fog===!0,fogExp2:!!D&&D.isFogExp2,flatShading:_.flatShading===!0,sizeAttenuation:_.sizeAttenuation===!0,logarithmicDepthBuffer:u,reverseDepthBuffer:Nt,skinning:k.isSkinnedMesh===!0,morphTargets:V.morphAttributes.position!==void 0,morphNormals:V.morphAttributes.normal!==void 0,morphColors:V.morphAttributes.color!==void 0,morphTargetsCount:ot,morphTextureStride:St,numDirLights:b.directional.length,numPointLights:b.point.length,numSpotLights:b.spot.length,numSpotLightMaps:b.spotLightMap.length,numRectAreaLights:b.rectArea.length,numHemiLights:b.hemi.length,numDirLightShadows:b.directionalShadowMap.length,numPointLightShadows:b.pointShadowMap.length,numSpotLightShadows:b.spotShadowMap.length,numSpotLightShadowsWithMaps:b.numSpotLightShadowsWithMaps,numLightProbes:b.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:_.dithering,shadowMapEnabled:i.shadowMap.enabled&&C.length>0,shadowMapType:i.shadowMap.type,toneMapping:Le,decodeVideoTexture:Ee&&_.map.isVideoTexture===!0&&re.getTransfer(_.map.colorSpace)===pe,decodeVideoTextureEmissive:ve&&_.emissiveMap.isVideoTexture===!0&&re.getTransfer(_.emissiveMap.colorSpace)===pe,premultipliedAlpha:_.premultipliedAlpha,doubleSided:_.side===Te,flipSided:_.side===en,useDepthPacking:_.depthPacking>=0,depthPacking:_.depthPacking||0,index0AttributeName:_.index0AttributeName,extensionClipCullDistance:Gt&&_.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Gt&&_.extensions.multiDraw===!0||Jt)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:_.customProgramCacheKey()};return je.vertexUv1s=c.has(1),je.vertexUv2s=c.has(2),je.vertexUv3s=c.has(3),c.clear(),je}function p(_){let b=[];if(_.shaderID?b.push(_.shaderID):(b.push(_.customVertexShaderID),b.push(_.customFragmentShaderID)),_.defines!==void 0)for(let C in _.defines)b.push(C),b.push(_.defines[C]);return _.isRawShaderMaterial===!1&&(M(b,_),v(b,_),b.push(i.outputColorSpace)),b.push(_.customProgramCacheKey),b.join()}function M(_,b){_.push(b.precision),_.push(b.outputColorSpace),_.push(b.envMapMode),_.push(b.envMapCubeUVHeight),_.push(b.mapUv),_.push(b.alphaMapUv),_.push(b.lightMapUv),_.push(b.aoMapUv),_.push(b.bumpMapUv),_.push(b.normalMapUv),_.push(b.displacementMapUv),_.push(b.emissiveMapUv),_.push(b.metalnessMapUv),_.push(b.roughnessMapUv),_.push(b.anisotropyMapUv),_.push(b.clearcoatMapUv),_.push(b.clearcoatNormalMapUv),_.push(b.clearcoatRoughnessMapUv),_.push(b.iridescenceMapUv),_.push(b.iridescenceThicknessMapUv),_.push(b.sheenColorMapUv),_.push(b.sheenRoughnessMapUv),_.push(b.specularMapUv),_.push(b.specularColorMapUv),_.push(b.specularIntensityMapUv),_.push(b.transmissionMapUv),_.push(b.thicknessMapUv),_.push(b.combine),_.push(b.fogExp2),_.push(b.sizeAttenuation),_.push(b.morphTargetsCount),_.push(b.morphAttributeCount),_.push(b.numDirLights),_.push(b.numPointLights),_.push(b.numSpotLights),_.push(b.numSpotLightMaps),_.push(b.numHemiLights),_.push(b.numRectAreaLights),_.push(b.numDirLightShadows),_.push(b.numPointLightShadows),_.push(b.numSpotLightShadows),_.push(b.numSpotLightShadowsWithMaps),_.push(b.numLightProbes),_.push(b.shadowMapType),_.push(b.toneMapping),_.push(b.numClippingPlanes),_.push(b.numClipIntersection),_.push(b.depthPacking)}function v(_,b){a.disableAll(),b.supportsVertexTextures&&a.enable(0),b.instancing&&a.enable(1),b.instancingColor&&a.enable(2),b.instancingMorph&&a.enable(3),b.matcap&&a.enable(4),b.envMap&&a.enable(5),b.normalMapObjectSpace&&a.enable(6),b.normalMapTangentSpace&&a.enable(7),b.clearcoat&&a.enable(8),b.iridescence&&a.enable(9),b.alphaTest&&a.enable(10),b.vertexColors&&a.enable(11),b.vertexAlphas&&a.enable(12),b.vertexUv1s&&a.enable(13),b.vertexUv2s&&a.enable(14),b.vertexUv3s&&a.enable(15),b.vertexTangents&&a.enable(16),b.anisotropy&&a.enable(17),b.alphaHash&&a.enable(18),b.batching&&a.enable(19),b.dispersion&&a.enable(20),b.batchingColor&&a.enable(21),_.push(a.mask),a.disableAll(),b.fog&&a.enable(0),b.useFog&&a.enable(1),b.flatShading&&a.enable(2),b.logarithmicDepthBuffer&&a.enable(3),b.reverseDepthBuffer&&a.enable(4),b.skinning&&a.enable(5),b.morphTargets&&a.enable(6),b.morphNormals&&a.enable(7),b.morphColors&&a.enable(8),b.premultipliedAlpha&&a.enable(9),b.shadowMapEnabled&&a.enable(10),b.doubleSided&&a.enable(11),b.flipSided&&a.enable(12),b.useDepthPacking&&a.enable(13),b.dithering&&a.enable(14),b.transmission&&a.enable(15),b.sheen&&a.enable(16),b.opaque&&a.enable(17),b.pointsUvs&&a.enable(18),b.decodeVideoTexture&&a.enable(19),b.decodeVideoTextureEmissive&&a.enable(20),b.alphaToCoverage&&a.enable(21),_.push(a.mask)}function y(_){let b=m[_.type],C;if(b){let L=ai[b];C=Pr.clone(L.uniforms)}else C=_.uniforms;return C}function w(_,b){let C;for(let L=0,k=h.length;L<k;L++){let D=h[L];if(D.cacheKey===b){C=D,++C.usedTimes;break}}return C===void 0&&(C=new ub(i,b,_,r),h.push(C)),C}function S(_){if(--_.usedTimes===0){let b=h.indexOf(_);h[b]=h[h.length-1],h.pop(),_.destroy()}}function T(_){l.remove(_)}function R(){l.dispose()}return{getParameters:g,getProgramCacheKey:p,getUniforms:y,acquireProgram:w,releaseProgram:S,releaseShaderCache:T,programs:h,dispose:R}}function pb(){let i=new WeakMap;function t(o){return i.has(o)}function e(o){let a=i.get(o);return a===void 0&&(a={},i.set(o,a)),a}function n(o){i.delete(o)}function s(o,a,l){i.get(o)[a]=l}function r(){i=new WeakMap}return{has:t,get:e,remove:n,update:s,dispose:r}}function mb(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.material.id!==t.material.id?i.material.id-t.material.id:i.z!==t.z?i.z-t.z:i.id-t.id}function pf(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.z!==t.z?t.z-i.z:i.id-t.id}function mf(){let i=[],t=0,e=[],n=[],s=[];function r(){t=0,e.length=0,n.length=0,s.length=0}function o(u,d,f,m,x,g){let p=i[t];return p===void 0?(p={id:u.id,object:u,geometry:d,material:f,groupOrder:m,renderOrder:u.renderOrder,z:x,group:g},i[t]=p):(p.id=u.id,p.object=u,p.geometry=d,p.material=f,p.groupOrder=m,p.renderOrder=u.renderOrder,p.z=x,p.group=g),t++,p}function a(u,d,f,m,x,g){let p=o(u,d,f,m,x,g);f.transmission>0?n.push(p):f.transparent===!0?s.push(p):e.push(p)}function l(u,d,f,m,x,g){let p=o(u,d,f,m,x,g);f.transmission>0?n.unshift(p):f.transparent===!0?s.unshift(p):e.unshift(p)}function c(u,d){e.length>1&&e.sort(u||mb),n.length>1&&n.sort(d||pf),s.length>1&&s.sort(d||pf)}function h(){for(let u=t,d=i.length;u<d;u++){let f=i[u];if(f.id===null)break;f.id=null,f.object=null,f.geometry=null,f.material=null,f.group=null}}return{opaque:e,transmissive:n,transparent:s,init:r,push:a,unshift:l,finish:h,sort:c}}function gb(){let i=new WeakMap;function t(n,s){let r=i.get(n),o;return r===void 0?(o=new mf,i.set(n,[o])):s>=r.length?(o=new mf,r.push(o)):o=r[s],o}function e(){i=new WeakMap}return{get:t,dispose:e}}function xb(){let i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new P,color:new wt};break;case"SpotLight":e={position:new P,direction:new P,color:new wt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new P,color:new wt,distance:0,decay:0};break;case"HemisphereLight":e={direction:new P,skyColor:new wt,groundColor:new wt};break;case"RectAreaLight":e={color:new wt,position:new P,halfWidth:new P,halfHeight:new P};break}return i[t.id]=e,e}}}function yb(){let i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new rt};break;case"SpotLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new rt};break;case"PointLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new rt,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[t.id]=e,e}}}var vb=0;function bb(i,t){return(t.castShadow?2:0)-(i.castShadow?2:0)+(t.map?1:0)-(i.map?1:0)}function _b(i){let t=new xb,e=yb(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new P);let s=new P,r=new qt,o=new qt;function a(c){let h=0,u=0,d=0;for(let _=0;_<9;_++)n.probe[_].set(0,0,0);let f=0,m=0,x=0,g=0,p=0,M=0,v=0,y=0,w=0,S=0,T=0;c.sort(bb);for(let _=0,b=c.length;_<b;_++){let C=c[_],L=C.color,k=C.intensity,D=C.distance,V=C.shadow&&C.shadow.map?C.shadow.map.texture:null;if(C.isAmbientLight)h+=L.r*k,u+=L.g*k,d+=L.b*k;else if(C.isLightProbe){for(let z=0;z<9;z++)n.probe[z].addScaledVector(C.sh.coefficients[z],k);T++}else if(C.isDirectionalLight){let z=t.get(C);if(z.color.copy(C.color).multiplyScalar(C.intensity),C.castShadow){let G=C.shadow,F=e.get(C);F.shadowIntensity=G.intensity,F.shadowBias=G.bias,F.shadowNormalBias=G.normalBias,F.shadowRadius=G.radius,F.shadowMapSize=G.mapSize,n.directionalShadow[f]=F,n.directionalShadowMap[f]=V,n.directionalShadowMatrix[f]=C.shadow.matrix,M++}n.directional[f]=z,f++}else if(C.isSpotLight){let z=t.get(C);z.position.setFromMatrixPosition(C.matrixWorld),z.color.copy(L).multiplyScalar(k),z.distance=D,z.coneCos=Math.cos(C.angle),z.penumbraCos=Math.cos(C.angle*(1-C.penumbra)),z.decay=C.decay,n.spot[x]=z;let G=C.shadow;if(C.map&&(n.spotLightMap[w]=C.map,w++,G.updateMatrices(C),C.castShadow&&S++),n.spotLightMatrix[x]=G.matrix,C.castShadow){let F=e.get(C);F.shadowIntensity=G.intensity,F.shadowBias=G.bias,F.shadowNormalBias=G.normalBias,F.shadowRadius=G.radius,F.shadowMapSize=G.mapSize,n.spotShadow[x]=F,n.spotShadowMap[x]=V,y++}x++}else if(C.isRectAreaLight){let z=t.get(C);z.color.copy(L).multiplyScalar(k),z.halfWidth.set(C.width*.5,0,0),z.halfHeight.set(0,C.height*.5,0),n.rectArea[g]=z,g++}else if(C.isPointLight){let z=t.get(C);if(z.color.copy(C.color).multiplyScalar(C.intensity),z.distance=C.distance,z.decay=C.decay,C.castShadow){let G=C.shadow,F=e.get(C);F.shadowIntensity=G.intensity,F.shadowBias=G.bias,F.shadowNormalBias=G.normalBias,F.shadowRadius=G.radius,F.shadowMapSize=G.mapSize,F.shadowCameraNear=G.camera.near,F.shadowCameraFar=G.camera.far,n.pointShadow[m]=F,n.pointShadowMap[m]=V,n.pointShadowMatrix[m]=C.shadow.matrix,v++}n.point[m]=z,m++}else if(C.isHemisphereLight){let z=t.get(C);z.skyColor.copy(C.color).multiplyScalar(k),z.groundColor.copy(C.groundColor).multiplyScalar(k),n.hemi[p]=z,p++}}g>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=lt.LTC_FLOAT_1,n.rectAreaLTC2=lt.LTC_FLOAT_2):(n.rectAreaLTC1=lt.LTC_HALF_1,n.rectAreaLTC2=lt.LTC_HALF_2)),n.ambient[0]=h,n.ambient[1]=u,n.ambient[2]=d;let R=n.hash;(R.directionalLength!==f||R.pointLength!==m||R.spotLength!==x||R.rectAreaLength!==g||R.hemiLength!==p||R.numDirectionalShadows!==M||R.numPointShadows!==v||R.numSpotShadows!==y||R.numSpotMaps!==w||R.numLightProbes!==T)&&(n.directional.length=f,n.spot.length=x,n.rectArea.length=g,n.point.length=m,n.hemi.length=p,n.directionalShadow.length=M,n.directionalShadowMap.length=M,n.pointShadow.length=v,n.pointShadowMap.length=v,n.spotShadow.length=y,n.spotShadowMap.length=y,n.directionalShadowMatrix.length=M,n.pointShadowMatrix.length=v,n.spotLightMatrix.length=y+w-S,n.spotLightMap.length=w,n.numSpotLightShadowsWithMaps=S,n.numLightProbes=T,R.directionalLength=f,R.pointLength=m,R.spotLength=x,R.rectAreaLength=g,R.hemiLength=p,R.numDirectionalShadows=M,R.numPointShadows=v,R.numSpotShadows=y,R.numSpotMaps=w,R.numLightProbes=T,n.version=vb++)}function l(c,h){let u=0,d=0,f=0,m=0,x=0,g=h.matrixWorldInverse;for(let p=0,M=c.length;p<M;p++){let v=c[p];if(v.isDirectionalLight){let y=n.directional[u];y.direction.setFromMatrixPosition(v.matrixWorld),s.setFromMatrixPosition(v.target.matrixWorld),y.direction.sub(s),y.direction.transformDirection(g),u++}else if(v.isSpotLight){let y=n.spot[f];y.position.setFromMatrixPosition(v.matrixWorld),y.position.applyMatrix4(g),y.direction.setFromMatrixPosition(v.matrixWorld),s.setFromMatrixPosition(v.target.matrixWorld),y.direction.sub(s),y.direction.transformDirection(g),f++}else if(v.isRectAreaLight){let y=n.rectArea[m];y.position.setFromMatrixPosition(v.matrixWorld),y.position.applyMatrix4(g),o.identity(),r.copy(v.matrixWorld),r.premultiply(g),o.extractRotation(r),y.halfWidth.set(v.width*.5,0,0),y.halfHeight.set(0,v.height*.5,0),y.halfWidth.applyMatrix4(o),y.halfHeight.applyMatrix4(o),m++}else if(v.isPointLight){let y=n.point[d];y.position.setFromMatrixPosition(v.matrixWorld),y.position.applyMatrix4(g),d++}else if(v.isHemisphereLight){let y=n.hemi[x];y.direction.setFromMatrixPosition(v.matrixWorld),y.direction.transformDirection(g),x++}}}return{setup:a,setupView:l,state:n}}function gf(i){let t=new _b(i),e=[],n=[];function s(h){c.camera=h,e.length=0,n.length=0}function r(h){e.push(h)}function o(h){n.push(h)}function a(){t.setup(e)}function l(h){t.setupView(e,h)}let c={lightsArray:e,shadowsArray:n,camera:null,lights:t,transmissionRenderTarget:{}};return{init:s,state:c,setupLights:a,setupLightsView:l,pushLight:r,pushShadow:o}}function Mb(i){let t=new WeakMap;function e(s,r=0){let o=t.get(s),a;return o===void 0?(a=new gf(i),t.set(s,[a])):r>=o.length?(a=new gf(i),o.push(a)):a=o[r],a}function n(){t=new WeakMap}return{get:e,dispose:n}}var Ch=class extends Li{static get type(){return"MeshDepthMaterial"}constructor(t){super(),this.isMeshDepthMaterial=!0,this.depthPacking=m0,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}},Ph=class extends Li{static get type(){return"MeshDistanceMaterial"}constructor(t){super(),this.isMeshDistanceMaterial=!0,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}},wb=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Sb=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function Eb(i,t,e){let n=new go,s=new rt,r=new rt,o=new Me,a=new Ch({depthPacking:g0}),l=new Ph,c={},h=e.maxTextureSize,u={[hi]:en,[en]:hi,[Te]:Te},d=new xn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new rt},radius:{value:4}},vertexShader:wb,fragmentShader:Sb}),f=d.clone();f.defines.HORIZONTAL_PASS=1;let m=new ce;m.setAttribute("position",new Oe(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let x=new nt(m,d),g=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Nf;let p=this.type;this.render=function(S,T,R){if(g.enabled===!1||g.autoUpdate===!1&&g.needsUpdate===!1||S.length===0)return;let _=i.getRenderTarget(),b=i.getActiveCubeFace(),C=i.getActiveMipmapLevel(),L=i.state;L.setBlending(Ji),L.buffers.color.setClear(1,1,1,1),L.buffers.depth.setTest(!0),L.setScissorTest(!1);let k=p!==Ti&&this.type===Ti,D=p===Ti&&this.type!==Ti;for(let V=0,z=S.length;V<z;V++){let G=S[V],F=G.shadow;if(F===void 0){console.warn("THREE.WebGLShadowMap:",G,"has no shadow.");continue}if(F.autoUpdate===!1&&F.needsUpdate===!1)continue;s.copy(F.mapSize);let K=F.getFrameExtents();if(s.multiply(K),r.copy(F.mapSize),(s.x>h||s.y>h)&&(s.x>h&&(r.x=Math.floor(h/K.x),s.x=r.x*K.x,F.mapSize.x=r.x),s.y>h&&(r.y=Math.floor(h/K.y),s.y=r.y*K.y,F.mapSize.y=r.y)),F.map===null||k===!0||D===!0){let ot=this.type!==Ti?{minFilter:In,magFilter:In}:{};F.map!==null&&F.map.dispose(),F.map=new Qn(s.x,s.y,ot),F.map.texture.name=G.name+".shadowMap",F.camera.updateProjectionMatrix()}i.setRenderTarget(F.map),i.clear();let Q=F.getViewportCount();for(let ot=0;ot<Q;ot++){let St=F.getViewport(ot);o.set(r.x*St.x,r.y*St.y,r.x*St.z,r.y*St.w),L.viewport(o),F.updateMatrices(G,ot),n=F.getFrustum(),y(T,R,F.camera,G,this.type)}F.isPointLightShadow!==!0&&this.type===Ti&&M(F,R),F.needsUpdate=!1}p=this.type,g.needsUpdate=!1,i.setRenderTarget(_,b,C)};function M(S,T){let R=t.update(x);d.defines.VSM_SAMPLES!==S.blurSamples&&(d.defines.VSM_SAMPLES=S.blurSamples,f.defines.VSM_SAMPLES=S.blurSamples,d.needsUpdate=!0,f.needsUpdate=!0),S.mapPass===null&&(S.mapPass=new Qn(s.x,s.y)),d.uniforms.shadow_pass.value=S.map.texture,d.uniforms.resolution.value=S.mapSize,d.uniforms.radius.value=S.radius,i.setRenderTarget(S.mapPass),i.clear(),i.renderBufferDirect(T,null,R,d,x,null),f.uniforms.shadow_pass.value=S.mapPass.texture,f.uniforms.resolution.value=S.mapSize,f.uniforms.radius.value=S.radius,i.setRenderTarget(S.map),i.clear(),i.renderBufferDirect(T,null,R,f,x,null)}function v(S,T,R,_){let b=null,C=R.isPointLight===!0?S.customDistanceMaterial:S.customDepthMaterial;if(C!==void 0)b=C;else if(b=R.isPointLight===!0?l:a,i.localClippingEnabled&&T.clipShadows===!0&&Array.isArray(T.clippingPlanes)&&T.clippingPlanes.length!==0||T.displacementMap&&T.displacementScale!==0||T.alphaMap&&T.alphaTest>0||T.map&&T.alphaTest>0){let L=b.uuid,k=T.uuid,D=c[L];D===void 0&&(D={},c[L]=D);let V=D[k];V===void 0&&(V=b.clone(),D[k]=V,T.addEventListener("dispose",w)),b=V}if(b.visible=T.visible,b.wireframe=T.wireframe,_===Ti?b.side=T.shadowSide!==null?T.shadowSide:T.side:b.side=T.shadowSide!==null?T.shadowSide:u[T.side],b.alphaMap=T.alphaMap,b.alphaTest=T.alphaTest,b.map=T.map,b.clipShadows=T.clipShadows,b.clippingPlanes=T.clippingPlanes,b.clipIntersection=T.clipIntersection,b.displacementMap=T.displacementMap,b.displacementScale=T.displacementScale,b.displacementBias=T.displacementBias,b.wireframeLinewidth=T.wireframeLinewidth,b.linewidth=T.linewidth,R.isPointLight===!0&&b.isMeshDistanceMaterial===!0){let L=i.properties.get(b);L.light=R}return b}function y(S,T,R,_,b){if(S.visible===!1)return;if(S.layers.test(T.layers)&&(S.isMesh||S.isLine||S.isPoints)&&(S.castShadow||S.receiveShadow&&b===Ti)&&(!S.frustumCulled||n.intersectsObject(S))){S.modelViewMatrix.multiplyMatrices(R.matrixWorldInverse,S.matrixWorld);let k=t.update(S),D=S.material;if(Array.isArray(D)){let V=k.groups;for(let z=0,G=V.length;z<G;z++){let F=V[z],K=D[F.materialIndex];if(K&&K.visible){let Q=v(S,K,_,b);S.onBeforeShadow(i,S,T,R,k,Q,F),i.renderBufferDirect(R,null,k,Q,S,F),S.onAfterShadow(i,S,T,R,k,Q,F)}}}else if(D.visible){let V=v(S,D,_,b);S.onBeforeShadow(i,S,T,R,k,V,null),i.renderBufferDirect(R,null,k,V,S,null),S.onAfterShadow(i,S,T,R,k,V,null)}}let L=S.children;for(let k=0,D=L.length;k<D;k++)y(L[k],T,R,_,b)}function w(S){S.target.removeEventListener("dispose",w);for(let R in c){let _=c[R],b=S.target.uuid;b in _&&(_[b].dispose(),delete _[b])}}}var Tb={[Dc]:Uc,[Nc]:Bc,[zc]:Oc,[xr]:Fc,[Uc]:Dc,[Bc]:Nc,[Oc]:zc,[Fc]:xr};function Ab(i,t){function e(){let N=!1,ct=new Me,X=null,j=new Me(0,0,0,0);return{setMask:function(mt){X!==mt&&!N&&(i.colorMask(mt,mt,mt,mt),X=mt)},setLocked:function(mt){N=mt},setClear:function(mt,dt,Gt,Le,je){je===!0&&(mt*=Le,dt*=Le,Gt*=Le),ct.set(mt,dt,Gt,Le),j.equals(ct)===!1&&(i.clearColor(mt,dt,Gt,Le),j.copy(ct))},reset:function(){N=!1,X=null,j.set(-1,0,0,0)}}}function n(){let N=!1,ct=!1,X=null,j=null,mt=null;return{setReversed:function(dt){if(ct!==dt){let Gt=t.get("EXT_clip_control");ct?Gt.clipControlEXT(Gt.LOWER_LEFT_EXT,Gt.ZERO_TO_ONE_EXT):Gt.clipControlEXT(Gt.LOWER_LEFT_EXT,Gt.NEGATIVE_ONE_TO_ONE_EXT);let Le=mt;mt=null,this.setClear(Le)}ct=dt},getReversed:function(){return ct},setTest:function(dt){dt?ht(i.DEPTH_TEST):Nt(i.DEPTH_TEST)},setMask:function(dt){X!==dt&&!N&&(i.depthMask(dt),X=dt)},setFunc:function(dt){if(ct&&(dt=Tb[dt]),j!==dt){switch(dt){case Dc:i.depthFunc(i.NEVER);break;case Uc:i.depthFunc(i.ALWAYS);break;case Nc:i.depthFunc(i.LESS);break;case xr:i.depthFunc(i.LEQUAL);break;case zc:i.depthFunc(i.EQUAL);break;case Fc:i.depthFunc(i.GEQUAL);break;case Bc:i.depthFunc(i.GREATER);break;case Oc:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}j=dt}},setLocked:function(dt){N=dt},setClear:function(dt){mt!==dt&&(ct&&(dt=1-dt),i.clearDepth(dt),mt=dt)},reset:function(){N=!1,X=null,j=null,mt=null,ct=!1}}}function s(){let N=!1,ct=null,X=null,j=null,mt=null,dt=null,Gt=null,Le=null,je=null;return{setTest:function(de){N||(de?ht(i.STENCIL_TEST):Nt(i.STENCIL_TEST))},setMask:function(de){ct!==de&&!N&&(i.stencilMask(de),ct=de)},setFunc:function(de,qn,vi){(X!==de||j!==qn||mt!==vi)&&(i.stencilFunc(de,qn,vi),X=de,j=qn,mt=vi)},setOp:function(de,qn,vi){(dt!==de||Gt!==qn||Le!==vi)&&(i.stencilOp(de,qn,vi),dt=de,Gt=qn,Le=vi)},setLocked:function(de){N=de},setClear:function(de){je!==de&&(i.clearStencil(de),je=de)},reset:function(){N=!1,ct=null,X=null,j=null,mt=null,dt=null,Gt=null,Le=null,je=null}}}let r=new e,o=new n,a=new s,l=new WeakMap,c=new WeakMap,h={},u={},d=new WeakMap,f=[],m=null,x=!1,g=null,p=null,M=null,v=null,y=null,w=null,S=null,T=new wt(0,0,0),R=0,_=!1,b=null,C=null,L=null,k=null,D=null,V=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS),z=!1,G=0,F=i.getParameter(i.VERSION);F.indexOf("WebGL")!==-1?(G=parseFloat(/^WebGL (\d)/.exec(F)[1]),z=G>=1):F.indexOf("OpenGL ES")!==-1&&(G=parseFloat(/^OpenGL ES (\d)/.exec(F)[1]),z=G>=2);let K=null,Q={},ot=i.getParameter(i.SCISSOR_BOX),St=i.getParameter(i.VIEWPORT),Vt=new Me().fromArray(ot),Y=new Me().fromArray(St);function et(N,ct,X,j){let mt=new Uint8Array(4),dt=i.createTexture();i.bindTexture(N,dt),i.texParameteri(N,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(N,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let Gt=0;Gt<X;Gt++)N===i.TEXTURE_3D||N===i.TEXTURE_2D_ARRAY?i.texImage3D(ct,0,i.RGBA,1,1,j,0,i.RGBA,i.UNSIGNED_BYTE,mt):i.texImage2D(ct+Gt,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,mt);return dt}let Mt={};Mt[i.TEXTURE_2D]=et(i.TEXTURE_2D,i.TEXTURE_2D,1),Mt[i.TEXTURE_CUBE_MAP]=et(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),Mt[i.TEXTURE_2D_ARRAY]=et(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),Mt[i.TEXTURE_3D]=et(i.TEXTURE_3D,i.TEXTURE_3D,1,1),r.setClear(0,0,0,1),o.setClear(1),a.setClear(0),ht(i.DEPTH_TEST),o.setFunc(xr),te(!1),ee(xd),ht(i.CULL_FACE),H(Ji);function ht(N){h[N]!==!0&&(i.enable(N),h[N]=!0)}function Nt(N){h[N]!==!1&&(i.disable(N),h[N]=!1)}function Ot(N,ct){return u[N]!==ct?(i.bindFramebuffer(N,ct),u[N]=ct,N===i.DRAW_FRAMEBUFFER&&(u[i.FRAMEBUFFER]=ct),N===i.FRAMEBUFFER&&(u[i.DRAW_FRAMEBUFFER]=ct),!0):!1}function Jt(N,ct){let X=f,j=!1;if(N){X=d.get(ct),X===void 0&&(X=[],d.set(ct,X));let mt=N.textures;if(X.length!==mt.length||X[0]!==i.COLOR_ATTACHMENT0){for(let dt=0,Gt=mt.length;dt<Gt;dt++)X[dt]=i.COLOR_ATTACHMENT0+dt;X.length=mt.length,j=!0}}else X[0]!==i.BACK&&(X[0]=i.BACK,j=!0);j&&i.drawBuffers(X)}function Ee(N){return m!==N?(i.useProgram(N),m=N,!0):!1}let ie={[vs]:i.FUNC_ADD,[Gm]:i.FUNC_SUBTRACT,[Wm]:i.FUNC_REVERSE_SUBTRACT};ie[$m]=i.MIN,ie[qm]=i.MAX;let Ne={[Xm]:i.ZERO,[Ym]:i.ONE,[Zm]:i.SRC_COLOR,[Lc]:i.SRC_ALPHA,[e0]:i.SRC_ALPHA_SATURATE,[Qm]:i.DST_COLOR,[Jm]:i.DST_ALPHA,[Km]:i.ONE_MINUS_SRC_COLOR,[kc]:i.ONE_MINUS_SRC_ALPHA,[t0]:i.ONE_MINUS_DST_COLOR,[jm]:i.ONE_MINUS_DST_ALPHA,[n0]:i.CONSTANT_COLOR,[i0]:i.ONE_MINUS_CONSTANT_COLOR,[s0]:i.CONSTANT_ALPHA,[r0]:i.ONE_MINUS_CONSTANT_ALPHA};function H(N,ct,X,j,mt,dt,Gt,Le,je,de){if(N===Ji){x===!0&&(Nt(i.BLEND),x=!1);return}if(x===!1&&(ht(i.BLEND),x=!0),N!==Vm){if(N!==g||de!==_){if((p!==vs||y!==vs)&&(i.blendEquation(i.FUNC_ADD),p=vs,y=vs),de)switch(N){case fr:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case yd:i.blendFunc(i.ONE,i.ONE);break;case vd:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case bd:i.blendFuncSeparate(i.ZERO,i.SRC_COLOR,i.ZERO,i.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",N);break}else switch(N){case fr:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case yd:i.blendFunc(i.SRC_ALPHA,i.ONE);break;case vd:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case bd:i.blendFunc(i.ZERO,i.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",N);break}M=null,v=null,w=null,S=null,T.set(0,0,0),R=0,g=N,_=de}return}mt=mt||ct,dt=dt||X,Gt=Gt||j,(ct!==p||mt!==y)&&(i.blendEquationSeparate(ie[ct],ie[mt]),p=ct,y=mt),(X!==M||j!==v||dt!==w||Gt!==S)&&(i.blendFuncSeparate(Ne[X],Ne[j],Ne[dt],Ne[Gt]),M=X,v=j,w=dt,S=Gt),(Le.equals(T)===!1||je!==R)&&(i.blendColor(Le.r,Le.g,Le.b,je),T.copy(Le),R=je),g=N,_=!1}function Bn(N,ct){N.side===Te?Nt(i.CULL_FACE):ht(i.CULL_FACE);let X=N.side===en;ct&&(X=!X),te(X),N.blending===fr&&N.transparent===!1?H(Ji):H(N.blending,N.blendEquation,N.blendSrc,N.blendDst,N.blendEquationAlpha,N.blendSrcAlpha,N.blendDstAlpha,N.blendColor,N.blendAlpha,N.premultipliedAlpha),o.setFunc(N.depthFunc),o.setTest(N.depthTest),o.setMask(N.depthWrite),r.setMask(N.colorWrite);let j=N.stencilWrite;a.setTest(j),j&&(a.setMask(N.stencilWriteMask),a.setFunc(N.stencilFunc,N.stencilRef,N.stencilFuncMask),a.setOp(N.stencilFail,N.stencilZFail,N.stencilZPass)),ve(N.polygonOffset,N.polygonOffsetFactor,N.polygonOffsetUnits),N.alphaToCoverage===!0?ht(i.SAMPLE_ALPHA_TO_COVERAGE):Nt(i.SAMPLE_ALPHA_TO_COVERAGE)}function te(N){b!==N&&(N?i.frontFace(i.CW):i.frontFace(i.CCW),b=N)}function ee(N){N!==Om?(ht(i.CULL_FACE),N!==C&&(N===xd?i.cullFace(i.BACK):N===Hm?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):Nt(i.CULL_FACE),C=N}function Dt(N){N!==L&&(z&&i.lineWidth(N),L=N)}function ve(N,ct,X){N?(ht(i.POLYGON_OFFSET_FILL),(k!==ct||D!==X)&&(i.polygonOffset(ct,X),k=ct,D=X)):Nt(i.POLYGON_OFFSET_FILL)}function Lt(N){N?ht(i.SCISSOR_TEST):Nt(i.SCISSOR_TEST)}function I(N){N===void 0&&(N=i.TEXTURE0+V-1),K!==N&&(i.activeTexture(N),K=N)}function E(N,ct,X){X===void 0&&(K===null?X=i.TEXTURE0+V-1:X=K);let j=Q[X];j===void 0&&(j={type:void 0,texture:void 0},Q[X]=j),(j.type!==N||j.texture!==ct)&&(K!==X&&(i.activeTexture(X),K=X),i.bindTexture(N,ct||Mt[N]),j.type=N,j.texture=ct)}function W(){let N=Q[K];N!==void 0&&N.type!==void 0&&(i.bindTexture(N.type,null),N.type=void 0,N.texture=void 0)}function J(){try{i.compressedTexImage2D.apply(i,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function tt(){try{i.compressedTexImage3D.apply(i,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Z(){try{i.texSubImage2D.apply(i,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Rt(){try{i.texSubImage3D.apply(i,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function ut(){try{i.compressedTexSubImage2D.apply(i,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function gt(){try{i.compressedTexSubImage3D.apply(i,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function se(){try{i.texStorage2D.apply(i,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function it(){try{i.texStorage3D.apply(i,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function yt(){try{i.texImage2D.apply(i,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Ut(){try{i.texImage3D.apply(i,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Ft(N){Vt.equals(N)===!1&&(i.scissor(N.x,N.y,N.z,N.w),Vt.copy(N))}function vt(N){Y.equals(N)===!1&&(i.viewport(N.x,N.y,N.z,N.w),Y.copy(N))}function ne(N,ct){let X=c.get(ct);X===void 0&&(X=new WeakMap,c.set(ct,X));let j=X.get(N);j===void 0&&(j=i.getUniformBlockIndex(ct,N.name),X.set(N,j))}function Zt(N,ct){let j=c.get(ct).get(N);l.get(ct)!==j&&(i.uniformBlockBinding(ct,j,N.__bindingPointIndex),l.set(ct,j))}function ge(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),o.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),h={},K=null,Q={},u={},d=new WeakMap,f=[],m=null,x=!1,g=null,p=null,M=null,v=null,y=null,w=null,S=null,T=new wt(0,0,0),R=0,_=!1,b=null,C=null,L=null,k=null,D=null,Vt.set(0,0,i.canvas.width,i.canvas.height),Y.set(0,0,i.canvas.width,i.canvas.height),r.reset(),o.reset(),a.reset()}return{buffers:{color:r,depth:o,stencil:a},enable:ht,disable:Nt,bindFramebuffer:Ot,drawBuffers:Jt,useProgram:Ee,setBlending:H,setMaterial:Bn,setFlipSided:te,setCullFace:ee,setLineWidth:Dt,setPolygonOffset:ve,setScissorTest:Lt,activeTexture:I,bindTexture:E,unbindTexture:W,compressedTexImage2D:J,compressedTexImage3D:tt,texImage2D:yt,texImage3D:Ut,updateUBOMapping:ne,uniformBlockBinding:Zt,texStorage2D:se,texStorage3D:it,texSubImage2D:Z,texSubImage3D:Rt,compressedTexSubImage2D:ut,compressedTexSubImage3D:gt,scissor:Ft,viewport:vt,reset:ge}}function xf(i,t,e,n){let s=Rb(n);switch(e){case Vf:return i*t;case Wf:return i*t;case $f:return i*t*2;case lu:return i*t/s.components*s.byteLength;case cu:return i*t/s.components*s.byteLength;case qf:return i*t*2/s.components*s.byteLength;case hu:return i*t*2/s.components*s.byteLength;case Gf:return i*t*3/s.components*s.byteLength;case jn:return i*t*4/s.components*s.byteLength;case uu:return i*t*4/s.components*s.byteLength;case Pa:case Ia:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*8;case La:case ka:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case $c:case Xc:return Math.max(i,16)*Math.max(t,8)/4;case Wc:case qc:return Math.max(i,8)*Math.max(t,8)/2;case Yc:case Zc:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*8;case Kc:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case Jc:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case jc:return Math.floor((i+4)/5)*Math.floor((t+3)/4)*16;case Qc:return Math.floor((i+4)/5)*Math.floor((t+4)/5)*16;case th:return Math.floor((i+5)/6)*Math.floor((t+4)/5)*16;case eh:return Math.floor((i+5)/6)*Math.floor((t+5)/6)*16;case nh:return Math.floor((i+7)/8)*Math.floor((t+4)/5)*16;case ih:return Math.floor((i+7)/8)*Math.floor((t+5)/6)*16;case sh:return Math.floor((i+7)/8)*Math.floor((t+7)/8)*16;case rh:return Math.floor((i+9)/10)*Math.floor((t+4)/5)*16;case oh:return Math.floor((i+9)/10)*Math.floor((t+5)/6)*16;case ah:return Math.floor((i+9)/10)*Math.floor((t+7)/8)*16;case lh:return Math.floor((i+9)/10)*Math.floor((t+9)/10)*16;case ch:return Math.floor((i+11)/12)*Math.floor((t+9)/10)*16;case hh:return Math.floor((i+11)/12)*Math.floor((t+11)/12)*16;case Da:case uh:case dh:return Math.ceil(i/4)*Math.ceil(t/4)*16;case Xf:case fh:return Math.ceil(i/4)*Math.ceil(t/4)*8;case ph:case mh:return Math.ceil(i/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${e} format.`)}function Rb(i){switch(i){case Pi:case Bf:return{byteLength:1,components:1};case uo:case Of:case Ro:return{byteLength:2,components:1};case ou:case au:return{byteLength:2,components:4};case ws:case ru:case li:return{byteLength:4,components:1};case Hf:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${i}.`)}function Cb(i,t,e,n,s,r,o){let a=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new rt,h=new WeakMap,u,d=new WeakMap,f=!1;try{f=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function m(I,E){return f?new OffscreenCanvas(I,E):za("canvas")}function x(I,E,W){let J=1,tt=Lt(I);if((tt.width>W||tt.height>W)&&(J=W/Math.max(tt.width,tt.height)),J<1)if(typeof HTMLImageElement<"u"&&I instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&I instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&I instanceof ImageBitmap||typeof VideoFrame<"u"&&I instanceof VideoFrame){let Z=Math.floor(J*tt.width),Rt=Math.floor(J*tt.height);u===void 0&&(u=m(Z,Rt));let ut=E?m(Z,Rt):u;return ut.width=Z,ut.height=Rt,ut.getContext("2d").drawImage(I,0,0,Z,Rt),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+tt.width+"x"+tt.height+") to ("+Z+"x"+Rt+")."),ut}else return"data"in I&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+tt.width+"x"+tt.height+")."),I;return I}function g(I){return I.generateMipmaps}function p(I){i.generateMipmap(I)}function M(I){return I.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:I.isWebGL3DRenderTarget?i.TEXTURE_3D:I.isWebGLArrayRenderTarget||I.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function v(I,E,W,J,tt=!1){if(I!==null){if(i[I]!==void 0)return i[I];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+I+"'")}let Z=E;if(E===i.RED&&(W===i.FLOAT&&(Z=i.R32F),W===i.HALF_FLOAT&&(Z=i.R16F),W===i.UNSIGNED_BYTE&&(Z=i.R8)),E===i.RED_INTEGER&&(W===i.UNSIGNED_BYTE&&(Z=i.R8UI),W===i.UNSIGNED_SHORT&&(Z=i.R16UI),W===i.UNSIGNED_INT&&(Z=i.R32UI),W===i.BYTE&&(Z=i.R8I),W===i.SHORT&&(Z=i.R16I),W===i.INT&&(Z=i.R32I)),E===i.RG&&(W===i.FLOAT&&(Z=i.RG32F),W===i.HALF_FLOAT&&(Z=i.RG16F),W===i.UNSIGNED_BYTE&&(Z=i.RG8)),E===i.RG_INTEGER&&(W===i.UNSIGNED_BYTE&&(Z=i.RG8UI),W===i.UNSIGNED_SHORT&&(Z=i.RG16UI),W===i.UNSIGNED_INT&&(Z=i.RG32UI),W===i.BYTE&&(Z=i.RG8I),W===i.SHORT&&(Z=i.RG16I),W===i.INT&&(Z=i.RG32I)),E===i.RGB_INTEGER&&(W===i.UNSIGNED_BYTE&&(Z=i.RGB8UI),W===i.UNSIGNED_SHORT&&(Z=i.RGB16UI),W===i.UNSIGNED_INT&&(Z=i.RGB32UI),W===i.BYTE&&(Z=i.RGB8I),W===i.SHORT&&(Z=i.RGB16I),W===i.INT&&(Z=i.RGB32I)),E===i.RGBA_INTEGER&&(W===i.UNSIGNED_BYTE&&(Z=i.RGBA8UI),W===i.UNSIGNED_SHORT&&(Z=i.RGBA16UI),W===i.UNSIGNED_INT&&(Z=i.RGBA32UI),W===i.BYTE&&(Z=i.RGBA8I),W===i.SHORT&&(Z=i.RGBA16I),W===i.INT&&(Z=i.RGBA32I)),E===i.RGB&&W===i.UNSIGNED_INT_5_9_9_9_REV&&(Z=i.RGB9_E5),E===i.RGBA){let Rt=tt?dl:re.getTransfer(J);W===i.FLOAT&&(Z=i.RGBA32F),W===i.HALF_FLOAT&&(Z=i.RGBA16F),W===i.UNSIGNED_BYTE&&(Z=Rt===pe?i.SRGB8_ALPHA8:i.RGBA8),W===i.UNSIGNED_SHORT_4_4_4_4&&(Z=i.RGBA4),W===i.UNSIGNED_SHORT_5_5_5_1&&(Z=i.RGB5_A1)}return(Z===i.R16F||Z===i.R32F||Z===i.RG16F||Z===i.RG32F||Z===i.RGBA16F||Z===i.RGBA32F)&&t.get("EXT_color_buffer_float"),Z}function y(I,E){let W;return I?E===null||E===ws||E===br?W=i.DEPTH24_STENCIL8:E===li?W=i.DEPTH32F_STENCIL8:E===uo&&(W=i.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):E===null||E===ws||E===br?W=i.DEPTH_COMPONENT24:E===li?W=i.DEPTH_COMPONENT32F:E===uo&&(W=i.DEPTH_COMPONENT16),W}function w(I,E){return g(I)===!0||I.isFramebufferTexture&&I.minFilter!==In&&I.minFilter!==Vn?Math.log2(Math.max(E.width,E.height))+1:I.mipmaps!==void 0&&I.mipmaps.length>0?I.mipmaps.length:I.isCompressedTexture&&Array.isArray(I.image)?E.mipmaps.length:1}function S(I){let E=I.target;E.removeEventListener("dispose",S),R(E),E.isVideoTexture&&h.delete(E)}function T(I){let E=I.target;E.removeEventListener("dispose",T),b(E)}function R(I){let E=n.get(I);if(E.__webglInit===void 0)return;let W=I.source,J=d.get(W);if(J){let tt=J[E.__cacheKey];tt.usedTimes--,tt.usedTimes===0&&_(I),Object.keys(J).length===0&&d.delete(W)}n.remove(I)}function _(I){let E=n.get(I);i.deleteTexture(E.__webglTexture);let W=I.source,J=d.get(W);delete J[E.__cacheKey],o.memory.textures--}function b(I){let E=n.get(I);if(I.depthTexture&&(I.depthTexture.dispose(),n.remove(I.depthTexture)),I.isWebGLCubeRenderTarget)for(let J=0;J<6;J++){if(Array.isArray(E.__webglFramebuffer[J]))for(let tt=0;tt<E.__webglFramebuffer[J].length;tt++)i.deleteFramebuffer(E.__webglFramebuffer[J][tt]);else i.deleteFramebuffer(E.__webglFramebuffer[J]);E.__webglDepthbuffer&&i.deleteRenderbuffer(E.__webglDepthbuffer[J])}else{if(Array.isArray(E.__webglFramebuffer))for(let J=0;J<E.__webglFramebuffer.length;J++)i.deleteFramebuffer(E.__webglFramebuffer[J]);else i.deleteFramebuffer(E.__webglFramebuffer);if(E.__webglDepthbuffer&&i.deleteRenderbuffer(E.__webglDepthbuffer),E.__webglMultisampledFramebuffer&&i.deleteFramebuffer(E.__webglMultisampledFramebuffer),E.__webglColorRenderbuffer)for(let J=0;J<E.__webglColorRenderbuffer.length;J++)E.__webglColorRenderbuffer[J]&&i.deleteRenderbuffer(E.__webglColorRenderbuffer[J]);E.__webglDepthRenderbuffer&&i.deleteRenderbuffer(E.__webglDepthRenderbuffer)}let W=I.textures;for(let J=0,tt=W.length;J<tt;J++){let Z=n.get(W[J]);Z.__webglTexture&&(i.deleteTexture(Z.__webglTexture),o.memory.textures--),n.remove(W[J])}n.remove(I)}let C=0;function L(){C=0}function k(){let I=C;return I>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+I+" texture units while this GPU supports only "+s.maxTextures),C+=1,I}function D(I){let E=[];return E.push(I.wrapS),E.push(I.wrapT),E.push(I.wrapR||0),E.push(I.magFilter),E.push(I.minFilter),E.push(I.anisotropy),E.push(I.internalFormat),E.push(I.format),E.push(I.type),E.push(I.generateMipmaps),E.push(I.premultiplyAlpha),E.push(I.flipY),E.push(I.unpackAlignment),E.push(I.colorSpace),E.join()}function V(I,E){let W=n.get(I);if(I.isVideoTexture&&Dt(I),I.isRenderTargetTexture===!1&&I.version>0&&W.__version!==I.version){let J=I.image;if(J===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(J.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{Y(W,I,E);return}}e.bindTexture(i.TEXTURE_2D,W.__webglTexture,i.TEXTURE0+E)}function z(I,E){let W=n.get(I);if(I.version>0&&W.__version!==I.version){Y(W,I,E);return}e.bindTexture(i.TEXTURE_2D_ARRAY,W.__webglTexture,i.TEXTURE0+E)}function G(I,E){let W=n.get(I);if(I.version>0&&W.__version!==I.version){Y(W,I,E);return}e.bindTexture(i.TEXTURE_3D,W.__webglTexture,i.TEXTURE0+E)}function F(I,E){let W=n.get(I);if(I.version>0&&W.__version!==I.version){et(W,I,E);return}e.bindTexture(i.TEXTURE_CUBE_MAP,W.__webglTexture,i.TEXTURE0+E)}let K={[Ms]:i.REPEAT,[_s]:i.CLAMP_TO_EDGE,[Gc]:i.MIRRORED_REPEAT},Q={[In]:i.NEAREST,[p0]:i.NEAREST_MIPMAP_NEAREST,[Qo]:i.NEAREST_MIPMAP_LINEAR,[Vn]:i.LINEAR,[jl]:i.LINEAR_MIPMAP_NEAREST,[Ai]:i.LINEAR_MIPMAP_LINEAR},ot={[y0]:i.NEVER,[S0]:i.ALWAYS,[v0]:i.LESS,[Zf]:i.LEQUAL,[b0]:i.EQUAL,[w0]:i.GEQUAL,[_0]:i.GREATER,[M0]:i.NOTEQUAL};function St(I,E){if(E.type===li&&t.has("OES_texture_float_linear")===!1&&(E.magFilter===Vn||E.magFilter===jl||E.magFilter===Qo||E.magFilter===Ai||E.minFilter===Vn||E.minFilter===jl||E.minFilter===Qo||E.minFilter===Ai)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(I,i.TEXTURE_WRAP_S,K[E.wrapS]),i.texParameteri(I,i.TEXTURE_WRAP_T,K[E.wrapT]),(I===i.TEXTURE_3D||I===i.TEXTURE_2D_ARRAY)&&i.texParameteri(I,i.TEXTURE_WRAP_R,K[E.wrapR]),i.texParameteri(I,i.TEXTURE_MAG_FILTER,Q[E.magFilter]),i.texParameteri(I,i.TEXTURE_MIN_FILTER,Q[E.minFilter]),E.compareFunction&&(i.texParameteri(I,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(I,i.TEXTURE_COMPARE_FUNC,ot[E.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(E.magFilter===In||E.minFilter!==Qo&&E.minFilter!==Ai||E.type===li&&t.has("OES_texture_float_linear")===!1)return;if(E.anisotropy>1||n.get(E).__currentAnisotropy){let W=t.get("EXT_texture_filter_anisotropic");i.texParameterf(I,W.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(E.anisotropy,s.getMaxAnisotropy())),n.get(E).__currentAnisotropy=E.anisotropy}}}function Vt(I,E){let W=!1;I.__webglInit===void 0&&(I.__webglInit=!0,E.addEventListener("dispose",S));let J=E.source,tt=d.get(J);tt===void 0&&(tt={},d.set(J,tt));let Z=D(E);if(Z!==I.__cacheKey){tt[Z]===void 0&&(tt[Z]={texture:i.createTexture(),usedTimes:0},o.memory.textures++,W=!0),tt[Z].usedTimes++;let Rt=tt[I.__cacheKey];Rt!==void 0&&(tt[I.__cacheKey].usedTimes--,Rt.usedTimes===0&&_(E)),I.__cacheKey=Z,I.__webglTexture=tt[Z].texture}return W}function Y(I,E,W){let J=i.TEXTURE_2D;(E.isDataArrayTexture||E.isCompressedArrayTexture)&&(J=i.TEXTURE_2D_ARRAY),E.isData3DTexture&&(J=i.TEXTURE_3D);let tt=Vt(I,E),Z=E.source;e.bindTexture(J,I.__webglTexture,i.TEXTURE0+W);let Rt=n.get(Z);if(Z.version!==Rt.__version||tt===!0){e.activeTexture(i.TEXTURE0+W);let ut=re.getPrimaries(re.workingColorSpace),gt=E.colorSpace===Zi?null:re.getPrimaries(E.colorSpace),se=E.colorSpace===Zi||ut===gt?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,E.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,E.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,se);let it=x(E.image,!1,s.maxTextureSize);it=ve(E,it);let yt=r.convert(E.format,E.colorSpace),Ut=r.convert(E.type),Ft=v(E.internalFormat,yt,Ut,E.colorSpace,E.isVideoTexture);St(J,E);let vt,ne=E.mipmaps,Zt=E.isVideoTexture!==!0,ge=Rt.__version===void 0||tt===!0,N=Z.dataReady,ct=w(E,it);if(E.isDepthTexture)Ft=y(E.format===_r,E.type),ge&&(Zt?e.texStorage2D(i.TEXTURE_2D,1,Ft,it.width,it.height):e.texImage2D(i.TEXTURE_2D,0,Ft,it.width,it.height,0,yt,Ut,null));else if(E.isDataTexture)if(ne.length>0){Zt&&ge&&e.texStorage2D(i.TEXTURE_2D,ct,Ft,ne[0].width,ne[0].height);for(let X=0,j=ne.length;X<j;X++)vt=ne[X],Zt?N&&e.texSubImage2D(i.TEXTURE_2D,X,0,0,vt.width,vt.height,yt,Ut,vt.data):e.texImage2D(i.TEXTURE_2D,X,Ft,vt.width,vt.height,0,yt,Ut,vt.data);E.generateMipmaps=!1}else Zt?(ge&&e.texStorage2D(i.TEXTURE_2D,ct,Ft,it.width,it.height),N&&e.texSubImage2D(i.TEXTURE_2D,0,0,0,it.width,it.height,yt,Ut,it.data)):e.texImage2D(i.TEXTURE_2D,0,Ft,it.width,it.height,0,yt,Ut,it.data);else if(E.isCompressedTexture)if(E.isCompressedArrayTexture){Zt&&ge&&e.texStorage3D(i.TEXTURE_2D_ARRAY,ct,Ft,ne[0].width,ne[0].height,it.depth);for(let X=0,j=ne.length;X<j;X++)if(vt=ne[X],E.format!==jn)if(yt!==null)if(Zt){if(N)if(E.layerUpdates.size>0){let mt=xf(vt.width,vt.height,E.format,E.type);for(let dt of E.layerUpdates){let Gt=vt.data.subarray(dt*mt/vt.data.BYTES_PER_ELEMENT,(dt+1)*mt/vt.data.BYTES_PER_ELEMENT);e.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,X,0,0,dt,vt.width,vt.height,1,yt,Gt)}E.clearLayerUpdates()}else e.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,X,0,0,0,vt.width,vt.height,it.depth,yt,vt.data)}else e.compressedTexImage3D(i.TEXTURE_2D_ARRAY,X,Ft,vt.width,vt.height,it.depth,0,vt.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else Zt?N&&e.texSubImage3D(i.TEXTURE_2D_ARRAY,X,0,0,0,vt.width,vt.height,it.depth,yt,Ut,vt.data):e.texImage3D(i.TEXTURE_2D_ARRAY,X,Ft,vt.width,vt.height,it.depth,0,yt,Ut,vt.data)}else{Zt&&ge&&e.texStorage2D(i.TEXTURE_2D,ct,Ft,ne[0].width,ne[0].height);for(let X=0,j=ne.length;X<j;X++)vt=ne[X],E.format!==jn?yt!==null?Zt?N&&e.compressedTexSubImage2D(i.TEXTURE_2D,X,0,0,vt.width,vt.height,yt,vt.data):e.compressedTexImage2D(i.TEXTURE_2D,X,Ft,vt.width,vt.height,0,vt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Zt?N&&e.texSubImage2D(i.TEXTURE_2D,X,0,0,vt.width,vt.height,yt,Ut,vt.data):e.texImage2D(i.TEXTURE_2D,X,Ft,vt.width,vt.height,0,yt,Ut,vt.data)}else if(E.isDataArrayTexture)if(Zt){if(ge&&e.texStorage3D(i.TEXTURE_2D_ARRAY,ct,Ft,it.width,it.height,it.depth),N)if(E.layerUpdates.size>0){let X=xf(it.width,it.height,E.format,E.type);for(let j of E.layerUpdates){let mt=it.data.subarray(j*X/it.data.BYTES_PER_ELEMENT,(j+1)*X/it.data.BYTES_PER_ELEMENT);e.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,j,it.width,it.height,1,yt,Ut,mt)}E.clearLayerUpdates()}else e.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,it.width,it.height,it.depth,yt,Ut,it.data)}else e.texImage3D(i.TEXTURE_2D_ARRAY,0,Ft,it.width,it.height,it.depth,0,yt,Ut,it.data);else if(E.isData3DTexture)Zt?(ge&&e.texStorage3D(i.TEXTURE_3D,ct,Ft,it.width,it.height,it.depth),N&&e.texSubImage3D(i.TEXTURE_3D,0,0,0,0,it.width,it.height,it.depth,yt,Ut,it.data)):e.texImage3D(i.TEXTURE_3D,0,Ft,it.width,it.height,it.depth,0,yt,Ut,it.data);else if(E.isFramebufferTexture){if(ge)if(Zt)e.texStorage2D(i.TEXTURE_2D,ct,Ft,it.width,it.height);else{let X=it.width,j=it.height;for(let mt=0;mt<ct;mt++)e.texImage2D(i.TEXTURE_2D,mt,Ft,X,j,0,yt,Ut,null),X>>=1,j>>=1}}else if(ne.length>0){if(Zt&&ge){let X=Lt(ne[0]);e.texStorage2D(i.TEXTURE_2D,ct,Ft,X.width,X.height)}for(let X=0,j=ne.length;X<j;X++)vt=ne[X],Zt?N&&e.texSubImage2D(i.TEXTURE_2D,X,0,0,yt,Ut,vt):e.texImage2D(i.TEXTURE_2D,X,Ft,yt,Ut,vt);E.generateMipmaps=!1}else if(Zt){if(ge){let X=Lt(it);e.texStorage2D(i.TEXTURE_2D,ct,Ft,X.width,X.height)}N&&e.texSubImage2D(i.TEXTURE_2D,0,0,0,yt,Ut,it)}else e.texImage2D(i.TEXTURE_2D,0,Ft,yt,Ut,it);g(E)&&p(J),Rt.__version=Z.version,E.onUpdate&&E.onUpdate(E)}I.__version=E.version}function et(I,E,W){if(E.image.length!==6)return;let J=Vt(I,E),tt=E.source;e.bindTexture(i.TEXTURE_CUBE_MAP,I.__webglTexture,i.TEXTURE0+W);let Z=n.get(tt);if(tt.version!==Z.__version||J===!0){e.activeTexture(i.TEXTURE0+W);let Rt=re.getPrimaries(re.workingColorSpace),ut=E.colorSpace===Zi?null:re.getPrimaries(E.colorSpace),gt=E.colorSpace===Zi||Rt===ut?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,E.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,E.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,gt);let se=E.isCompressedTexture||E.image[0].isCompressedTexture,it=E.image[0]&&E.image[0].isDataTexture,yt=[];for(let j=0;j<6;j++)!se&&!it?yt[j]=x(E.image[j],!0,s.maxCubemapSize):yt[j]=it?E.image[j].image:E.image[j],yt[j]=ve(E,yt[j]);let Ut=yt[0],Ft=r.convert(E.format,E.colorSpace),vt=r.convert(E.type),ne=v(E.internalFormat,Ft,vt,E.colorSpace),Zt=E.isVideoTexture!==!0,ge=Z.__version===void 0||J===!0,N=tt.dataReady,ct=w(E,Ut);St(i.TEXTURE_CUBE_MAP,E);let X;if(se){Zt&&ge&&e.texStorage2D(i.TEXTURE_CUBE_MAP,ct,ne,Ut.width,Ut.height);for(let j=0;j<6;j++){X=yt[j].mipmaps;for(let mt=0;mt<X.length;mt++){let dt=X[mt];E.format!==jn?Ft!==null?Zt?N&&e.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,mt,0,0,dt.width,dt.height,Ft,dt.data):e.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,mt,ne,dt.width,dt.height,0,dt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Zt?N&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,mt,0,0,dt.width,dt.height,Ft,vt,dt.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,mt,ne,dt.width,dt.height,0,Ft,vt,dt.data)}}}else{if(X=E.mipmaps,Zt&&ge){X.length>0&&ct++;let j=Lt(yt[0]);e.texStorage2D(i.TEXTURE_CUBE_MAP,ct,ne,j.width,j.height)}for(let j=0;j<6;j++)if(it){Zt?N&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,0,0,0,yt[j].width,yt[j].height,Ft,vt,yt[j].data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,0,ne,yt[j].width,yt[j].height,0,Ft,vt,yt[j].data);for(let mt=0;mt<X.length;mt++){let Gt=X[mt].image[j].image;Zt?N&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,mt+1,0,0,Gt.width,Gt.height,Ft,vt,Gt.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,mt+1,ne,Gt.width,Gt.height,0,Ft,vt,Gt.data)}}else{Zt?N&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,0,0,0,Ft,vt,yt[j]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,0,ne,Ft,vt,yt[j]);for(let mt=0;mt<X.length;mt++){let dt=X[mt];Zt?N&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,mt+1,0,0,Ft,vt,dt.image[j]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,mt+1,ne,Ft,vt,dt.image[j])}}}g(E)&&p(i.TEXTURE_CUBE_MAP),Z.__version=tt.version,E.onUpdate&&E.onUpdate(E)}I.__version=E.version}function Mt(I,E,W,J,tt,Z){let Rt=r.convert(W.format,W.colorSpace),ut=r.convert(W.type),gt=v(W.internalFormat,Rt,ut,W.colorSpace),se=n.get(E),it=n.get(W);if(it.__renderTarget=E,!se.__hasExternalTextures){let yt=Math.max(1,E.width>>Z),Ut=Math.max(1,E.height>>Z);tt===i.TEXTURE_3D||tt===i.TEXTURE_2D_ARRAY?e.texImage3D(tt,Z,gt,yt,Ut,E.depth,0,Rt,ut,null):e.texImage2D(tt,Z,gt,yt,Ut,0,Rt,ut,null)}e.bindFramebuffer(i.FRAMEBUFFER,I),ee(E)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,J,tt,it.__webglTexture,0,te(E)):(tt===i.TEXTURE_2D||tt>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&tt<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,J,tt,it.__webglTexture,Z),e.bindFramebuffer(i.FRAMEBUFFER,null)}function ht(I,E,W){if(i.bindRenderbuffer(i.RENDERBUFFER,I),E.depthBuffer){let J=E.depthTexture,tt=J&&J.isDepthTexture?J.type:null,Z=y(E.stencilBuffer,tt),Rt=E.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,ut=te(E);ee(E)?a.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,ut,Z,E.width,E.height):W?i.renderbufferStorageMultisample(i.RENDERBUFFER,ut,Z,E.width,E.height):i.renderbufferStorage(i.RENDERBUFFER,Z,E.width,E.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,Rt,i.RENDERBUFFER,I)}else{let J=E.textures;for(let tt=0;tt<J.length;tt++){let Z=J[tt],Rt=r.convert(Z.format,Z.colorSpace),ut=r.convert(Z.type),gt=v(Z.internalFormat,Rt,ut,Z.colorSpace),se=te(E);W&&ee(E)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,se,gt,E.width,E.height):ee(E)?a.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,se,gt,E.width,E.height):i.renderbufferStorage(i.RENDERBUFFER,gt,E.width,E.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function Nt(I,E){if(E&&E.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(i.FRAMEBUFFER,I),!(E.depthTexture&&E.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");let J=n.get(E.depthTexture);J.__renderTarget=E,(!J.__webglTexture||E.depthTexture.image.width!==E.width||E.depthTexture.image.height!==E.height)&&(E.depthTexture.image.width=E.width,E.depthTexture.image.height=E.height,E.depthTexture.needsUpdate=!0),V(E.depthTexture,0);let tt=J.__webglTexture,Z=te(E);if(E.depthTexture.format===pr)ee(E)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,tt,0,Z):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,tt,0);else if(E.depthTexture.format===_r)ee(E)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,tt,0,Z):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,tt,0);else throw new Error("Unknown depthTexture format")}function Ot(I){let E=n.get(I),W=I.isWebGLCubeRenderTarget===!0;if(E.__boundDepthTexture!==I.depthTexture){let J=I.depthTexture;if(E.__depthDisposeCallback&&E.__depthDisposeCallback(),J){let tt=()=>{delete E.__boundDepthTexture,delete E.__depthDisposeCallback,J.removeEventListener("dispose",tt)};J.addEventListener("dispose",tt),E.__depthDisposeCallback=tt}E.__boundDepthTexture=J}if(I.depthTexture&&!E.__autoAllocateDepthBuffer){if(W)throw new Error("target.depthTexture not supported in Cube render targets");Nt(E.__webglFramebuffer,I)}else if(W){E.__webglDepthbuffer=[];for(let J=0;J<6;J++)if(e.bindFramebuffer(i.FRAMEBUFFER,E.__webglFramebuffer[J]),E.__webglDepthbuffer[J]===void 0)E.__webglDepthbuffer[J]=i.createRenderbuffer(),ht(E.__webglDepthbuffer[J],I,!1);else{let tt=I.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,Z=E.__webglDepthbuffer[J];i.bindRenderbuffer(i.RENDERBUFFER,Z),i.framebufferRenderbuffer(i.FRAMEBUFFER,tt,i.RENDERBUFFER,Z)}}else if(e.bindFramebuffer(i.FRAMEBUFFER,E.__webglFramebuffer),E.__webglDepthbuffer===void 0)E.__webglDepthbuffer=i.createRenderbuffer(),ht(E.__webglDepthbuffer,I,!1);else{let J=I.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,tt=E.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,tt),i.framebufferRenderbuffer(i.FRAMEBUFFER,J,i.RENDERBUFFER,tt)}e.bindFramebuffer(i.FRAMEBUFFER,null)}function Jt(I,E,W){let J=n.get(I);E!==void 0&&Mt(J.__webglFramebuffer,I,I.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),W!==void 0&&Ot(I)}function Ee(I){let E=I.texture,W=n.get(I),J=n.get(E);I.addEventListener("dispose",T);let tt=I.textures,Z=I.isWebGLCubeRenderTarget===!0,Rt=tt.length>1;if(Rt||(J.__webglTexture===void 0&&(J.__webglTexture=i.createTexture()),J.__version=E.version,o.memory.textures++),Z){W.__webglFramebuffer=[];for(let ut=0;ut<6;ut++)if(E.mipmaps&&E.mipmaps.length>0){W.__webglFramebuffer[ut]=[];for(let gt=0;gt<E.mipmaps.length;gt++)W.__webglFramebuffer[ut][gt]=i.createFramebuffer()}else W.__webglFramebuffer[ut]=i.createFramebuffer()}else{if(E.mipmaps&&E.mipmaps.length>0){W.__webglFramebuffer=[];for(let ut=0;ut<E.mipmaps.length;ut++)W.__webglFramebuffer[ut]=i.createFramebuffer()}else W.__webglFramebuffer=i.createFramebuffer();if(Rt)for(let ut=0,gt=tt.length;ut<gt;ut++){let se=n.get(tt[ut]);se.__webglTexture===void 0&&(se.__webglTexture=i.createTexture(),o.memory.textures++)}if(I.samples>0&&ee(I)===!1){W.__webglMultisampledFramebuffer=i.createFramebuffer(),W.__webglColorRenderbuffer=[],e.bindFramebuffer(i.FRAMEBUFFER,W.__webglMultisampledFramebuffer);for(let ut=0;ut<tt.length;ut++){let gt=tt[ut];W.__webglColorRenderbuffer[ut]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,W.__webglColorRenderbuffer[ut]);let se=r.convert(gt.format,gt.colorSpace),it=r.convert(gt.type),yt=v(gt.internalFormat,se,it,gt.colorSpace,I.isXRRenderTarget===!0),Ut=te(I);i.renderbufferStorageMultisample(i.RENDERBUFFER,Ut,yt,I.width,I.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+ut,i.RENDERBUFFER,W.__webglColorRenderbuffer[ut])}i.bindRenderbuffer(i.RENDERBUFFER,null),I.depthBuffer&&(W.__webglDepthRenderbuffer=i.createRenderbuffer(),ht(W.__webglDepthRenderbuffer,I,!0)),e.bindFramebuffer(i.FRAMEBUFFER,null)}}if(Z){e.bindTexture(i.TEXTURE_CUBE_MAP,J.__webglTexture),St(i.TEXTURE_CUBE_MAP,E);for(let ut=0;ut<6;ut++)if(E.mipmaps&&E.mipmaps.length>0)for(let gt=0;gt<E.mipmaps.length;gt++)Mt(W.__webglFramebuffer[ut][gt],I,E,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+ut,gt);else Mt(W.__webglFramebuffer[ut],I,E,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+ut,0);g(E)&&p(i.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(Rt){for(let ut=0,gt=tt.length;ut<gt;ut++){let se=tt[ut],it=n.get(se);e.bindTexture(i.TEXTURE_2D,it.__webglTexture),St(i.TEXTURE_2D,se),Mt(W.__webglFramebuffer,I,se,i.COLOR_ATTACHMENT0+ut,i.TEXTURE_2D,0),g(se)&&p(i.TEXTURE_2D)}e.unbindTexture()}else{let ut=i.TEXTURE_2D;if((I.isWebGL3DRenderTarget||I.isWebGLArrayRenderTarget)&&(ut=I.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),e.bindTexture(ut,J.__webglTexture),St(ut,E),E.mipmaps&&E.mipmaps.length>0)for(let gt=0;gt<E.mipmaps.length;gt++)Mt(W.__webglFramebuffer[gt],I,E,i.COLOR_ATTACHMENT0,ut,gt);else Mt(W.__webglFramebuffer,I,E,i.COLOR_ATTACHMENT0,ut,0);g(E)&&p(ut),e.unbindTexture()}I.depthBuffer&&Ot(I)}function ie(I){let E=I.textures;for(let W=0,J=E.length;W<J;W++){let tt=E[W];if(g(tt)){let Z=M(I),Rt=n.get(tt).__webglTexture;e.bindTexture(Z,Rt),p(Z),e.unbindTexture()}}}let Ne=[],H=[];function Bn(I){if(I.samples>0){if(ee(I)===!1){let E=I.textures,W=I.width,J=I.height,tt=i.COLOR_BUFFER_BIT,Z=I.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,Rt=n.get(I),ut=E.length>1;if(ut)for(let gt=0;gt<E.length;gt++)e.bindFramebuffer(i.FRAMEBUFFER,Rt.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+gt,i.RENDERBUFFER,null),e.bindFramebuffer(i.FRAMEBUFFER,Rt.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+gt,i.TEXTURE_2D,null,0);e.bindFramebuffer(i.READ_FRAMEBUFFER,Rt.__webglMultisampledFramebuffer),e.bindFramebuffer(i.DRAW_FRAMEBUFFER,Rt.__webglFramebuffer);for(let gt=0;gt<E.length;gt++){if(I.resolveDepthBuffer&&(I.depthBuffer&&(tt|=i.DEPTH_BUFFER_BIT),I.stencilBuffer&&I.resolveStencilBuffer&&(tt|=i.STENCIL_BUFFER_BIT)),ut){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,Rt.__webglColorRenderbuffer[gt]);let se=n.get(E[gt]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,se,0)}i.blitFramebuffer(0,0,W,J,0,0,W,J,tt,i.NEAREST),l===!0&&(Ne.length=0,H.length=0,Ne.push(i.COLOR_ATTACHMENT0+gt),I.depthBuffer&&I.resolveDepthBuffer===!1&&(Ne.push(Z),H.push(Z),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,H)),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,Ne))}if(e.bindFramebuffer(i.READ_FRAMEBUFFER,null),e.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),ut)for(let gt=0;gt<E.length;gt++){e.bindFramebuffer(i.FRAMEBUFFER,Rt.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+gt,i.RENDERBUFFER,Rt.__webglColorRenderbuffer[gt]);let se=n.get(E[gt]).__webglTexture;e.bindFramebuffer(i.FRAMEBUFFER,Rt.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+gt,i.TEXTURE_2D,se,0)}e.bindFramebuffer(i.DRAW_FRAMEBUFFER,Rt.__webglMultisampledFramebuffer)}else if(I.depthBuffer&&I.resolveDepthBuffer===!1&&l){let E=I.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[E])}}}function te(I){return Math.min(s.maxSamples,I.samples)}function ee(I){let E=n.get(I);return I.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&E.__useRenderToTexture!==!1}function Dt(I){let E=o.render.frame;h.get(I)!==E&&(h.set(I,E),I.update())}function ve(I,E){let W=I.colorSpace,J=I.format,tt=I.type;return I.isCompressedTexture===!0||I.isVideoTexture===!0||W!==Rr&&W!==Zi&&(re.getTransfer(W)===pe?(J!==jn||tt!==Pi)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",W)),E}function Lt(I){return typeof HTMLImageElement<"u"&&I instanceof HTMLImageElement?(c.width=I.naturalWidth||I.width,c.height=I.naturalHeight||I.height):typeof VideoFrame<"u"&&I instanceof VideoFrame?(c.width=I.displayWidth,c.height=I.displayHeight):(c.width=I.width,c.height=I.height),c}this.allocateTextureUnit=k,this.resetTextureUnits=L,this.setTexture2D=V,this.setTexture2DArray=z,this.setTexture3D=G,this.setTextureCube=F,this.rebindTextures=Jt,this.setupRenderTarget=Ee,this.updateRenderTargetMipmap=ie,this.updateMultisampleRenderTarget=Bn,this.setupDepthRenderbuffer=Ot,this.setupFrameBufferTexture=Mt,this.useMultisampledRTT=ee}function Pb(i,t){function e(n,s=Zi){let r,o=re.getTransfer(s);if(n===Pi)return i.UNSIGNED_BYTE;if(n===ou)return i.UNSIGNED_SHORT_4_4_4_4;if(n===au)return i.UNSIGNED_SHORT_5_5_5_1;if(n===Hf)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===Bf)return i.BYTE;if(n===Of)return i.SHORT;if(n===uo)return i.UNSIGNED_SHORT;if(n===ru)return i.INT;if(n===ws)return i.UNSIGNED_INT;if(n===li)return i.FLOAT;if(n===Ro)return i.HALF_FLOAT;if(n===Vf)return i.ALPHA;if(n===Gf)return i.RGB;if(n===jn)return i.RGBA;if(n===Wf)return i.LUMINANCE;if(n===$f)return i.LUMINANCE_ALPHA;if(n===pr)return i.DEPTH_COMPONENT;if(n===_r)return i.DEPTH_STENCIL;if(n===lu)return i.RED;if(n===cu)return i.RED_INTEGER;if(n===qf)return i.RG;if(n===hu)return i.RG_INTEGER;if(n===uu)return i.RGBA_INTEGER;if(n===Pa||n===Ia||n===La||n===ka)if(o===pe)if(r=t.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===Pa)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Ia)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===La)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===ka)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=t.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===Pa)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Ia)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===La)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===ka)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===Wc||n===$c||n===qc||n===Xc)if(r=t.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===Wc)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===$c)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===qc)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===Xc)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===Yc||n===Zc||n===Kc)if(r=t.get("WEBGL_compressed_texture_etc"),r!==null){if(n===Yc||n===Zc)return o===pe?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===Kc)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===Jc||n===jc||n===Qc||n===th||n===eh||n===nh||n===ih||n===sh||n===rh||n===oh||n===ah||n===lh||n===ch||n===hh)if(r=t.get("WEBGL_compressed_texture_astc"),r!==null){if(n===Jc)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===jc)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Qc)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===th)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===eh)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===nh)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===ih)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===sh)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===rh)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===oh)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===ah)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===lh)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===ch)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===hh)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===Da||n===uh||n===dh)if(r=t.get("EXT_texture_compression_bptc"),r!==null){if(n===Da)return o===pe?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===uh)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===dh)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===Xf||n===fh||n===ph||n===mh)if(r=t.get("EXT_texture_compression_rgtc"),r!==null){if(n===Da)return r.COMPRESSED_RED_RGTC1_EXT;if(n===fh)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===ph)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===mh)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===br?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:e}}var Ih=class extends Ge{constructor(t=[]){super(),this.isArrayCamera=!0,this.cameras=t}},Qt=class extends We{constructor(){super(),this.isGroup=!0,this.type="Group"}},Ib={type:"move"},ao=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Qt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Qt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new P,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new P),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Qt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new P,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new P),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){let e=this._hand;if(e)for(let n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let s=null,r=null,o=null,a=this._targetRay,l=this._grip,c=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(c&&t.hand){o=!0;for(let x of t.hand.values()){let g=e.getJointPose(x,n),p=this._getHandJoint(c,x);g!==null&&(p.matrix.fromArray(g.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=g.radius),p.visible=g!==null}let h=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],d=h.position.distanceTo(u.position),f=.02,m=.005;c.inputState.pinching&&d>f+m?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!c.inputState.pinching&&d<=f-m&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else l!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,n),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1));a!==null&&(s=e.getPose(t.targetRaySpace,n),s===null&&r!==null&&(s=r),s!==null&&(a.matrix.fromArray(s.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,s.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(s.linearVelocity)):a.hasLinearVelocity=!1,s.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(s.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(Ib)))}return a!==null&&(a.visible=s!==null),l!==null&&(l.visible=r!==null),c!==null&&(c.visible=o!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){let n=new Qt;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}},Lb=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,kb=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`,Lh=class{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,e,n){if(this.texture===null){let s=new mn,r=t.properties.get(s);r.__webglTexture=e.texture,(e.depthNear!=n.depthNear||e.depthFar!=n.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=s}}getMesh(t){if(this.texture!==null&&this.mesh===null){let e=t.cameras[0].viewport,n=new xn({vertexShader:Lb,fragmentShader:kb,uniforms:{depthColor:{value:this.texture},depthWidth:{value:e.z},depthHeight:{value:e.w}}});this.mesh=new nt(new Ln(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}},kh=class extends Qi{constructor(t,e){super();let n=this,s=null,r=1,o=null,a="local-floor",l=1,c=null,h=null,u=null,d=null,f=null,m=null,x=new Lh,g=e.getContextAttributes(),p=null,M=null,v=[],y=[],w=new rt,S=null,T=new Ge;T.viewport=new Me;let R=new Ge;R.viewport=new Me;let _=[T,R],b=new Ih,C=null,L=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(Y){let et=v[Y];return et===void 0&&(et=new ao,v[Y]=et),et.getTargetRaySpace()},this.getControllerGrip=function(Y){let et=v[Y];return et===void 0&&(et=new ao,v[Y]=et),et.getGripSpace()},this.getHand=function(Y){let et=v[Y];return et===void 0&&(et=new ao,v[Y]=et),et.getHandSpace()};function k(Y){let et=y.indexOf(Y.inputSource);if(et===-1)return;let Mt=v[et];Mt!==void 0&&(Mt.update(Y.inputSource,Y.frame,c||o),Mt.dispatchEvent({type:Y.type,data:Y.inputSource}))}function D(){s.removeEventListener("select",k),s.removeEventListener("selectstart",k),s.removeEventListener("selectend",k),s.removeEventListener("squeeze",k),s.removeEventListener("squeezestart",k),s.removeEventListener("squeezeend",k),s.removeEventListener("end",D),s.removeEventListener("inputsourceschange",V);for(let Y=0;Y<v.length;Y++){let et=y[Y];et!==null&&(y[Y]=null,v[Y].disconnect(et))}C=null,L=null,x.reset(),t.setRenderTarget(p),f=null,d=null,u=null,s=null,M=null,Vt.stop(),n.isPresenting=!1,t.setPixelRatio(S),t.setSize(w.width,w.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(Y){r=Y,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(Y){a=Y,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||o},this.setReferenceSpace=function(Y){c=Y},this.getBaseLayer=function(){return d!==null?d:f},this.getBinding=function(){return u},this.getFrame=function(){return m},this.getSession=function(){return s},this.setSession=async function(Y){if(s=Y,s!==null){if(p=t.getRenderTarget(),s.addEventListener("select",k),s.addEventListener("selectstart",k),s.addEventListener("selectend",k),s.addEventListener("squeeze",k),s.addEventListener("squeezestart",k),s.addEventListener("squeezeend",k),s.addEventListener("end",D),s.addEventListener("inputsourceschange",V),g.xrCompatible!==!0&&await e.makeXRCompatible(),S=t.getPixelRatio(),t.getSize(w),s.renderState.layers===void 0){let et={antialias:g.antialias,alpha:!0,depth:g.depth,stencil:g.stencil,framebufferScaleFactor:r};f=new XRWebGLLayer(s,e,et),s.updateRenderState({baseLayer:f}),t.setPixelRatio(1),t.setSize(f.framebufferWidth,f.framebufferHeight,!1),M=new Qn(f.framebufferWidth,f.framebufferHeight,{format:jn,type:Pi,colorSpace:t.outputColorSpace,stencilBuffer:g.stencil})}else{let et=null,Mt=null,ht=null;g.depth&&(ht=g.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,et=g.stencil?_r:pr,Mt=g.stencil?br:ws);let Nt={colorFormat:e.RGBA8,depthFormat:ht,scaleFactor:r};u=new XRWebGLBinding(s,e),d=u.createProjectionLayer(Nt),s.updateRenderState({layers:[d]}),t.setPixelRatio(1),t.setSize(d.textureWidth,d.textureHeight,!1),M=new Qn(d.textureWidth,d.textureHeight,{format:jn,type:Pi,depthTexture:new $a(d.textureWidth,d.textureHeight,Mt,void 0,void 0,void 0,void 0,void 0,void 0,et),stencilBuffer:g.stencil,colorSpace:t.outputColorSpace,samples:g.antialias?4:0,resolveDepthBuffer:d.ignoreDepthValues===!1})}M.isXRRenderTarget=!0,this.setFoveation(l),c=null,o=await s.requestReferenceSpace(a),Vt.setContext(s),Vt.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return x.getDepthTexture()};function V(Y){for(let et=0;et<Y.removed.length;et++){let Mt=Y.removed[et],ht=y.indexOf(Mt);ht>=0&&(y[ht]=null,v[ht].disconnect(Mt))}for(let et=0;et<Y.added.length;et++){let Mt=Y.added[et],ht=y.indexOf(Mt);if(ht===-1){for(let Ot=0;Ot<v.length;Ot++)if(Ot>=y.length){y.push(Mt),ht=Ot;break}else if(y[Ot]===null){y[Ot]=Mt,ht=Ot;break}if(ht===-1)break}let Nt=v[ht];Nt&&Nt.connect(Mt)}}let z=new P,G=new P;function F(Y,et,Mt){z.setFromMatrixPosition(et.matrixWorld),G.setFromMatrixPosition(Mt.matrixWorld);let ht=z.distanceTo(G),Nt=et.projectionMatrix.elements,Ot=Mt.projectionMatrix.elements,Jt=Nt[14]/(Nt[10]-1),Ee=Nt[14]/(Nt[10]+1),ie=(Nt[9]+1)/Nt[5],Ne=(Nt[9]-1)/Nt[5],H=(Nt[8]-1)/Nt[0],Bn=(Ot[8]+1)/Ot[0],te=Jt*H,ee=Jt*Bn,Dt=ht/(-H+Bn),ve=Dt*-H;if(et.matrixWorld.decompose(Y.position,Y.quaternion,Y.scale),Y.translateX(ve),Y.translateZ(Dt),Y.matrixWorld.compose(Y.position,Y.quaternion,Y.scale),Y.matrixWorldInverse.copy(Y.matrixWorld).invert(),Nt[10]===-1)Y.projectionMatrix.copy(et.projectionMatrix),Y.projectionMatrixInverse.copy(et.projectionMatrixInverse);else{let Lt=Jt+Dt,I=Ee+Dt,E=te-ve,W=ee+(ht-ve),J=ie*Ee/I*Lt,tt=Ne*Ee/I*Lt;Y.projectionMatrix.makePerspective(E,W,J,tt,Lt,I),Y.projectionMatrixInverse.copy(Y.projectionMatrix).invert()}}function K(Y,et){et===null?Y.matrixWorld.copy(Y.matrix):Y.matrixWorld.multiplyMatrices(et.matrixWorld,Y.matrix),Y.matrixWorldInverse.copy(Y.matrixWorld).invert()}this.updateCamera=function(Y){if(s===null)return;let et=Y.near,Mt=Y.far;x.texture!==null&&(x.depthNear>0&&(et=x.depthNear),x.depthFar>0&&(Mt=x.depthFar)),b.near=R.near=T.near=et,b.far=R.far=T.far=Mt,(C!==b.near||L!==b.far)&&(s.updateRenderState({depthNear:b.near,depthFar:b.far}),C=b.near,L=b.far),T.layers.mask=Y.layers.mask|2,R.layers.mask=Y.layers.mask|4,b.layers.mask=T.layers.mask|R.layers.mask;let ht=Y.parent,Nt=b.cameras;K(b,ht);for(let Ot=0;Ot<Nt.length;Ot++)K(Nt[Ot],ht);Nt.length===2?F(b,T,R):b.projectionMatrix.copy(T.projectionMatrix),Q(Y,b,ht)};function Q(Y,et,Mt){Mt===null?Y.matrix.copy(et.matrixWorld):(Y.matrix.copy(Mt.matrixWorld),Y.matrix.invert(),Y.matrix.multiply(et.matrixWorld)),Y.matrix.decompose(Y.position,Y.quaternion,Y.scale),Y.updateMatrixWorld(!0),Y.projectionMatrix.copy(et.projectionMatrix),Y.projectionMatrixInverse.copy(et.projectionMatrixInverse),Y.isPerspectiveCamera&&(Y.fov=fo*2*Math.atan(1/Y.projectionMatrix.elements[5]),Y.zoom=1)}this.getCamera=function(){return b},this.getFoveation=function(){if(!(d===null&&f===null))return l},this.setFoveation=function(Y){l=Y,d!==null&&(d.fixedFoveation=Y),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=Y)},this.hasDepthSensing=function(){return x.texture!==null},this.getDepthSensingMesh=function(){return x.getMesh(b)};let ot=null;function St(Y,et){if(h=et.getViewerPose(c||o),m=et,h!==null){let Mt=h.views;f!==null&&(t.setRenderTargetFramebuffer(M,f.framebuffer),t.setRenderTarget(M));let ht=!1;Mt.length!==b.cameras.length&&(b.cameras.length=0,ht=!0);for(let Ot=0;Ot<Mt.length;Ot++){let Jt=Mt[Ot],Ee=null;if(f!==null)Ee=f.getViewport(Jt);else{let Ne=u.getViewSubImage(d,Jt);Ee=Ne.viewport,Ot===0&&(t.setRenderTargetTextures(M,Ne.colorTexture,d.ignoreDepthValues?void 0:Ne.depthStencilTexture),t.setRenderTarget(M))}let ie=_[Ot];ie===void 0&&(ie=new Ge,ie.layers.enable(Ot),ie.viewport=new Me,_[Ot]=ie),ie.matrix.fromArray(Jt.transform.matrix),ie.matrix.decompose(ie.position,ie.quaternion,ie.scale),ie.projectionMatrix.fromArray(Jt.projectionMatrix),ie.projectionMatrixInverse.copy(ie.projectionMatrix).invert(),ie.viewport.set(Ee.x,Ee.y,Ee.width,Ee.height),Ot===0&&(b.matrix.copy(ie.matrix),b.matrix.decompose(b.position,b.quaternion,b.scale)),ht===!0&&b.cameras.push(ie)}let Nt=s.enabledFeatures;if(Nt&&Nt.includes("depth-sensing")){let Ot=u.getDepthInformation(Mt[0]);Ot&&Ot.isValid&&Ot.texture&&x.init(t,Ot,s.renderState)}}for(let Mt=0;Mt<v.length;Mt++){let ht=y[Mt],Nt=v[Mt];ht!==null&&Nt!==void 0&&Nt.update(ht,et,c||o)}ot&&ot(Y,et),et.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:et}),m=null}let Vt=new Qf;Vt.setAnimationLoop(St),this.setAnimationLoop=function(Y){ot=Y},this.dispose=function(){}}},xs=new gn,Db=new qt;function Ub(i,t){function e(g,p){g.matrixAutoUpdate===!0&&g.updateMatrix(),p.value.copy(g.matrix)}function n(g,p){p.color.getRGB(g.fogColor.value,jf(i)),p.isFog?(g.fogNear.value=p.near,g.fogFar.value=p.far):p.isFogExp2&&(g.fogDensity.value=p.density)}function s(g,p,M,v,y){p.isMeshBasicMaterial||p.isMeshLambertMaterial?r(g,p):p.isMeshToonMaterial?(r(g,p),u(g,p)):p.isMeshPhongMaterial?(r(g,p),h(g,p)):p.isMeshStandardMaterial?(r(g,p),d(g,p),p.isMeshPhysicalMaterial&&f(g,p,y)):p.isMeshMatcapMaterial?(r(g,p),m(g,p)):p.isMeshDepthMaterial?r(g,p):p.isMeshDistanceMaterial?(r(g,p),x(g,p)):p.isMeshNormalMaterial?r(g,p):p.isLineBasicMaterial?(o(g,p),p.isLineDashedMaterial&&a(g,p)):p.isPointsMaterial?l(g,p,M,v):p.isSpriteMaterial?c(g,p):p.isShadowMaterial?(g.color.value.copy(p.color),g.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function r(g,p){g.opacity.value=p.opacity,p.color&&g.diffuse.value.copy(p.color),p.emissive&&g.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(g.map.value=p.map,e(p.map,g.mapTransform)),p.alphaMap&&(g.alphaMap.value=p.alphaMap,e(p.alphaMap,g.alphaMapTransform)),p.bumpMap&&(g.bumpMap.value=p.bumpMap,e(p.bumpMap,g.bumpMapTransform),g.bumpScale.value=p.bumpScale,p.side===en&&(g.bumpScale.value*=-1)),p.normalMap&&(g.normalMap.value=p.normalMap,e(p.normalMap,g.normalMapTransform),g.normalScale.value.copy(p.normalScale),p.side===en&&g.normalScale.value.negate()),p.displacementMap&&(g.displacementMap.value=p.displacementMap,e(p.displacementMap,g.displacementMapTransform),g.displacementScale.value=p.displacementScale,g.displacementBias.value=p.displacementBias),p.emissiveMap&&(g.emissiveMap.value=p.emissiveMap,e(p.emissiveMap,g.emissiveMapTransform)),p.specularMap&&(g.specularMap.value=p.specularMap,e(p.specularMap,g.specularMapTransform)),p.alphaTest>0&&(g.alphaTest.value=p.alphaTest);let M=t.get(p),v=M.envMap,y=M.envMapRotation;v&&(g.envMap.value=v,xs.copy(y),xs.x*=-1,xs.y*=-1,xs.z*=-1,v.isCubeTexture&&v.isRenderTargetTexture===!1&&(xs.y*=-1,xs.z*=-1),g.envMapRotation.value.setFromMatrix4(Db.makeRotationFromEuler(xs)),g.flipEnvMap.value=v.isCubeTexture&&v.isRenderTargetTexture===!1?-1:1,g.reflectivity.value=p.reflectivity,g.ior.value=p.ior,g.refractionRatio.value=p.refractionRatio),p.lightMap&&(g.lightMap.value=p.lightMap,g.lightMapIntensity.value=p.lightMapIntensity,e(p.lightMap,g.lightMapTransform)),p.aoMap&&(g.aoMap.value=p.aoMap,g.aoMapIntensity.value=p.aoMapIntensity,e(p.aoMap,g.aoMapTransform))}function o(g,p){g.diffuse.value.copy(p.color),g.opacity.value=p.opacity,p.map&&(g.map.value=p.map,e(p.map,g.mapTransform))}function a(g,p){g.dashSize.value=p.dashSize,g.totalSize.value=p.dashSize+p.gapSize,g.scale.value=p.scale}function l(g,p,M,v){g.diffuse.value.copy(p.color),g.opacity.value=p.opacity,g.size.value=p.size*M,g.scale.value=v*.5,p.map&&(g.map.value=p.map,e(p.map,g.uvTransform)),p.alphaMap&&(g.alphaMap.value=p.alphaMap,e(p.alphaMap,g.alphaMapTransform)),p.alphaTest>0&&(g.alphaTest.value=p.alphaTest)}function c(g,p){g.diffuse.value.copy(p.color),g.opacity.value=p.opacity,g.rotation.value=p.rotation,p.map&&(g.map.value=p.map,e(p.map,g.mapTransform)),p.alphaMap&&(g.alphaMap.value=p.alphaMap,e(p.alphaMap,g.alphaMapTransform)),p.alphaTest>0&&(g.alphaTest.value=p.alphaTest)}function h(g,p){g.specular.value.copy(p.specular),g.shininess.value=Math.max(p.shininess,1e-4)}function u(g,p){p.gradientMap&&(g.gradientMap.value=p.gradientMap)}function d(g,p){g.metalness.value=p.metalness,p.metalnessMap&&(g.metalnessMap.value=p.metalnessMap,e(p.metalnessMap,g.metalnessMapTransform)),g.roughness.value=p.roughness,p.roughnessMap&&(g.roughnessMap.value=p.roughnessMap,e(p.roughnessMap,g.roughnessMapTransform)),p.envMap&&(g.envMapIntensity.value=p.envMapIntensity)}function f(g,p,M){g.ior.value=p.ior,p.sheen>0&&(g.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),g.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(g.sheenColorMap.value=p.sheenColorMap,e(p.sheenColorMap,g.sheenColorMapTransform)),p.sheenRoughnessMap&&(g.sheenRoughnessMap.value=p.sheenRoughnessMap,e(p.sheenRoughnessMap,g.sheenRoughnessMapTransform))),p.clearcoat>0&&(g.clearcoat.value=p.clearcoat,g.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(g.clearcoatMap.value=p.clearcoatMap,e(p.clearcoatMap,g.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(g.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,e(p.clearcoatRoughnessMap,g.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(g.clearcoatNormalMap.value=p.clearcoatNormalMap,e(p.clearcoatNormalMap,g.clearcoatNormalMapTransform),g.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===en&&g.clearcoatNormalScale.value.negate())),p.dispersion>0&&(g.dispersion.value=p.dispersion),p.iridescence>0&&(g.iridescence.value=p.iridescence,g.iridescenceIOR.value=p.iridescenceIOR,g.iridescenceThicknessMinimum.value=p.iridescenceThicknessRange[0],g.iridescenceThicknessMaximum.value=p.iridescenceThicknessRange[1],p.iridescenceMap&&(g.iridescenceMap.value=p.iridescenceMap,e(p.iridescenceMap,g.iridescenceMapTransform)),p.iridescenceThicknessMap&&(g.iridescenceThicknessMap.value=p.iridescenceThicknessMap,e(p.iridescenceThicknessMap,g.iridescenceThicknessMapTransform))),p.transmission>0&&(g.transmission.value=p.transmission,g.transmissionSamplerMap.value=M.texture,g.transmissionSamplerSize.value.set(M.width,M.height),p.transmissionMap&&(g.transmissionMap.value=p.transmissionMap,e(p.transmissionMap,g.transmissionMapTransform)),g.thickness.value=p.thickness,p.thicknessMap&&(g.thicknessMap.value=p.thicknessMap,e(p.thicknessMap,g.thicknessMapTransform)),g.attenuationDistance.value=p.attenuationDistance,g.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(g.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(g.anisotropyMap.value=p.anisotropyMap,e(p.anisotropyMap,g.anisotropyMapTransform))),g.specularIntensity.value=p.specularIntensity,g.specularColor.value.copy(p.specularColor),p.specularColorMap&&(g.specularColorMap.value=p.specularColorMap,e(p.specularColorMap,g.specularColorMapTransform)),p.specularIntensityMap&&(g.specularIntensityMap.value=p.specularIntensityMap,e(p.specularIntensityMap,g.specularIntensityMapTransform))}function m(g,p){p.matcap&&(g.matcap.value=p.matcap)}function x(g,p){let M=t.get(p).light;g.referencePosition.value.setFromMatrixPosition(M.matrixWorld),g.nearDistance.value=M.shadow.camera.near,g.farDistance.value=M.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function Nb(i,t,e,n){let s={},r={},o=[],a=i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS);function l(M,v){let y=v.program;n.uniformBlockBinding(M,y)}function c(M,v){let y=s[M.id];y===void 0&&(m(M),y=h(M),s[M.id]=y,M.addEventListener("dispose",g));let w=v.program;n.updateUBOMapping(M,w);let S=t.render.frame;r[M.id]!==S&&(d(M),r[M.id]=S)}function h(M){let v=u();M.__bindingPointIndex=v;let y=i.createBuffer(),w=M.__size,S=M.usage;return i.bindBuffer(i.UNIFORM_BUFFER,y),i.bufferData(i.UNIFORM_BUFFER,w,S),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,v,y),y}function u(){for(let M=0;M<a;M++)if(o.indexOf(M)===-1)return o.push(M),M;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function d(M){let v=s[M.id],y=M.uniforms,w=M.__cache;i.bindBuffer(i.UNIFORM_BUFFER,v);for(let S=0,T=y.length;S<T;S++){let R=Array.isArray(y[S])?y[S]:[y[S]];for(let _=0,b=R.length;_<b;_++){let C=R[_];if(f(C,S,_,w)===!0){let L=C.__offset,k=Array.isArray(C.value)?C.value:[C.value],D=0;for(let V=0;V<k.length;V++){let z=k[V],G=x(z);typeof z=="number"||typeof z=="boolean"?(C.__data[0]=z,i.bufferSubData(i.UNIFORM_BUFFER,L+D,C.__data)):z.isMatrix3?(C.__data[0]=z.elements[0],C.__data[1]=z.elements[1],C.__data[2]=z.elements[2],C.__data[3]=0,C.__data[4]=z.elements[3],C.__data[5]=z.elements[4],C.__data[6]=z.elements[5],C.__data[7]=0,C.__data[8]=z.elements[6],C.__data[9]=z.elements[7],C.__data[10]=z.elements[8],C.__data[11]=0):(z.toArray(C.__data,D),D+=G.storage/Float32Array.BYTES_PER_ELEMENT)}i.bufferSubData(i.UNIFORM_BUFFER,L,C.__data)}}}i.bindBuffer(i.UNIFORM_BUFFER,null)}function f(M,v,y,w){let S=M.value,T=v+"_"+y;if(w[T]===void 0)return typeof S=="number"||typeof S=="boolean"?w[T]=S:w[T]=S.clone(),!0;{let R=w[T];if(typeof S=="number"||typeof S=="boolean"){if(R!==S)return w[T]=S,!0}else if(R.equals(S)===!1)return R.copy(S),!0}return!1}function m(M){let v=M.uniforms,y=0,w=16;for(let T=0,R=v.length;T<R;T++){let _=Array.isArray(v[T])?v[T]:[v[T]];for(let b=0,C=_.length;b<C;b++){let L=_[b],k=Array.isArray(L.value)?L.value:[L.value];for(let D=0,V=k.length;D<V;D++){let z=k[D],G=x(z),F=y%w,K=F%G.boundary,Q=F+K;y+=K,Q!==0&&w-Q<G.storage&&(y+=w-Q),L.__data=new Float32Array(G.storage/Float32Array.BYTES_PER_ELEMENT),L.__offset=y,y+=G.storage}}}let S=y%w;return S>0&&(y+=w-S),M.__size=y,M.__cache={},this}function x(M){let v={boundary:0,storage:0};return typeof M=="number"||typeof M=="boolean"?(v.boundary=4,v.storage=4):M.isVector2?(v.boundary=8,v.storage=8):M.isVector3||M.isColor?(v.boundary=16,v.storage=12):M.isVector4?(v.boundary=16,v.storage=16):M.isMatrix3?(v.boundary=48,v.storage=48):M.isMatrix4?(v.boundary=64,v.storage=64):M.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",M),v}function g(M){let v=M.target;v.removeEventListener("dispose",g);let y=o.indexOf(v.__bindingPointIndex);o.splice(y,1),i.deleteBuffer(s[v.id]),delete s[v.id],delete r[v.id]}function p(){for(let M in s)i.deleteBuffer(s[M]);o=[],s={},r={}}return{bind:l,update:c,dispose:p}}var qa=class{constructor(t={}){let{canvas:e=H0(),context:n=null,depth:s=!0,stencil:r=!1,alpha:o=!1,antialias:a=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1,reverseDepthBuffer:d=!1}=t;this.isWebGLRenderer=!0;let f;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");f=n.getContextAttributes().alpha}else f=o;let m=new Uint32Array(4),x=new Int32Array(4),g=null,p=null,M=[],v=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=me,this.toneMapping=ji,this.toneMappingExposure=1;let y=this,w=!1,S=0,T=0,R=null,_=-1,b=null,C=new Me,L=new Me,k=null,D=new wt(0),V=0,z=e.width,G=e.height,F=1,K=null,Q=null,ot=new Me(0,0,z,G),St=new Me(0,0,z,G),Vt=!1,Y=new go,et=!1,Mt=!1,ht=new qt,Nt=new qt,Ot=new P,Jt=new Me,Ee={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0},ie=!1;function Ne(){return R===null?F:1}let H=n;function Bn(A,B){return e.getContext(A,B)}try{let A={alpha:!0,depth:s,stencil:r,antialias:a,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${nu}`),e.addEventListener("webglcontextlost",j,!1),e.addEventListener("webglcontextrestored",mt,!1),e.addEventListener("webglcontextcreationerror",dt,!1),H===null){let B="webgl2";if(H=Bn(B,A),H===null)throw Bn(B)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(A){throw console.error("THREE.WebGLRenderer: "+A.message),A}let te,ee,Dt,ve,Lt,I,E,W,J,tt,Z,Rt,ut,gt,se,it,yt,Ut,Ft,vt,ne,Zt,ge,N;function ct(){te=new jy(H),te.init(),Zt=new Pb(H,te),ee=new qy(H,te,t,Zt),Dt=new Ab(H,te),ee.reverseDepthBuffer&&d&&Dt.buffers.depth.setReversed(!0),ve=new ev(H),Lt=new pb,I=new Cb(H,te,Dt,Lt,ee,Zt,ve),E=new Yy(y),W=new Jy(y),J=new lg(H),ge=new Wy(H,J),tt=new Qy(H,J,ve,ge),Z=new iv(H,tt,J,ve),Ft=new nv(H,ee,I),it=new Xy(Lt),Rt=new fb(y,E,W,te,ee,ge,it),ut=new Ub(y,Lt),gt=new gb,se=new Mb(te),Ut=new Gy(y,E,W,Dt,Z,f,l),yt=new Eb(y,Z,ee),N=new Nb(H,ve,ee,Dt),vt=new $y(H,te,ve),ne=new tv(H,te,ve),ve.programs=Rt.programs,y.capabilities=ee,y.extensions=te,y.properties=Lt,y.renderLists=gt,y.shadowMap=yt,y.state=Dt,y.info=ve}ct();let X=new kh(y,H);this.xr=X,this.getContext=function(){return H},this.getContextAttributes=function(){return H.getContextAttributes()},this.forceContextLoss=function(){let A=te.get("WEBGL_lose_context");A&&A.loseContext()},this.forceContextRestore=function(){let A=te.get("WEBGL_lose_context");A&&A.restoreContext()},this.getPixelRatio=function(){return F},this.setPixelRatio=function(A){A!==void 0&&(F=A,this.setSize(z,G,!1))},this.getSize=function(A){return A.set(z,G)},this.setSize=function(A,B,$=!0){if(X.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}z=A,G=B,e.width=Math.floor(A*F),e.height=Math.floor(B*F),$===!0&&(e.style.width=A+"px",e.style.height=B+"px"),this.setViewport(0,0,A,B)},this.getDrawingBufferSize=function(A){return A.set(z*F,G*F).floor()},this.setDrawingBufferSize=function(A,B,$){z=A,G=B,F=$,e.width=Math.floor(A*$),e.height=Math.floor(B*$),this.setViewport(0,0,A,B)},this.getCurrentViewport=function(A){return A.copy(C)},this.getViewport=function(A){return A.copy(ot)},this.setViewport=function(A,B,$,q){A.isVector4?ot.set(A.x,A.y,A.z,A.w):ot.set(A,B,$,q),Dt.viewport(C.copy(ot).multiplyScalar(F).round())},this.getScissor=function(A){return A.copy(St)},this.setScissor=function(A,B,$,q){A.isVector4?St.set(A.x,A.y,A.z,A.w):St.set(A,B,$,q),Dt.scissor(L.copy(St).multiplyScalar(F).round())},this.getScissorTest=function(){return Vt},this.setScissorTest=function(A){Dt.setScissorTest(Vt=A)},this.setOpaqueSort=function(A){K=A},this.setTransparentSort=function(A){Q=A},this.getClearColor=function(A){return A.copy(Ut.getClearColor())},this.setClearColor=function(){Ut.setClearColor.apply(Ut,arguments)},this.getClearAlpha=function(){return Ut.getClearAlpha()},this.setClearAlpha=function(){Ut.setClearAlpha.apply(Ut,arguments)},this.clear=function(A=!0,B=!0,$=!0){let q=0;if(A){let O=!1;if(R!==null){let st=R.texture.format;O=st===uu||st===hu||st===cu}if(O){let st=R.texture.type,ft=st===Pi||st===ws||st===uo||st===br||st===ou||st===au,Et=Ut.getClearColor(),Tt=Ut.getClearAlpha(),Bt=Et.r,Wt=Et.g,At=Et.b;ft?(m[0]=Bt,m[1]=Wt,m[2]=At,m[3]=Tt,H.clearBufferuiv(H.COLOR,0,m)):(x[0]=Bt,x[1]=Wt,x[2]=At,x[3]=Tt,H.clearBufferiv(H.COLOR,0,x))}else q|=H.COLOR_BUFFER_BIT}B&&(q|=H.DEPTH_BUFFER_BIT),$&&(q|=H.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),H.clear(q)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",j,!1),e.removeEventListener("webglcontextrestored",mt,!1),e.removeEventListener("webglcontextcreationerror",dt,!1),gt.dispose(),se.dispose(),Lt.dispose(),E.dispose(),W.dispose(),Z.dispose(),ge.dispose(),N.dispose(),Rt.dispose(),X.dispose(),X.removeEventListener("sessionstart",cd),X.removeEventListener("sessionend",hd),us.stop()};function j(A){A.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),w=!0}function mt(){console.log("THREE.WebGLRenderer: Context Restored."),w=!1;let A=ve.autoReset,B=yt.enabled,$=yt.autoUpdate,q=yt.needsUpdate,O=yt.type;ct(),ve.autoReset=A,yt.enabled=B,yt.autoUpdate=$,yt.needsUpdate=q,yt.type=O}function dt(A){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",A.statusMessage)}function Gt(A){let B=A.target;B.removeEventListener("dispose",Gt),Le(B)}function Le(A){je(A),Lt.remove(A)}function je(A){let B=Lt.get(A).programs;B!==void 0&&(B.forEach(function($){Rt.releaseProgram($)}),A.isShaderMaterial&&Rt.releaseShaderCache(A))}this.renderBufferDirect=function(A,B,$,q,O,st){B===null&&(B=Ee);let ft=O.isMesh&&O.matrixWorld.determinant()<0,Et=zm(A,B,$,q,O);Dt.setMaterial(q,ft);let Tt=$.index,Bt=1;if(q.wireframe===!0){if(Tt=tt.getWireframeAttribute($),Tt===void 0)return;Bt=2}let Wt=$.drawRange,At=$.attributes.position,le=Wt.start*Bt,xe=(Wt.start+Wt.count)*Bt;st!==null&&(le=Math.max(le,st.start*Bt),xe=Math.min(xe,(st.start+st.count)*Bt)),Tt!==null?(le=Math.max(le,0),xe=Math.min(xe,Tt.count)):At!=null&&(le=Math.max(le,0),xe=Math.min(xe,At.count));let be=xe-le;if(be<0||be===1/0)return;ge.setup(O,q,Et,$,Tt);let pn,he=vt;if(Tt!==null&&(pn=J.get(Tt),he=ne,he.setIndex(pn)),O.isMesh)q.wireframe===!0?(Dt.setLineWidth(q.wireframeLinewidth*Ne()),he.setMode(H.LINES)):he.setMode(H.TRIANGLES);else if(O.isLine){let Ct=q.linewidth;Ct===void 0&&(Ct=1),Dt.setLineWidth(Ct*Ne()),O.isLineSegments?he.setMode(H.LINES):O.isLineLoop?he.setMode(H.LINE_LOOP):he.setMode(H.LINE_STRIP)}else O.isPoints?he.setMode(H.POINTS):O.isSprite&&he.setMode(H.TRIANGLES);if(O.isBatchedMesh)if(O._multiDrawInstances!==null)he.renderMultiDrawInstances(O._multiDrawStarts,O._multiDrawCounts,O._multiDrawCount,O._multiDrawInstances);else if(te.get("WEBGL_multi_draw"))he.renderMultiDraw(O._multiDrawStarts,O._multiDrawCounts,O._multiDrawCount);else{let Ct=O._multiDrawStarts,bi=O._multiDrawCounts,ue=O._multiDrawCount,Xn=Tt?J.get(Tt).bytesPerElement:1,$s=Lt.get(q).currentProgram.getUniforms();for(let An=0;An<ue;An++)$s.setValue(H,"_gl_DrawID",An),he.render(Ct[An]/Xn,bi[An])}else if(O.isInstancedMesh)he.renderInstances(le,be,O.count);else if($.isInstancedBufferGeometry){let Ct=$._maxInstanceCount!==void 0?$._maxInstanceCount:1/0,bi=Math.min($.instanceCount,Ct);he.renderInstances(le,be,bi)}else he.render(le,be)};function de(A,B,$){A.transparent===!0&&A.side===Te&&A.forceSinglePass===!1?(A.side=en,A.needsUpdate=!0,jo(A,B,$),A.side=hi,A.needsUpdate=!0,jo(A,B,$),A.side=Te):jo(A,B,$)}this.compile=function(A,B,$=null){$===null&&($=A),p=se.get($),p.init(B),v.push(p),$.traverseVisible(function(O){O.isLight&&O.layers.test(B.layers)&&(p.pushLight(O),O.castShadow&&p.pushShadow(O))}),A!==$&&A.traverseVisible(function(O){O.isLight&&O.layers.test(B.layers)&&(p.pushLight(O),O.castShadow&&p.pushShadow(O))}),p.setupLights();let q=new Set;return A.traverse(function(O){if(!(O.isMesh||O.isPoints||O.isLine||O.isSprite))return;let st=O.material;if(st)if(Array.isArray(st))for(let ft=0;ft<st.length;ft++){let Et=st[ft];de(Et,$,O),q.add(Et)}else de(st,$,O),q.add(st)}),v.pop(),p=null,q},this.compileAsync=function(A,B,$=null){let q=this.compile(A,B,$);return new Promise(O=>{function st(){if(q.forEach(function(ft){Lt.get(ft).currentProgram.isReady()&&q.delete(ft)}),q.size===0){O(A);return}setTimeout(st,10)}te.get("KHR_parallel_shader_compile")!==null?st():setTimeout(st,10)})};let qn=null;function vi(A){qn&&qn(A)}function cd(){us.stop()}function hd(){us.start()}let us=new Qf;us.setAnimationLoop(vi),typeof self<"u"&&us.setContext(self),this.setAnimationLoop=function(A){qn=A,X.setAnimationLoop(A),A===null?us.stop():us.start()},X.addEventListener("sessionstart",cd),X.addEventListener("sessionend",hd),this.render=function(A,B){if(B!==void 0&&B.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(w===!0)return;if(A.matrixWorldAutoUpdate===!0&&A.updateMatrixWorld(),B.parent===null&&B.matrixWorldAutoUpdate===!0&&B.updateMatrixWorld(),X.enabled===!0&&X.isPresenting===!0&&(X.cameraAutoUpdate===!0&&X.updateCamera(B),B=X.getCamera()),A.isScene===!0&&A.onBeforeRender(y,A,B,R),p=se.get(A,v.length),p.init(B),v.push(p),Nt.multiplyMatrices(B.projectionMatrix,B.matrixWorldInverse),Y.setFromProjectionMatrix(Nt),Mt=this.localClippingEnabled,et=it.init(this.clippingPlanes,Mt),g=gt.get(A,M.length),g.init(),M.push(g),X.enabled===!0&&X.isPresenting===!0){let st=y.xr.getDepthSensingMesh();st!==null&&Jl(st,B,-1/0,y.sortObjects)}Jl(A,B,0,y.sortObjects),g.finish(),y.sortObjects===!0&&g.sort(K,Q),ie=X.enabled===!1||X.isPresenting===!1||X.hasDepthSensing()===!1,ie&&Ut.addToRenderList(g,A),this.info.render.frame++,et===!0&&it.beginShadows();let $=p.state.shadowsArray;yt.render($,A,B),et===!0&&it.endShadows(),this.info.autoReset===!0&&this.info.reset();let q=g.opaque,O=g.transmissive;if(p.setupLights(),B.isArrayCamera){let st=B.cameras;if(O.length>0)for(let ft=0,Et=st.length;ft<Et;ft++){let Tt=st[ft];dd(q,O,A,Tt)}ie&&Ut.render(A);for(let ft=0,Et=st.length;ft<Et;ft++){let Tt=st[ft];ud(g,A,Tt,Tt.viewport)}}else O.length>0&&dd(q,O,A,B),ie&&Ut.render(A),ud(g,A,B);R!==null&&(I.updateMultisampleRenderTarget(R),I.updateRenderTargetMipmap(R)),A.isScene===!0&&A.onAfterRender(y,A,B),ge.resetDefaultState(),_=-1,b=null,v.pop(),v.length>0?(p=v[v.length-1],et===!0&&it.setGlobalState(y.clippingPlanes,p.state.camera)):p=null,M.pop(),M.length>0?g=M[M.length-1]:g=null};function Jl(A,B,$,q){if(A.visible===!1)return;if(A.layers.test(B.layers)){if(A.isGroup)$=A.renderOrder;else if(A.isLOD)A.autoUpdate===!0&&A.update(B);else if(A.isLight)p.pushLight(A),A.castShadow&&p.pushShadow(A);else if(A.isSprite){if(!A.frustumCulled||Y.intersectsSprite(A)){q&&Jt.setFromMatrixPosition(A.matrixWorld).applyMatrix4(Nt);let ft=Z.update(A),Et=A.material;Et.visible&&g.push(A,ft,Et,$,Jt.z,null)}}else if((A.isMesh||A.isLine||A.isPoints)&&(!A.frustumCulled||Y.intersectsObject(A))){let ft=Z.update(A),Et=A.material;if(q&&(A.boundingSphere!==void 0?(A.boundingSphere===null&&A.computeBoundingSphere(),Jt.copy(A.boundingSphere.center)):(ft.boundingSphere===null&&ft.computeBoundingSphere(),Jt.copy(ft.boundingSphere.center)),Jt.applyMatrix4(A.matrixWorld).applyMatrix4(Nt)),Array.isArray(Et)){let Tt=ft.groups;for(let Bt=0,Wt=Tt.length;Bt<Wt;Bt++){let At=Tt[Bt],le=Et[At.materialIndex];le&&le.visible&&g.push(A,ft,le,$,Jt.z,At)}}else Et.visible&&g.push(A,ft,Et,$,Jt.z,null)}}let st=A.children;for(let ft=0,Et=st.length;ft<Et;ft++)Jl(st[ft],B,$,q)}function ud(A,B,$,q){let O=A.opaque,st=A.transmissive,ft=A.transparent;p.setupLightsView($),et===!0&&it.setGlobalState(y.clippingPlanes,$),q&&Dt.viewport(C.copy(q)),O.length>0&&Jo(O,B,$),st.length>0&&Jo(st,B,$),ft.length>0&&Jo(ft,B,$),Dt.buffers.depth.setTest(!0),Dt.buffers.depth.setMask(!0),Dt.buffers.color.setMask(!0),Dt.setPolygonOffset(!1)}function dd(A,B,$,q){if(($.isScene===!0?$.overrideMaterial:null)!==null)return;p.state.transmissionRenderTarget[q.id]===void 0&&(p.state.transmissionRenderTarget[q.id]=new Qn(1,1,{generateMipmaps:!0,type:te.has("EXT_color_buffer_half_float")||te.has("EXT_color_buffer_float")?Ro:Pi,minFilter:Ai,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:re.workingColorSpace}));let st=p.state.transmissionRenderTarget[q.id],ft=q.viewport||C;st.setSize(ft.z,ft.w);let Et=y.getRenderTarget();y.setRenderTarget(st),y.getClearColor(D),V=y.getClearAlpha(),V<1&&y.setClearColor(16777215,.5),y.clear(),ie&&Ut.render($);let Tt=y.toneMapping;y.toneMapping=ji;let Bt=q.viewport;if(q.viewport!==void 0&&(q.viewport=void 0),p.setupLightsView(q),et===!0&&it.setGlobalState(y.clippingPlanes,q),Jo(A,$,q),I.updateMultisampleRenderTarget(st),I.updateRenderTargetMipmap(st),te.has("WEBGL_multisampled_render_to_texture")===!1){let Wt=!1;for(let At=0,le=B.length;At<le;At++){let xe=B[At],be=xe.object,pn=xe.geometry,he=xe.material,Ct=xe.group;if(he.side===Te&&be.layers.test(q.layers)){let bi=he.side;he.side=en,he.needsUpdate=!0,fd(be,$,q,pn,he,Ct),he.side=bi,he.needsUpdate=!0,Wt=!0}}Wt===!0&&(I.updateMultisampleRenderTarget(st),I.updateRenderTargetMipmap(st))}y.setRenderTarget(Et),y.setClearColor(D,V),Bt!==void 0&&(q.viewport=Bt),y.toneMapping=Tt}function Jo(A,B,$){let q=B.isScene===!0?B.overrideMaterial:null;for(let O=0,st=A.length;O<st;O++){let ft=A[O],Et=ft.object,Tt=ft.geometry,Bt=q===null?ft.material:q,Wt=ft.group;Et.layers.test($.layers)&&fd(Et,B,$,Tt,Bt,Wt)}}function fd(A,B,$,q,O,st){A.onBeforeRender(y,B,$,q,O,st),A.modelViewMatrix.multiplyMatrices($.matrixWorldInverse,A.matrixWorld),A.normalMatrix.getNormalMatrix(A.modelViewMatrix),O.onBeforeRender(y,B,$,q,A,st),O.transparent===!0&&O.side===Te&&O.forceSinglePass===!1?(O.side=en,O.needsUpdate=!0,y.renderBufferDirect($,B,q,O,A,st),O.side=hi,O.needsUpdate=!0,y.renderBufferDirect($,B,q,O,A,st),O.side=Te):y.renderBufferDirect($,B,q,O,A,st),A.onAfterRender(y,B,$,q,O,st)}function jo(A,B,$){B.isScene!==!0&&(B=Ee);let q=Lt.get(A),O=p.state.lights,st=p.state.shadowsArray,ft=O.state.version,Et=Rt.getParameters(A,O.state,st,B,$),Tt=Rt.getProgramCacheKey(Et),Bt=q.programs;q.environment=A.isMeshStandardMaterial?B.environment:null,q.fog=B.fog,q.envMap=(A.isMeshStandardMaterial?W:E).get(A.envMap||q.environment),q.envMapRotation=q.environment!==null&&A.envMap===null?B.environmentRotation:A.envMapRotation,Bt===void 0&&(A.addEventListener("dispose",Gt),Bt=new Map,q.programs=Bt);let Wt=Bt.get(Tt);if(Wt!==void 0){if(q.currentProgram===Wt&&q.lightsStateVersion===ft)return md(A,Et),Wt}else Et.uniforms=Rt.getUniforms(A),A.onBeforeCompile(Et,y),Wt=Rt.acquireProgram(Et,Tt),Bt.set(Tt,Wt),q.uniforms=Et.uniforms;let At=q.uniforms;return(!A.isShaderMaterial&&!A.isRawShaderMaterial||A.clipping===!0)&&(At.clippingPlanes=it.uniform),md(A,Et),q.needsLights=Bm(A),q.lightsStateVersion=ft,q.needsLights&&(At.ambientLightColor.value=O.state.ambient,At.lightProbe.value=O.state.probe,At.directionalLights.value=O.state.directional,At.directionalLightShadows.value=O.state.directionalShadow,At.spotLights.value=O.state.spot,At.spotLightShadows.value=O.state.spotShadow,At.rectAreaLights.value=O.state.rectArea,At.ltc_1.value=O.state.rectAreaLTC1,At.ltc_2.value=O.state.rectAreaLTC2,At.pointLights.value=O.state.point,At.pointLightShadows.value=O.state.pointShadow,At.hemisphereLights.value=O.state.hemi,At.directionalShadowMap.value=O.state.directionalShadowMap,At.directionalShadowMatrix.value=O.state.directionalShadowMatrix,At.spotShadowMap.value=O.state.spotShadowMap,At.spotLightMatrix.value=O.state.spotLightMatrix,At.spotLightMap.value=O.state.spotLightMap,At.pointShadowMap.value=O.state.pointShadowMap,At.pointShadowMatrix.value=O.state.pointShadowMatrix),q.currentProgram=Wt,q.uniformsList=null,Wt}function pd(A){if(A.uniformsList===null){let B=A.currentProgram.getUniforms();A.uniformsList=gr.seqWithValue(B.seq,A.uniforms)}return A.uniformsList}function md(A,B){let $=Lt.get(A);$.outputColorSpace=B.outputColorSpace,$.batching=B.batching,$.batchingColor=B.batchingColor,$.instancing=B.instancing,$.instancingColor=B.instancingColor,$.instancingMorph=B.instancingMorph,$.skinning=B.skinning,$.morphTargets=B.morphTargets,$.morphNormals=B.morphNormals,$.morphColors=B.morphColors,$.morphTargetsCount=B.morphTargetsCount,$.numClippingPlanes=B.numClippingPlanes,$.numIntersection=B.numClipIntersection,$.vertexAlphas=B.vertexAlphas,$.vertexTangents=B.vertexTangents,$.toneMapping=B.toneMapping}function zm(A,B,$,q,O){B.isScene!==!0&&(B=Ee),I.resetTextureUnits();let st=B.fog,ft=q.isMeshStandardMaterial?B.environment:null,Et=R===null?y.outputColorSpace:R.isXRRenderTarget===!0?R.texture.colorSpace:Rr,Tt=(q.isMeshStandardMaterial?W:E).get(q.envMap||ft),Bt=q.vertexColors===!0&&!!$.attributes.color&&$.attributes.color.itemSize===4,Wt=!!$.attributes.tangent&&(!!q.normalMap||q.anisotropy>0),At=!!$.morphAttributes.position,le=!!$.morphAttributes.normal,xe=!!$.morphAttributes.color,be=ji;q.toneMapped&&(R===null||R.isXRRenderTarget===!0)&&(be=y.toneMapping);let pn=$.morphAttributes.position||$.morphAttributes.normal||$.morphAttributes.color,he=pn!==void 0?pn.length:0,Ct=Lt.get(q),bi=p.state.lights;if(et===!0&&(Mt===!0||A!==b)){let On=A===b&&q.id===_;it.setState(q,A,On)}let ue=!1;q.version===Ct.__version?(Ct.needsLights&&Ct.lightsStateVersion!==bi.state.version||Ct.outputColorSpace!==Et||O.isBatchedMesh&&Ct.batching===!1||!O.isBatchedMesh&&Ct.batching===!0||O.isBatchedMesh&&Ct.batchingColor===!0&&O.colorTexture===null||O.isBatchedMesh&&Ct.batchingColor===!1&&O.colorTexture!==null||O.isInstancedMesh&&Ct.instancing===!1||!O.isInstancedMesh&&Ct.instancing===!0||O.isSkinnedMesh&&Ct.skinning===!1||!O.isSkinnedMesh&&Ct.skinning===!0||O.isInstancedMesh&&Ct.instancingColor===!0&&O.instanceColor===null||O.isInstancedMesh&&Ct.instancingColor===!1&&O.instanceColor!==null||O.isInstancedMesh&&Ct.instancingMorph===!0&&O.morphTexture===null||O.isInstancedMesh&&Ct.instancingMorph===!1&&O.morphTexture!==null||Ct.envMap!==Tt||q.fog===!0&&Ct.fog!==st||Ct.numClippingPlanes!==void 0&&(Ct.numClippingPlanes!==it.numPlanes||Ct.numIntersection!==it.numIntersection)||Ct.vertexAlphas!==Bt||Ct.vertexTangents!==Wt||Ct.morphTargets!==At||Ct.morphNormals!==le||Ct.morphColors!==xe||Ct.toneMapping!==be||Ct.morphTargetsCount!==he)&&(ue=!0):(ue=!0,Ct.__version=q.version);let Xn=Ct.currentProgram;ue===!0&&(Xn=jo(q,B,O));let $s=!1,An=!1,$r=!1,_e=Xn.getUniforms(),oi=Ct.uniforms;if(Dt.useProgram(Xn.program)&&($s=!0,An=!0,$r=!0),q.id!==_&&(_=q.id,An=!0),$s||b!==A){Dt.buffers.depth.getReversed()?(ht.copy(A.projectionMatrix),G0(ht),W0(ht),_e.setValue(H,"projectionMatrix",ht)):_e.setValue(H,"projectionMatrix",A.projectionMatrix),_e.setValue(H,"viewMatrix",A.matrixWorldInverse);let Hi=_e.map.cameraPosition;Hi!==void 0&&Hi.setValue(H,Ot.setFromMatrixPosition(A.matrixWorld)),ee.logarithmicDepthBuffer&&_e.setValue(H,"logDepthBufFC",2/(Math.log(A.far+1)/Math.LN2)),(q.isMeshPhongMaterial||q.isMeshToonMaterial||q.isMeshLambertMaterial||q.isMeshBasicMaterial||q.isMeshStandardMaterial||q.isShaderMaterial)&&_e.setValue(H,"isOrthographic",A.isOrthographicCamera===!0),b!==A&&(b=A,An=!0,$r=!0)}if(O.isSkinnedMesh){_e.setOptional(H,O,"bindMatrix"),_e.setOptional(H,O,"bindMatrixInverse");let On=O.skeleton;On&&(On.boneTexture===null&&On.computeBoneTexture(),_e.setValue(H,"boneTexture",On.boneTexture,I))}O.isBatchedMesh&&(_e.setOptional(H,O,"batchingTexture"),_e.setValue(H,"batchingTexture",O._matricesTexture,I),_e.setOptional(H,O,"batchingIdTexture"),_e.setValue(H,"batchingIdTexture",O._indirectTexture,I),_e.setOptional(H,O,"batchingColorTexture"),O._colorsTexture!==null&&_e.setValue(H,"batchingColorTexture",O._colorsTexture,I));let qr=$.morphAttributes;if((qr.position!==void 0||qr.normal!==void 0||qr.color!==void 0)&&Ft.update(O,$,Xn),(An||Ct.receiveShadow!==O.receiveShadow)&&(Ct.receiveShadow=O.receiveShadow,_e.setValue(H,"receiveShadow",O.receiveShadow)),q.isMeshGouraudMaterial&&q.envMap!==null&&(oi.envMap.value=Tt,oi.flipEnvMap.value=Tt.isCubeTexture&&Tt.isRenderTargetTexture===!1?-1:1),q.isMeshStandardMaterial&&q.envMap===null&&B.environment!==null&&(oi.envMapIntensity.value=B.environmentIntensity),An&&(_e.setValue(H,"toneMappingExposure",y.toneMappingExposure),Ct.needsLights&&Fm(oi,$r),st&&q.fog===!0&&ut.refreshFogUniforms(oi,st),ut.refreshMaterialUniforms(oi,q,F,G,p.state.transmissionRenderTarget[A.id]),gr.upload(H,pd(Ct),oi,I)),q.isShaderMaterial&&q.uniformsNeedUpdate===!0&&(gr.upload(H,pd(Ct),oi,I),q.uniformsNeedUpdate=!1),q.isSpriteMaterial&&_e.setValue(H,"center",O.center),_e.setValue(H,"modelViewMatrix",O.modelViewMatrix),_e.setValue(H,"normalMatrix",O.normalMatrix),_e.setValue(H,"modelMatrix",O.matrixWorld),q.isShaderMaterial||q.isRawShaderMaterial){let On=q.uniformsGroups;for(let Hi=0,Vi=On.length;Hi<Vi;Hi++){let gd=On[Hi];N.update(gd,Xn),N.bind(gd,Xn)}}return Xn}function Fm(A,B){A.ambientLightColor.needsUpdate=B,A.lightProbe.needsUpdate=B,A.directionalLights.needsUpdate=B,A.directionalLightShadows.needsUpdate=B,A.pointLights.needsUpdate=B,A.pointLightShadows.needsUpdate=B,A.spotLights.needsUpdate=B,A.spotLightShadows.needsUpdate=B,A.rectAreaLights.needsUpdate=B,A.hemisphereLights.needsUpdate=B}function Bm(A){return A.isMeshLambertMaterial||A.isMeshToonMaterial||A.isMeshPhongMaterial||A.isMeshStandardMaterial||A.isShadowMaterial||A.isShaderMaterial&&A.lights===!0}this.getActiveCubeFace=function(){return S},this.getActiveMipmapLevel=function(){return T},this.getRenderTarget=function(){return R},this.setRenderTargetTextures=function(A,B,$){Lt.get(A.texture).__webglTexture=B,Lt.get(A.depthTexture).__webglTexture=$;let q=Lt.get(A);q.__hasExternalTextures=!0,q.__autoAllocateDepthBuffer=$===void 0,q.__autoAllocateDepthBuffer||te.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),q.__useRenderToTexture=!1)},this.setRenderTargetFramebuffer=function(A,B){let $=Lt.get(A);$.__webglFramebuffer=B,$.__useDefaultFramebuffer=B===void 0},this.setRenderTarget=function(A,B=0,$=0){R=A,S=B,T=$;let q=!0,O=null,st=!1,ft=!1;if(A){let Tt=Lt.get(A);if(Tt.__useDefaultFramebuffer!==void 0)Dt.bindFramebuffer(H.FRAMEBUFFER,null),q=!1;else if(Tt.__webglFramebuffer===void 0)I.setupRenderTarget(A);else if(Tt.__hasExternalTextures)I.rebindTextures(A,Lt.get(A.texture).__webglTexture,Lt.get(A.depthTexture).__webglTexture);else if(A.depthBuffer){let At=A.depthTexture;if(Tt.__boundDepthTexture!==At){if(At!==null&&Lt.has(At)&&(A.width!==At.image.width||A.height!==At.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");I.setupDepthRenderbuffer(A)}}let Bt=A.texture;(Bt.isData3DTexture||Bt.isDataArrayTexture||Bt.isCompressedArrayTexture)&&(ft=!0);let Wt=Lt.get(A).__webglFramebuffer;A.isWebGLCubeRenderTarget?(Array.isArray(Wt[B])?O=Wt[B][$]:O=Wt[B],st=!0):A.samples>0&&I.useMultisampledRTT(A)===!1?O=Lt.get(A).__webglMultisampledFramebuffer:Array.isArray(Wt)?O=Wt[$]:O=Wt,C.copy(A.viewport),L.copy(A.scissor),k=A.scissorTest}else C.copy(ot).multiplyScalar(F).floor(),L.copy(St).multiplyScalar(F).floor(),k=Vt;if(Dt.bindFramebuffer(H.FRAMEBUFFER,O)&&q&&Dt.drawBuffers(A,O),Dt.viewport(C),Dt.scissor(L),Dt.setScissorTest(k),st){let Tt=Lt.get(A.texture);H.framebufferTexture2D(H.FRAMEBUFFER,H.COLOR_ATTACHMENT0,H.TEXTURE_CUBE_MAP_POSITIVE_X+B,Tt.__webglTexture,$)}else if(ft){let Tt=Lt.get(A.texture),Bt=B||0;H.framebufferTextureLayer(H.FRAMEBUFFER,H.COLOR_ATTACHMENT0,Tt.__webglTexture,$||0,Bt)}_=-1},this.readRenderTargetPixels=function(A,B,$,q,O,st,ft){if(!(A&&A.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Et=Lt.get(A).__webglFramebuffer;if(A.isWebGLCubeRenderTarget&&ft!==void 0&&(Et=Et[ft]),Et){Dt.bindFramebuffer(H.FRAMEBUFFER,Et);try{let Tt=A.texture,Bt=Tt.format,Wt=Tt.type;if(!ee.textureFormatReadable(Bt)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!ee.textureTypeReadable(Wt)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}B>=0&&B<=A.width-q&&$>=0&&$<=A.height-O&&H.readPixels(B,$,q,O,Zt.convert(Bt),Zt.convert(Wt),st)}finally{let Tt=R!==null?Lt.get(R).__webglFramebuffer:null;Dt.bindFramebuffer(H.FRAMEBUFFER,Tt)}}},this.readRenderTargetPixelsAsync=async function(A,B,$,q,O,st,ft){if(!(A&&A.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Et=Lt.get(A).__webglFramebuffer;if(A.isWebGLCubeRenderTarget&&ft!==void 0&&(Et=Et[ft]),Et){let Tt=A.texture,Bt=Tt.format,Wt=Tt.type;if(!ee.textureFormatReadable(Bt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!ee.textureTypeReadable(Wt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");if(B>=0&&B<=A.width-q&&$>=0&&$<=A.height-O){Dt.bindFramebuffer(H.FRAMEBUFFER,Et);let At=H.createBuffer();H.bindBuffer(H.PIXEL_PACK_BUFFER,At),H.bufferData(H.PIXEL_PACK_BUFFER,st.byteLength,H.STREAM_READ),H.readPixels(B,$,q,O,Zt.convert(Bt),Zt.convert(Wt),0);let le=R!==null?Lt.get(R).__webglFramebuffer:null;Dt.bindFramebuffer(H.FRAMEBUFFER,le);let xe=H.fenceSync(H.SYNC_GPU_COMMANDS_COMPLETE,0);return H.flush(),await V0(H,xe,4),H.bindBuffer(H.PIXEL_PACK_BUFFER,At),H.getBufferSubData(H.PIXEL_PACK_BUFFER,0,st),H.deleteBuffer(At),H.deleteSync(xe),st}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")}},this.copyFramebufferToTexture=function(A,B=null,$=0){A.isTexture!==!0&&(io("WebGLRenderer: copyFramebufferToTexture function signature has changed."),B=arguments[0]||null,A=arguments[1]);let q=Math.pow(2,-$),O=Math.floor(A.image.width*q),st=Math.floor(A.image.height*q),ft=B!==null?B.x:0,Et=B!==null?B.y:0;I.setTexture2D(A,0),H.copyTexSubImage2D(H.TEXTURE_2D,$,0,0,ft,Et,O,st),Dt.unbindTexture()},this.copyTextureToTexture=function(A,B,$=null,q=null,O=0){A.isTexture!==!0&&(io("WebGLRenderer: copyTextureToTexture function signature has changed."),q=arguments[0]||null,A=arguments[1],B=arguments[2],O=arguments[3]||0,$=null);let st,ft,Et,Tt,Bt,Wt,At,le,xe,be=A.isCompressedTexture?A.mipmaps[O]:A.image;$!==null?(st=$.max.x-$.min.x,ft=$.max.y-$.min.y,Et=$.isBox3?$.max.z-$.min.z:1,Tt=$.min.x,Bt=$.min.y,Wt=$.isBox3?$.min.z:0):(st=be.width,ft=be.height,Et=be.depth||1,Tt=0,Bt=0,Wt=0),q!==null?(At=q.x,le=q.y,xe=q.z):(At=0,le=0,xe=0);let pn=Zt.convert(B.format),he=Zt.convert(B.type),Ct;B.isData3DTexture?(I.setTexture3D(B,0),Ct=H.TEXTURE_3D):B.isDataArrayTexture||B.isCompressedArrayTexture?(I.setTexture2DArray(B,0),Ct=H.TEXTURE_2D_ARRAY):(I.setTexture2D(B,0),Ct=H.TEXTURE_2D),H.pixelStorei(H.UNPACK_FLIP_Y_WEBGL,B.flipY),H.pixelStorei(H.UNPACK_PREMULTIPLY_ALPHA_WEBGL,B.premultiplyAlpha),H.pixelStorei(H.UNPACK_ALIGNMENT,B.unpackAlignment);let bi=H.getParameter(H.UNPACK_ROW_LENGTH),ue=H.getParameter(H.UNPACK_IMAGE_HEIGHT),Xn=H.getParameter(H.UNPACK_SKIP_PIXELS),$s=H.getParameter(H.UNPACK_SKIP_ROWS),An=H.getParameter(H.UNPACK_SKIP_IMAGES);H.pixelStorei(H.UNPACK_ROW_LENGTH,be.width),H.pixelStorei(H.UNPACK_IMAGE_HEIGHT,be.height),H.pixelStorei(H.UNPACK_SKIP_PIXELS,Tt),H.pixelStorei(H.UNPACK_SKIP_ROWS,Bt),H.pixelStorei(H.UNPACK_SKIP_IMAGES,Wt);let $r=A.isDataArrayTexture||A.isData3DTexture,_e=B.isDataArrayTexture||B.isData3DTexture;if(A.isRenderTargetTexture||A.isDepthTexture){let oi=Lt.get(A),qr=Lt.get(B),On=Lt.get(oi.__renderTarget),Hi=Lt.get(qr.__renderTarget);Dt.bindFramebuffer(H.READ_FRAMEBUFFER,On.__webglFramebuffer),Dt.bindFramebuffer(H.DRAW_FRAMEBUFFER,Hi.__webglFramebuffer);for(let Vi=0;Vi<Et;Vi++)$r&&H.framebufferTextureLayer(H.READ_FRAMEBUFFER,H.COLOR_ATTACHMENT0,Lt.get(A).__webglTexture,O,Wt+Vi),A.isDepthTexture?(_e&&H.framebufferTextureLayer(H.DRAW_FRAMEBUFFER,H.COLOR_ATTACHMENT0,Lt.get(B).__webglTexture,O,xe+Vi),H.blitFramebuffer(Tt,Bt,st,ft,At,le,st,ft,H.DEPTH_BUFFER_BIT,H.NEAREST)):_e?H.copyTexSubImage3D(Ct,O,At,le,xe+Vi,Tt,Bt,st,ft):H.copyTexSubImage2D(Ct,O,At,le,xe+Vi,Tt,Bt,st,ft);Dt.bindFramebuffer(H.READ_FRAMEBUFFER,null),Dt.bindFramebuffer(H.DRAW_FRAMEBUFFER,null)}else _e?A.isDataTexture||A.isData3DTexture?H.texSubImage3D(Ct,O,At,le,xe,st,ft,Et,pn,he,be.data):B.isCompressedArrayTexture?H.compressedTexSubImage3D(Ct,O,At,le,xe,st,ft,Et,pn,be.data):H.texSubImage3D(Ct,O,At,le,xe,st,ft,Et,pn,he,be):A.isDataTexture?H.texSubImage2D(H.TEXTURE_2D,O,At,le,st,ft,pn,he,be.data):A.isCompressedTexture?H.compressedTexSubImage2D(H.TEXTURE_2D,O,At,le,be.width,be.height,pn,be.data):H.texSubImage2D(H.TEXTURE_2D,O,At,le,st,ft,pn,he,be);H.pixelStorei(H.UNPACK_ROW_LENGTH,bi),H.pixelStorei(H.UNPACK_IMAGE_HEIGHT,ue),H.pixelStorei(H.UNPACK_SKIP_PIXELS,Xn),H.pixelStorei(H.UNPACK_SKIP_ROWS,$s),H.pixelStorei(H.UNPACK_SKIP_IMAGES,An),O===0&&B.generateMipmaps&&H.generateMipmap(Ct),Dt.unbindTexture()},this.copyTextureToTexture3D=function(A,B,$=null,q=null,O=0){return A.isTexture!==!0&&(io("WebGLRenderer: copyTextureToTexture3D function signature has changed."),$=arguments[0]||null,q=arguments[1]||null,A=arguments[2],B=arguments[3],O=arguments[4]||0),io('WebGLRenderer: copyTextureToTexture3D function has been deprecated. Use "copyTextureToTexture" instead.'),this.copyTextureToTexture(A,B,$,q,O)},this.initRenderTarget=function(A){Lt.get(A).__webglFramebuffer===void 0&&I.setupRenderTarget(A)},this.initTexture=function(A){A.isCubeTexture?I.setTextureCube(A,0):A.isData3DTexture?I.setTexture3D(A,0):A.isDataArrayTexture||A.isCompressedArrayTexture?I.setTexture2DArray(A,0):I.setTexture2D(A,0),Dt.unbindTexture()},this.resetState=function(){S=0,T=0,R=null,Dt.reset(),ge.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Ri}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;let e=this.getContext();e.drawingBufferColorspace=re._getDrawingBufferColorSpace(t),e.unpackColorSpace=re._getUnpackColorSpace()}};var Xa=class i{constructor(t,e=1,n=1e3){this.isFog=!0,this.name="",this.color=new wt(t),this.near=e,this.far=n}clone(){return new i(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}},Sr=class extends We{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new gn,this.environmentIntensity=1,this.environmentRotation=new gn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){let e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(e.object.environmentIntensity=this.environmentIntensity),e.object.environmentRotation=this.environmentRotation.toArray(),e}},Ya=class{constructor(t,e){this.isInterleavedBuffer=!0,this.array=t,this.stride=e,this.count=t!==void 0?t.length/e:0,this.usage=xh,this.updateRanges=[],this.version=0,this.uuid=ci()}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.array=new t.array.constructor(t.array),this.count=t.count,this.stride=t.stride,this.usage=t.usage,this}copyAt(t,e,n){t*=this.stride,n*=e.stride;for(let s=0,r=this.stride;s<r;s++)this.array[t+s]=e.array[n+s];return this}set(t,e=0){return this.array.set(t,e),this}clone(t){t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=ci()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let e=new this.array.constructor(t.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(e,this.stride);return n.setUsage(this.usage),n}onUpload(t){return this.onUploadCallback=t,this}toJSON(t){return t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=ci()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}},an=new P,xo=class i{constructor(t,e,n,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=t,this.itemSize=e,this.offset=n,this.normalized=s}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(t){this.data.needsUpdate=t}applyMatrix4(t){for(let e=0,n=this.data.count;e<n;e++)an.fromBufferAttribute(this,e),an.applyMatrix4(t),this.setXYZ(e,an.x,an.y,an.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)an.fromBufferAttribute(this,e),an.applyNormalMatrix(t),this.setXYZ(e,an.x,an.y,an.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)an.fromBufferAttribute(this,e),an.transformDirection(t),this.setXYZ(e,an.x,an.y,an.z);return this}getComponent(t,e){let n=this.array[t*this.data.stride+this.offset+e];return this.normalized&&(n=Jn(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=fe(n,this.array)),this.data.array[t*this.data.stride+this.offset+e]=n,this}setX(t,e){return this.normalized&&(e=fe(e,this.array)),this.data.array[t*this.data.stride+this.offset]=e,this}setY(t,e){return this.normalized&&(e=fe(e,this.array)),this.data.array[t*this.data.stride+this.offset+1]=e,this}setZ(t,e){return this.normalized&&(e=fe(e,this.array)),this.data.array[t*this.data.stride+this.offset+2]=e,this}setW(t,e){return this.normalized&&(e=fe(e,this.array)),this.data.array[t*this.data.stride+this.offset+3]=e,this}getX(t){let e=this.data.array[t*this.data.stride+this.offset];return this.normalized&&(e=Jn(e,this.array)),e}getY(t){let e=this.data.array[t*this.data.stride+this.offset+1];return this.normalized&&(e=Jn(e,this.array)),e}getZ(t){let e=this.data.array[t*this.data.stride+this.offset+2];return this.normalized&&(e=Jn(e,this.array)),e}getW(t){let e=this.data.array[t*this.data.stride+this.offset+3];return this.normalized&&(e=Jn(e,this.array)),e}setXY(t,e,n){return t=t*this.data.stride+this.offset,this.normalized&&(e=fe(e,this.array),n=fe(n,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this}setXYZ(t,e,n,s){return t=t*this.data.stride+this.offset,this.normalized&&(e=fe(e,this.array),n=fe(n,this.array),s=fe(s,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=s,this}setXYZW(t,e,n,s,r){return t=t*this.data.stride+this.offset,this.normalized&&(e=fe(e,this.array),n=fe(n,this.array),s=fe(s,this.array),r=fe(r,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=s,this.data.array[t+3]=r,this}clone(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let n=0;n<this.count;n++){let s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return new Oe(new this.array.constructor(e),this.itemSize,this.normalized)}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new i(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let n=0;n<this.count;n++){let s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.toJSON(t)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},yo=class extends Li{static get type(){return"SpriteMaterial"}constructor(t){super(),this.isSpriteMaterial=!0,this.color=new wt(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.rotation=t.rotation,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},or,Jr=new P,ar=new P,lr=new P,cr=new rt,jr=new rt,sp=new qt,ba=new P,Qr=new P,_a=new P,yf=new rt,Tc=new rt,vf=new rt,Za=class extends We{constructor(t=new yo){if(super(),this.isSprite=!0,this.type="Sprite",or===void 0){or=new ce;let e=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new Ya(e,5);or.setIndex([0,1,2,0,2,3]),or.setAttribute("position",new xo(n,3,0,!1)),or.setAttribute("uv",new xo(n,2,3,!1))}this.geometry=or,this.material=t,this.center=new rt(.5,.5)}raycast(t,e){t.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),ar.setFromMatrixScale(this.matrixWorld),sp.copy(t.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse,this.matrixWorld),lr.setFromMatrixPosition(this.modelViewMatrix),t.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&ar.multiplyScalar(-lr.z);let n=this.material.rotation,s,r;n!==0&&(r=Math.cos(n),s=Math.sin(n));let o=this.center;Ma(ba.set(-.5,-.5,0),lr,o,ar,s,r),Ma(Qr.set(.5,-.5,0),lr,o,ar,s,r),Ma(_a.set(.5,.5,0),lr,o,ar,s,r),yf.set(0,0),Tc.set(1,0),vf.set(1,1);let a=t.ray.intersectTriangle(ba,Qr,_a,!1,Jr);if(a===null&&(Ma(Qr.set(-.5,.5,0),lr,o,ar,s,r),Tc.set(0,1),a=t.ray.intersectTriangle(ba,_a,Qr,!1,Jr),a===null))return;let l=t.ray.origin.distanceTo(Jr);l<t.near||l>t.far||e.push({distance:l,point:Jr.clone(),uv:Ki.getInterpolation(Jr,ba,Qr,_a,yf,Tc,vf,new rt),face:null,object:this})}copy(t,e){return super.copy(t,e),t.center!==void 0&&this.center.copy(t.center),this.material=t.material,this}};function Ma(i,t,e,n,s,r){cr.subVectors(i,e).addScalar(.5).multiply(n),s!==void 0?(jr.x=r*cr.x-s*cr.y,jr.y=s*cr.x+r*cr.y):jr.copy(cr),i.copy(t),i.x+=jr.x,i.y+=jr.y,i.applyMatrix4(sp)}var Dh=class extends mn{constructor(t=null,e=1,n=1,s,r,o,a,l,c=In,h=In,u,d){super(null,o,a,l,c,h,s,r,u,d),this.isDataTexture=!0,this.image={data:t,width:e,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var vo=class extends Oe{constructor(t,e,n,s=1){super(t,e,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){let t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}},hr=new qt,bf=new qt,wa=[],_f=new Ii,zb=new qt,to=new nt,eo=new ts,cn=class extends nt{constructor(t,e,n){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new vo(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<n;s++)this.setMatrixAt(s,zb)}computeBoundingBox(){let t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new Ii),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,hr),_f.copy(t.boundingBox).applyMatrix4(hr),this.boundingBox.union(_f)}computeBoundingSphere(){let t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new ts),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,hr),eo.copy(t.boundingSphere).applyMatrix4(hr),this.boundingSphere.union(eo)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),t.morphTexture!==null&&(this.morphTexture=t.morphTexture.clone()),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,e){e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){e.fromArray(this.instanceMatrix.array,t*16)}getMorphAt(t,e){let n=e.morphTargetInfluences,s=this.morphTexture.source.data.data,r=n.length+1,o=t*r+1;for(let a=0;a<n.length;a++)n[a]=s[o+a]}raycast(t,e){let n=this.matrixWorld,s=this.count;if(to.geometry=this.geometry,to.material=this.material,to.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),eo.copy(this.boundingSphere),eo.applyMatrix4(n),t.ray.intersectsSphere(eo)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,hr),bf.multiplyMatrices(n,hr),to.matrixWorld=bf,to.raycast(t,wa);for(let o=0,a=wa.length;o<a;o++){let l=wa[o];l.instanceId=r,l.object=this,e.push(l)}wa.length=0}}setColorAt(t,e){this.instanceColor===null&&(this.instanceColor=new vo(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),e.toArray(this.instanceColor.array,t*3)}setMatrixAt(t,e){e.toArray(this.instanceMatrix.array,t*16)}setMorphAt(t,e){let n=e.morphTargetInfluences,s=n.length+1;this.morphTexture===null&&(this.morphTexture=new Dh(new Float32Array(s*this.count),s,this.count,lu,li));let r=this.morphTexture.source.data.data,o=0;for(let c=0;c<n.length;c++)o+=n[c];let a=this.geometry.morphTargetsRelative?1:1-o,l=s*t;r[l]=a,r.set(n,l+1)}updateMorphTargets(){}dispose(){return this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null),this}};var ki=class extends Li{static get type(){return"LineBasicMaterial"}constructor(t){super(),this.isLineBasicMaterial=!0,this.color=new wt(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.linewidth=t.linewidth,this.linecap=t.linecap,this.linejoin=t.linejoin,this.fog=t.fog,this}},Ka=new P,Ja=new P,Mf=new qt,no=new po,Sa=new ts,Ac=new P,wf=new P,Gn=class extends We{constructor(t=new ce,e=new ki){super(),this.isLine=!0,this.type="Line",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}computeLineDistances(){let t=this.geometry;if(t.index===null){let e=t.attributes.position,n=[0];for(let s=1,r=e.count;s<r;s++)Ka.fromBufferAttribute(e,s-1),Ja.fromBufferAttribute(e,s),n[s]=n[s-1],n[s]+=Ka.distanceTo(Ja);t.setAttribute("lineDistance",new Ht(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(t,e){let n=this.geometry,s=this.matrixWorld,r=t.params.Line.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Sa.copy(n.boundingSphere),Sa.applyMatrix4(s),Sa.radius+=r,t.ray.intersectsSphere(Sa)===!1)return;Mf.copy(s).invert(),no.copy(t.ray).applyMatrix4(Mf);let a=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,c=this.isLineSegments?2:1,h=n.index,d=n.attributes.position;if(h!==null){let f=Math.max(0,o.start),m=Math.min(h.count,o.start+o.count);for(let x=f,g=m-1;x<g;x+=c){let p=h.getX(x),M=h.getX(x+1),v=Ea(this,t,no,l,p,M);v&&e.push(v)}if(this.isLineLoop){let x=h.getX(m-1),g=h.getX(f),p=Ea(this,t,no,l,x,g);p&&e.push(p)}}else{let f=Math.max(0,o.start),m=Math.min(d.count,o.start+o.count);for(let x=f,g=m-1;x<g;x+=c){let p=Ea(this,t,no,l,x,x+1);p&&e.push(p)}if(this.isLineLoop){let x=Ea(this,t,no,l,m-1,f);x&&e.push(x)}}}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}};function Ea(i,t,e,n,s,r){let o=i.geometry.attributes.position;if(Ka.fromBufferAttribute(o,s),Ja.fromBufferAttribute(o,r),e.distanceSqToSegment(Ka,Ja,Ac,wf)>n)return;Ac.applyMatrix4(i.matrixWorld);let l=t.ray.origin.distanceTo(Ac);if(!(l<t.near||l>t.far))return{distance:l,point:wf.clone().applyMatrix4(i.matrixWorld),index:s,face:null,faceIndex:null,barycoord:null,object:i}}var Sf=new P,Ef=new P,ja=class extends Gn{constructor(t,e){super(t,e),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){let t=this.geometry;if(t.index===null){let e=t.attributes.position,n=[];for(let s=0,r=e.count;s<r;s+=2)Sf.fromBufferAttribute(e,s),Ef.fromBufferAttribute(e,s+1),n[s]=s===0?0:n[s-1],n[s+1]=n[s]+Sf.distanceTo(Ef);t.setAttribute("lineDistance",new Ht(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}};var nn=class extends mn{constructor(t,e,n,s,r,o,a,l,c){super(t,e,n,s,r,o,a,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}},Wn=class{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(t,e){let n=this.getUtoTmapping(t);return this.getPoint(n,e)}getPoints(t=5){let e=[];for(let n=0;n<=t;n++)e.push(this.getPoint(n/t));return e}getSpacedPoints(t=5){let e=[];for(let n=0;n<=t;n++)e.push(this.getPointAt(n/t));return e}getLength(){let t=this.getLengths();return t[t.length-1]}getLengths(t=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===t+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;let e=[],n,s=this.getPoint(0),r=0;e.push(0);for(let o=1;o<=t;o++)n=this.getPoint(o/t),r+=n.distanceTo(s),e.push(r),s=n;return this.cacheArcLengths=e,e}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(t,e){let n=this.getLengths(),s=0,r=n.length,o;e?o=e:o=t*n[r-1];let a=0,l=r-1,c;for(;a<=l;)if(s=Math.floor(a+(l-a)/2),c=n[s]-o,c<0)a=s+1;else if(c>0)l=s-1;else{l=s;break}if(s=l,n[s]===o)return s/(r-1);let h=n[s],d=n[s+1]-h,f=(o-h)/d;return(s+f)/(r-1)}getTangent(t,e){let s=t-1e-4,r=t+1e-4;s<0&&(s=0),r>1&&(r=1);let o=this.getPoint(s),a=this.getPoint(r),l=e||(o.isVector2?new rt:new P);return l.copy(a).sub(o).normalize(),l}getTangentAt(t,e){let n=this.getUtoTmapping(t);return this.getTangent(n,e)}computeFrenetFrames(t,e){let n=new P,s=[],r=[],o=[],a=new P,l=new qt;for(let f=0;f<=t;f++){let m=f/t;s[f]=this.getTangentAt(m,new P)}r[0]=new P,o[0]=new P;let c=Number.MAX_VALUE,h=Math.abs(s[0].x),u=Math.abs(s[0].y),d=Math.abs(s[0].z);h<=c&&(c=h,n.set(1,0,0)),u<=c&&(c=u,n.set(0,1,0)),d<=c&&n.set(0,0,1),a.crossVectors(s[0],n).normalize(),r[0].crossVectors(s[0],a),o[0].crossVectors(s[0],r[0]);for(let f=1;f<=t;f++){if(r[f]=r[f-1].clone(),o[f]=o[f-1].clone(),a.crossVectors(s[f-1],s[f]),a.length()>Number.EPSILON){a.normalize();let m=Math.acos(Ve(s[f-1].dot(s[f]),-1,1));r[f].applyMatrix4(l.makeRotationAxis(a,m))}o[f].crossVectors(s[f],r[f])}if(e===!0){let f=Math.acos(Ve(r[0].dot(r[t]),-1,1));f/=t,s[0].dot(a.crossVectors(r[0],r[t]))>0&&(f=-f);for(let m=1;m<=t;m++)r[m].applyMatrix4(l.makeRotationAxis(s[m],f*m)),o[m].crossVectors(s[m],r[m])}return{tangents:s,normals:r,binormals:o}}clone(){return new this.constructor().copy(this)}copy(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}toJSON(){let t={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return t.arcLengthDivisions=this.arcLengthDivisions,t.type=this.type,t}fromJSON(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}},bo=class extends Wn{constructor(t=0,e=0,n=1,s=1,r=0,o=Math.PI*2,a=!1,l=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=t,this.aY=e,this.xRadius=n,this.yRadius=s,this.aStartAngle=r,this.aEndAngle=o,this.aClockwise=a,this.aRotation=l}getPoint(t,e=new rt){let n=e,s=Math.PI*2,r=this.aEndAngle-this.aStartAngle,o=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=s;for(;r>s;)r-=s;r<Number.EPSILON&&(o?r=0:r=s),this.aClockwise===!0&&!o&&(r===s?r=-s:r=r-s);let a=this.aStartAngle+t*r,l=this.aX+this.xRadius*Math.cos(a),c=this.aY+this.yRadius*Math.sin(a);if(this.aRotation!==0){let h=Math.cos(this.aRotation),u=Math.sin(this.aRotation),d=l-this.aX,f=c-this.aY;l=d*h-f*u+this.aX,c=d*u+f*h+this.aY}return n.set(l,c)}copy(t){return super.copy(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}toJSON(){let t=super.toJSON();return t.aX=this.aX,t.aY=this.aY,t.xRadius=this.xRadius,t.yRadius=this.yRadius,t.aStartAngle=this.aStartAngle,t.aEndAngle=this.aEndAngle,t.aClockwise=this.aClockwise,t.aRotation=this.aRotation,t}fromJSON(t){return super.fromJSON(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}},Uh=class extends bo{constructor(t,e,n,s,r,o){super(t,e,n,n,s,r,o),this.isArcCurve=!0,this.type="ArcCurve"}};function pu(){let i=0,t=0,e=0,n=0;function s(r,o,a,l){i=r,t=a,e=-3*r+3*o-2*a-l,n=2*r-2*o+a+l}return{initCatmullRom:function(r,o,a,l,c){s(o,a,c*(a-r),c*(l-o))},initNonuniformCatmullRom:function(r,o,a,l,c,h,u){let d=(o-r)/c-(a-r)/(c+h)+(a-o)/h,f=(a-o)/h-(l-o)/(h+u)+(l-a)/u;d*=h,f*=h,s(o,a,d,f)},calc:function(r){let o=r*r,a=o*r;return i+t*r+e*o+n*a}}}var Ta=new P,Rc=new pu,Cc=new pu,Pc=new pu,Nh=class extends Wn{constructor(t=[],e=!1,n="centripetal",s=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=t,this.closed=e,this.curveType=n,this.tension=s}getPoint(t,e=new P){let n=e,s=this.points,r=s.length,o=(r-(this.closed?0:1))*t,a=Math.floor(o),l=o-a;this.closed?a+=a>0?0:(Math.floor(Math.abs(a)/r)+1)*r:l===0&&a===r-1&&(a=r-2,l=1);let c,h;this.closed||a>0?c=s[(a-1)%r]:(Ta.subVectors(s[0],s[1]).add(s[0]),c=Ta);let u=s[a%r],d=s[(a+1)%r];if(this.closed||a+2<r?h=s[(a+2)%r]:(Ta.subVectors(s[r-1],s[r-2]).add(s[r-1]),h=Ta),this.curveType==="centripetal"||this.curveType==="chordal"){let f=this.curveType==="chordal"?.5:.25,m=Math.pow(c.distanceToSquared(u),f),x=Math.pow(u.distanceToSquared(d),f),g=Math.pow(d.distanceToSquared(h),f);x<1e-4&&(x=1),m<1e-4&&(m=x),g<1e-4&&(g=x),Rc.initNonuniformCatmullRom(c.x,u.x,d.x,h.x,m,x,g),Cc.initNonuniformCatmullRom(c.y,u.y,d.y,h.y,m,x,g),Pc.initNonuniformCatmullRom(c.z,u.z,d.z,h.z,m,x,g)}else this.curveType==="catmullrom"&&(Rc.initCatmullRom(c.x,u.x,d.x,h.x,this.tension),Cc.initCatmullRom(c.y,u.y,d.y,h.y,this.tension),Pc.initCatmullRom(c.z,u.z,d.z,h.z,this.tension));return n.set(Rc.calc(l),Cc.calc(l),Pc.calc(l)),n}copy(t){super.copy(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let s=t.points[e];this.points.push(s.clone())}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}toJSON(){let t=super.toJSON();t.points=[];for(let e=0,n=this.points.length;e<n;e++){let s=this.points[e];t.points.push(s.toArray())}return t.closed=this.closed,t.curveType=this.curveType,t.tension=this.tension,t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let s=t.points[e];this.points.push(new P().fromArray(s))}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}};function Tf(i,t,e,n,s){let r=(n-t)*.5,o=(s-e)*.5,a=i*i,l=i*a;return(2*e-2*n+r+o)*l+(-3*e+3*n-2*r-o)*a+r*i+e}function Fb(i,t){let e=1-i;return e*e*t}function Bb(i,t){return 2*(1-i)*i*t}function Ob(i,t){return i*i*t}function lo(i,t,e,n){return Fb(i,t)+Bb(i,e)+Ob(i,n)}function Hb(i,t){let e=1-i;return e*e*e*t}function Vb(i,t){let e=1-i;return 3*e*e*i*t}function Gb(i,t){return 3*(1-i)*i*i*t}function Wb(i,t){return i*i*i*t}function co(i,t,e,n,s){return Hb(i,t)+Vb(i,e)+Gb(i,n)+Wb(i,s)}var Qa=class extends Wn{constructor(t=new rt,e=new rt,n=new rt,s=new rt){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=t,this.v1=e,this.v2=n,this.v3=s}getPoint(t,e=new rt){let n=e,s=this.v0,r=this.v1,o=this.v2,a=this.v3;return n.set(co(t,s.x,r.x,o.x,a.x),co(t,s.y,r.y,o.y,a.y)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}},zh=class extends Wn{constructor(t=new P,e=new P,n=new P,s=new P){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=t,this.v1=e,this.v2=n,this.v3=s}getPoint(t,e=new P){let n=e,s=this.v0,r=this.v1,o=this.v2,a=this.v3;return n.set(co(t,s.x,r.x,o.x,a.x),co(t,s.y,r.y,o.y,a.y),co(t,s.z,r.z,o.z,a.z)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}},tl=class extends Wn{constructor(t=new rt,e=new rt){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=t,this.v2=e}getPoint(t,e=new rt){let n=e;return t===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(t).add(this.v1)),n}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new rt){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Fh=class extends Wn{constructor(t=new P,e=new P){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=t,this.v2=e}getPoint(t,e=new P){let n=e;return t===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(t).add(this.v1)),n}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new P){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},el=class extends Wn{constructor(t=new rt,e=new rt,n=new rt){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=t,this.v1=e,this.v2=n}getPoint(t,e=new rt){let n=e,s=this.v0,r=this.v1,o=this.v2;return n.set(lo(t,s.x,r.x,o.x),lo(t,s.y,r.y,o.y)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},_o=class extends Wn{constructor(t=new P,e=new P,n=new P){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=t,this.v1=e,this.v2=n}getPoint(t,e=new P){let n=e,s=this.v0,r=this.v1,o=this.v2;return n.set(lo(t,s.x,r.x,o.x),lo(t,s.y,r.y,o.y),lo(t,s.z,r.z,o.z)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},nl=class extends Wn{constructor(t=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=t}getPoint(t,e=new rt){let n=e,s=this.points,r=(s.length-1)*t,o=Math.floor(r),a=r-o,l=s[o===0?o:o-1],c=s[o],h=s[o>s.length-2?s.length-1:o+1],u=s[o>s.length-3?s.length-1:o+2];return n.set(Tf(a,l.x,c.x,h.x,u.x),Tf(a,l.y,c.y,h.y,u.y)),n}copy(t){super.copy(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let s=t.points[e];this.points.push(s.clone())}return this}toJSON(){let t=super.toJSON();t.points=[];for(let e=0,n=this.points.length;e<n;e++){let s=this.points[e];t.points.push(s.toArray())}return t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let s=t.points[e];this.points.push(new rt().fromArray(s))}return this}},Af=Object.freeze({__proto__:null,ArcCurve:Uh,CatmullRomCurve3:Nh,CubicBezierCurve:Qa,CubicBezierCurve3:zh,EllipseCurve:bo,LineCurve:tl,LineCurve3:Fh,QuadraticBezierCurve:el,QuadraticBezierCurve3:_o,SplineCurve:nl}),Bh=class extends Wn{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(t){this.curves.push(t)}closePath(){let t=this.curves[0].getPoint(0),e=this.curves[this.curves.length-1].getPoint(1);if(!t.equals(e)){let n=t.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new Af[n](e,t))}return this}getPoint(t,e){let n=t*this.getLength(),s=this.getCurveLengths(),r=0;for(;r<s.length;){if(s[r]>=n){let o=s[r]-n,a=this.curves[r],l=a.getLength(),c=l===0?0:1-o/l;return a.getPointAt(c,e)}r++}return null}getLength(){let t=this.getCurveLengths();return t[t.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;let t=[],e=0;for(let n=0,s=this.curves.length;n<s;n++)e+=this.curves[n].getLength(),t.push(e);return this.cacheLengths=t,t}getSpacedPoints(t=40){let e=[];for(let n=0;n<=t;n++)e.push(this.getPoint(n/t));return this.autoClose&&e.push(e[0]),e}getPoints(t=12){let e=[],n;for(let s=0,r=this.curves;s<r.length;s++){let o=r[s],a=o.isEllipseCurve?t*2:o.isLineCurve||o.isLineCurve3?1:o.isSplineCurve?t*o.points.length:t,l=o.getPoints(a);for(let c=0;c<l.length;c++){let h=l[c];n&&n.equals(h)||(e.push(h),n=h)}}return this.autoClose&&e.length>1&&!e[e.length-1].equals(e[0])&&e.push(e[0]),e}copy(t){super.copy(t),this.curves=[];for(let e=0,n=t.curves.length;e<n;e++){let s=t.curves[e];this.curves.push(s.clone())}return this.autoClose=t.autoClose,this}toJSON(){let t=super.toJSON();t.autoClose=this.autoClose,t.curves=[];for(let e=0,n=this.curves.length;e<n;e++){let s=this.curves[e];t.curves.push(s.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.autoClose=t.autoClose,this.curves=[];for(let e=0,n=t.curves.length;e<n;e++){let s=t.curves[e];this.curves.push(new Af[s.type]().fromJSON(s))}return this}},Mo=class extends Bh{constructor(t){super(),this.type="Path",this.currentPoint=new rt,t&&this.setFromPoints(t)}setFromPoints(t){this.moveTo(t[0].x,t[0].y);for(let e=1,n=t.length;e<n;e++)this.lineTo(t[e].x,t[e].y);return this}moveTo(t,e){return this.currentPoint.set(t,e),this}lineTo(t,e){let n=new tl(this.currentPoint.clone(),new rt(t,e));return this.curves.push(n),this.currentPoint.set(t,e),this}quadraticCurveTo(t,e,n,s){let r=new el(this.currentPoint.clone(),new rt(t,e),new rt(n,s));return this.curves.push(r),this.currentPoint.set(n,s),this}bezierCurveTo(t,e,n,s,r,o){let a=new Qa(this.currentPoint.clone(),new rt(t,e),new rt(n,s),new rt(r,o));return this.curves.push(a),this.currentPoint.set(r,o),this}splineThru(t){let e=[this.currentPoint.clone()].concat(t),n=new nl(e);return this.curves.push(n),this.currentPoint.copy(t[t.length-1]),this}arc(t,e,n,s,r,o){let a=this.currentPoint.x,l=this.currentPoint.y;return this.absarc(t+a,e+l,n,s,r,o),this}absarc(t,e,n,s,r,o){return this.absellipse(t,e,n,n,s,r,o),this}ellipse(t,e,n,s,r,o,a,l){let c=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(t+c,e+h,n,s,r,o,a,l),this}absellipse(t,e,n,s,r,o,a,l){let c=new bo(t,e,n,s,r,o,a,l);if(this.curves.length>0){let u=c.getPoint(0);u.equals(this.currentPoint)||this.lineTo(u.x,u.y)}this.curves.push(c);let h=c.getPoint(1);return this.currentPoint.copy(h),this}copy(t){return super.copy(t),this.currentPoint.copy(t.currentPoint),this}toJSON(){let t=super.toJSON();return t.currentPoint=this.currentPoint.toArray(),t}fromJSON(t){return super.fromJSON(t),this.currentPoint.fromArray(t.currentPoint),this}},Oh=class i extends ce{constructor(t=[new rt(0,-.5),new rt(.5,0),new rt(0,.5)],e=12,n=0,s=Math.PI*2){super(),this.type="LatheGeometry",this.parameters={points:t,segments:e,phiStart:n,phiLength:s},e=Math.floor(e),s=Ve(s,0,Math.PI*2);let r=[],o=[],a=[],l=[],c=[],h=1/e,u=new P,d=new rt,f=new P,m=new P,x=new P,g=0,p=0;for(let M=0;M<=t.length-1;M++)switch(M){case 0:g=t[M+1].x-t[M].x,p=t[M+1].y-t[M].y,f.x=p*1,f.y=-g,f.z=p*0,x.copy(f),f.normalize(),l.push(f.x,f.y,f.z);break;case t.length-1:l.push(x.x,x.y,x.z);break;default:g=t[M+1].x-t[M].x,p=t[M+1].y-t[M].y,f.x=p*1,f.y=-g,f.z=p*0,m.copy(f),f.x+=x.x,f.y+=x.y,f.z+=x.z,f.normalize(),l.push(f.x,f.y,f.z),x.copy(m)}for(let M=0;M<=e;M++){let v=n+M*h*s,y=Math.sin(v),w=Math.cos(v);for(let S=0;S<=t.length-1;S++){u.x=t[S].x*y,u.y=t[S].y,u.z=t[S].x*w,o.push(u.x,u.y,u.z),d.x=M/e,d.y=S/(t.length-1),a.push(d.x,d.y);let T=l[3*S+0]*y,R=l[3*S+1],_=l[3*S+0]*w;c.push(T,R,_)}}for(let M=0;M<e;M++)for(let v=0;v<t.length-1;v++){let y=v+M*t.length,w=y,S=y+t.length,T=y+t.length+1,R=y+1;r.push(w,S,R),r.push(T,R,S)}this.setIndex(r),this.setAttribute("position",new Ht(o,3)),this.setAttribute("uv",new Ht(a,2)),this.setAttribute("normal",new Ht(c,3))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.points,t.segments,t.phiStart,t.phiLength)}},ti=class i extends Oh{constructor(t=1,e=1,n=4,s=8){let r=new Mo;r.absarc(0,-e/2,t,Math.PI*1.5,0),r.absarc(0,e/2,t,0,Math.PI*.5),super(r.getPoints(n),s),this.type="CapsuleGeometry",this.parameters={radius:t,length:e,capSegments:n,radialSegments:s}}static fromJSON(t){return new i(t.radius,t.length,t.capSegments,t.radialSegments)}},sn=class i extends ce{constructor(t=1,e=32,n=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:n,thetaLength:s},e=Math.max(3,e);let r=[],o=[],a=[],l=[],c=new P,h=new rt;o.push(0,0,0),a.push(0,0,1),l.push(.5,.5);for(let u=0,d=3;u<=e;u++,d+=3){let f=n+u/e*s;c.x=t*Math.cos(f),c.y=t*Math.sin(f),o.push(c.x,c.y,c.z),a.push(0,0,1),h.x=(o[d]/t+1)/2,h.y=(o[d+1]/t+1)/2,l.push(h.x,h.y)}for(let u=1;u<=e;u++)r.push(u,u+1,0);this.setIndex(r),this.setAttribute("position",new Ht(o,3)),this.setAttribute("normal",new Ht(a,3)),this.setAttribute("uv",new Ht(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.radius,t.segments,t.thetaStart,t.thetaLength)}},zt=class i extends ce{constructor(t=1,e=1,n=1,s=32,r=1,o=!1,a=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:n,radialSegments:s,heightSegments:r,openEnded:o,thetaStart:a,thetaLength:l};let c=this;s=Math.floor(s),r=Math.floor(r);let h=[],u=[],d=[],f=[],m=0,x=[],g=n/2,p=0;M(),o===!1&&(t>0&&v(!0),e>0&&v(!1)),this.setIndex(h),this.setAttribute("position",new Ht(u,3)),this.setAttribute("normal",new Ht(d,3)),this.setAttribute("uv",new Ht(f,2));function M(){let y=new P,w=new P,S=0,T=(e-t)/n;for(let R=0;R<=r;R++){let _=[],b=R/r,C=b*(e-t)+t;for(let L=0;L<=s;L++){let k=L/s,D=k*l+a,V=Math.sin(D),z=Math.cos(D);w.x=C*V,w.y=-b*n+g,w.z=C*z,u.push(w.x,w.y,w.z),y.set(V,T,z).normalize(),d.push(y.x,y.y,y.z),f.push(k,1-b),_.push(m++)}x.push(_)}for(let R=0;R<s;R++)for(let _=0;_<r;_++){let b=x[_][R],C=x[_+1][R],L=x[_+1][R+1],k=x[_][R+1];(t>0||_!==0)&&(h.push(b,C,k),S+=3),(e>0||_!==r-1)&&(h.push(C,L,k),S+=3)}c.addGroup(p,S,0),p+=S}function v(y){let w=m,S=new rt,T=new P,R=0,_=y===!0?t:e,b=y===!0?1:-1;for(let L=1;L<=s;L++)u.push(0,g*b,0),d.push(0,b,0),f.push(.5,.5),m++;let C=m;for(let L=0;L<=s;L++){let D=L/s*l+a,V=Math.cos(D),z=Math.sin(D);T.x=_*z,T.y=g*b,T.z=_*V,u.push(T.x,T.y,T.z),d.push(0,b,0),S.x=V*.5+.5,S.y=z*.5*b+.5,f.push(S.x,S.y),m++}for(let L=0;L<s;L++){let k=w+L,D=C+L;y===!0?h.push(D,D+1,k):h.push(D+1,D,k),R+=3}c.addGroup(p,R,y===!0?1:2),p+=R}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},ui=class i extends zt{constructor(t=1,e=1,n=32,s=1,r=!1,o=0,a=Math.PI*2){super(0,t,e,n,s,r,o,a),this.type="ConeGeometry",this.parameters={radius:t,height:e,radialSegments:n,heightSegments:s,openEnded:r,thetaStart:o,thetaLength:a}}static fromJSON(t){return new i(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},il=class i extends ce{constructor(t=[],e=[],n=1,s=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:e,radius:n,detail:s};let r=[],o=[];a(s),c(n),h(),this.setAttribute("position",new Ht(r,3)),this.setAttribute("normal",new Ht(r.slice(),3)),this.setAttribute("uv",new Ht(o,2)),s===0?this.computeVertexNormals():this.normalizeNormals();function a(M){let v=new P,y=new P,w=new P;for(let S=0;S<e.length;S+=3)f(e[S+0],v),f(e[S+1],y),f(e[S+2],w),l(v,y,w,M)}function l(M,v,y,w){let S=w+1,T=[];for(let R=0;R<=S;R++){T[R]=[];let _=M.clone().lerp(y,R/S),b=v.clone().lerp(y,R/S),C=S-R;for(let L=0;L<=C;L++)L===0&&R===S?T[R][L]=_:T[R][L]=_.clone().lerp(b,L/C)}for(let R=0;R<S;R++)for(let _=0;_<2*(S-R)-1;_++){let b=Math.floor(_/2);_%2===0?(d(T[R][b+1]),d(T[R+1][b]),d(T[R][b])):(d(T[R][b+1]),d(T[R+1][b+1]),d(T[R+1][b]))}}function c(M){let v=new P;for(let y=0;y<r.length;y+=3)v.x=r[y+0],v.y=r[y+1],v.z=r[y+2],v.normalize().multiplyScalar(M),r[y+0]=v.x,r[y+1]=v.y,r[y+2]=v.z}function h(){let M=new P;for(let v=0;v<r.length;v+=3){M.x=r[v+0],M.y=r[v+1],M.z=r[v+2];let y=g(M)/2/Math.PI+.5,w=p(M)/Math.PI+.5;o.push(y,1-w)}m(),u()}function u(){for(let M=0;M<o.length;M+=6){let v=o[M+0],y=o[M+2],w=o[M+4],S=Math.max(v,y,w),T=Math.min(v,y,w);S>.9&&T<.1&&(v<.2&&(o[M+0]+=1),y<.2&&(o[M+2]+=1),w<.2&&(o[M+4]+=1))}}function d(M){r.push(M.x,M.y,M.z)}function f(M,v){let y=M*3;v.x=t[y+0],v.y=t[y+1],v.z=t[y+2]}function m(){let M=new P,v=new P,y=new P,w=new P,S=new rt,T=new rt,R=new rt;for(let _=0,b=0;_<r.length;_+=9,b+=6){M.set(r[_+0],r[_+1],r[_+2]),v.set(r[_+3],r[_+4],r[_+5]),y.set(r[_+6],r[_+7],r[_+8]),S.set(o[b+0],o[b+1]),T.set(o[b+2],o[b+3]),R.set(o[b+4],o[b+5]),w.copy(M).add(v).add(y).divideScalar(3);let C=g(w);x(S,b+0,M,C),x(T,b+2,v,C),x(R,b+4,y,C)}}function x(M,v,y,w){w<0&&M.x===1&&(o[v]=M.x-1),y.x===0&&y.z===0&&(o[v]=w/2/Math.PI+.5)}function g(M){return Math.atan2(M.z,-M.x)}function p(M){return Math.atan2(-M.y,Math.sqrt(M.x*M.x+M.z*M.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.vertices,t.indices,t.radius,t.details)}},wo=class i extends il{constructor(t=1,e=0){let n=(1+Math.sqrt(5))/2,s=1/n,r=[-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-s,-n,0,-s,n,0,s,-n,0,s,n,-s,-n,0,-s,n,0,s,-n,0,s,n,0,-n,0,-s,n,0,-s,-n,0,s,n,0,s],o=[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9];super(r,o,t,e),this.type="DodecahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new i(t.radius,t.detail)}};var Er=class extends Mo{constructor(t){super(t),this.uuid=ci(),this.type="Shape",this.holes=[]}getPointsHoles(t){let e=[];for(let n=0,s=this.holes.length;n<s;n++)e[n]=this.holes[n].getPoints(t);return e}extractPoints(t){return{shape:this.getPoints(t),holes:this.getPointsHoles(t)}}copy(t){super.copy(t),this.holes=[];for(let e=0,n=t.holes.length;e<n;e++){let s=t.holes[e];this.holes.push(s.clone())}return this}toJSON(){let t=super.toJSON();t.uuid=this.uuid,t.holes=[];for(let e=0,n=this.holes.length;e<n;e++){let s=this.holes[e];t.holes.push(s.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.uuid=t.uuid,this.holes=[];for(let e=0,n=t.holes.length;e<n;e++){let s=t.holes[e];this.holes.push(new Mo().fromJSON(s))}return this}},$b={triangulate:function(i,t,e=2){let n=t&&t.length,s=n?t[0]*e:i.length,r=rp(i,0,s,e,!0),o=[];if(!r||r.next===r.prev)return o;let a,l,c,h,u,d,f;if(n&&(r=Kb(i,t,r,e)),i.length>80*e){a=c=i[0],l=h=i[1];for(let m=e;m<s;m+=e)u=i[m],d=i[m+1],u<a&&(a=u),d<l&&(l=d),u>c&&(c=u),d>h&&(h=d);f=Math.max(c-a,h-l),f=f!==0?32767/f:0}return So(r,o,e,a,l,f,0),o}};function rp(i,t,e,n,s){let r,o;if(s===a_(i,t,e,n)>0)for(r=t;r<e;r+=n)o=Rf(r,i[r],i[r+1],o);else for(r=e-n;r>=t;r-=n)o=Rf(r,i[r],i[r+1],o);return o&&pl(o,o.next)&&(To(o),o=o.next),o}function Ss(i,t){if(!i)return i;t||(t=i);let e=i,n;do if(n=!1,!e.steiner&&(pl(e,e.next)||Ae(e.prev,e,e.next)===0)){if(To(e),e=t=e.prev,e===e.next)break;n=!0}else e=e.next;while(n||e!==t);return t}function So(i,t,e,n,s,r,o){if(!i)return;!o&&r&&e_(i,n,s,r);let a=i,l,c;for(;i.prev!==i.next;){if(l=i.prev,c=i.next,r?Xb(i,n,s,r):qb(i)){t.push(l.i/e|0),t.push(i.i/e|0),t.push(c.i/e|0),To(i),i=c.next,a=c.next;continue}if(i=c,i===a){o?o===1?(i=Yb(Ss(i),t,e),So(i,t,e,n,s,r,2)):o===2&&Zb(i,t,e,n,s,r):So(Ss(i),t,e,n,s,r,1);break}}}function qb(i){let t=i.prev,e=i,n=i.next;if(Ae(t,e,n)>=0)return!1;let s=t.x,r=e.x,o=n.x,a=t.y,l=e.y,c=n.y,h=s<r?s<o?s:o:r<o?r:o,u=a<l?a<c?a:c:l<c?l:c,d=s>r?s>o?s:o:r>o?r:o,f=a>l?a>c?a:c:l>c?l:c,m=n.next;for(;m!==t;){if(m.x>=h&&m.x<=d&&m.y>=u&&m.y<=f&&dr(s,a,r,l,o,c,m.x,m.y)&&Ae(m.prev,m,m.next)>=0)return!1;m=m.next}return!0}function Xb(i,t,e,n){let s=i.prev,r=i,o=i.next;if(Ae(s,r,o)>=0)return!1;let a=s.x,l=r.x,c=o.x,h=s.y,u=r.y,d=o.y,f=a<l?a<c?a:c:l<c?l:c,m=h<u?h<d?h:d:u<d?u:d,x=a>l?a>c?a:c:l>c?l:c,g=h>u?h>d?h:d:u>d?u:d,p=Hh(f,m,t,e,n),M=Hh(x,g,t,e,n),v=i.prevZ,y=i.nextZ;for(;v&&v.z>=p&&y&&y.z<=M;){if(v.x>=f&&v.x<=x&&v.y>=m&&v.y<=g&&v!==s&&v!==o&&dr(a,h,l,u,c,d,v.x,v.y)&&Ae(v.prev,v,v.next)>=0||(v=v.prevZ,y.x>=f&&y.x<=x&&y.y>=m&&y.y<=g&&y!==s&&y!==o&&dr(a,h,l,u,c,d,y.x,y.y)&&Ae(y.prev,y,y.next)>=0))return!1;y=y.nextZ}for(;v&&v.z>=p;){if(v.x>=f&&v.x<=x&&v.y>=m&&v.y<=g&&v!==s&&v!==o&&dr(a,h,l,u,c,d,v.x,v.y)&&Ae(v.prev,v,v.next)>=0)return!1;v=v.prevZ}for(;y&&y.z<=M;){if(y.x>=f&&y.x<=x&&y.y>=m&&y.y<=g&&y!==s&&y!==o&&dr(a,h,l,u,c,d,y.x,y.y)&&Ae(y.prev,y,y.next)>=0)return!1;y=y.nextZ}return!0}function Yb(i,t,e){let n=i;do{let s=n.prev,r=n.next.next;!pl(s,r)&&op(s,n,n.next,r)&&Eo(s,r)&&Eo(r,s)&&(t.push(s.i/e|0),t.push(n.i/e|0),t.push(r.i/e|0),To(n),To(n.next),n=i=r),n=n.next}while(n!==i);return Ss(n)}function Zb(i,t,e,n,s,r){let o=i;do{let a=o.next.next;for(;a!==o.prev;){if(o.i!==a.i&&s_(o,a)){let l=ap(o,a);o=Ss(o,o.next),l=Ss(l,l.next),So(o,t,e,n,s,r,0),So(l,t,e,n,s,r,0);return}a=a.next}o=o.next}while(o!==i)}function Kb(i,t,e,n){let s=[],r,o,a,l,c;for(r=0,o=t.length;r<o;r++)a=t[r]*n,l=r<o-1?t[r+1]*n:i.length,c=rp(i,a,l,n,!1),c===c.next&&(c.steiner=!0),s.push(i_(c));for(s.sort(Jb),r=0;r<s.length;r++)e=jb(s[r],e);return e}function Jb(i,t){return i.x-t.x}function jb(i,t){let e=Qb(i,t);if(!e)return t;let n=ap(e,i);return Ss(n,n.next),Ss(e,e.next)}function Qb(i,t){let e=t,n=-1/0,s,r=i.x,o=i.y;do{if(o<=e.y&&o>=e.next.y&&e.next.y!==e.y){let d=e.x+(o-e.y)*(e.next.x-e.x)/(e.next.y-e.y);if(d<=r&&d>n&&(n=d,s=e.x<e.next.x?e:e.next,d===r))return s}e=e.next}while(e!==t);if(!s)return null;let a=s,l=s.x,c=s.y,h=1/0,u;e=s;do r>=e.x&&e.x>=l&&r!==e.x&&dr(o<c?r:n,o,l,c,o<c?n:r,o,e.x,e.y)&&(u=Math.abs(o-e.y)/(r-e.x),Eo(e,i)&&(u<h||u===h&&(e.x>s.x||e.x===s.x&&t_(s,e)))&&(s=e,h=u)),e=e.next;while(e!==a);return s}function t_(i,t){return Ae(i.prev,i,t.prev)<0&&Ae(t.next,i,i.next)<0}function e_(i,t,e,n){let s=i;do s.z===0&&(s.z=Hh(s.x,s.y,t,e,n)),s.prevZ=s.prev,s.nextZ=s.next,s=s.next;while(s!==i);s.prevZ.nextZ=null,s.prevZ=null,n_(s)}function n_(i){let t,e,n,s,r,o,a,l,c=1;do{for(e=i,i=null,r=null,o=0;e;){for(o++,n=e,a=0,t=0;t<c&&(a++,n=n.nextZ,!!n);t++);for(l=c;a>0||l>0&&n;)a!==0&&(l===0||!n||e.z<=n.z)?(s=e,e=e.nextZ,a--):(s=n,n=n.nextZ,l--),r?r.nextZ=s:i=s,s.prevZ=r,r=s;e=n}r.nextZ=null,c*=2}while(o>1);return i}function Hh(i,t,e,n,s){return i=(i-e)*s|0,t=(t-n)*s|0,i=(i|i<<8)&16711935,i=(i|i<<4)&252645135,i=(i|i<<2)&858993459,i=(i|i<<1)&1431655765,t=(t|t<<8)&16711935,t=(t|t<<4)&252645135,t=(t|t<<2)&858993459,t=(t|t<<1)&1431655765,i|t<<1}function i_(i){let t=i,e=i;do(t.x<e.x||t.x===e.x&&t.y<e.y)&&(e=t),t=t.next;while(t!==i);return e}function dr(i,t,e,n,s,r,o,a){return(s-o)*(t-a)>=(i-o)*(r-a)&&(i-o)*(n-a)>=(e-o)*(t-a)&&(e-o)*(r-a)>=(s-o)*(n-a)}function s_(i,t){return i.next.i!==t.i&&i.prev.i!==t.i&&!r_(i,t)&&(Eo(i,t)&&Eo(t,i)&&o_(i,t)&&(Ae(i.prev,i,t.prev)||Ae(i,t.prev,t))||pl(i,t)&&Ae(i.prev,i,i.next)>0&&Ae(t.prev,t,t.next)>0)}function Ae(i,t,e){return(t.y-i.y)*(e.x-t.x)-(t.x-i.x)*(e.y-t.y)}function pl(i,t){return i.x===t.x&&i.y===t.y}function op(i,t,e,n){let s=Ra(Ae(i,t,e)),r=Ra(Ae(i,t,n)),o=Ra(Ae(e,n,i)),a=Ra(Ae(e,n,t));return!!(s!==r&&o!==a||s===0&&Aa(i,e,t)||r===0&&Aa(i,n,t)||o===0&&Aa(e,i,n)||a===0&&Aa(e,t,n))}function Aa(i,t,e){return t.x<=Math.max(i.x,e.x)&&t.x>=Math.min(i.x,e.x)&&t.y<=Math.max(i.y,e.y)&&t.y>=Math.min(i.y,e.y)}function Ra(i){return i>0?1:i<0?-1:0}function r_(i,t){let e=i;do{if(e.i!==i.i&&e.next.i!==i.i&&e.i!==t.i&&e.next.i!==t.i&&op(e,e.next,i,t))return!0;e=e.next}while(e!==i);return!1}function Eo(i,t){return Ae(i.prev,i,i.next)<0?Ae(i,t,i.next)>=0&&Ae(i,i.prev,t)>=0:Ae(i,t,i.prev)<0||Ae(i,i.next,t)<0}function o_(i,t){let e=i,n=!1,s=(i.x+t.x)/2,r=(i.y+t.y)/2;do e.y>r!=e.next.y>r&&e.next.y!==e.y&&s<(e.next.x-e.x)*(r-e.y)/(e.next.y-e.y)+e.x&&(n=!n),e=e.next;while(e!==i);return n}function ap(i,t){let e=new Vh(i.i,i.x,i.y),n=new Vh(t.i,t.x,t.y),s=i.next,r=t.prev;return i.next=t,t.prev=i,e.next=s,s.prev=e,n.next=e,e.prev=n,r.next=n,n.prev=r,n}function Rf(i,t,e,n){let s=new Vh(i,t,e);return n?(s.next=n.next,s.prev=n,n.next.prev=s,n.next=s):(s.prev=s,s.next=s),s}function To(i){i.next.prev=i.prev,i.prev.next=i.next,i.prevZ&&(i.prevZ.nextZ=i.nextZ),i.nextZ&&(i.nextZ.prevZ=i.prevZ)}function Vh(i,t,e){this.i=i,this.x=t,this.y=e,this.prev=null,this.next=null,this.z=0,this.prevZ=null,this.nextZ=null,this.steiner=!1}function a_(i,t,e,n){let s=0;for(let r=t,o=e-n;r<e;r+=n)s+=(i[o]-i[r])*(i[r+1]+i[o+1]),o=r;return s}var ho=class i{static area(t){let e=t.length,n=0;for(let s=e-1,r=0;r<e;s=r++)n+=t[s].x*t[r].y-t[r].x*t[s].y;return n*.5}static isClockWise(t){return i.area(t)<0}static triangulateShape(t,e){let n=[],s=[],r=[];Cf(t),Pf(n,t);let o=t.length;e.forEach(Cf);for(let l=0;l<e.length;l++)s.push(o),o+=e[l].length,Pf(n,e[l]);let a=$b.triangulate(n,s);for(let l=0;l<a.length;l+=3)r.push(a.slice(l,l+3));return r}};function Cf(i){let t=i.length;t>2&&i[t-1].equals(i[0])&&i.pop()}function Pf(i,t){for(let e=0;e<t.length;e++)i.push(t[e].x),i.push(t[e].y)}var Es=class i extends il{constructor(t=1,e=0){let n=(1+Math.sqrt(5))/2,s=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],r=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(s,r,t,e),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new i(t.radius,t.detail)}};var yn=class i extends ce{constructor(t=.5,e=1,n=32,s=1,r=0,o=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:e,thetaSegments:n,phiSegments:s,thetaStart:r,thetaLength:o},n=Math.max(3,n),s=Math.max(1,s);let a=[],l=[],c=[],h=[],u=t,d=(e-t)/s,f=new P,m=new rt;for(let x=0;x<=s;x++){for(let g=0;g<=n;g++){let p=r+g/n*o;f.x=u*Math.cos(p),f.y=u*Math.sin(p),l.push(f.x,f.y,f.z),c.push(0,0,1),m.x=(f.x/e+1)/2,m.y=(f.y/e+1)/2,h.push(m.x,m.y)}u+=d}for(let x=0;x<s;x++){let g=x*(n+1);for(let p=0;p<n;p++){let M=p+g,v=M,y=M+n+1,w=M+n+2,S=M+1;a.push(v,y,S),a.push(y,w,S)}}this.setIndex(a),this.setAttribute("position",new Ht(l,3)),this.setAttribute("normal",new Ht(c,3)),this.setAttribute("uv",new Ht(h,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}},Ao=class i extends ce{constructor(t=new Er([new rt(0,.5),new rt(-.5,-.5),new rt(.5,-.5)]),e=12){super(),this.type="ShapeGeometry",this.parameters={shapes:t,curveSegments:e};let n=[],s=[],r=[],o=[],a=0,l=0;if(Array.isArray(t)===!1)c(t);else for(let h=0;h<t.length;h++)c(t[h]),this.addGroup(a,l,h),a+=l,l=0;this.setIndex(n),this.setAttribute("position",new Ht(s,3)),this.setAttribute("normal",new Ht(r,3)),this.setAttribute("uv",new Ht(o,2));function c(h){let u=s.length/3,d=h.extractPoints(e),f=d.shape,m=d.holes;ho.isClockWise(f)===!1&&(f=f.reverse());for(let g=0,p=m.length;g<p;g++){let M=m[g];ho.isClockWise(M)===!0&&(m[g]=M.reverse())}let x=ho.triangulateShape(f,m);for(let g=0,p=m.length;g<p;g++){let M=m[g];f=f.concat(M)}for(let g=0,p=f.length;g<p;g++){let M=f[g];s.push(M.x,M.y,0),r.push(0,0,1),o.push(M.x,M.y)}for(let g=0,p=x.length;g<p;g++){let M=x[g],v=M[0]+u,y=M[1]+u,w=M[2]+u;n.push(v,y,w),l+=3}}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){let t=super.toJSON(),e=this.parameters.shapes;return l_(e,t)}static fromJSON(t,e){let n=[];for(let s=0,r=t.shapes.length;s<r;s++){let o=e[t.shapes[s]];n.push(o)}return new i(n,t.curveSegments)}};function l_(i,t){if(t.shapes=[],Array.isArray(i))for(let e=0,n=i.length;e<n;e++){let s=i[e];t.shapes.push(s.uuid)}else t.shapes.push(i.uuid);return t}var Ce=class i extends ce{constructor(t=1,e=32,n=16,s=0,r=Math.PI*2,o=0,a=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:n,phiStart:s,phiLength:r,thetaStart:o,thetaLength:a},e=Math.max(3,Math.floor(e)),n=Math.max(2,Math.floor(n));let l=Math.min(o+a,Math.PI),c=0,h=[],u=new P,d=new P,f=[],m=[],x=[],g=[];for(let p=0;p<=n;p++){let M=[],v=p/n,y=0;p===0&&o===0?y=.5/e:p===n&&l===Math.PI&&(y=-.5/e);for(let w=0;w<=e;w++){let S=w/e;u.x=-t*Math.cos(s+S*r)*Math.sin(o+v*a),u.y=t*Math.cos(o+v*a),u.z=t*Math.sin(s+S*r)*Math.sin(o+v*a),m.push(u.x,u.y,u.z),d.copy(u).normalize(),x.push(d.x,d.y,d.z),g.push(S+y,1-v),M.push(c++)}h.push(M)}for(let p=0;p<n;p++)for(let M=0;M<e;M++){let v=h[p][M+1],y=h[p][M],w=h[p+1][M],S=h[p+1][M+1];(p!==0||o>0)&&f.push(v,y,S),(p!==n-1||l<Math.PI)&&f.push(y,w,S)}this.setIndex(f),this.setAttribute("position",new Ht(m,3)),this.setAttribute("normal",new Ht(x,3)),this.setAttribute("uv",new Ht(g,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}};var Ts=class i extends ce{constructor(t=1,e=.4,n=12,s=48,r=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:t,tube:e,radialSegments:n,tubularSegments:s,arc:r},n=Math.floor(n),s=Math.floor(s);let o=[],a=[],l=[],c=[],h=new P,u=new P,d=new P;for(let f=0;f<=n;f++)for(let m=0;m<=s;m++){let x=m/s*r,g=f/n*Math.PI*2;u.x=(t+e*Math.cos(g))*Math.cos(x),u.y=(t+e*Math.cos(g))*Math.sin(x),u.z=e*Math.sin(g),a.push(u.x,u.y,u.z),h.x=t*Math.cos(x),h.y=t*Math.sin(x),d.subVectors(u,h).normalize(),l.push(d.x,d.y,d.z),c.push(m/s),c.push(f/n)}for(let f=1;f<=n;f++)for(let m=1;m<=s;m++){let x=(s+1)*f+m-1,g=(s+1)*(f-1)+m-1,p=(s+1)*(f-1)+m,M=(s+1)*f+m;o.push(x,g,M),o.push(g,p,M)}this.setIndex(o),this.setAttribute("position",new Ht(a,3)),this.setAttribute("normal",new Ht(l,3)),this.setAttribute("uv",new Ht(c,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc)}};var ye=class extends Li{static get type(){return"MeshStandardMaterial"}constructor(t){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.color=new wt(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new wt(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Yf,this.normalScale=new rt(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new gn,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}},sl=class extends ye{static get type(){return"MeshPhysicalMaterial"}constructor(t){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new rt(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return Ve(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(e){this.ior=(1+.4*e)/(1-.4*e)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new wt(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new wt(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new wt(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._dispersion=0,this._iridescence=0,this._sheen=0,this._transmission=0,this.setValues(t)}get anisotropy(){return this._anisotropy}set anisotropy(t){this._anisotropy>0!=t>0&&this.version++,this._anisotropy=t}get clearcoat(){return this._clearcoat}set clearcoat(t){this._clearcoat>0!=t>0&&this.version++,this._clearcoat=t}get iridescence(){return this._iridescence}set iridescence(t){this._iridescence>0!=t>0&&this.version++,this._iridescence=t}get dispersion(){return this._dispersion}set dispersion(t){this._dispersion>0!=t>0&&this.version++,this._dispersion=t}get sheen(){return this._sheen}set sheen(t){this._sheen>0!=t>0&&this.version++,this._sheen=t}get transmission(){return this._transmission}set transmission(t){this._transmission>0!=t>0&&this.version++,this._transmission=t}copy(t){return super.copy(t),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=t.anisotropy,this.anisotropyRotation=t.anisotropyRotation,this.anisotropyMap=t.anisotropyMap,this.clearcoat=t.clearcoat,this.clearcoatMap=t.clearcoatMap,this.clearcoatRoughness=t.clearcoatRoughness,this.clearcoatRoughnessMap=t.clearcoatRoughnessMap,this.clearcoatNormalMap=t.clearcoatNormalMap,this.clearcoatNormalScale.copy(t.clearcoatNormalScale),this.dispersion=t.dispersion,this.ior=t.ior,this.iridescence=t.iridescence,this.iridescenceMap=t.iridescenceMap,this.iridescenceIOR=t.iridescenceIOR,this.iridescenceThicknessRange=[...t.iridescenceThicknessRange],this.iridescenceThicknessMap=t.iridescenceThicknessMap,this.sheen=t.sheen,this.sheenColor.copy(t.sheenColor),this.sheenColorMap=t.sheenColorMap,this.sheenRoughness=t.sheenRoughness,this.sheenRoughnessMap=t.sheenRoughnessMap,this.transmission=t.transmission,this.transmissionMap=t.transmissionMap,this.thickness=t.thickness,this.thicknessMap=t.thicknessMap,this.attenuationDistance=t.attenuationDistance,this.attenuationColor.copy(t.attenuationColor),this.specularIntensity=t.specularIntensity,this.specularIntensityMap=t.specularIntensityMap,this.specularColor.copy(t.specularColor),this.specularColorMap=t.specularColorMap,this}};var Tr=class extends ki{static get type(){return"LineDashedMaterial"}constructor(t){super(),this.isLineDashedMaterial=!0,this.scale=1,this.dashSize=3,this.gapSize=1,this.setValues(t)}copy(t){return super.copy(t),this.scale=t.scale,this.dashSize=t.dashSize,this.gapSize=t.gapSize,this}};function Ca(i,t,e){return!i||!e&&i.constructor===t?i:typeof t.BYTES_PER_ELEMENT=="number"?new t(i):Array.prototype.slice.call(i)}function c_(i){return ArrayBuffer.isView(i)&&!(i instanceof DataView)}var Ar=class{constructor(t,e,n,s){this.parameterPositions=t,this._cachedIndex=0,this.resultBuffer=s!==void 0?s:new e.constructor(n),this.sampleValues=e,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(t){let e=this.parameterPositions,n=this._cachedIndex,s=e[n],r=e[n-1];n:{t:{let o;e:{i:if(!(t<s)){for(let a=n+2;;){if(s===void 0){if(t<r)break i;return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===a)break;if(r=s,s=e[++n],t<s)break t}o=e.length;break e}if(!(t>=r)){let a=e[1];t<a&&(n=2,r=a);for(let l=n-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===l)break;if(s=r,r=e[--n-1],t>=r)break t}o=n,n=0;break e}break n}for(;n<o;){let a=n+o>>>1;t<e[a]?o=a:n=a+1}if(s=e[n],r=e[n-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(s===void 0)return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,r,s)}return this.interpolate_(n,r,t,s)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(t){let e=this.resultBuffer,n=this.sampleValues,s=this.valueSize,r=t*s;for(let o=0;o!==s;++o)e[o]=n[r+o];return e}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},Gh=class extends Ar{constructor(t,e,n,s){super(t,e,n,s),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:_d,endingEnd:_d}}intervalChanged_(t,e,n){let s=this.parameterPositions,r=t-2,o=t+1,a=s[r],l=s[o];if(a===void 0)switch(this.getSettings_().endingStart){case Md:r=t,a=2*e-n;break;case wd:r=s.length-2,a=e+s[r]-s[r+1];break;default:r=t,a=n}if(l===void 0)switch(this.getSettings_().endingEnd){case Md:o=t,l=2*n-e;break;case wd:o=1,l=n+s[1]-s[0];break;default:o=t-1,l=e}let c=(n-e)*.5,h=this.valueSize;this._weightPrev=c/(e-a),this._weightNext=c/(l-n),this._offsetPrev=r*h,this._offsetNext=o*h}interpolate_(t,e,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=t*a,c=l-a,h=this._offsetPrev,u=this._offsetNext,d=this._weightPrev,f=this._weightNext,m=(n-e)/(s-e),x=m*m,g=x*m,p=-d*g+2*d*x-d*m,M=(1+d)*g+(-1.5-2*d)*x+(-.5+d)*m+1,v=(-1-f)*g+(1.5+f)*x+.5*m,y=f*g-f*x;for(let w=0;w!==a;++w)r[w]=p*o[h+w]+M*o[c+w]+v*o[l+w]+y*o[u+w];return r}},Wh=class extends Ar{constructor(t,e,n,s){super(t,e,n,s)}interpolate_(t,e,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=t*a,c=l-a,h=(n-e)/(s-e),u=1-h;for(let d=0;d!==a;++d)r[d]=o[c+d]*u+o[l+d]*h;return r}},$h=class extends Ar{constructor(t,e,n,s){super(t,e,n,s)}interpolate_(t){return this.copySampleValue_(t-1)}},ei=class{constructor(t,e,n,s){if(t===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(e===void 0||e.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+t);this.name=t,this.times=Ca(e,this.TimeBufferType),this.values=Ca(n,this.ValueBufferType),this.setInterpolation(s||this.DefaultInterpolation)}static toJSON(t){let e=t.constructor,n;if(e.toJSON!==this.toJSON)n=e.toJSON(t);else{n={name:t.name,times:Ca(t.times,Array),values:Ca(t.values,Array)};let s=t.getInterpolation();s!==t.DefaultInterpolation&&(n.interpolation=s)}return n.type=t.ValueTypeName,n}InterpolantFactoryMethodDiscrete(t){return new $h(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodLinear(t){return new Wh(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodSmooth(t){return new Gh(this.times,this.values,this.getValueSize(),t)}setInterpolation(t){let e;switch(t){case Ua:e=this.InterpolantFactoryMethodDiscrete;break;case gh:e=this.InterpolantFactoryMethodLinear;break;case Ql:e=this.InterpolantFactoryMethodSmooth;break}if(e===void 0){let n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(t!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return console.warn("THREE.KeyframeTrack:",n),this}return this.createInterpolant=e,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return Ua;case this.InterpolantFactoryMethodLinear:return gh;case this.InterpolantFactoryMethodSmooth:return Ql}}getValueSize(){return this.values.length/this.times.length}shift(t){if(t!==0){let e=this.times;for(let n=0,s=e.length;n!==s;++n)e[n]+=t}return this}scale(t){if(t!==1){let e=this.times;for(let n=0,s=e.length;n!==s;++n)e[n]*=t}return this}trim(t,e){let n=this.times,s=n.length,r=0,o=s-1;for(;r!==s&&n[r]<t;)++r;for(;o!==-1&&n[o]>e;)--o;if(++o,r!==0||o!==s){r>=o&&(o=Math.max(o,1),r=o-1);let a=this.getValueSize();this.times=n.slice(r,o),this.values=this.values.slice(r*a,o*a)}return this}validate(){let t=!0,e=this.getValueSize();e-Math.floor(e)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),t=!1);let n=this.times,s=this.values,r=n.length;r===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),t=!1);let o=null;for(let a=0;a!==r;a++){let l=n[a];if(typeof l=="number"&&isNaN(l)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,a,l),t=!1;break}if(o!==null&&o>l){console.error("THREE.KeyframeTrack: Out of order keys.",this,a,l,o),t=!1;break}o=l}if(s!==void 0&&c_(s))for(let a=0,l=s.length;a!==l;++a){let c=s[a];if(isNaN(c)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,a,c),t=!1;break}}return t}optimize(){let t=this.times.slice(),e=this.values.slice(),n=this.getValueSize(),s=this.getInterpolation()===Ql,r=t.length-1,o=1;for(let a=1;a<r;++a){let l=!1,c=t[a],h=t[a+1];if(c!==h&&(a!==1||c!==t[0]))if(s)l=!0;else{let u=a*n,d=u-n,f=u+n;for(let m=0;m!==n;++m){let x=e[u+m];if(x!==e[d+m]||x!==e[f+m]){l=!0;break}}}if(l){if(a!==o){t[o]=t[a];let u=a*n,d=o*n;for(let f=0;f!==n;++f)e[d+f]=e[u+f]}++o}}if(r>0){t[o]=t[r];for(let a=r*n,l=o*n,c=0;c!==n;++c)e[l+c]=e[a+c];++o}return o!==t.length?(this.times=t.slice(0,o),this.values=e.slice(0,o*n)):(this.times=t,this.values=e),this}clone(){let t=this.times.slice(),e=this.values.slice(),n=this.constructor,s=new n(this.name,t,e);return s.createInterpolant=this.createInterpolant,s}};ei.prototype.TimeBufferType=Float32Array;ei.prototype.ValueBufferType=Float32Array;ei.prototype.DefaultInterpolation=gh;var As=class extends ei{constructor(t,e,n){super(t,e,n)}};As.prototype.ValueTypeName="bool";As.prototype.ValueBufferType=Array;As.prototype.DefaultInterpolation=Ua;As.prototype.InterpolantFactoryMethodLinear=void 0;As.prototype.InterpolantFactoryMethodSmooth=void 0;var qh=class extends ei{};qh.prototype.ValueTypeName="color";var Xh=class extends ei{};Xh.prototype.ValueTypeName="number";var Yh=class extends Ar{constructor(t,e,n,s){super(t,e,n,s)}interpolate_(t,e,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=(n-e)/(s-e),c=t*a;for(let h=c+a;c!==h;c+=4)Re.slerpFlat(r,0,o,c-a,o,c,l);return r}},rl=class extends ei{InterpolantFactoryMethodLinear(t){return new Yh(this.times,this.values,this.getValueSize(),t)}};rl.prototype.ValueTypeName="quaternion";rl.prototype.InterpolantFactoryMethodSmooth=void 0;var Rs=class extends ei{constructor(t,e,n){super(t,e,n)}};Rs.prototype.ValueTypeName="string";Rs.prototype.ValueBufferType=Array;Rs.prototype.DefaultInterpolation=Ua;Rs.prototype.InterpolantFactoryMethodLinear=void 0;Rs.prototype.InterpolantFactoryMethodSmooth=void 0;var Zh=class extends ei{};Zh.prototype.ValueTypeName="vector";var Kh=class{constructor(t,e,n){let s=this,r=!1,o=0,a=0,l,c=[];this.onStart=void 0,this.onLoad=t,this.onProgress=e,this.onError=n,this.itemStart=function(h){a++,r===!1&&s.onStart!==void 0&&s.onStart(h,o,a),r=!0},this.itemEnd=function(h){o++,s.onProgress!==void 0&&s.onProgress(h,o,a),o===a&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(h){s.onError!==void 0&&s.onError(h)},this.resolveURL=function(h){return l?l(h):h},this.setURLModifier=function(h){return l=h,this},this.addHandler=function(h,u){return c.push(h,u),this},this.removeHandler=function(h){let u=c.indexOf(h);return u!==-1&&c.splice(u,2),this},this.getHandler=function(h){for(let u=0,d=c.length;u<d;u+=2){let f=c[u],m=c[u+1];if(f.global&&(f.lastIndex=0),f.test(h))return m}return null}}},h_=new Kh,Jh=class{constructor(t){this.manager=t!==void 0?t:h_,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(t,e){let n=this;return new Promise(function(s,r){n.load(t,s,e,r)})}parse(){}setCrossOrigin(t){return this.crossOrigin=t,this}setWithCredentials(t){return this.withCredentials=t,this}setPath(t){return this.path=t,this}setResourcePath(t){return this.resourcePath=t,this}setRequestHeader(t){return this.requestHeader=t,this}};Jh.DEFAULT_MATERIAL_NAME="__DEFAULT";var ol=class extends We{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new wt(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){let e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(e.object.target=this.target.uuid),e}},al=class extends ol{constructor(t,e,n){super(t,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(We.DEFAULT_UP),this.updateMatrix(),this.groundColor=new wt(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}},Ic=new qt,If=new P,Lf=new P,jh=class{constructor(t){this.camera=t,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new rt(512,512),this.map=null,this.mapPass=null,this.matrix=new qt,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new go,this._frameExtents=new rt(1,1),this._viewportCount=1,this._viewports=[new Me(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){let e=this.camera,n=this.matrix;If.setFromMatrixPosition(t.matrixWorld),e.position.copy(If),Lf.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(Lf),e.updateMatrixWorld(),Ic.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Ic),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(Ic)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.intensity=t.intensity,this.bias=t.bias,this.radius=t.radius,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let t={};return this.intensity!==1&&(t.intensity=this.intensity),this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}};var Qh=class extends jh{constructor(){super(new Wa(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},ll=class extends ol{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(We.DEFAULT_UP),this.updateMatrix(),this.target=new We,this.shadow=new Qh}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}};var cl=class{constructor(t=!0){this.autoStart=t,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=kf(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let t=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){let e=kf();t=(e-this.oldTime)/1e3,this.oldTime=e,this.elapsedTime+=t}return t}};function kf(){return performance.now()}var mu="\\[\\]\\.:\\/",u_=new RegExp("["+mu+"]","g"),gu="[^"+mu+"]",d_="[^"+mu.replace("\\.","")+"]",f_=/((?:WC+[\/:])*)/.source.replace("WC",gu),p_=/(WCOD+)?/.source.replace("WCOD",d_),m_=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",gu),g_=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",gu),x_=new RegExp("^"+f_+p_+m_+g_+"$"),y_=["material","materials","bones","map"],tu=class{constructor(t,e,n){let s=n||we.parseTrackName(e);this._targetGroup=t,this._bindings=t.subscribe_(e,s)}getValue(t,e){this.bind();let n=this._targetGroup.nCachedObjects_,s=this._bindings[n];s!==void 0&&s.getValue(t,e)}setValue(t,e){let n=this._bindings;for(let s=this._targetGroup.nCachedObjects_,r=n.length;s!==r;++s)n[s].setValue(t,e)}bind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].bind()}unbind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].unbind()}},we=class i{constructor(t,e,n){this.path=e,this.parsedPath=n||i.parseTrackName(e),this.node=i.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,e,n){return t&&t.isAnimationObjectGroup?new i.Composite(t,e,n):new i(t,e,n)}static sanitizeNodeName(t){return t.replace(/\s/g,"_").replace(u_,"")}static parseTrackName(t){let e=x_.exec(t);if(e===null)throw new Error("PropertyBinding: Cannot parse trackName: "+t);let n={nodeName:e[2],objectName:e[3],objectIndex:e[4],propertyName:e[5],propertyIndex:e[6]},s=n.nodeName&&n.nodeName.lastIndexOf(".");if(s!==void 0&&s!==-1){let r=n.nodeName.substring(s+1);y_.indexOf(r)!==-1&&(n.nodeName=n.nodeName.substring(0,s),n.objectName=r)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+t);return n}static findNode(t,e){if(e===void 0||e===""||e==="."||e===-1||e===t.name||e===t.uuid)return t;if(t.skeleton){let n=t.skeleton.getBoneByName(e);if(n!==void 0)return n}if(t.children){let n=function(r){for(let o=0;o<r.length;o++){let a=r[o];if(a.name===e||a.uuid===e)return a;let l=n(a.children);if(l)return l}return null},s=n(t.children);if(s)return s}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(t,e){t[e]=this.targetObject[this.propertyName]}_getValue_array(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)t[e++]=n[s]}_getValue_arrayElement(t,e){t[e]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(t,e){this.resolvedProperty.toArray(t,e)}_setValue_direct(t,e){this.targetObject[this.propertyName]=t[e]}_setValue_direct_setNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=t[e++]}_setValue_array_setNeedsUpdate(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=t[e++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=t[e++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(t,e){this.resolvedProperty[this.propertyIndex]=t[e]}_setValue_arrayElement_setNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(t,e){this.resolvedProperty.fromArray(t,e)}_setValue_fromArray_setNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(t,e){this.bind(),this.getValue(t,e)}_setValue_unbound(t,e){this.bind(),this.setValue(t,e)}bind(){let t=this.node,e=this.parsedPath,n=e.objectName,s=e.propertyName,r=e.propertyIndex;if(t||(t=i.findNode(this.rootNode,e.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let c=e.objectIndex;switch(n){case"materials":if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}t=t.material.materials;break;case"bones":if(!t.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}t=t.skeleton.bones;for(let h=0;h<t.length;h++)if(t[h].name===c){c=h;break}break;case"map":if("map"in t){t=t.map;break}if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}t=t.material.map;break;default:if(t[n]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}t=t[n]}if(c!==void 0){if(t[c]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,t);return}t=t[c]}}let o=t[s];if(o===void 0){let c=e.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+c+"."+s+" but it wasn't found.",t);return}let a=this.Versioning.None;this.targetObject=t,t.needsUpdate!==void 0?a=this.Versioning.NeedsUpdate:t.matrixWorldNeedsUpdate!==void 0&&(a=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(r!==void 0){if(s==="morphTargetInfluences"){if(!t.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!t.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}t.morphTargetDictionary[r]!==void 0&&(r=t.morphTargetDictionary[r])}l=this.BindingType.ArrayElement,this.resolvedProperty=o,this.propertyIndex=r}else o.fromArray!==void 0&&o.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=o):Array.isArray(o)?(l=this.BindingType.EntireArray,this.resolvedProperty=o):this.propertyName=s;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][a]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};we.Composite=tu;we.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};we.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};we.prototype.GetterByBindingType=[we.prototype._getValue_direct,we.prototype._getValue_array,we.prototype._getValue_arrayElement,we.prototype._getValue_toArray];we.prototype.SetterByBindingTypeAndVersioning=[[we.prototype._setValue_direct,we.prototype._setValue_direct_setNeedsUpdate,we.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[we.prototype._setValue_array,we.prototype._setValue_array_setNeedsUpdate,we.prototype._setValue_array_setMatrixWorldNeedsUpdate],[we.prototype._setValue_arrayElement,we.prototype._setValue_arrayElement_setNeedsUpdate,we.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[we.prototype._setValue_fromArray,we.prototype._setValue_fromArray_setNeedsUpdate,we.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var Q1=new Float32Array(1);var Df=new qt,hl=class{constructor(t,e,n=0,s=1/0){this.ray=new po(t,e),this.near=n,this.far=s,this.camera=null,this.layers=new mo,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(t,e){this.ray.set(t,e)}setFromCamera(t,e){e.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(t.x,t.y,.5).unproject(e).sub(this.ray.origin).normalize(),this.camera=e):e.isOrthographicCamera?(this.ray.origin.set(t.x,t.y,(e.near+e.far)/(e.near-e.far)).unproject(e),this.ray.direction.set(0,0,-1).transformDirection(e.matrixWorld),this.camera=e):console.error("THREE.Raycaster: Unsupported camera type: "+e.type)}setFromXRController(t){return Df.identity().extractRotation(t.matrixWorld),this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(Df),this}intersectObject(t,e=!0,n=[]){return eu(t,this,n,e),n.sort(Uf),n}intersectObjects(t,e=!0,n=[]){for(let s=0,r=t.length;s<r;s++)eu(t[s],this,n,e);return n.sort(Uf),n}};function Uf(i,t){return i.distance-t.distance}function eu(i,t,e,n){let s=!0;if(i.layers.test(t.layers)&&i.raycast(t,e)===!1&&(s=!1),s===!0&&n===!0){let r=i.children;for(let o=0,a=r.length;o<a;o++)eu(r[o],t,e,!0)}}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:nu}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=nu);function Cs(i){let t=i>>>0;return()=>{t=t+1831565813>>>0;let e=t;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}}function v_(i,t){let e=Cs(i),n=new Float32Array(t*t).map(()=>e()),s=(r,o)=>n[(o%t+t)%t*t+(r%t+t)%t];return(r,o)=>{let a=Math.floor(r),l=Math.floor(o),c=r-a,h=o-l,u=c*c*(3-2*c),d=h*h*(3-2*h),f=s(a,l),m=s(a+1,l),x=s(a,l+1),g=s(a+1,l+1);return f+(m-f)*u+(x-f)*d+(f-m-x+g)*u*d}}function Xe(i,t,e=5){let n=Array.from({length:e},(s,r)=>v_(i+r*101,t<<r));return(s,r)=>{let o=0,a=.5,l=0;for(let c=0;c<e;c++)o+=n[c](s*(t<<c),r*(t<<c))*a,l+=a,a*=.5;return o/l}}var oe=512;function vn(i,t=oe){let e=new Float32Array(t*t),n=new Uint8ClampedArray(t*t*4);for(let s=0;s<t;s++)for(let r=0;r<t;r++){let o=s*t+r,[a,l,c,h]=i(r/t,s/t,r,s);n[o*4]=a,n[o*4+1]=l,n[o*4+2]=c,n[o*4+3]=255,e[o]=h}return{size:t,h:e,col:n}}function b_({size:i,h:t,col:e},n){let s=document.createElement("canvas");s.width=s.height=i,s.getContext("2d").putImageData(new ImageData(e,i,i),0,0);let r=new nn(s);r.colorSpace=me;let o=new Uint8ClampedArray(i*i*4),a=(h,u)=>t[(u+i)%i*i+(h+i)%i];for(let h=0;h<i;h++)for(let u=0;u<i;u++){let d=(a(u+1,h)-a(u-1,h))*n,f=(a(u,h+1)-a(u,h-1))*n,m=Math.hypot(d,f,1),x=(h*i+u)*4;o[x]=(-d/m*.5+.5)*255,o[x+1]=(f/m*.5+.5)*255,o[x+2]=(1/m*.5+.5)*255,o[x+3]=255}let l=document.createElement("canvas");l.width=l.height=i,l.getContext("2d").putImageData(new ImageData(o,i,i),0,0);let c=new nn(l);for(let h of[r,c])h.wrapS=h.wrapT=Ms,h.anisotropy=4,h.generateMipmaps=!0,h.minFilter=Ai;return{map:r,normal:c}}var Ke=(i,t,e)=>i+(t-i)*e,Co=i=>Math.max(0,Math.min(1,i)),__={grass(){let i=Xe(11,4),t=Xe(12,32,3),e=Cs(5),n=new Float32Array(oe*oe);for(let s=0;s<26e3;s++){let r=e()*oe,o=e()*oe,a=4+e()*9,l=-Math.PI/2+(e()-.5)*.9,c=.4+e()*.6;for(let h=0;h<a;h++)n[(Math.floor(o)+oe)%oe*oe+(Math.floor(r)+oe)%oe]=c,r+=Math.cos(l),o+=Math.sin(l)}return vn((s,r,o,a)=>{let l=i(s,r),c=t(s,r),h=n[a*oe+o],u=Co(l*1.3-.15),d=Co((l-.62)*4),f=Ke(58,92,u)+h*18,m=Ke(92,128,u)+h*26,x=Ke(34,46,u);f=Ke(f,142,d*.5),m=Ke(m,136,d*.4),x=Ke(x,70,d*.4);let g=.78+c*.35;return[f*g,m*g,x*g,h*.8+c*.4]})},green(){let i=Xe(21,64,3),t=Xe(22,4,3);return vn((e,n)=>{let s=i(e,n),r=t(e,n),o=.88+s*.22+r*.08;return[78*o,140*o,52*o,s*.3]})},dirt(){let i=Xe(31,4),t=Xe(32,48,3),e=Cs(33),n=new Float32Array(oe*oe);for(let s=0;s<900;s++){let r=e()*oe,o=e()*oe,a=1.5+e()*4,l=.5+e()*.5;for(let c=-a;c<=a;c++)for(let h=-a;h<=a;h++){let u=1-Math.hypot(h,c)/a;if(u>0){let d=(Math.floor(o+c)+oe)%oe*oe+(Math.floor(r+h)+oe)%oe;n[d]=Math.max(n[d],Math.sqrt(u)*l)}}}return vn((s,r,o,a)=>{let l=i(s,r),c=t(s,r),h=n[a*oe+o],u=.75+l*.35+c*.15;return[Ke(150*u,175,h*.6),Ke(122*u,165,h*.6),Ke(86*u,150,h*.6),c*.5+h]})},paving(){let i=Cs(41),t=Xe(42,32,3),e=Xe(43,4),n=Array.from({length:22},()=>[i(),i(),.75+i()*.3]);return vn((s,r)=>{let o=9,a=9,l=1;for(let[g,p,M]of n)for(let v=-1;v<=1;v++)for(let y=-1;y<=1;y++){let w=Math.hypot(s-g-y,r-p-v);w<o?(a=o,o=w,l=M):w<a&&(a=w)}let c=a-o,h=Co(1-c/.012),u=t(s,r),d=e(s,r),f=.8+u*.25+d*.1,m=[196*l*f,186*l*f,168*l*f],x=[110,104,96];return[Ke(m[0],x[0],h),Ke(m[1],x[1],h),Ke(m[2],x[2],h),(1-h)*(.8+u*.2)-Co(1-c/.03)*.15]},256)},wood(){let i=Xe(51,8,4),t=Cs(52),e=Array.from({length:8},()=>.8+t()*.35);return vn((n,s)=>{let r=Math.floor(s*8),o=s*8-r,a=Math.sin((n*6+i(n*.2+r*.13,s)*3)*Math.PI*6)*.5+.5,l=e[r]*(.85+a*.2+i(n,s)*.1),c=o<.03||o>.97?.45:1;return[150*l*c,102*l*c,64*l*c,c<1?0:.6+a*.2]})},bark(){let i=Xe(61,4,4);return vn((t,e)=>{let n=i(t*3,e*.4),s=Math.abs(Math.sin((t*10+n*2)*Math.PI)),r=.55+s*.4+i(t,e)*.2;return[96*r,74*r,56*r,s]})},leaves(){let i=Cs(71),t=Xe(72,8,3),e=new Float32Array(oe*oe),n=new Float32Array(oe*oe);for(let s=0;s<2600;s++){let r=i()*oe,o=i()*oe,a=5+i()*7,l=i(),c=i()*Math.PI;for(let h=-a;h<=a;h++)for(let u=-a;u<=a;u++){let d=u*Math.cos(c)+h*Math.sin(c),f=-u*Math.sin(c)+h*Math.cos(c),m=1-d*d/(a*a)-f*f/(a*a*.25);if(m>0){let x=(Math.floor(o+h)+oe)%oe*oe+(Math.floor(r+u)+oe)%oe,g=s/2600+m*.2;g>e[x]&&(e[x]=g,n[x]=l)}}}return vn((s,r,o,a)=>{let l=a*oe+o,c=n[l],h=t(s,r),u=.55+e[l]*.5+h*.15;return[Ke(48,92,c)*u,Ke(88,128,c)*u,Ke(34,40,c)*u,e[l]]})},sand(){let i=Xe(81,64,3),t=Xe(82,4);return vn((e,n)=>{let s=i(e,n),r=t(e,n),o=.85+s*.2+r*.1;return[222*o,202*o,160*o,s*.4+Math.sin((e+r*.3)*60)*.05]})},rock(){let i=Xe(91,4,6),t=Xe(92,16,3);return vn((e,n)=>{let s=i(e,n),r=t(e,n),o=.6+s*.5,a=Co((r-.65)*5);return[Ke(132*o,120,a*.4),Ke(128*o,132,a*.4),Ke(120*o,90,a*.4),s]})},felt(){let i=Xe(101,128,2);return vn((t,e)=>{let n=i(t,e),s=.9+n*.12;return[200*s,200*s,200*s,n*.2]},256)},plaster(){let i=Xe(111,32,4);return vn((t,e)=>{let n=i(t,e),s=.9+n*.12;return[238*s,232*s,220*s,n*.5]},256)},roof(){let i=Xe(121,16,3),t=Cs(122),e=Array.from({length:64},()=>.85+t()*.25);return vn((n,s)=>{let r=Math.floor(s*8),o=s*8-r,a=Math.floor(n*8+r%2*.5)%8,l=(n*8+r%2*.5)%1,c=Math.sin(l*Math.PI),h=e[r*8+a]*(.75+c*.3)*(.7+o*.3)*(.9+i(n,s)*.15);return[255*h,255*h,255*h,c*.5+o*.5]},256)},fabric(){return vn((i,t,e,n)=>{let s=((e>>1)+(n>>1))%2?1:.92;return[255*s,255*s,255*s,s]},128)},water(){let i=Xe(131,8,5);return vn((t,e)=>[128,128,255,i(t,e)],256)}},xu={};function Di(i){if(!xu[i]){let t={grass:6,dirt:10,paving:14,wood:5,bark:10,leaves:9,sand:4,rock:12,felt:2,plaster:5,roof:8,fabric:3,water:22,green:3}[i]||6;xu[i]=b_(__[i](),t)}return xu[i]}var Ps={value:new URLSearchParams(location.search).has("curve")?.0022:0},M_=`
  uniform float uBend;
  varying vec3 vTpPos;
  varying vec3 vTpNormal;
`,w_=`
  vec4 tpW = vec4(transformed, 1.0);
  vec3 tpN = objectNormal;
  #ifdef USE_INSTANCING
    tpW = instanceMatrix * tpW;
    tpN = mat3(instanceMatrix) * tpN;
  #endif
  tpW = modelMatrix * tpW;
  vTpPos = tpW.xyz;
  vTpNormal = normalize(mat3(modelMatrix) * tpN);
  vec2 dxz = tpW.xz - cameraPosition.xz;
  tpW.y -= dot(dxz, dxz) * uBend;
  vec4 mvPosition = viewMatrix * tpW;
  gl_Position = projectionMatrix * mvPosition;
`,S_=`
  uniform sampler2D uTpNormal;
  uniform float uTpScale;
  uniform float uTpNS;
  varying vec3 vTpPos;
  varying vec3 vTpNormal;
  vec3 tpW3() { vec3 b = pow(abs(normalize(vTpNormal)), vec3(4.0)); return b / (b.x + b.y + b.z); }
`,E_=`
  #ifdef USE_MAP
    vec3 tpB = tpW3();
    vec2 tpUX = vTpPos.zy * uTpScale, tpUY = vTpPos.xz * uTpScale, tpUZ = vTpPos.xy * uTpScale;
    vec4 tpC = texture2D(map, tpUX) * tpB.x + texture2D(map, tpUY) * tpB.y + texture2D(map, tpUZ) * tpB.z;
    diffuseColor *= tpC;
  #endif
`,T_=`
  #ifdef USE_MAP
  {
    vec3 tpB2 = tpW3();
    vec3 nX = texture2D(uTpNormal, vTpPos.zy * uTpScale).xyz * 2.0 - 1.0;
    vec3 nY = texture2D(uTpNormal, vTpPos.xz * uTpScale).xyz * 2.0 - 1.0;
    vec3 nZ = texture2D(uTpNormal, vTpPos.xy * uTpScale).xyz * 2.0 - 1.0;
    vec3 wn = normalize(vTpNormal);
    vec3 pert = vec3(0.0, nX.y, nX.x) * tpB2.x + vec3(nY.x, 0.0, nY.y) * tpB2.y + vec3(nZ.x, nZ.y, 0.0) * tpB2.z;
    vec3 vn = normalize((viewMatrix * vec4(normalize(wn + pert * uTpNS), 0.0)).xyz);
    normal = normalize(mix(normal, vn, 0.85));
  }
  #endif
`;function A_(i,t,e,n){return i.onBeforeCompile=s=>{s.uniforms.uBend=Ps,s.uniforms.uTpNormal={value:t},s.uniforms.uTpScale={value:e},s.uniforms.uTpNS={value:n},s.vertexShader=M_+s.vertexShader.replace("#include <project_vertex>",w_),s.fragmentShader=S_+s.fragmentShader.replace("#include <map_fragment>",E_).replace("#include <normal_fragment_maps>",`#include <normal_fragment_maps>
`+T_)},i.customProgramCacheKey=()=>"tp",i}var R_=`
  vec4 cW = vec4(transformed, 1.0);
  #ifdef USE_INSTANCING
    cW = instanceMatrix * cW;
  #endif
  cW = modelMatrix * cW;
  vec2 cdxz = cW.xz - cameraPosition.xz;
  cW.y -= dot(cdxz, cdxz) * uBend;
  vec4 mvPosition = viewMatrix * cW;
  gl_Position = projectionMatrix * mvPosition;
`;function kn(i){return i.onBeforeCompile=t=>{t.uniforms.uBend=Ps,t.vertexShader=`uniform float uBend;
`+t.vertexShader.replace("#include <project_vertex>",R_)},i.customProgramCacheKey=()=>"curve",i}var C_={grass:["grass",3,.8,.95],green:["green",2,.5,.85],dirt:["dirt",2.5,1,.95],paving:["paving",3,1,.85],wood:["wood",1.6,.8,.7],bark:["bark",1.2,1,.95],leaves:["leaves",1.6,1,.8],sand:["sand",2,.6,.95],rock:["rock",2.5,1.2,.9],felt:["felt",.4,.4,.95],plaster:["plaster",2,.5,.9],roof:["roof",1.4,1,.75],fabric:["fabric",.08,.5,.9],concrete:["plaster",1.5,.9,.9]},Lr=new Map;function kt(i,t=16777215,e={}){let n=`${i}|${t}|${JSON.stringify(e)}`;if(Lr.has(n))return Lr.get(n);let[s,r,o,a,l=0]=C_[i],{map:c,normal:h}=Di(s),u=A_(new ye({color:t,map:c,roughness:a,metalness:l,...e}),h,1/r,o);return Lr.set(n,u),u}function Pt(i,t={}){let e=`plain|${i}|${JSON.stringify(t)}`;return Lr.has(e)||Lr.set(e,kn(new ye({color:i,roughness:.6,metalness:0,...t}))),Lr.get(e)}var lp={skin:[16769220,16107936,14263418,11039052,8015411],shirts:["#ff8fa3","#ffb86b","#ffe066","#8ce99a","#74c0fc","#b197fc","#f783ac","#63e6be"],wood:13011541,woodDark:9263668,stone:15129803,path:15785908,roof:14711391,white:16775920};var kr=class i extends nt{constructor(){let t=i.SkyShader,e=new xn({name:t.name,uniforms:Pr.clone(t.uniforms),vertexShader:t.vertexShader,fragmentShader:t.fragmentShader,side:en,depthWrite:!1});super(new Xt(1,1,1),e),this.isSky=!0}};kr.SkyShader={name:"SkyShader",uniforms:{turbidity:{value:2},rayleigh:{value:1},mieCoefficient:{value:.005},mieDirectionalG:{value:.8},sunPosition:{value:new P},up:{value:new P(0,1,0)}},vertexShader:`
		uniform vec3 sunPosition;
		uniform float rayleigh;
		uniform float turbidity;
		uniform float mieCoefficient;
		uniform vec3 up;

		varying vec3 vWorldPosition;
		varying vec3 vSunDirection;
		varying float vSunfade;
		varying vec3 vBetaR;
		varying vec3 vBetaM;
		varying float vSunE;

		// constants for atmospheric scattering
		const float e = 2.71828182845904523536028747135266249775724709369995957;
		const float pi = 3.141592653589793238462643383279502884197169;

		// wavelength of used primaries, according to preetham
		const vec3 lambda = vec3( 680E-9, 550E-9, 450E-9 );
		// this pre-calcuation replaces older TotalRayleigh(vec3 lambda) function:
		// (8.0 * pow(pi, 3.0) * pow(pow(n, 2.0) - 1.0, 2.0) * (6.0 + 3.0 * pn)) / (3.0 * N * pow(lambda, vec3(4.0)) * (6.0 - 7.0 * pn))
		const vec3 totalRayleigh = vec3( 5.804542996261093E-6, 1.3562911419845635E-5, 3.0265902468824876E-5 );

		// mie stuff
		// K coefficient for the primaries
		const float v = 4.0;
		const vec3 K = vec3( 0.686, 0.678, 0.666 );
		// MieConst = pi * pow( ( 2.0 * pi ) / lambda, vec3( v - 2.0 ) ) * K
		const vec3 MieConst = vec3( 1.8399918514433978E14, 2.7798023919660528E14, 4.0790479543861094E14 );

		// earth shadow hack
		// cutoffAngle = pi / 1.95;
		const float cutoffAngle = 1.6110731556870734;
		const float steepness = 1.5;
		const float EE = 1000.0;

		float sunIntensity( float zenithAngleCos ) {
			zenithAngleCos = clamp( zenithAngleCos, -1.0, 1.0 );
			return EE * max( 0.0, 1.0 - pow( e, -( ( cutoffAngle - acos( zenithAngleCos ) ) / steepness ) ) );
		}

		vec3 totalMie( float T ) {
			float c = ( 0.2 * T ) * 10E-18;
			return 0.434 * c * MieConst;
		}

		void main() {

			vec4 worldPosition = modelMatrix * vec4( position, 1.0 );
			vWorldPosition = worldPosition.xyz;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			gl_Position.z = gl_Position.w; // set z to camera.far

			vSunDirection = normalize( sunPosition );

			vSunE = sunIntensity( dot( vSunDirection, up ) );

			vSunfade = 1.0 - clamp( 1.0 - exp( ( sunPosition.y / 450000.0 ) ), 0.0, 1.0 );

			float rayleighCoefficient = rayleigh - ( 1.0 * ( 1.0 - vSunfade ) );

			// extinction (absorbtion + out scattering)
			// rayleigh coefficients
			vBetaR = totalRayleigh * rayleighCoefficient;

			// mie coefficients
			vBetaM = totalMie( turbidity ) * mieCoefficient;

		}`,fragmentShader:`
		varying vec3 vWorldPosition;
		varying vec3 vSunDirection;
		varying float vSunfade;
		varying vec3 vBetaR;
		varying vec3 vBetaM;
		varying float vSunE;

		uniform float mieDirectionalG;
		uniform vec3 up;

		// constants for atmospheric scattering
		const float pi = 3.141592653589793238462643383279502884197169;

		const float n = 1.0003; // refractive index of air
		const float N = 2.545E25; // number of molecules per unit volume for air at 288.15K and 1013mb (sea level -45 celsius)

		// optical length at zenith for molecules
		const float rayleighZenithLength = 8.4E3;
		const float mieZenithLength = 1.25E3;
		// 66 arc seconds -> degrees, and the cosine of that
		const float sunAngularDiameterCos = 0.999956676946448443553574619906976478926848692873900859324;

		// 3.0 / ( 16.0 * pi )
		const float THREE_OVER_SIXTEENPI = 0.05968310365946075;
		// 1.0 / ( 4.0 * pi )
		const float ONE_OVER_FOURPI = 0.07957747154594767;

		float rayleighPhase( float cosTheta ) {
			return THREE_OVER_SIXTEENPI * ( 1.0 + pow( cosTheta, 2.0 ) );
		}

		float hgPhase( float cosTheta, float g ) {
			float g2 = pow( g, 2.0 );
			float inverse = 1.0 / pow( 1.0 - 2.0 * g * cosTheta + g2, 1.5 );
			return ONE_OVER_FOURPI * ( ( 1.0 - g2 ) * inverse );
		}

		void main() {

			vec3 direction = normalize( vWorldPosition - cameraPosition );

			// optical length
			// cutoff angle at 90 to avoid singularity in next formula.
			float zenithAngle = acos( max( 0.0, dot( up, direction ) ) );
			float inverse = 1.0 / ( cos( zenithAngle ) + 0.15 * pow( 93.885 - ( ( zenithAngle * 180.0 ) / pi ), -1.253 ) );
			float sR = rayleighZenithLength * inverse;
			float sM = mieZenithLength * inverse;

			// combined extinction factor
			vec3 Fex = exp( -( vBetaR * sR + vBetaM * sM ) );

			// in scattering
			float cosTheta = dot( direction, vSunDirection );

			float rPhase = rayleighPhase( cosTheta * 0.5 + 0.5 );
			vec3 betaRTheta = vBetaR * rPhase;

			float mPhase = hgPhase( cosTheta, mieDirectionalG );
			vec3 betaMTheta = vBetaM * mPhase;

			vec3 Lin = pow( vSunE * ( ( betaRTheta + betaMTheta ) / ( vBetaR + vBetaM ) ) * ( 1.0 - Fex ), vec3( 1.5 ) );
			Lin *= mix( vec3( 1.0 ), pow( vSunE * ( ( betaRTheta + betaMTheta ) / ( vBetaR + vBetaM ) ) * Fex, vec3( 1.0 / 2.0 ) ), clamp( pow( 1.0 - dot( up, vSunDirection ), 5.0 ), 0.0, 1.0 ) );

			// nightsky
			float theta = acos( direction.y ); // elevation --> y-axis, [-pi/2, pi/2]
			float phi = atan( direction.z, direction.x ); // azimuth --> x-axis [-pi/2, pi/2]
			vec2 uv = vec2( phi, theta ) / vec2( 2.0 * pi, pi ) + vec2( 0.5, 0.0 );
			vec3 L0 = vec3( 0.1 ) * Fex;

			// composition + solar disc
			float sundisk = smoothstep( sunAngularDiameterCos, sunAngularDiameterCos + 0.00002, cosTheta );
			L0 += ( vSunE * 19000.0 * Fex ) * sundisk;

			vec3 texColor = ( Lin + L0 ) * 0.04 + vec3( 0.0, 0.0003, 0.00075 );

			vec3 retColor = pow( texColor, vec3( 1.0 / ( 1.2 + ( 1.2 * vSunfade ) ) ) );

			gl_FragColor = vec4( retColor, 1.0 );

			#include <tonemapping_fragment>
			#include <colorspace_fragment>

		}`};var ml=class extends nt{constructor(t,e={}){super(t),this.isWater=!0;let n=this,s=e.textureWidth!==void 0?e.textureWidth:512,r=e.textureHeight!==void 0?e.textureHeight:512,o=e.clipBias!==void 0?e.clipBias:0,a=e.alpha!==void 0?e.alpha:1,l=e.time!==void 0?e.time:0,c=e.waterNormals!==void 0?e.waterNormals:null,h=e.sunDirection!==void 0?e.sunDirection:new P(.70707,.70707,0),u=new wt(e.sunColor!==void 0?e.sunColor:16777215),d=new wt(e.waterColor!==void 0?e.waterColor:8355711),f=e.eye!==void 0?e.eye:new P(0,0,0),m=e.distortionScale!==void 0?e.distortionScale:20,x=e.side!==void 0?e.side:hi,g=e.fog!==void 0?e.fog:!1,p=new Pn,M=new P,v=new P,y=new P,w=new qt,S=new P(0,0,-1),T=new Me,R=new P,_=new P,b=new Me,C=new qt,L=new Ge,k=new Qn(s,r),D={name:"MirrorShader",uniforms:Pr.merge([lt.fog,lt.lights,{normalSampler:{value:null},mirrorSampler:{value:null},alpha:{value:1},time:{value:0},size:{value:1},distortionScale:{value:20},textureMatrix:{value:new qt},sunColor:{value:new wt(8355711)},sunDirection:{value:new P(.70707,.70707,0)},eye:{value:new P},waterColor:{value:new wt(5592405)}}]),vertexShader:`
				uniform mat4 textureMatrix;
				uniform float time;

				varying vec4 mirrorCoord;
				varying vec4 worldPosition;

				#include <common>
				#include <fog_pars_vertex>
				#include <shadowmap_pars_vertex>
				#include <logdepthbuf_pars_vertex>

				void main() {
					mirrorCoord = modelMatrix * vec4( position, 1.0 );
					worldPosition = mirrorCoord.xyzw;
					mirrorCoord = textureMatrix * mirrorCoord;
					vec4 mvPosition =  modelViewMatrix * vec4( position, 1.0 );
					gl_Position = projectionMatrix * mvPosition;

				#include <beginnormal_vertex>
				#include <defaultnormal_vertex>
				#include <logdepthbuf_vertex>
				#include <fog_vertex>
				#include <shadowmap_vertex>
			}`,fragmentShader:`
				uniform sampler2D mirrorSampler;
				uniform float alpha;
				uniform float time;
				uniform float size;
				uniform float distortionScale;
				uniform sampler2D normalSampler;
				uniform vec3 sunColor;
				uniform vec3 sunDirection;
				uniform vec3 eye;
				uniform vec3 waterColor;

				varying vec4 mirrorCoord;
				varying vec4 worldPosition;

				vec4 getNoise( vec2 uv ) {
					vec2 uv0 = ( uv / 103.0 ) + vec2(time / 17.0, time / 29.0);
					vec2 uv1 = uv / 107.0-vec2( time / -19.0, time / 31.0 );
					vec2 uv2 = uv / vec2( 8907.0, 9803.0 ) + vec2( time / 101.0, time / 97.0 );
					vec2 uv3 = uv / vec2( 1091.0, 1027.0 ) - vec2( time / 109.0, time / -113.0 );
					vec4 noise = texture2D( normalSampler, uv0 ) +
						texture2D( normalSampler, uv1 ) +
						texture2D( normalSampler, uv2 ) +
						texture2D( normalSampler, uv3 );
					return noise * 0.5 - 1.0;
				}

				void sunLight( const vec3 surfaceNormal, const vec3 eyeDirection, float shiny, float spec, float diffuse, inout vec3 diffuseColor, inout vec3 specularColor ) {
					vec3 reflection = normalize( reflect( -sunDirection, surfaceNormal ) );
					float direction = max( 0.0, dot( eyeDirection, reflection ) );
					specularColor += pow( direction, shiny ) * sunColor * spec;
					diffuseColor += max( dot( sunDirection, surfaceNormal ), 0.0 ) * sunColor * diffuse;
				}

				#include <common>
				#include <packing>
				#include <bsdfs>
				#include <fog_pars_fragment>
				#include <logdepthbuf_pars_fragment>
				#include <lights_pars_begin>
				#include <shadowmap_pars_fragment>
				#include <shadowmask_pars_fragment>

				void main() {

					#include <logdepthbuf_fragment>
					vec4 noise = getNoise( worldPosition.xz * size );
					vec3 surfaceNormal = normalize( noise.xzy * vec3( 1.5, 1.0, 1.5 ) );

					vec3 diffuseLight = vec3(0.0);
					vec3 specularLight = vec3(0.0);

					vec3 worldToEye = eye-worldPosition.xyz;
					vec3 eyeDirection = normalize( worldToEye );
					sunLight( surfaceNormal, eyeDirection, 100.0, 2.0, 0.5, diffuseLight, specularLight );

					float distance = length(worldToEye);

					vec2 distortion = surfaceNormal.xz * ( 0.001 + 1.0 / distance ) * distortionScale;
					vec3 reflectionSample = vec3( texture2D( mirrorSampler, mirrorCoord.xy / mirrorCoord.w + distortion ) );

					float theta = max( dot( eyeDirection, surfaceNormal ), 0.0 );
					float rf0 = 0.3;
					float reflectance = rf0 + ( 1.0 - rf0 ) * pow( ( 1.0 - theta ), 5.0 );
					vec3 scatter = max( 0.0, dot( surfaceNormal, eyeDirection ) ) * waterColor;
					vec3 albedo = mix( ( sunColor * diffuseLight * 0.3 + scatter ) * getShadowMask(), ( vec3( 0.1 ) + reflectionSample * 0.9 + reflectionSample * specularLight ), reflectance);
					vec3 outgoingLight = albedo;
					gl_FragColor = vec4( outgoingLight, alpha );

					#include <tonemapping_fragment>
					#include <colorspace_fragment>
					#include <fog_fragment>	
				}`},V=new xn({name:D.name,uniforms:Pr.clone(D.uniforms),vertexShader:D.vertexShader,fragmentShader:D.fragmentShader,lights:!0,side:x,fog:g});V.uniforms.mirrorSampler.value=k.texture,V.uniforms.textureMatrix.value=C,V.uniforms.alpha.value=a,V.uniforms.time.value=l,V.uniforms.normalSampler.value=c,V.uniforms.sunColor.value=u,V.uniforms.waterColor.value=d,V.uniforms.sunDirection.value=h,V.uniforms.distortionScale.value=m,V.uniforms.eye.value=f,n.material=V,n.onBeforeRender=function(z,G,F){if(v.setFromMatrixPosition(n.matrixWorld),y.setFromMatrixPosition(F.matrixWorld),w.extractRotation(n.matrixWorld),M.set(0,0,1),M.applyMatrix4(w),R.subVectors(v,y),R.dot(M)>0)return;R.reflect(M).negate(),R.add(v),w.extractRotation(F.matrixWorld),S.set(0,0,-1),S.applyMatrix4(w),S.add(y),_.subVectors(v,S),_.reflect(M).negate(),_.add(v),L.position.copy(R),L.up.set(0,1,0),L.up.applyMatrix4(w),L.up.reflect(M),L.lookAt(_),L.far=F.far,L.updateMatrixWorld(),L.projectionMatrix.copy(F.projectionMatrix),C.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),C.multiply(L.projectionMatrix),C.multiply(L.matrixWorldInverse),p.setFromNormalAndCoplanarPoint(M,v),p.applyMatrix4(L.matrixWorldInverse),T.set(p.normal.x,p.normal.y,p.normal.z,p.constant);let K=L.projectionMatrix;b.x=(Math.sign(T.x)+K.elements[8])/K.elements[0],b.y=(Math.sign(T.y)+K.elements[9])/K.elements[5],b.z=-1,b.w=(1+K.elements[10])/K.elements[14],T.multiplyScalar(2/T.dot(b)),K.elements[2]=T.x,K.elements[6]=T.y,K.elements[10]=T.z+1-o,K.elements[14]=T.w,f.setFromMatrixPosition(F.matrixWorld);let Q=z.getRenderTarget(),ot=z.xr.enabled,St=z.shadowMap.autoUpdate;n.visible=!1,z.xr.enabled=!1,z.shadowMap.autoUpdate=!1,z.setRenderTarget(k),z.state.buffers.depth.setMask(!0),z.autoClear===!1&&z.clear(),z.render(G,L),n.visible=!0,z.xr.enabled=ot,z.shadowMap.autoUpdate=St,z.setRenderTarget(Q);let Vt=F.viewport;Vt!==void 0&&z.state.viewport(Vt)}}};function yu(i,t=!1){let e=i[0].index!==null,n=new Set(Object.keys(i[0].attributes)),s=new Set(Object.keys(i[0].morphAttributes)),r={},o={},a=i[0].morphTargetsRelative,l=new ce,c=0;for(let h=0;h<i.length;++h){let u=i[h],d=0;if(e!==(u.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(let f in u.attributes){if(!n.has(f))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+'. All geometries must have compatible attributes; make sure "'+f+'" attribute exists among all geometries, or in none of them.'),null;r[f]===void 0&&(r[f]=[]),r[f].push(u.attributes[f]),d++}if(d!==n.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". Make sure all geometries have the same number of attributes."),null;if(a!==u.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(let f in u.morphAttributes){if(!s.has(f))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+".  .morphAttributes must be consistent throughout all geometries."),null;o[f]===void 0&&(o[f]=[]),o[f].push(u.morphAttributes[f])}if(t){let f;if(e)f=u.index.count;else if(u.attributes.position!==void 0)f=u.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". The geometry must have either an index or a position attribute"),null;l.addGroup(c,f,h),c+=f}}if(e){let h=0,u=[];for(let d=0;d<i.length;++d){let f=i[d].index;for(let m=0;m<f.count;++m)u.push(f.getX(m)+h);h+=i[d].attributes.position.count}l.setIndex(u)}for(let h in r){let u=cp(r[h]);if(!u)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" attribute."),null;l.setAttribute(h,u)}for(let h in o){let u=o[h][0].length;if(u===0)break;l.morphAttributes=l.morphAttributes||{},l.morphAttributes[h]=[];for(let d=0;d<u;++d){let f=[];for(let x=0;x<o[h].length;++x)f.push(o[h][x][d]);let m=cp(f);if(!m)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" morphAttribute."),null;l.morphAttributes[h].push(m)}}return l}function cp(i){let t,e,n,s=-1,r=0;for(let c=0;c<i.length;++c){let h=i[c];if(t===void 0&&(t=h.array.constructor),t!==h.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(e===void 0&&(e=h.itemSize),e!==h.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(n===void 0&&(n=h.normalized),n!==h.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(s===-1&&(s=h.gpuType),s!==h.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;r+=h.count*e}let o=new t(r),a=new Oe(o,e,n),l=0;for(let c=0;c<i.length;++c){let h=i[c];if(h.isInterleavedBufferAttribute){let u=l/e;for(let d=0,f=h.count;d<f;d++)for(let m=0;m<e;m++){let x=h.getComponent(d,m);a.setComponent(d+u,m,x)}}else o.set(h.array,l);l+=h.count*e}return s!==void 0&&(a.gpuType=s),a}var hp={id:"hub",type:"hub",name:"\uD0DC\uC77C\uACE8\uD504 \uB77C\uC6B4\uC9C0",biome:"temperate"},vu={temperate:{tint:16777215,patch:14208140,water:1920867,tree:"round",elev:38,turb:4,sun:1},links:{tint:14277806,patch:13219708,water:2113362,tree:"none",elev:24,turb:8,sun:.85},coastal:{tint:15925232,patch:14208140,water:1331306,tree:"pine",elev:42,turb:3,sun:1},dry:{tint:15128476,patch:13215850,water:2054768,tree:"round",elev:55,turb:6,sun:1.15},tropical:{tint:15138776,patch:12572538,water:1010296,tree:"palm",elev:62,turb:5,sun:1.15},savanna:{tint:15256708,patch:13213792,water:2776166,tree:"acacia",elev:48,turb:9,sun:1.2},cold:{tint:12175021,patch:16054266,water:1718860,tree:"pine",elev:14,turb:2,sun:.75,snow:!0}};function Is(i){let t=2166136261;for(let e of String(i))t=Math.imul(t^e.charCodeAt(0),16777619);return()=>{t+=1831565813;let e=t;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}}var jt={islandR:135,lake:{x:-62,z:0,r:22},pier:{x0:-52,x1:-37,hw:1.5,y:.45},green:{x0:44,x1:76,z0:-8,z1:8,y:.12},pavilion:{x:0,z:-48,hw:6,hd:5,y:.15},table:{x:0,z:-48,L:2.24,W:1.12,h:.78}};jt.table.y=jt.pavilion.y+jt.table.h;var Po=[{id:"golf",x:46.5,z:0,r:3.2},{id:"fishing",x:-50.5,z:0,r:2.6},{id:"billiards",x:0,z:-45.2,r:2.4}];function gl(i){return new yn(.001,i,Math.max(24,Math.ceil(i*.7)),Math.max(2,Math.ceil(i/3)))}function Ls(i,t,e){return new Xt(i,t,e,Math.max(1,Math.ceil(i/2)),1,Math.max(1,Math.ceil(e/2)))}function It(i,t,e=0,n=0,s=0,{cast:r=!0,receive:o=!0}={}){let a=new nt(i,t);return a.position.set(e,n,s),a.castShadow=r,a.receiveShadow=o,a}var xl=class{constructor(t,e,n,s){this.scene=t,this.venue=e,this.biome=vu[e.biome]||vu.temperate,this.rand=Is(e.id),this.group=new Qt,this.colliders={circles:[],rects:[]},this.anim=[],this.quality=n,t.add(this.group),this.renderer=s,this.water=null,this.buildLights(),this.buildGround(),this.buildPlaza(),this.buildGolf(),this.buildLake(),this.buildPavilion(),this.buildNature(),this.buildEnvironment()}buildLights(){let t=this.biome,e=Cr.degToRad(90-t.elev),n=Cr.degToRad(215);this.sunDir=new P().setFromSphericalCoords(1,e,n);let s=new wt(16773596).lerp(new wt(16756848),Cr.clamp((30-t.elev)/30,0,1)),r=new al(13624319,5919286,.35),o=new ll(s,3*t.sun);o.castShadow=this.quality.shadows;let a=this.quality.shadowMap;o.shadow.mapSize.set(a,a);let l=o.shadow.camera;l.left=l.bottom=-26,l.right=l.top=26,l.near=1,l.far=160,o.shadow.bias=-4e-4,o.shadow.normalBias=.04,this.sun=o,this.group.add(r,o,o.target)}buildEnvironment(){let t=this.biome,e=new kr;e.scale.setScalar(4e3);let n=e.material.uniforms;if(n.turbidity.value=t.turb*.55,n.rayleigh.value=t.elev<20?3:2.6,n.mieCoefficient.value=.003,n.mieDirectionalG.value=.8,n.sunPosition.value.copy(this.sunDir),this.scene.add(e),this.sky=e,this.renderer){let r=new wr(this.renderer),o=new Sr,a=new kr;a.scale.setScalar(4e3);for(let l in n)a.material.uniforms[l].value=n[l].value;o.add(a),this.scene.environment=r.fromScene(o,0,1,5e3).texture,this.scene.environmentIntensity=.75,r.dispose()}let s=new wt(13228262).lerp(new wt(15259840),t.turb/12);this.scene.fog=new Xa(s,70,330)}follow(t){this.sun.position.set(t.x+this.sunDir.x*80,this.sunDir.y*80,t.z+this.sunDir.z*80),this.sun.target.position.set(t.x,0,t.z)}buildGround(){let{islandR:t}=jt,e=this.biome,n=It(new yn(.001,t,96,40),kt("grass",e.tint),0,0,0,{cast:!1});n.rotation.x=-Math.PI/2,this.group.add(n);let s=new sn(1,20),r=Pt(e.patch,{roughness:.9});r.polygonOffset=!0,r.polygonOffsetFactor=-1;let o=new cn(s,r,e.snow?70:0),a=new qt,l=new Re().setFromEuler(new gn(-Math.PI/2,0,0));for(let m=0;m<70;m++){let x=this.rand()*Math.PI*2,g=15+this.rand()*110,p=3+this.rand()*9;a.compose(new P(Math.cos(x)*g,.01,Math.sin(x)*g),l,new P(p,p*(.6+this.rand()*.6),1)),o.setMatrixAt(m,a)}o.receiveShadow=!0,this.group.add(o);let c=It(new yn(t-1,t+9,96,3),kt("sand"),0,-.02,0,{cast:!1});c.rotation.x=-Math.PI/2;let h=new ye({color:e.water,roughness:.12,metalness:.1,normalMap:Di("water").normal,normalScale:new rt(.4,.4)});h.normalMap.repeat.set(60,60);let u=It(new yn(.001,900,64,40),kn(h),0,-.3,0,{cast:!1});u.rotation.x=-Math.PI/2,this.anim.push(m=>{h.normalMap.offset.set(m*.004,m*.003)}),this.group.add(c,u);let d=kt("dirt");d.polygonOffset=!0,d.polygonOffsetFactor=-2,this.paths=[];let f=(m,x,g,p,M=3)=>{let v=Math.hypot(g-m,p-x),y=It(new Ln(M,v,1,Math.ceil(v/2)),d,(m+g)/2,.02,(x+p)/2,{cast:!1});y.rotation.x=-Math.PI/2,y.rotation.z=Math.atan2(g-m,p-x),this.group.add(y),this.paths.push({x0:m,z0:x,x1:g,z1:p,w:M})};f(9,0,44,0),f(-9,0,-37,0),f(0,-9,0,-42.5),f(0,9,0,30,2.4)}buildPlaza(){let t=kt("paving"),e=It(gl(10),t,0,.05,0,{cast:!1});e.rotation.x=-Math.PI/2,this.group.add(e);let n=It(new Ts(10,.22,8,64),kt("concrete",11906722),0,.08,0);n.rotation.x=Math.PI/2,this.group.add(n);let s=It(new zt(2.4,2.6,.6,40),kt("concrete",14210252),0,.3,0),r=It(new zt(2.1,2.1,.05,40),Pt(4029839,{roughness:.05,metalness:.2}),0,.58,0,{cast:!1}),o=It(new zt(.3,.45,1.6,24),kt("concrete",14210252),0,1.2,0),a=It(new zt(.9,.4,.3,32),kt("concrete",14210252),0,2,0),l=It(new Ce(.45,20,14),Pt(15136511,{transparent:!0,opacity:.45,roughness:.05}),0,2.4,0,{cast:!1});this.group.add(s,r,o,a,l),this.anim.push(f=>{l.scale.set(1,1+Math.sin(f*4)*.25,1),l.position.y=2.4+Math.sin(f*4)*.08}),this.colliders.circles.push({x:0,z:0,r:2.8});let c=kt("wood",14267276),h=Pt(2829616,{metalness:.8,roughness:.45});for(let f=0;f<8;f++){let m=f/8*Math.PI*2+Math.PI/8,x=Math.cos(m)*7.5,g=Math.sin(m)*7.5,p=new Qt;p.add(It(new Xt(1.8,.12,.5),c,0,.45,0)),p.add(It(new Xt(1.8,.4,.1),c,0,.75,-.22)),p.add(It(new Xt(.1,.45,.45),h,-.8,.22,0),It(new Xt(.1,.45,.45),h,.8,.22,0)),p.position.set(x,0,g),p.rotation.y=-m-Math.PI/2,this.group.add(p),this.colliders.circles.push({x,z:g,r:.9});let M=m,v=Math.cos(M)*9.3,y=Math.sin(M)*9.3;this.group.add(It(new zt(.06,.09,2.6,12),h,v,1.3,y)),this.group.add(It(new Ce(.22,16,12),Pt(16774877,{emissive:16769696,emissiveIntensity:.6,roughness:.2}),v,2.7,y,{cast:!1}))}let u=[12607551,7311226,11569754,6258586];[[-14,18],[14,18],[-22,6],[22,6]].forEach(([f,m],x)=>{let g=new Qt;g.add(It(new Xt(4,2.6,3.6),kt("plaster"),0,1.3,0));let p=It(new ui(3.4,1.9,4),kt("roof",u[x]),0,3.55,0);p.rotation.y=Math.PI/4,g.add(p),g.add(It(new Xt(.9,1.5,.1),kt("wood",8016438),0,.75,-1.82)),g.add(It(new Xt(.7,.6,.1),Pt(1911347,{roughness:.05,metalness:.9}),1.2,1.5,-1.82),It(new Xt(.7,.6,.1),Pt(1911347,{roughness:.05,metalness:.9}),-1.2,1.5,-1.82)),g.position.set(f,0,m),g.rotation.y=Math.atan2(f,m),this.group.add(g),this.colliders.circles.push({x:f,z:m,r:2.8})});let d=[["\u26F3",12,2.2,16769126],["\u{1F3A3}",-12,2.2,7651580],["\u{1F3B1}",2.2,-12,11638780]];for(let[f,m,x,g]of d){this.group.add(It(new zt(.07,.08,2,10),kt("wood",9068608),m,1,x));let p=this.emojiBoard(f,g);p.position.set(m,2.1,x),p.rotation.y=Math.atan2(-m,-x)+Math.PI,this.group.add(p)}}emojiBoard(t,e){let n=document.createElement("canvas");n.width=128,n.height=128;let s=n.getContext("2d");s.fillStyle="#"+e.toString(16).padStart(6,"0"),s.beginPath(),s.roundRect(4,4,120,120,24),s.fill(),s.font="80px serif",s.textAlign="center",s.textBaseline="middle",s.fillText(t,64,70);let r=new nn(n);return r.colorSpace=me,It(new Ln(1.1,1.1),kn(new ke({map:r,side:Te})),0,0,0,{cast:!1})}buildGolf(){let t=jt.green,e=t.x1-t.x0,n=t.z1-t.z0,s=(t.x0+t.x1)/2,r=(t.z0+t.z1)/2;this.group.add(It(Ls(e+3,.08,n+3),kt("grass",13164712),s,.04,r,{cast:!1}));let o=kt("green",16777215),a=kt("green",13821636),l=8;for(let y=0;y<l;y++)this.group.add(It(Ls(e/l,t.y,n),y%2?o:a,t.x0+(y+.5)*(e/l),t.y/2,r,{cast:!1}));let c=kt("wood",13279866),h=.22,u=.25;this.group.add(It(Ls(e+u*2,h,u),c,s,t.y+h/2,t.z0-u/2)),this.group.add(It(Ls(e+u*2,h,u),c,s,t.y+h/2,t.z1+u/2)),this.group.add(It(Ls(u,h,n),c,t.x0-u/2,t.y+h/2,r)),this.group.add(It(Ls(u,h,n),c,t.x1+u/2,t.y+h/2,r));let d=this.rand;this.golf={holes:[],obstacles:[],tee:{x:t.x0+2.2,z:r}};for(let y=0;y<3;y++)this.golf.holes.push({x:t.x1-2.5-d()*6,z:t.z0+2+d()*(n-4)});let f=kt("wood",10253394),m=kt("rock"),x=3+Math.floor(d()*3);for(let y=0;y<x;y++){let w=t.x0+8+d()*(e-16),S=t.z0+1.5+d()*(n-3);if(d()<.5){let R=.6+d()*.6;this.golf.obstacles.push({kind:"circle",x:w,z:S,r:R});let _=It(new wo(R,0),m,w,t.y+R*.45,S);_.scale.y=.6,this.group.add(_)}else{let R=.3+d()*1.5,_=.3+d()*.3,b=d()<.5,C=b?_:R,L=b?R:_;this.golf.obstacles.push({kind:"rect",x0:w-C,x1:w+C,z0:S-L,z1:S+L}),this.group.add(It(new Xt(C*2,.3,L*2),f,w,t.y+.15,S))}}this.cup=It(new sn(.16,20),new ke({color:1710618}),0,t.y+.003,0,{cast:!1}),this.cup.rotation.x=-Math.PI/2,kn(this.cup.material);let g=new Qt;g.add(It(new zt(.02,.02,1.8,8),Pt(15921906,{metalness:.6,roughness:.3}),0,.9,0));let p=It(new Ln(.6,.4,6,1),kt("fabric",14100029,{side:Te}),.3,1.6,0);g.add(p),this.anim.push(y=>{p.rotation.y=Math.sin(y*3)*.25}),this.flag=g,this.group.add(this.cup,g),this.setHole(0);let M=It(new zt(.06,.06,.04,10),Pt(16777215),this.golf.tee.x,t.y+.01,this.golf.tee.z,{cast:!1});this.group.add(M);let v=new Qt;v.add(It(new Xt(1.4,.6,2.2),Pt(16053488,{roughness:.25,metalness:.1}),0,.6,0)),v.add(It(new Xt(1.5,.08,1.6),kt("fabric",3104070),0,1.9,.1));for(let[y,w]of[[-.6,-.8],[.6,-.8],[-.6,.8],[.6,.8]]){let S=It(new zt(.28,.28,.2,20),Pt(1842204,{roughness:.9}),y,.28,w);S.rotation.z=Math.PI/2,v.add(S)}v.add(It(new zt(.04,.04,1.3,6),Pt(13421772,{metalness:.9,roughness:.3}),-.65,1.25,.8),It(new zt(.04,.04,1.3,6),Pt(13421772,{metalness:.9,roughness:.3}),.65,1.25,.8)),v.position.set(41,0,-5),v.rotation.y=.4,this.group.add(v),this.colliders.circles.push({x:41,z:-5,r:1.4})}setHole(t){let e=this.golf.holes[t%this.golf.holes.length];this.cup.position.set(e.x,jt.green.y+.003,e.z),this.flag.position.set(e.x,jt.green.y,e.z)}buildLake(){let t=jt.lake,e=jt.pier,n=It(gl(t.r+2.5),kt("sand",14272928),t.x,.015,t.z,{cast:!1});n.rotation.x=-Math.PI/2;let s;if(this.quality.reflect){s=new ml(gl(t.r),{textureWidth:512,textureHeight:512,waterNormals:Di("water").normal,sunDirection:this.sunDir.clone(),sunColor:16774368,waterColor:new wt(this.biome.water).multiplyScalar(.6),distortionScale:3.2,alpha:.95,fog:!0}),s.material.uniforms.size.value=6,s.position.set(t.x,.05,t.z),this.noReflect=[];let f=s.onBeforeRender.bind(s);s.onBeforeRender=(...m)=>{for(let x of this.noReflect)x.visible=!1;f(...m);for(let x of this.noReflect)x.visible=!0},this.anim.push((m,x)=>{s.material.uniforms.time.value+=x*.6})}else{let f=new ye({color:this.biome.water,roughness:.06,metalness:.15,normalMap:Di("water").normal,normalScale:new rt(.35,.35)});f.normalMap=f.normalMap.clone(),f.normalMap.repeat.set(8,8),s=It(gl(t.r),kn(f),t.x,.05,t.z,{cast:!1}),this.anim.push(m=>{f.normalMap.offset.set(m*.01,m*.007)})}s.rotation.x=-Math.PI/2,s.receiveShadow=!0,this.water=s,this.group.add(n,s);let r=new qt,o=new sn(.7,10,.3,Math.PI*1.8),a=new cn(o,kt("leaves",9416816),14);for(let f=0;f<14;f++){let m=this.rand()*Math.PI*2,x=t.r-2-this.rand()*5;r.compose(new P(t.x+Math.cos(m)*x,.07,t.z+Math.sin(m)*x),new Re().setFromEuler(new gn(-Math.PI/2,0,this.rand()*6)),new P(1,1,1)),a.setMatrixAt(f,r)}this.group.add(a);let l=kt("wood",12096114),c=kt("bark",7034436),h=e.x1-e.x0;for(let f=0;f<Math.floor(h/.6);f++)this.group.add(It(new Xt(.52,.1,e.hw*2),f%2?l:kt("wood",11042910),e.x0+.3+f*.6,e.y-.05,0));for(let f=e.x0+.3;f<e.x1;f+=3)for(let m of[-e.hw,e.hw])this.group.add(It(new zt(.12,.12,1.2,8),c,f,e.y-.5,m));let u=new Qt,d=It(new zt(.9,.6,.5,10,1,!1,0,Math.PI),kt("wood",11880494),0,0,0);d.rotation.set(Math.PI/2,0,Math.PI/2),d.scale.set(1,2.2,1),u.add(d),u.position.set(t.x+8,.25,t.z+9),this.anim.push(f=>{u.position.y=.25+Math.sin(f*1.2)*.05,u.rotation.z=Math.sin(f)*.04}),this.group.add(u)}buildPavilion(){let t=jt.pavilion,e=jt.table,n=kt("wood",4861468);this.group.add(It(Ls(t.hw*2,t.y,t.hd*2),kt("wood",14729370),t.x,t.y/2,t.z,{cast:!1}));for(let[r,o]of[[-1,-1],[1,-1],[-1,1],[1,1]]){let a=t.x+r*(t.hw-.4),l=t.z+o*(t.hd-.4);this.group.add(It(new zt(.2,.24,3.6,20),kt("plaster"),a,t.y+1.8,l)),this.colliders.circles.push({x:a,z:l,r:.45})}let s=It(new ui(Math.hypot(t.hw,t.hd)+.8,2.2,4),kt("roof",6122365),t.x,t.y+4.7,t.z);s.rotation.y=Math.PI/4,s.scale.z=t.hd/t.hw,this.group.add(s),this.pavilionRoof=s,this.lamp=new Qt,this.lamp.add(It(new zt(.01,.01,1.4,4),Pt(2236962,{metalness:.8}),e.x,t.y+3.1,e.z,{cast:!1})),this.lamp.add(It(new ui(.6,.4,32,1,!0),Pt(2051374,{side:Te,metalness:.7,roughness:.35,emissive:3353104}),e.x,t.y+2.3,e.z,{cast:!1})),this.group.add(this.lamp),this.colliders.rects.push({x0:e.x-1.95,x1:e.x+1.95,z0:e.z-1.2,z1:e.z+1.2})}buildNature(){let t=this.biome.tree,e=(w,S)=>Math.hypot(w,S)<14||Math.hypot(w-jt.lake.x,S-jt.lake.z)<jt.lake.r+5||w>38&&w<82&&Math.abs(S)<14||Math.abs(w)<10&&S<-38&&S>-58||Math.abs(S)<3.5||Math.abs(w)<3.5||Math.hypot(Math.abs(w)-18,S-12)<9,n=[],s=0,r=t==="none"?0:this.quality.trees;for(;n.length<r&&s++<r*20;){let w=this.rand()*Math.PI*2,S=14+Math.sqrt(this.rand())*115,T=Math.cos(w)*S,R=Math.sin(w)*S;e(T,R)||n.push([T,R,.8+this.rand()*.6])}let o=kt("bark"),a={round:14217408,pine:10467482,palm:14742960,acacia:15262368},l=kt("leaves",16777215),c,h,u,d,f=(w,S)=>{let T=w.attributes.position,R=new P;for(let _=0;_<T.count;_++){R.fromBufferAttribute(T,_);let b=Math.sin(R.x*3.1+R.y*1.7)*Math.cos(R.z*2.3-R.y)*S;R.multiplyScalar(1+b),T.setXYZ(_,R.x,R.y,R.z)}return w.computeVertexNormals(),w};if(t==="pine"?(d=1.4,c=new zt(.13,.24,d,10),h=yu([0,1,2,3].map(w=>f(new ui(1.6-w*.32,1.7,14,3).translate(0,w*.95,0),.08))),u=2):t==="palm"?(d=4,c=new zt(.12,.2,d,6),h=new ui(1.8,.7,7),u=4.1):t==="acacia"?(d=2.4,c=new zt(.12,.18,d,6),h=new zt(2,1.6,.6,10),u=2.6):(d=1.8,c=new zt(.14,.26,d,10),h=yu([[0,0,0,1.3],[.8,-.3,.3,.9],[-.7,-.2,-.4,.95],[.1,.6,-.5,.85],[-.3,-.4,.8,.8]].map(([w,S,T,R])=>f(new Es(R,2),.1).translate(w,S,T))),u=2.7),c.translate(0,d/2,0),h.translate(0,u,0),n.length){let w=new cn(c,o,n.length),S=new cn(h,l,n.length),T=new qt,R=new Re,_=new wt;n.forEach(([b,C,L],k)=>{R.setFromAxisAngle(new P(0,1,0),this.rand()*6.28),T.compose(new P(b,0,C),R,new P(L,L,L)),w.setMatrixAt(k,T),S.setMatrixAt(k,T),S.setColorAt(k,_.set(l.color).offsetHSL((this.rand()-.5)*.06,0,(this.rand()-.5)*.12)),this.colliders.circles.push({x:b,z:C,r:.45*L})});for(let b of[w,S])b.castShadow=!0,b.receiveShadow=!0,this.group.add(b)}let m=new Es(.16,0),x=new cn(m,Pt(16777215,{roughness:.7}),this.quality.flowers),g=[16748459,16765286,16777215,13481179,16739179,10221311],p=new qt,M=new wt,v=0;for(;v<this.quality.flowers;){let w=this.rand()*Math.PI*2,S=11+this.rand()*110,T=Math.cos(w)*S,R=Math.sin(w)*S;if(e(T,R)&&Math.hypot(T,R)>11)continue;let _=g[Math.floor(this.rand()*g.length)];for(let b=0;b<8&&v<this.quality.flowers;b++,v++){let C=T+(this.rand()-.5)*3,L=R+(this.rand()-.5)*3;p.makeTranslation(C,.16,L),x.setMatrixAt(v,p),x.setColorAt(v,M.set(_))}}this.group.add(x);let y=new cn(new wo(.6,1),kt("rock"),30);for(let w=0;w<30;w++){let S=this.rand()*Math.PI*2,T=20+this.rand()*110,R=.5+this.rand()*1.5;p.compose(new P(Math.cos(S)*T,.1,Math.sin(S)*T),new Re().setFromEuler(new gn(this.rand(),this.rand()*6,0)),new P(R,R*.6,R)),y.setMatrixAt(w,p)}y.castShadow=!0,this.group.add(y)}isGrass(t,e){let n=Math.hypot(t,e);if(n<10.6||n>jt.islandR-1.5)return!1;let s=jt.lake;if(Math.hypot(t-s.x,e-s.z)<s.r+2.8)return!1;let r=jt.green;if(t>r.x0-2&&t<r.x1+2&&e>r.z0-2&&e<r.z1+2)return!1;let o=jt.pavilion;if(Math.abs(t-o.x)<o.hw+.3&&Math.abs(e-o.z)<o.hd+.3)return!1;for(let a of this.paths){let l=a.x1-a.x0,c=a.z1-a.z0,h=l*l+c*c,u=Math.max(0,Math.min(1,((t-a.x0)*l+(e-a.z0)*c)/h));if(Math.hypot(t-a.x0-l*u,e-a.z0-c*u)<a.w/2+.15)return!1}for(let a of this.colliders.circles)if(a.r>1&&Math.hypot(t-a.x,e-a.z)<a.r)return!1;return!0}groundHeight(t,e){let n=jt.pier,s=jt.green,r=jt.pavilion;return t>=n.x0&&t<=n.x1+.5&&Math.abs(e)<=n.hw?n.y:t>=s.x0&&t<=s.x1&&e>=s.z0&&e<=s.z1?s.y:Math.abs(t-r.x)<=r.hw&&Math.abs(e-r.z)<=r.hd?r.y:0}resolve(t){let n=jt.lake,s=jt.pier;if(t.x>=s.x0&&t.x<=s.x1+.5&&Math.abs(t.z)<=s.hw-.2)t.z=Math.max(-s.hw+.3,Math.min(s.hw-.3,t.z)),t.x=Math.max(s.x0+.3,t.x);else{let l=t.x-n.x,c=t.z-n.z,h=Math.hypot(l,c);h<n.r+.35&&(t.x=n.x+l/h*(n.r+.35),t.z=n.z+c/h*(n.r+.35))}for(let l of this.colliders.circles){let c=t.x-l.x,h=t.z-l.z,u=l.r+.35,d=c*c+h*h;if(d<u*u&&d>1e-6){let f=Math.sqrt(d);t.x=l.x+c/f*u,t.z=l.z+h/f*u}}for(let l of this.colliders.rects)if(t.x>l.x0&&t.x<l.x1&&t.z>l.z0&&t.z<l.z1){let c=[[t.x-l.x0,"x",l.x0],[l.x1-t.x,"x",l.x1],[t.z-l.z0,"z",l.z0],[l.z1-t.z,"z",l.z1]];c.sort((h,u)=>h[0]-u[0]),t[c[0][1]]=c[0][2]}let o=Math.hypot(t.x,t.z),a=jt.islandR-2;o>a&&(t.x*=a/o,t.z*=a/o)}update(t,e){for(let n of this.anim)n(t,e)}dispose(){this.scene.remove(this.group),this.group.traverse(t=>{t.geometry&&t.geometry.dispose()})}};var fi={body:new ti(.26,.32,4,12),head:new Ce(.44,18,14),eye:new ti(.045,.06,2,8),cheek:new sn(.06,10),hair:new Ce(.46,18,10,0,Math.PI*2,0,Math.PI*.55),arm:new ti(.075,.22,2,8).translate(0,-.15,0),leg:new ti(.09,.16,2,8)},P_=new ke({color:2827296}),up=new ke({color:16751266,transparent:!0,opacity:.7}),dp=[5978665,3023904,15254138,12605498,9072593,4026294];function I_(i){return kt("fabric",i)}function bu(i,{bg:t="rgba(0,0,0,0.55)",fg:e="#fff",size:n=28,maxW:s=420}={}){let r=document.createElement("canvas"),o=r.getContext("2d"),a=`600 ${n}px system-ui, -apple-system, "Segoe UI", "Noto Sans KR", sans-serif`;o.font=a;let l=String(i).split(/(\s+)/),c=[],h="";for(let y of l){let w=h+y;o.measureText(w).width>s&&h?(c.push(h.trim()),h=y):h=w}h.trim()&&c.push(h.trim());let u=[];for(let y of c){let w="";for(let S of y)o.measureText(w+S).width>s?(u.push(w),w=S):w+=S;u.push(w)}let d=u.slice(0,3),f=Math.min(s,Math.max(...d.map(y=>o.measureText(y).width)))+28,m=n*1.25,x=d.length*m+16;r.width=Math.ceil(f),r.height=Math.ceil(x),o.font=a,o.fillStyle=t;let g=14;o.beginPath(),o.roundRect(0,0,r.width,r.height,g),o.fill(),o.fillStyle=e,o.textBaseline="middle",o.textAlign="center",d.forEach((y,w)=>o.fillText(y,r.width/2,8+m*(w+.5)));let p=new nn(r);p.colorSpace=me,p.minFilter=Vn,p.generateMipmaps=!1;let M=new Za(new yo({map:p,depthWrite:!1,transparent:!0})),v=.0085;return M.scale.set(r.width*v,r.height*v,1),M.renderOrder=10,M}function Io(i){i.material.map.dispose(),i.material.dispose()}var Lo=class{constructor({name:t,color:e,flag:n=""}){this.root=new Qt;let s=new Qt;this.body=s,this.root.add(s);let r=I_(e),o=0;for(let p of String(t))o=o*31+p.charCodeAt(0)>>>0;let a=Pt([16769220,16107936,14263418,11039052,8015411][o%5],{roughness:.55}),l=Pt(dp[(o>>>3)%dp.length],{roughness:.45}),c=kt("fabric",4016742),h=new nt(fi.body,r);h.position.y=.62,h.castShadow=!0;let u=new nt(fi.head,a);u.position.y=1.28,u.scale.set(1,.94,.96),u.castShadow=!0;let d=new nt(fi.hair,l);d.position.set(0,1.33,-.03),d.rotation.x=-.25;let f=new nt(fi.eye,P_);f.position.set(-.15,1.27,.4);let m=f.clone();m.position.x=.15;let x=new nt(fi.cheek,up);x.position.set(-.26,1.16,.36),x.rotation.y=-.5;let g=new nt(fi.cheek,up);g.position.set(.26,1.16,.36),g.rotation.y=.5,this.armL=new nt(fi.arm,r),this.armL.position.set(-.32,.83,0),this.armL.rotation.z=-.3,this.armR=new nt(fi.arm,r),this.armR.position.set(.32,.83,0),this.armR.rotation.z=.3,this.legL=new nt(fi.leg,c),this.legL.position.set(-.12,.2,0),this.legR=new nt(fi.leg,c),this.legR.position.set(.12,.2,0);for(let p of[this.legL,this.legR,this.armL,this.armR])p.castShadow=!0;s.add(h,u,d,f,m,x,g,this.armL,this.armR,this.legL,this.legR),this.blinkT=2+Math.random()*3,this.eyes=[f,m],this.tag=bu(`${n?n+" ":""}${t}`,{size:26}),this.tag.position.y=2.05,this.root.add(this.tag),this.bubble=null,this.bubbleUntil=0,this.walk=0,this.prop=null}setName(t,e=""){this.root.remove(this.tag),Io(this.tag),this.tag=bu(`${e?e+" ":""}${t}`,{size:26}),this.tag.position.y=2.05,this.root.add(this.tag)}say(t,e){this.bubble&&(this.root.remove(this.bubble),Io(this.bubble)),this.bubble=bu(t,{bg:"rgba(255,255,255,0.95)",fg:"#1b1f2a",size:26,maxW:380}),this.bubble.position.y=2.4+this.bubble.scale.y/2,this.root.add(this.bubble),this.bubbleUntil=e+6e3}setProp(t){this.prop&&this.armR.remove(this.prop),this.prop=null,t&&(this.prop=new Qt,this.prop.position.y=-.15,this.prop.add(t),this.armR.add(this.prop))}animate(t,e,n){e>.2?this.walk+=t*(4+e*1.6):this.walk*=Math.pow(.001,t);let s=Math.sin(this.walk)*Math.min(1,e/3);this.legL.rotation.x=s*.7,this.legR.rotation.x=-s*.7,this.armL.rotation.x=-s*.6,this.prop||(this.armR.rotation.x=s*.6),this.blinkT-=t;let r=this.blinkT<.12?.15:1;if(this.blinkT<0&&(this.blinkT=2+Math.random()*4),this.eyes[0].scale.y=this.eyes[1].scale.y=r,this.body.position.y=Math.abs(Math.sin(this.walk))*.05*Math.min(1,e/3),this.armLOverride!=null&&(this.armL.rotation.x=this.armLOverride),this.swingPose!=null){let o=this.swingPose,a=Math.max(0,-o),l=Math.max(0,o);this.body.rotation.y=-a*1.15+l*1.45;let c=.45+a*2.4+l*2.2;this.armR.rotation.x=this.armL.rotation.x=-c,this.armR.rotation.z=-.32,this.armL.rotation.z=.32,this.legL.rotation.x=this.legR.rotation.x=0,this.legR.rotation.z=l*.18}else this.body.rotation.y&&(this.body.rotation.y=0,this.armR.rotation.z=.3,this.armL.rotation.z=-.3,this.legR.rotation.z=0);this.bubble&&n>this.bubbleUntil&&(this.root.remove(this.bubble),Io(this.bubble),this.bubble=null)}curveFix(t,e){let n=this.root.position.x-t.x,s=this.root.position.z-t.z,r=(n*n+s*s)*e;this.tag.position.y=2.05-r,this.bubble&&(this.bubble.position.y=2.4+this.bubble.scale.y/2-r)}dispose(){Io(this.tag),this.bubble&&Io(this.bubble)}};var pt={keys:new Set,move:{x:0,y:0},lookDX:0,lookDY:0,orbitDX:0,orbitDY:0,zoomMul:1,power:!1,touch:matchMedia("(pointer: coarse)").matches,pointer:{x:0,y:0,down:!1,moved:!1,startX:0,startY:0,downAt:0}},fp={action:[],powerDown:[],powerUp:[],pointerDown:[],pointerUp:[]};function ks(i,t){fp[i].push(t)}var Ui=i=>fp[i].forEach(t=>t());function L_(){let i=document.activeElement;return i&&(i.tagName==="INPUT"||i.tagName==="TEXTAREA"||i.tagName==="SELECT")}function _u(i,t){let e=t.getBoundingClientRect();pt.pointer.x=(i.clientX-e.left)/e.width*2-1,pt.pointer.y=-((i.clientY-e.top)/e.height)*2+1}function pp(i){addEventListener("keydown",p=>{if(!L_()){if(p.code==="Space"){p.preventDefault(),pt.power||(pt.power=!0,Ui("powerDown"));return}p.code==="KeyE"&&!p.repeat&&Ui("action"),pt.keys.add(p.code)}}),addEventListener("keyup",p=>{if(p.code==="Space"){pt.power&&(pt.power=!1,Ui("powerUp"));return}pt.keys.delete(p.code)}),addEventListener("blur",()=>{pt.keys.clear(),pt.power&&(pt.power=!1,Ui("powerUp"))}),i.addEventListener("contextmenu",p=>p.preventDefault());let t=null,e=new Map,n=()=>{let[p,M]=[...e.values()];return{x:(p.x+M.x)/2,y:(p.y+M.y)/2,d:Math.hypot(p.x-M.x,p.y-M.y)}},s=null,r=null;i.addEventListener("pointerdown",p=>{if(p.pointerType==="mouse"&&p.button===2){t={id:p.pointerId,x:p.clientX,y:p.clientY},i.setPointerCapture(p.pointerId);return}if(p.pointerType==="touch"){if(e.set(p.pointerId,{x:p.clientX,y:p.clientY}),e.size===2){s=n(),pt.pointer.down=!1;return}if(e.size>2)return}r||(r={id:p.pointerId,x:p.clientX,y:p.clientY},i.setPointerCapture(p.pointerId),_u(p,i),Object.assign(pt.pointer,{down:!0,moved:!1,startX:pt.pointer.x,startY:pt.pointer.y,downAt:performance.now()}),Ui("pointerDown"))}),i.addEventListener("pointermove",p=>{if(t&&p.pointerId===t.id){pt.orbitDX+=p.clientX-t.x,pt.orbitDY+=p.clientY-t.y,t.x=p.clientX,t.y=p.clientY;return}if(e.has(p.pointerId)){if(e.set(p.pointerId,{x:p.clientX,y:p.clientY}),s&&e.size>=2){let M=n();pt.orbitDX+=M.x-s.x,pt.orbitDY+=M.y-s.y,s.d>20&&M.d>20&&(pt.zoomMul*=s.d/M.d),s=M,r&&(r.x=p.clientX,r.y=p.clientY);return}if(s)return}if(!r){_u(p,i);return}p.pointerId===r.id&&(_u(p,i),pt.pointer.moved=!0,pt.lookDX+=p.clientX-r.x,pt.lookDY+=p.clientY-r.y,r.x=p.clientX,r.y=p.clientY)});let o=p=>{if(t&&p.pointerId===t.id){t=null;return}e.delete(p.pointerId),e.size===0&&(s=null),r&&p.pointerId===r.id&&(r=null,pt.pointer.down=!1,Ui("pointerUp"))};i.addEventListener("pointerup",o),i.addEventListener("pointercancel",o);let a=document.getElementById("joy"),l=a.querySelector(".knob"),c=null,h=0,u=0,d=46;a.addEventListener("pointerdown",p=>{c=p.pointerId,a.setPointerCapture(c);let M=a.getBoundingClientRect();h=M.left+M.width/2,u=M.top+M.height/2,f(p)});let f=p=>{if(p.pointerId!==c)return;let M=p.clientX-h,v=p.clientY-u,y=Math.hypot(M,v);y>d&&(M*=d/y,v*=d/y),l.style.transform=`translate(${M}px, ${v}px)`,pt.move.x=M/d,pt.move.y=-v/d};a.addEventListener("pointermove",f);let m=p=>{p.pointerId===c&&(c=null,l.style.transform="",pt.move.x=pt.move.y=0)};a.addEventListener("pointerup",m),a.addEventListener("pointercancel",m);let x=document.getElementById("btnPower");x.addEventListener("pointerdown",p=>{p.preventDefault(),x.setPointerCapture(p.pointerId),pt.power=!0,Ui("powerDown")});let g=()=>{pt.power&&(pt.power=!1,Ui("powerUp"))};x.addEventListener("pointerup",g),x.addEventListener("pointercancel",g),document.getElementById("btnAction").addEventListener("click",()=>Ui("action"))}function mp(){let i=pt.keys,t=pt.move.x,e=pt.move.y;(i.has("KeyW")||i.has("ArrowUp"))&&(e+=1),(i.has("KeyS")||i.has("ArrowDown"))&&(e-=1),(i.has("KeyA")||i.has("ArrowLeft"))&&(t-=1),(i.has("KeyD")||i.has("ArrowRight"))&&(t+=1);let n=Math.hypot(t,e);return n>1&&(t/=n,e/=n),{x:t,y:e,run:i.has("ShiftLeft")||n>.92}}function Dr(i){let t=pt.keys,e=0;return(t.has("ArrowLeft")||t.has("KeyA"))&&(e+=1.4*i),(t.has("ArrowRight")||t.has("KeyD"))&&(e-=1.4*i),t.has("ShiftLeft")&&(e*=.25),e}function gp(){let i={x:pt.orbitDX,y:pt.orbitDY,zoom:pt.zoomMul};return pt.orbitDX=pt.orbitDY=0,pt.zoomMul=1,i}function es(){let i={x:pt.lookDX,y:pt.lookDY};return pt.lookDX=pt.lookDY=0,i}var yl=class{constructor(t){this.h=t,this.id=null,this.offline=!1,this.ws=null,this.lastSent=0,this.lastState=""}connect(t,e,n,s){this.profile=t,this.venue=e;let r=`${n.replace(/^http/,"ws")}/ws?room=${encodeURIComponent(e.id)}&token=${encodeURIComponent(s||"")}`;try{this.ws=new WebSocket(r)}catch{return this.goOffline()}let o=setTimeout(()=>{this.id===null&&(this.ws.onclose=null,this.ws.close(),this.goOffline())},9e3);this.ws.onopen=()=>this.send({t:"hello",color:t.color}),this.ws.onmessage=a=>{if(this.offline)return;let l;try{l=JSON.parse(a.data)}catch{return}l.t==="welcome"&&(clearTimeout(o),this.id=l.id),this.h.message(l)},this.ws.onclose=a=>{var l,c;clearTimeout(o),this.id===null&&!this.offline?this.goOffline():this.offline||(c=(l=this.h).disconnected)==null||c.call(l,a.code)},this.ws.onerror=()=>{},this._ping=setInterval(()=>{var a;((a=this.ws)==null?void 0:a.readyState)===1&&this.ws.send('{"t":"ping"}')},3e4)}close(){this.ws&&(this.ws.onclose=null,this.ws.close()),clearInterval(this._ping),this.id=null,this.offline=!1}send(t){var e;if(this.offline)return this.offlineSend(t);((e=this.ws)==null?void 0:e.readyState)===1&&this.ws.send(JSON.stringify(t))}state(t,e){if(e-this.lastSent<100)return;let n=JSON.stringify(t);n===this.lastState&&e-this.lastSent<1e3||(this.lastSent=e,this.lastState=n,this.send({t:"state",s:t}))}chat(t){this.send({t:"chat",text:t})}event(t){this.send({t:"event",e:t})}goOffline(){this.offline=!0,this.id=0,this.parties={},this.h.message({t:"welcome",id:0,offline:!0,room:"offline",players:[],parties:[]})}offlineSend(t){if(t.t==="chat")this.h.message({t:"chat",id:Math.random(),from:0,name:this.profile.name,lang:this.profile.lang,text:t.text});else if(t.t==="event")this.h.message({t:"event",from:0,name:this.profile.name,e:t.e});else if(t.t.startsWith("party_")){let e=this.parties[t.game]||(this.parties[t.game]={slots:[],state:null});if(t.t==="party_join"){if(e.slots.length>=(t.game==="golf"?8:4))return this.h.message({t:"sys",key:"partyFull"});if(!t.guest&&e.slots.some(n=>!n.guest))return;e.slots.push({owner:0,name:t.guest||this.profile.name,guest:!!t.guest})}else if(t.t==="party_leave")e.slots=Number.isInteger(t.slot)?e.slots.filter((n,s)=>s!==t.slot):[],e.slots.length||(e.state=null);else if(t.t==="party_state")e.state=t.state;else return;this.h.message({t:"party",game:t.game,slots:e.slots,state:e.state})}}};var Mu={ko:{title:"\uD0DC\uC77C\uACE8\uD504 \uB77C\uC6B4\uC9C0",subtitle:"\uD68C\uC6D0\uB07C\uB9AC \uACE8\uD504\xB7\uB09A\uC2DC\xB7\uB2F9\uAD6C",name:"\uB2C9\uB124\uC784",lang:"\uC5B8\uC5B4",color:"\uCE90\uB9AD\uD130 \uC0C9\uC0C1",start:"\uC785\uC7A5\uD558\uAE30",online:"\uC628\uB77C\uC778",offline:"\uD63C\uC790 \uC5F0\uC2B5 \uBAA8\uB4DC",players:"\uBA85 \uC811\uC18D \uC911",chatPh:"\uBA54\uC2DC\uC9C0 \uC785\uB825",send:"\uC804\uC1A1",golf:"\uACE8\uD504",fishing:"\uB09A\uC2DC",billiards:"\uB2F9\uAD6C",play:"\uC2DC\uC791",exit:"\uB098\uAC00\uAE30",globe:"\uC9C0\uAD6C\uBCF8",golfHelp:"\uC88C\uC6B0 \uB4DC\uB798\uADF8/\u2190\u2192 \uC870\uC900 \xB7 \uAE38\uAC8C \uB20C\uB7EC \uD798 \uC870\uC808 \uD6C4 \uB193\uAE30",strokes:"\uD0C0\uC218",nStrokes:"{n}\uD0C0",sumTotal:"\uD569\uACC4",greenRead:"\uADF8\uB9B0 \uACBD\uC0AC",slopeUp:"\uC624\uB974\uB9C9",slopeDown:"\uB0B4\uB9AC\uB9C9",breakL:"\u2190 \uC67C\uCABD \uD728",breakR:"\uC624\uB978\uCABD \uD728 \u2192",flat:"\uD3C9\uC9C0",hole:"\uD640",sunk:"\uD640\uC778! {n}\uD0C0",fishHelp:"\uAE38\uAC8C \uB20C\uB7EC \uCE90\uC2A4\uD305 \xB7 \uC785\uC9C8 \uC624\uBA74 \uD0ED! \xB7 \uB20C\uB7EC\uC11C \uAC10\uACE0 \uD150\uC158 \uC720\uC9C0",cast:"\uCE90\uC2A4\uD305",waiting:"\uC785\uC9C8 \uAE30\uB2E4\uB9AC\uB294 \uC911\u2026",bite:"\uC785\uC9C8! \uC9C0\uAE08 \uD0ED!",reel:"\uAC10\uAE30",tension:"\uD150\uC158",distance:"\uAC70\uB9AC",snapped:"\uC904\uC774 \uB04A\uC5B4\uC84C\uC5B4\uC694",escaped:"\uBB3C\uACE0\uAE30\uAC00 \uB3C4\uB9DD\uAC14\uC5B4\uC694",missed:"\uB193\uCCE4\uC5B4\uC694",caught:"{fish} {kg}kg \uC7A1\uC558\uB2E4!",billHelp:"\uB4DC\uB798\uADF8/\u2190\u2192 \uC870\uC900 \xB7 \uAE38\uAC8C \uB20C\uB7EC \uD798 \uC870\uC808 \uD6C4 \uC0F7",yourTurn:"\uB0B4 \uCC28\uB840",waitTurn:"{name} \uCC28\uB840",potted:"\uD3EC\uCF13 {n}\uAC1C",rack:"\uB2E4\uC2DC \uBC30\uCE58",scratch:"\uC2A4\uD06C\uB798\uCE58!",power:"\uD798",evCatch:"{name}\uB2D8\uC774 {fish} {kg}kg\uC744 \uC7A1\uC558\uC5B4\uC694",evSink:"{name}\uB2D8\uC774 {hole}\uBC88 \uD640\uC744 {n}\uD0C0\uB85C \uB05D\uB0C8\uC5B4\uC694",evPot:"{name}\uB2D8\uC774 {n}\uBC88 \uACF5\uC744 \uB123\uC5C8\uC5B4\uC694",joined:"{name}\uB2D8\uC774 \uB4E4\uC5B4\uC654\uC5B4\uC694",left:"{name}\uB2D8\uC774 \uB098\uAC14\uC5B4\uC694",slowDown:"\uBA54\uC2DC\uC9C0\uB97C \uB108\uBB34 \uBE68\uB9AC \uBCF4\uB0B4\uACE0 \uC788\uC5B4\uC694",noTr:"\uBC88\uC5ED \uC11C\uBC84 \uBBF8\uC5F0\uACB0",translated:"\uBC88\uC5ED\uB428",showOrig:"\uC6D0\uBB38",venuePick:"\uD50C\uB808\uC774\uD560 \uC7A5\uC18C\uB97C \uACE0\uB974\uC138\uC694",venueGolf:"\uACE8\uD504\uC7A5",venueFish:"\uB09A\uC2DC\uD130",goVenue:"\uC774\uB3D9",backHub:"\uAD11\uC7A5\uC73C\uB85C",here:"\uD604\uC7AC \uC704\uCE58",quality:"\uD654\uC9C8",auto:"\uC790\uB3D9",party:"\uD30C\uD2F0",partyHint:"\uCD5C\uB300 {n}\uBA85 \xB7 \uAC19\uC740 \uAE30\uAE30\uC5D0\uC11C \uAC8C\uC2A4\uD2B8 \uCD94\uAC00 \uAC00\uB2A5",guest:"\uAC8C\uC2A4\uD2B8",me:"\uB098",emptySlot:"\uBE48 \uC790\uB9AC",joinParty:"\uCC38\uAC00",leaveParty:"\uD30C\uD2F0 \uB098\uAC00\uAE30",addGuest:"\uAC8C\uC2A4\uD2B8",startGame:"\uAC8C\uC784 \uC2DC\uC791",partyFull:"\uD30C\uD2F0\uAC00 \uAC00\uB4DD \uCC3C\uC5B4\uC694",screenGolf:"\uC2A4\uD06C\uB9B0 \uACE8\uD504",golf3:"3\uD640 \uB77C\uC6B4\uB4DC",golf1:"1\uBC88 \uD640",golf1b:"2\uBC88 \uD640 (\uD30C3)",scoreCard:"\uC2A4\uCF54\uC5B4\uCE74\uB4DC",player:"\uD50C\uB808\uC774\uC5B4",pinDist:"\uD540\uAE4C\uC9C0",wind:"\uBC14\uB78C",lie:"\uB77C\uC774",putter:"\uD37C\uD130",strokeN:"{n}\uBC88\uC9F8 \uC0F7",spectating:"\uAD00\uC804",lie_tee:"\uD2F0",lie_fairway:"\uD398\uC5B4\uC6E8\uC774",lie_rough:"\uB7EC\uD504",lie_bunker:"\uBC99\uCEE4",lie_green:"\uADF8\uB9B0",lie_fringe:"\uD504\uB9B0\uC9C0",lie_water:"\uC6CC\uD130 \uD574\uC800\uB4DC",lie_ob:"OB",shotData:"\uC0F7 \uB370\uC774\uD130",ballSpeed:"\uBCFC \uC2A4\uD53C\uB4DC",launchAngle:"\uBC1C\uC0AC\uAC01",backSpin:"\uBC31\uC2A4\uD540",sideSpin:"\uC0AC\uC774\uB4DC\uC2A4\uD540",apex:"\uCD5C\uACE0 \uB192\uC774",carry:"\uCE90\uB9AC",total:"\uCD1D\uAC70\uB9AC",penaltyWater:"\uD574\uC800\uB4DC! 1\uBC8C\uD0C0 \uD6C4 \uB4DC\uB86D",penaltyOB:"OB! 1\uBC8C\uD0C0, \uC6D0\uB798 \uC790\uB9AC\uC5D0\uC11C \uB2E4\uC2DC",pickup:"\uB354\uBE14\uD30C \xB7 \uD640\uC544\uC6C3",holeInOne:"\uD640\uC778\uC6D0!!",sc_m3:"\uC54C\uBC14\uD2B8\uB85C\uC2A4",sc_m2:"\uC774\uAE00",sc_m1:"\uBC84\uB514",sc_0:"\uD30C",sc_1:"\uBCF4\uAE30",sc_2:"\uB354\uBE14\uBCF4\uAE30",sc_3:"\uD2B8\uB9AC\uD50C+",fishHelp2:"\uC2A4\uD398\uC774\uC2A4 \uAE38\uAC8C \uB20C\uB7EC \uCE90\uC2A4\uD305 \xB7 \uCC0C\uAC00 \uC465 \uC7A0\uAE30\uBA74 \uD0ED(\uCC54\uC9C8) \xB7 \uD30C\uC774\uD305: \uB204\uB974\uACE0 \uAC10\uAE30 + \uBB3C\uACE0\uAE30 \uBC18\uB300 \uBC29\uD5A5(\u2190\u2192)\uC73C\uB85C \uBC84\uD2F0\uAE30",nibble:"\uD1A1\uD1A1\u2026 \uAC74\uB4DC\uB9AC\uB294 \uC911",biteNow:"\uCC0C\uAC00 \uC7A0\uACBC\uB2E4! \uC9C0\uAE08 \uCC54\uC9C8!",tooEarly:"\uB108\uBB34 \uBE68\uB9AC \uCC58\uC5B4\uC694, \uBB3C\uACE0\uAE30\uAC00 \uB3C4\uB9DD\uAC14\uC5B4\uC694",hooked:"\uAC78\uC5C8\uB2E4!",fishStamina:"\uBB3C\uACE0\uAE30 \uCCB4\uB825",lineLeft:"\uB0A8\uC740 \uC904",pullLeft:"\u2190 \uC67C\uCABD\uC73C\uB85C \uBC84\uD168!",pullRight:"\uC624\uB978\uCABD\uC73C\uB85C \uBC84\uD168! \u2192",running:"\uBB3C\uACE0\uAE30\uAC00 \uCC28\uACE0 \uB098\uAC00\uC694",keep:"\uC5B4\uB9DD\uC5D0 \uB123\uAE30",release:"\uB193\uC544\uC8FC\uAE30",keepNet:"\uC5B4\uB9DD",dex:"\uB3C4\uAC10",newSpecies:"\uC0C8\uB85C\uC6B4 \uC5B4\uC885!",newRecord:"\uCD5C\uB300\uC5B4 \uAC31\uC2E0!",netFull:"\uC5B4\uB9DD\uC774 \uAC00\uB4DD \uCC3C\uC5B4\uC694 (20\uB9C8\uB9AC)",released:"\uB193\uC544\uC92C\uC5B4\uC694",seaWater:"\uBC14\uB2E4",freshWater:"\uBBFC\uBB3C",length:"\uAE38\uC774",weight:"\uBB34\uAC8C",totalWeight:"\uCD1D \uBB34\uAC8C",best:"\uCD5C\uB300",unknown:"???",emptyNet:"\uC544\uC9C1 \uBE44\uC5B4 \uC788\uC5B4\uC694",sell:"\uBAA8\uB450 \uBC29\uB958",carom3:"3\uAD6C",carom3s:"3\uCFE0\uC158",carom4:"4\uAD6C",carom4s:"\uD55C\uAD6D\uC2DD 4\uAD6C",pool8:"\uD3EC\uCF13\uBCFC",pool8s:"8\uBCFC",tipOffset:"\uB2F9\uC810",chalk:"\uCD08\uD06C",pullBack:"\uB2F9\uACA8\uC11C \uC0F7",follow:"\uBC00\uC5B4\uCE58\uAE30",draw:"\uB04C\uC5B4\uCE58\uAE30",rightEng:"\uC6B0\uD68C\uC804",leftEng:"\uC88C\uD68C\uC804",centerBall:"\uC911\uC559 (\uBB34\uD68C\uC804)",miscue:"\uBBF8\uC2A4\uD050!",point:"\uB4DD\uC810",needCush:"\uCFE0\uC158 \uBD80\uC871 ({n}\uCFE0\uC158)",miss:"\uC2E4\uD328 \xB7 \uCC28\uB840 \uB118\uAE40",foulOpp:"\uC0C1\uB300 \uACF5 \uD130\uCE58",foulNone:"\uD5DB\uCE68",wins:"\uC2B9\uB9AC!",foulWrong:"\uBA3C\uC800 \uB9DE\uD78C \uACF5\uC774 \uD2C0\uB9BC",foulRail:"\uCFE0\uC158 \uC5C6\uC74C",eightWin:"8\uBC88 \uBCFC \uC131\uACF5! \uC2B9\uB9AC",eightLose:"8\uBC88 \uBCFC \uC2E4\uD328 \xB7 \uD328\uBC30",solid:"\uC194\uB9AC\uB4DC(1~7)",stripe:"\uC2A4\uD2B8\uB77C\uC774\uD504(9~15)",assigned:"\uBC30\uC815",foul:"\uD30C\uC6B8",ballInHand:"\uD504\uB9AC\uBCFC",viewTop:"\uD0D1\uBDF0",viewCue:"\uD050 \uC2DC\uC810",ballInHandHelp:"\uD504\uB9AC\uBCFC: \uD770 \uACF5\uC744 \uB04C\uC5B4\uC11C \uB193\uACE0 \u2192 \uC870\uC900 \u2192 \uAC8C\uC774\uC9C0\uB97C \uC544\uB798\uB85C \uB2F9\uACBC\uB2E4 \uB193\uAE30",billCueHelp:"1\uC778\uCE6D: \uB4DC\uB798\uADF8 \u2190\u2192 \uC870\uC900 \xB7 \u2191\u2193 \uC2DC\uC57C \uAC01\uB3C4 \xB7 \uD720 \uD655\uB300/\uCD95\uC18C \xB7 Shift \uBBF8\uC138 \uC870\uC900 \xB7 \uC2A4\uD398\uC774\uC2A4/\uAC8C\uC774\uC9C0\uB85C \uC0F7",billHelp2:"\uD14C\uC774\uBE14 \uD074\uB9AD/\uB4DC\uB798\uADF8 \uC870\uC900 \xB7 \u25C0\u25B6 \uBBF8\uC138\uC870\uC815 \xB7 \uB2F9\uC810(\u2191\u2193 Z X) \xB7 [ ] \uD050 \uAC01\uB3C4 \xB7 \uAC8C\uC774\uC9C0\uB97C \uB2F9\uACBC\uB2E4 \uB193\uAC70\uB098 \uC2A4\uD398\uC774\uC2A4 \uAE38\uAC8C \u2192 \uB193\uAE30 \xB7 C \uCD08\uD06C \xB7 V \uC2DC\uC810 \xB7 \uC6B0\uD074\uB9AD \uB4DC\uB798\uADF8 \uC790\uC720 \uC2DC\uC810",target:"\uBAA9\uD45C",group:"\uADF8\uB8F9",ball:"\uACF5",score:"\uC810\uC218",innings:"\uC774\uB2DD",highRun:"\uD558\uC774\uB7F0",open:"\uBBF8\uC815",roundDone:"\uB77C\uC6B4\uB4DC \uC885\uB8CC",playAgain:"\uB2E4\uC2DC \uD558\uAE30",backLobby:"\uD30C\uD2F0 \uD654\uBA74",swing:"\uC2A4\uC719",swingHelp:"\u2190\u2192 \uC870\uC900 \xB7 Q/E \uD074\uB7FD \xB7 \uC2A4\uD398\uC774\uC2A4 \uB204\uB974\uBA74 \uBC31\uC2A4\uC719 \u2192 \uB5BC\uBA74 \uD30C\uC6CC \u2192 \uB2E4\uC2DC \uB20C\uB7EC \uC784\uD329\uD2B8(\uD558\uC580 \uCE78)",puttHelp:"\u2190\u2192 \uC870\uC900(\uC815\uBC00) \xB7 \uC2A4\uD398\uC774\uC2A4 \uB204\uB974\uACE0 \uC788\uB2E4\uAC00 \uB5BC\uBA74 \uD37C\uD305 (\uAC70\uB9AC \uD45C\uC2DC \uCC38\uACE0)"},en:{title:"WorldPlay",subtitle:"Golf, fishing & billiards with the world",name:"Nickname",lang:"Language",color:"Avatar color",start:"Enter",online:"Online",offline:"Offline demo",players:"online",chatPh:"Type a message (auto-translated)",send:"Send",golf:"Golf",fishing:"Fishing",billiards:"Billiards",play:"Play",exit:"Exit",globe:"Globe",golfHelp:"Drag / \u2190\u2192 to aim \xB7 hold to charge, release to putt",strokes:"Strokes",nStrokes:"{n} strokes",sumTotal:"Total",greenRead:"Green read",slopeUp:"Uphill",slopeDown:"Downhill",breakL:"\u2190 breaks left",breakR:"breaks right \u2192",flat:"flat",hole:"Hole",sunk:"In the hole! {n} strokes",fishHelp:"Hold to cast \xB7 tap when it bites \xB7 hold to reel, keep tension",cast:"Cast",waiting:"Waiting for a bite\u2026",bite:"Bite! Tap now!",reel:"Reel",tension:"Tension",distance:"Distance",snapped:"The line snapped",escaped:"The fish got away",missed:"Missed it",caught:"Caught a {fish}, {kg} kg!",billHelp:"Drag / \u2190\u2192 to aim \xB7 hold to charge, release to shoot",yourTurn:"Your turn",waitTurn:"{name}'s turn",potted:"Potted {n}",rack:"Re-rack",scratch:"Scratch!",power:"Power",evCatch:"{name} caught a {fish}, {kg} kg",evSink:"{name} finished hole {hole} in {n}",evPot:"{name} potted ball {n}",joined:"{name} joined",left:"{name} left",slowDown:"You are sending messages too fast",noTr:"translator offline",translated:"translated",showOrig:"original",venuePick:"Pick a place to play",venueGolf:"Golf courses",venueFish:"Fishing spots",goVenue:"Go",backHub:"Back to plaza",here:"You are here",quality:"Quality",auto:"Auto",party:"Party",partyHint:"Up to {n} \xB7 add guests on this device",guest:"Guest",me:"me",emptySlot:"Empty",joinParty:"Join",leaveParty:"Leave",addGuest:"Guest",startGame:"Start",partyFull:"Party is full",screenGolf:"Screen Golf",golf3:"3-hole round",golf1:"Hole 1",golf1b:"Hole 2 (par 3)",scoreCard:"Scorecard",player:"Player",pinDist:"To pin",wind:"Wind",lie:"Lie",putter:"Putter",strokeN:"shot {n}",spectating:"watching",lie_tee:"Tee",lie_fairway:"Fairway",lie_rough:"Rough",lie_bunker:"Bunker",lie_green:"Green",lie_fringe:"Fringe",lie_water:"Water",lie_ob:"OB",shotData:"Shot data",ballSpeed:"Ball speed",launchAngle:"Launch",backSpin:"Back spin",sideSpin:"Side spin",apex:"Apex",carry:"Carry",total:"Total",penaltyWater:"Water! 1-stroke penalty, drop",penaltyOB:"OB! 1-stroke penalty, replay",pickup:"Double par \xB7 picked up",holeInOne:"HOLE IN ONE!!",sc_m3:"Albatross",sc_m2:"Eagle",sc_m1:"Birdie",sc_0:"Par",sc_1:"Bogey",sc_2:"Double bogey",sc_3:"Triple+",fishHelp2:"Hold Space to cast \xB7 tap when the float goes under \xB7 fight: hold to reel and lean against the fish (\u2190\u2192)",nibble:"Nibbling\u2026",biteNow:"Float is under! Strike now!",tooEarly:"Too early, the fish got spooked",hooked:"Fish on!",fishStamina:"Fish stamina",lineLeft:"Line out",pullLeft:"\u2190 Lean left!",pullRight:"Lean right! \u2192",running:"The fish is running",keep:"Keep in net",release:"Release",keepNet:"Keep net",dex:"Fish guide",newSpecies:"New species!",newRecord:"New personal best!",netFull:"Keep net is full (20)",released:"Released",seaWater:"Sea",freshWater:"Freshwater",length:"Length",weight:"Weight",totalWeight:"Total",best:"Best",unknown:"???",emptyNet:"Nothing yet",sell:"Release all",carom3:"3-ball",carom3s:"3-cushion",carom4:"4-ball",carom4s:"Korean 4-ball",pool8:"Pool",pool8s:"8-ball",tipOffset:"Tip",chalk:"Chalk",pullBack:"pull to shoot",follow:"Follow",draw:"Draw",rightEng:"Right",leftEng:"Left",centerBall:"Centre (no spin)",miscue:"Miscue!",point:"Point",needCush:"Not enough cushions ({n})",miss:"Miss \xB7 next player",foulOpp:"Touched opponent's ball",foulNone:"No contact",wins:"wins!",foulWrong:"Wrong ball first",foulRail:"No rail after contact",eightWin:"8-ball down! You win",eightLose:"8-ball foul \xB7 you lose",solid:"Solids (1\u20137)",stripe:"Stripes (9\u201315)",assigned:"assigned",foul:"Foul",ballInHand:"Ball in hand",viewTop:"Top",viewCue:"Cue view",ballInHandHelp:"Ball in hand: drag the white ball, aim, then pull the gauge down and release",billCueHelp:"First person: drag \u2190\u2192 to aim \xB7 \u2191\u2193 to tilt the view \xB7 wheel to zoom \xB7 Shift for fine aim \xB7 Space/gauge to shoot",billHelp2:"Click/drag the table to aim \xB7 \u25C0\u25B6 fine \xB7 tip (\u2191\u2193 Z X) \xB7 pull the gauge or hold Space \u2192 release \xB7 [ ] cue angle \xB7 C chalk \xB7 V view \xB7 right-drag free view",target:"Target",group:"Group",ball:"Ball",score:"Score",innings:"Inn.",highRun:"High run",open:"Open",roundDone:"Round complete",playAgain:"Play again",backLobby:"Party screen",swing:"Swing",swingHelp:"\u2190\u2192 aim \xB7 Q/E club \xB7 press Space to backswing \u2192 release for power \u2192 press again at the white zone",puttHelp:"\u2190\u2192 fine aim \xB7 hold Space, release to putt (see distance)"},ja:{title:"\u30EF\u30FC\u30EB\u30C9\u30D7\u30EC\u30A4",subtitle:"\u4E16\u754C\u4E2D\u306E\u53CB\u9054\u3068\u30B4\u30EB\u30D5\u30FB\u91E3\u308A\u30FB\u30D3\u30EA\u30E4\u30FC\u30C9",name:"\u30CB\u30C3\u30AF\u30CD\u30FC\u30E0",lang:"\u8A00\u8A9E",color:"\u30AD\u30E3\u30E9\u306E\u8272",start:"\u5165\u5834",online:"\u30AA\u30F3\u30E9\u30A4\u30F3",offline:"\u30AA\u30D5\u30E9\u30A4\u30F3\u30C7\u30E2",players:"\u4EBA\u304C\u30AA\u30F3\u30E9\u30A4\u30F3",chatPh:"\u30E1\u30C3\u30BB\u30FC\u30B8\uFF08\u81EA\u52D5\u7FFB\u8A33\uFF09",send:"\u9001\u4FE1",golf:"\u30B4\u30EB\u30D5",fishing:"\u91E3\u308A",billiards:"\u30D3\u30EA\u30E4\u30FC\u30C9",play:"\u30B9\u30BF\u30FC\u30C8",exit:"\u7D42\u4E86",globe:"\u5730\u7403\u5100",golfHelp:"\u30C9\u30E9\u30C3\u30B0/\u2190\u2192\u3067\u72D9\u3046\u30FB\u9577\u62BC\u3057\u3067\u529B\u3092\u305F\u3081\u3066\u96E2\u3059",strokes:"\u6253\u6570",hole:"\u30DB\u30FC\u30EB",sunk:"\u30AB\u30C3\u30D7\u30A4\u30F3\uFF01{n}\u6253",fishHelp:"\u9577\u62BC\u3057\u3067\u30AD\u30E3\u30B9\u30C8\u30FB\u30A2\u30BF\u30EA\u3067\u30BF\u30C3\u30D7\u30FB\u62BC\u3057\u3066\u5DFB\u304D\u30C6\u30F3\u30B7\u30E7\u30F3\u7DAD\u6301",cast:"\u30AD\u30E3\u30B9\u30C8",waiting:"\u30A2\u30BF\u30EA\u5F85\u3061\u2026",bite:"\u30A2\u30BF\u30EA\uFF01\u4ECA\u30BF\u30C3\u30D7\uFF01",reel:"\u5DFB\u304F",tension:"\u30C6\u30F3\u30B7\u30E7\u30F3",distance:"\u8DDD\u96E2",snapped:"\u7CF8\u304C\u5207\u308C\u305F",escaped:"\u9B5A\u306B\u9003\u3052\u3089\u308C\u305F",missed:"\u9003\u3057\u305F",caught:"{fish} {kg}kg \u91E3\u308C\u305F\uFF01",billHelp:"\u30C9\u30E9\u30C3\u30B0/\u2190\u2192\u3067\u72D9\u3046\u30FB\u9577\u62BC\u3057\u3067\u529B\u3092\u305F\u3081\u3066\u30B7\u30E7\u30C3\u30C8",yourTurn:"\u3042\u306A\u305F\u306E\u756A",waitTurn:"{name}\u306E\u756A",potted:"\u30DD\u30B1\u30C3\u30C8 {n}",rack:"\u518D\u914D\u7F6E",scratch:"\u30B9\u30AF\u30E9\u30C3\u30C1\uFF01",power:"\u30D1\u30EF\u30FC",evCatch:"{name}\u3055\u3093\u304C{fish} {kg}kg\u3092\u91E3\u308A\u307E\u3057\u305F",evSink:"{name}\u3055\u3093\u304C{hole}\u756A\u30DB\u30FC\u30EB\u3092{n}\u6253\u3067\u7D42\u4E86",evPot:"{name}\u3055\u3093\u304C{n}\u756A\u30DC\u30FC\u30EB\u3092\u30DD\u30B1\u30C3\u30C8",joined:"{name}\u3055\u3093\u304C\u53C2\u52A0",left:"{name}\u3055\u3093\u304C\u9000\u51FA",slowDown:"\u9001\u4FE1\u304C\u901F\u3059\u304E\u307E\u3059",noTr:"\u7FFB\u8A33\u30B5\u30FC\u30D0\u30FC\u672A\u63A5\u7D9A",translated:"\u7FFB\u8A33\u6E08\u307F",showOrig:"\u539F\u6587",venuePick:"\u30D7\u30EC\u30A4\u3059\u308B\u5834\u6240\u3092\u9078\u629E",venueGolf:"\u30B4\u30EB\u30D5\u5834",venueFish:"\u91E3\u308A\u5834",goVenue:"\u79FB\u52D5",backHub:"\u5E83\u5834\u3078",here:"\u73FE\u5728\u5730",quality:"\u753B\u8CEA",auto:"\u81EA\u52D5"},zh:{title:"\u4E16\u754C\u4E50\u56ED",subtitle:"\u548C\u5168\u4E16\u754C\u4E00\u8D77\u6253\u9AD8\u5C14\u592B\u3001\u9493\u9C7C\u3001\u53F0\u7403",name:"\u6635\u79F0",lang:"\u8BED\u8A00",color:"\u89D2\u8272\u989C\u8272",start:"\u8FDB\u5165",online:"\u5728\u7EBF",offline:"\u79BB\u7EBF\u6F14\u793A",players:"\u4EBA\u5728\u7EBF",chatPh:"\u8F93\u5165\u6D88\u606F\uFF08\u81EA\u52A8\u7FFB\u8BD1\uFF09",send:"\u53D1\u9001",golf:"\u9AD8\u5C14\u592B",fishing:"\u9493\u9C7C",billiards:"\u53F0\u7403",play:"\u5F00\u59CB",exit:"\u9000\u51FA",globe:"\u5730\u7403\u4EEA",golfHelp:"\u62D6\u52A8/\u2190\u2192\u7784\u51C6 \xB7 \u957F\u6309\u84C4\u529B\u677E\u5F00\u63A8\u6746",strokes:"\u6746\u6570",hole:"\u6D1E",sunk:"\u8FDB\u6D1E\uFF01{n}\u6746",fishHelp:"\u957F\u6309\u629B\u7AFF \xB7 \u54AC\u94A9\u65F6\u70B9\u51FB \xB7 \u6309\u4F4F\u6536\u7EBF\u4FDD\u6301\u5F20\u529B",cast:"\u629B\u7AFF",waiting:"\u7B49\u5F85\u54AC\u94A9\u2026",bite:"\u54AC\u94A9\u4E86\uFF01\u5FEB\u70B9\uFF01",reel:"\u6536\u7EBF",tension:"\u5F20\u529B",distance:"\u8DDD\u79BB",snapped:"\u7EBF\u65AD\u4E86",escaped:"\u9C7C\u8DD1\u4E86",missed:"\u9519\u8FC7\u4E86",caught:"\u9493\u5230 {fish} {kg}kg\uFF01",billHelp:"\u62D6\u52A8/\u2190\u2192\u7784\u51C6 \xB7 \u957F\u6309\u84C4\u529B\u677E\u5F00\u51FB\u7403",yourTurn:"\u8F6E\u5230\u4F60",waitTurn:"\u8F6E\u5230{name}",potted:"\u8FDB\u7403 {n}",rack:"\u91CD\u65B0\u6446\u7403",scratch:"\u6BCD\u7403\u843D\u888B\uFF01",power:"\u529B\u5EA6",evCatch:"{name} \u9493\u5230 {fish} {kg}kg",evSink:"{name} \u7528{n}\u6746\u5B8C\u6210\u7B2C{hole}\u6D1E",evPot:"{name} \u6253\u8FDB{n}\u53F7\u7403",joined:"{name} \u52A0\u5165\u4E86",left:"{name} \u79BB\u5F00\u4E86",slowDown:"\u53D1\u9001\u592A\u5FEB\u4E86",noTr:"\u7FFB\u8BD1\u670D\u52A1\u5668\u672A\u8FDE\u63A5",translated:"\u5DF2\u7FFB\u8BD1",showOrig:"\u539F\u6587",venuePick:"\u9009\u62E9\u6E38\u73A9\u5730\u70B9",venueGolf:"\u9AD8\u5C14\u592B\u7403\u573A",venueFish:"\u9493\u9C7C\u70B9",goVenue:"\u524D\u5F80",backHub:"\u56DE\u5E7F\u573A",here:"\u5F53\u524D\u4F4D\u7F6E",quality:"\u753B\u8D28",auto:"\u81EA\u52A8"},es:{title:"WorldPlay",subtitle:"Golf, pesca y billar con todo el mundo",name:"Apodo",lang:"Idioma",color:"Color del avatar",start:"Entrar",online:"En l\xEDnea",offline:"Demo sin conexi\xF3n",players:"en l\xEDnea",chatPh:"Escribe (traducci\xF3n autom\xE1tica)",send:"Enviar",golf:"Golf",fishing:"Pesca",billiards:"Billar",play:"Jugar",exit:"Salir",globe:"Globo",golfHelp:"Arrastra / \u2190\u2192 para apuntar \xB7 mant\xE9n para cargar y suelta",strokes:"Golpes",hole:"Hoyo",sunk:"\xA1Al hoyo! {n} golpes",fishHelp:"Mant\xE9n para lanzar \xB7 toca al picar \xB7 mant\xE9n para recoger",cast:"Lanzar",waiting:"Esperando que piquen\u2026",bite:"\xA1Pica! \xA1Toca ya!",reel:"Recoger",tension:"Tensi\xF3n",distance:"Distancia",snapped:"Se rompi\xF3 el sedal",escaped:"Se escap\xF3 el pez",missed:"Se fue",caught:"\xA1{fish} de {kg} kg!",billHelp:"Arrastra / \u2190\u2192 para apuntar \xB7 mant\xE9n y suelta para tirar",yourTurn:"Tu turno",waitTurn:"Turno de {name}",potted:"Metidas {n}",rack:"Reiniciar",scratch:"\xA1Falta!",power:"Fuerza",evCatch:"{name} pesc\xF3 un {fish} de {kg} kg",evSink:"{name} termin\xF3 el hoyo {hole} en {n}",evPot:"{name} meti\xF3 la bola {n}",joined:"{name} entr\xF3",left:"{name} sali\xF3",slowDown:"Env\xEDas mensajes muy r\xE1pido",noTr:"traductor sin conexi\xF3n",translated:"traducido",showOrig:"original",venuePick:"Elige d\xF3nde jugar",venueGolf:"Campos de golf",venueFish:"Zonas de pesca",goVenue:"Ir",backHub:"Volver a la plaza",here:"Est\xE1s aqu\xED",quality:"Calidad",auto:"Auto"}},xp={ko:{bluegill:"\uBE14\uB8E8\uAE38",crucian:"\uBD95\uC5B4",bass:"\uBC30\uC2A4",carp:"\uC789\uC5B4",trout:"\uC1A1\uC5B4",mandarin:"\uC3D8\uAC00\uB9AC",catfish:"\uBA54\uAE30",pike:"\uAC15\uAF2C\uCE58\uACE0\uAE30",eel:"\uBC40\uC7A5\uC5B4",golden:"\uD669\uAE08 \uC789\uC5B4",mackerel:"\uACE0\uB4F1\uC5B4",rockfish:"\uC6B0\uB7ED",flounder:"\uAD11\uC5B4",blackporgy:"\uAC10\uC131\uB3D4",seabream:"\uCC38\uB3D4",seabass:"\uB18D\uC5B4",yellowtail:"\uBC29\uC5B4",salmon:"\uC5F0\uC5B4",tuna:"\uCC38\uCE58"},en:{bluegill:"Bluegill",crucian:"Crucian Carp",bass:"Black Bass",carp:"Carp",trout:"Trout",mandarin:"Mandarin Fish",catfish:"Catfish",pike:"Pike",eel:"Eel",golden:"Golden Koi",mackerel:"Mackerel",rockfish:"Rockfish",flounder:"Flounder",blackporgy:"Black Porgy",seabream:"Red Sea Bream",seabass:"Sea Bass",yellowtail:"Yellowtail",salmon:"Salmon",tuna:"Bluefin Tuna"},ja:{bluegill:"\u30D6\u30EB\u30FC\u30AE\u30EB",crucian:"\u30D5\u30CA",bass:"\u30D6\u30E9\u30C3\u30AF\u30D0\u30B9",carp:"\u30B3\u30A4",trout:"\u30DE\u30B9",mandarin:"\u30B3\u30A6\u30E9\u30A4\u30B1\u30C4\u30AE\u30E7",catfish:"\u30CA\u30DE\u30BA",pike:"\u30D1\u30A4\u30AF",eel:"\u30A6\u30CA\u30AE",golden:"\u9EC4\u91D1\u306E\u9BC9",mackerel:"\u30B5\u30D0",rockfish:"\u30AF\u30ED\u30BD\u30A4",flounder:"\u30D2\u30E9\u30E1",blackporgy:"\u30AF\u30ED\u30C0\u30A4",seabream:"\u30DE\u30C0\u30A4",seabass:"\u30B9\u30BA\u30AD",yellowtail:"\u30D6\u30EA",salmon:"\u30B5\u30B1",tuna:"\u30AF\u30ED\u30DE\u30B0\u30ED"},zh:{bluegill:"\u84DD\u9CC3\u592A\u9633\u9C7C",crucian:"\u9CAB\u9C7C",bass:"\u9ED1\u9C88",carp:"\u9CA4\u9C7C",trout:"\u9CDF\u9C7C",mandarin:"\u9CDC\u9C7C",catfish:"\u9CB6\u9C7C",pike:"\u72D7\u9C7C",eel:"\u9CD7\u9C7C",golden:"\u91D1\u9526\u9CA4",mackerel:"\u9CAD\u9C7C",rockfish:"\u8BB8\u6C0F\u5E73\u9C89",flounder:"\u7259\u9C86",blackporgy:"\u9ED1\u9CB7",seabream:"\u771F\u9CB7",seabass:"\u9C88\u9C7C",yellowtail:"\u9C24\u9C7C",salmon:"\u4E09\u6587\u9C7C",tuna:"\u84DD\u9CCD\u91D1\u67AA\u9C7C"},es:{bluegill:"Mojarra",crucian:"Carp\xEDn",bass:"Lubina negra",carp:"Carpa",trout:"Trucha",mandarin:"Pez mandar\xEDn",catfish:"Bagre",pike:"Lucio",eel:"Anguila",golden:"Koi dorado",mackerel:"Caballa",rockfish:"Rocote",flounder:"Lenguado",blackporgy:"Sargo negro",seabream:"Pargo rojo",seabass:"Lubina",yellowtail:"Medregal",salmon:"Salm\xF3n",tuna:"At\xFAn rojo"}},Ur="en";function yp(i){Ur=i}function hn(){return Ur}function U(i,t){let e=(Mu[Ur]&&Mu[Ur][i])??Mu.en[i]??i;if(t)for(let n in t)e=e.replace(`{${n}}`,t[n]);return e}var vl={ko:{},en:{}};function vp(i){for(let t in i)Object.assign(vl[t]||(vl[t]={}),i[t])}function Ni(i,t=Ur){var e,n;return((e=xp[t])==null?void 0:e[i])||((n=vl[t])==null?void 0:n[i])||vl.en[i]||xp.en[i]||i}function Ds(i,t=Ur){return i[t]||(t==="ko"?i.ko:i.en)||i.id}var bp="taeil-lounge.wallet.v1";var wu=()=>new Date(Date.now()+324e5).toISOString().slice(0,10),$n=null;function ns(){var i;if($n)return $n;try{$n=JSON.parse(localStorage.getItem(bp))}catch{$n=null}if(!$n){let t=0;try{t=+((i=JSON.parse(localStorage.getItem("taeil-lounge.fishing.v2")||"null"))==null?void 0:i.coins)||0}catch{}$n={pts:Math.max(100,Math.min(500,Math.round(t/10))),day:"",today:0,own:{},eq:{}}}return $n.own||={},$n.eq||={},$n}function bl(){try{localStorage.setItem(bp,JSON.stringify($n))}catch{}}var k_=new Set;var _l=()=>k_.forEach(i=>{try{i(ns().pts)}catch{}}),Us=()=>ns().pts,_p=()=>{let i=ns();return i.day===wu()?Math.max(0,30-i.today):30};function Nr(i){let t=ns();t.day!==wu()&&(t.day=wu(),t.today=0);let e=Math.max(0,Math.min(Math.round(i),30-t.today));return e?(t.today+=e,t.pts+=e,bl(),_l(),e):0}function Su(i){let t=ns();return i<0||t.pts<i?!1:(t.pts-=i,bl(),_l(),!0)}var ko={driver:{ko:"\uB4DC\uB77C\uC774\uBC84\xB7\uC6B0\uB4DC",items:[{id:"dr0",ko:"\uAE30\uBCF8 \uB4DC\uB77C\uC774\uBC84",price:0,carry:1,icon:"\u{1F3CC}"},{id:"dr1",ko:"\uD2F0\uD0C0\uB284 \uB4DC\uB77C\uC774\uBC84 10.5\xB0",price:3e3,carry:1.02,icon:"\u{1F3CC}"},{id:"dr2",ko:"\uCE74\uBCF8 \uD06C\uB77C\uC6B4 \uB4DC\uB77C\uC774\uBC84",price:8e3,carry:1.03,acc:.95,icon:"\u{1F3CC}"},{id:"dr3",ko:"\uD22C\uC5B4 \uB4DC\uB77C\uC774\uBC84 9\xB0",price:2e4,carry:1.05,icon:"\u{1F3CC}"},{id:"dr4",ko:"\uACE0\uBC18\uBC1C \uB4DC\uB77C\uC774\uBC84",price:45e3,carry:1.07,acc:.95,icon:"\u{1F680}"},{id:"dr5",ko:"\uD669\uAE08 \uB4DC\uB77C\uC774\uBC84",price:15e4,carry:1.09,acc:.9,icon:"\u2728"}]},iron:{ko:"\uC544\uC774\uC5B8 \uC138\uD2B8",items:[{id:"ir0",ko:"\uAE30\uBCF8 \uC544\uC774\uC5B8",price:0,carry:1,icon:"\u26F3"},{id:"ir1",ko:"\uCE90\uBE44\uD2F0 \uC544\uC774\uC5B8 \uC138\uD2B8",price:4e3,acc:.9,icon:"\u26F3"},{id:"ir2",ko:"\uB2E8\uC870 \uC544\uC774\uC5B8 \uC138\uD2B8",price:12e3,carry:1.02,acc:.85,icon:"\u26F3"},{id:"ir3",ko:"\uBA38\uC2AC\uBC31 \uD22C\uC5B4 \uC544\uC774\uC5B8",price:35e3,carry:1.03,acc:.8,icon:"\u26F3"},{id:"ir4",ko:"\uD669\uAE08 \uC544\uC774\uC5B8 \uC138\uD2B8",price:12e4,carry:1.05,acc:.75,icon:"\u2728"}]},putter:{ko:"\uD37C\uD130",items:[{id:"pt0",ko:"\uAE30\uBCF8 \uD37C\uD130",price:0,icon:"\u{1F3D1}"},{id:"pt1",ko:"\uBE14\uB808\uC774\uB4DC \uD37C\uD130",price:2500,look:1,icon:"\u{1F3D1}"},{id:"pt2",ko:"\uB9D0\uB81B \uD37C\uD130",price:9e3,look:1,icon:"\u{1F3D1}"},{id:"pt3",ko:"\uD22C\uC5B4 \uBC00\uB4DC \uD37C\uD130",price:3e4,look:1,icon:"\u{1F3D1}"},{id:"pt4",ko:"\uD669\uAE08 \uD37C\uD130",price:1e5,look:1,icon:"\u2728"}]},ball:{ko:"\uACE8\uD504\uACF5",items:[{id:"gb0",ko:"\uC5F0\uC2B5\uACF5",price:0,icon:"\u26AA"},{id:"gb1",ko:"2\uD53C\uC2A4 \uBE44\uAC70\uB9AC \uACF5",price:1500,carry:1.01,icon:"\u26AA"},{id:"gb2",ko:"3\uD53C\uC2A4 \uCEE8\uD2B8\uB864 \uACF5",price:6e3,acc:.95,icon:"\u26AA"},{id:"gb3",ko:"\uD22C\uC5B4 \uC6B0\uB808\uD0C4 \uACF5",price:18e3,carry:1.02,acc:.93,icon:"\u26AA"},{id:"gb4",ko:"\uCEEC\uB7EC \uB9E4\uD2B8 \uACF5 (\uD615\uAD11)",price:5e3,icon:"\u{1F7E1}"}]},cue:{ko:"\uB2F9\uAD6C \uD050",items:[{id:"cu0",ko:"\uD558\uC6B0\uC2A4 \uD050",price:0,col:15321504,butt:1842210,tip:3829720,icon:"\u{1F3B1}"},{id:"cu1",ko:"\uBA54\uC774\uD50C \uAC1C\uC778 \uD050",price:3e3,col:15916212,butt:5910036,tip:3829720,guide:1.1,icon:"\u{1F3B1}"},{id:"cu2",ko:"\uCE74\uBCF8 \uD050",price:1e4,col:2763310,butt:1118481,tip:2853438,guide:1.2,icon:"\u{1F3B1}"},{id:"cu3",ko:"\uD751\uB2E8 \uC0C1\uAC10 \uD050",price:3e4,col:14268810,butt:2364428,tip:13183530,guide:1.35,icon:"\u{1F3B1}"},{id:"cu4",ko:"3\uCFE0\uC158 \uD504\uB85C \uD050",price:6e4,col:15652784,butt:731738,tip:3829720,guide:1.5,icon:"\u{1F3AF}"},{id:"cu5",ko:"\uD669\uAE08 \uD050",price:2e5,col:14725168,butt:9071120,tip:16777215,guide:1.6,icon:"\u2728"}]},glove:{ko:"\uC7A5\uAC11\xB7\uC18C\uD488",items:[{id:"gl0",ko:"\uC5C6\uC74C",price:0,icon:"\u2014"},{id:"gl1",ko:"\uC591\uD53C \uACE8\uD504\uC7A5\uAC11",price:1200,acc:.98,icon:"\u{1F9E4}"},{id:"gl2",ko:"\uAC70\uB9AC\uCE21\uC815\uAE30",price:15e3,acc:.95,icon:"\u{1F52D}"},{id:"gl3",ko:"\uD22C\uC5B4 \uCE90\uB514\uBC31",price:25e3,icon:"\u{1F392}"},{id:"gl4",ko:"\uBA85\uD488 \uCE90\uB514\uBC31 (\uC790\uB791\uC6A9)",price:8e4,icon:"\u{1F4BC}"}]}},Dn=(i,t)=>{let e=ko[i];return e&&e.items.find(n=>n.id===(t??ns().eq[i]))||(e?e.items[0]:{})},Ml=(i,t)=>!Dn(i,t).price||(ns().own[i]||[]).includes(t);function Mp(i,t){let e=Dn(i,t);return Ml(i,t)?!0:Su(e.price)?(($n.own[i]||=[]).push(t),$n.eq[i]=t,bl(),_l(),!0):!1}function wp(i,t){return Ml(i,t)?(ns().eq[i]=t,bl(),_l(),!0):!1}function Sp(i){let t=Dn("ball"),e=Dn("glove");if(i.putter)return{carry:1,acc:1};let n=/W|DR/.test(i.id)?Dn("driver"):Dn("iron");return{carry:(n.carry||1)*(t.carry||1),acc:(n.acc||1)*(t.acc||1)*(e.acc||1)}}var Ns=new P(0,0,2500),ze=[{par:4,path:[[0,0],[150,0],[255,18],[352,26]],fw:32,green:{x:352,z:26,r:15,slope:[.018,-.012],crown:.012},pin:[356,22],bunkers:[[238,-6,10,5],[338,46,7,4.5],[369,9,6,4]],water:[],dog:"R"},{par:3,path:[[0,0],[70,-3],[168,-8]],fw:0,green:{x:168,z:-8,r:14,slope:[-.022,.008],crown:-.008},pin:[163,-12],bunkers:[[153,9,6,3.5],[182,-25,7,3.5],[186,4,4,5]],water:[[96,-5,34,20]]},{par:5,path:[[0,0],[210,-14],[335,12],[498,-10]],fw:34,green:{x:498,z:-10,r:16,slope:[.01,.024],crown:.015},pin:[503,-6],bunkers:[[205,6,9,5],[228,-36,8,5],[480,10,7,4],[485,-30,6,4]],water:[[300,-4,9,48]]}],D_={ob:[58,88,36],rough:[74,112,45],fairway:[104,150,60],fringe:[98,156,64],green:[112,172,70],tee:[108,156,62],bunker:[222,205,160],water:[40,78,90]};function Tp(i,t,e){let n=1e9,s=0,r=0;for(let o=0;o<e.length-1;o++){let[a,l]=e[o],[c,h]=e[o+1],u=c-a,d=h-l,f=u*u+d*d,m=Math.sqrt(f),x=Math.max(0,Math.min(1,((i-a)*u+(t-l)*d)/f)),g=Math.hypot(i-a-u*x,t-l-d*x);g<n&&(n=g,s=r+x*m),r+=m}return[n,s]}var Ep=(i,t,[e,n,s,r],o=0)=>((i-e)/(s+o))**2+((t-n)/(r+o))**2<=1;function U_(i){if(i._pp)return i._pp;let t={};for(let e of["water","bunker","green","tee","fairway"])t[e]=(i.polys[e]||[]).map(n=>{let s=1e9,r=-1e9,o=1e9,a=-1e9;for(let[l,c]of n)l<s&&(s=l),l>r&&(r=l),c<o&&(o=c),c>a&&(a=c);return{pts:n,bb:[s,r,o,a]}});return Object.defineProperty(i,"_pp",{value:t,enumerable:!1}),t}function zr(i,t,{pts:e,bb:n},s=0){if(i<n[0]-s||i>n[1]+s||t<n[2]-s||t>n[3]+s)return!1;let r=!1;for(let o=0,a=e.length-1;o<e.length;a=o++){let[l,c]=e[o],[h,u]=e[a];c>t!=u>t&&i<(h-l)*(t-c)/(u-c)+l&&(r=!r)}if(r||!s)return r;for(let o=0,a=e.length-1;o<e.length;a=o++){let[l,c]=e[a],[h,u]=e[o],d=h-l,f=u-c,m=d*d+f*f||1e-9,x=Math.max(0,Math.min(1,((i-l)*d+(t-c)*f)/m));if(Math.hypot(i-l-d*x,t-c-f*x)<s)return!0}return!1}function N_(i,t,e){let n=U_(i);for(let o of n.water)if(zr(t,e,o))return"water";for(let o of n.bunker)if(zr(t,e,o))return"bunker";for(let o of n.green)if(zr(t,e,o))return"green";for(let o of n.green)if(zr(t,e,o,2.2))return"fringe";if(Math.abs(t)<5&&Math.abs(e)<4)return"tee";for(let o of n.tee)if(zr(t,e,o))return"tee";if(t<-25)return"ob";for(let o of n.fairway)if(zr(t,e,o))return"fairway";let[s,r]=Tp(t,e,i.path);return!n.fairway.length&&i.fw&&r>28&&s<i.fw/2?"fairway":s>Math.max(i.fw||24,30)/2+45?"ob":"rough"}function Eu(i,t,e){if(i.polys)return N_(i,t,e);for(let l of i.water)if(Ep(t,e,l))return"water";for(let l of i.bunkers)if(Ep(t,e,l))return"bunker";let n=i.green,s=Math.hypot(t-n.x,e-n.z),r=n.r*(1+.12*Math.sin(Math.atan2(e-n.z,t-n.x)*2+1));if(s<r)return"green";if(s<r+2.2)return"fringe";if(Math.abs(t)<5&&Math.abs(e)<4)return"tee";let[o,a]=Tp(t,e,i.path);return t<-25?"ob":i.fw&&a>28&&o<i.fw/2*(1+.1*Math.sin(a*.05))?"fairway":o>(i.fw||24)/2+42?"ob":"rough"}function Tu(i,t){let e=Math.imul(i|0,374761393)^Math.imul(t|0,668265263);return e=Math.imul(e^e>>>13,1274126177),((e^e>>>16)>>>0)/4294967296}var Sl=class{constructor(t,e){this.scene=t,this.seed=e,this.group=new Qt,this.group.position.copy(Ns),this.group.visible=!1,t.add(this.group);let n=new nt(new sn(1600,48),kt("grass",7311178));n.rotation.x=-Math.PI/2,n.position.y=-.05,n.receiveShadow=!0,this.group.add(n),this.buildHills(),this.holeGroup=null,this.index=-1}buildHills(){let t=Is(this.seed+"hills"),e=kt("leaves",5599306);for(let n=0;n<22;n++){let s=n/22*Math.PI*2+t()*.2,r=750+t()*450,o=90+t()*160,a=new nt(new Ce(1,16,8,0,Math.PI*2,0,Math.PI/2),e);a.scale.set(o*(1.4+t()),o*(.25+t()*.25),o),a.position.set(250+Math.cos(s)*r,-2,Math.sin(s)*r),this.group.add(a)}}get visible(){return this.group.visible}set visible(t){this.group.visible=t}toWorld(t,e,n=new P){return n.set(t+Ns.x,0,e+Ns.z)}lie(t,e){return Eu(this.hole,t-Ns.x,e-Ns.z)}slopeAt(t,e){let n=this.hole,s=n==null?void 0:n.green;if(!(s!=null&&s.slope))return null;let r=t-Ns.x,o=e-Ns.z,a=r-s.x,l=o-s.z;if(Math.hypot(a,l)>s.r+3)return null;let h=(s.crown||0)/s.r;return[s.slope[0]-h*a,s.slope[1]-h*l]}build(t){var L;if(this.index===t&&this.holeGroup)return;this.index=t,this.holeGroup&&(this.group.remove(this.holeGroup),this.holeGroup.traverse(k=>{var D,V,z;(D=k.geometry)==null||D.dispose(),(z=(V=k.material)==null?void 0:V.map)!=null&&z.isCanvasTexture&&k.material.map.dispose()}));let e=this.hole=ze[t%ze.length],n=this.holeGroup=new Qt;this.group.add(n),this.tee=this.toWorld(0,0),this.pin=this.toWorld(e.pin[0],e.pin[1]);let s=e.path.map(k=>k[0]),r=e.path.map(k=>k[1]);if(e.polys){let k=Math.max(...s)+80;for(let D of["green","fairway","water","bunker"])for(let V of e.polys[D]||[])for(let[z,G]of V)z>-40&&z<k&&(s.push(z),r.push(G))}let o=-40,a=Math.max(...s)+60,l=Math.min(...r)-80,c=Math.max(...r)+80,h=a-o,u=c-l,d=Math.min(2048,Math.ceil(h/.28)),f=Math.ceil(d*u/h),m=document.createElement("canvas");m.width=d,m.height=f;let x=m.getContext("2d"),g=x.createImageData(d,f),p=h/d,M=u/f;for(let k=0;k<f;k++)for(let D=0;D<d;D++){let V=o+(D+.5)*p,z=l+(k+.5)*M,G=Eu(e,V,z),[F,K,Q]=D_[G],ot=.92+Tu(D>>2,k>>2)*.08+Tu(D,k)*.06;(G==="fairway"||G==="tee")&&(ot*=Math.floor(V/9)&1?1.07:.95),G==="green"&&(ot*=Math.floor((V+z)/3)&1?1.05:.97),G==="bunker"&&(ot=.96+Tu(D,k)*.08);let St=(k*d+D)*4;g.data[St]=F*ot,g.data[St+1]=K*ot,g.data[St+2]=Q*ot,g.data[St+3]=255}x.putImageData(g,0,0),this.mapCanvas=m,this.mapRect={x0:o,z0:l,W:h,H:u};let v=new nn(m);v.colorSpace=me,v.anisotropy=8;let y=new nt(new Ln(h,u),z_(v));y.rotation.x=-Math.PI/2,y.position.set(o+h/2,0,l+u/2),y.receiveShadow=!0,n.add(y);let w=Di("water").normal.clone();w.wrapS=w.wrapT=Ms,w.repeat.set(1/9,1/9),w.needsUpdate=!0;let S=new ye({color:2773600,roughness:.06,metalness:.1,normalMap:w,normalScale:new rt(.35,.35)});for(let k of((L=e.polys)==null?void 0:L.water)||[]){let D=new Er(k.map(([z,G])=>new rt(z,-G))),V=new nt(new Ao(D),S);V.rotation.x=-Math.PI/2,V.position.y=.03,n.add(V)}for(let[k,D,V,z]of e.water){let G=new Er;G.absellipse(0,0,V,z,0,Math.PI*2,!1,0);let F=new nt(new Ao(G,48),S);F.rotation.x=-Math.PI/2,F.position.set(k,.03,D),n.add(F)}for(let k of[-1,1]){let D=new nt(new Ce(.14,12,8),Pt(2976991,{roughness:.3}));D.position.set(0,.12,k*3),D.castShadow=!0,n.add(D)}let[T,R]=e.pin,_=new nt(new sn(.075,20),new ke({color:1118481}));_.rotation.x=-Math.PI/2,_.position.set(T,.012,R),n.add(_);let b=new nt(new zt(.018,.018,2.4,8),Pt(16119285,{roughness:.3,metalness:.4}));b.position.set(T,1.2,R),b.castShadow=!0;let C=new nt(new Ln(.7,.45,6,1),new ye({color:16726832,side:Te,roughness:.8}));C.position.set(T+.35,2.15,R),this.flag=C,n.add(b,C);for(let[k,D]of[[100,16777215],[150,16766474],[200,16726832]]){let V=this.pointFromGreen(k);if(!V)continue;let z=new nt(new zt(.08,.08,1.1,8),Pt(D));z.position.set(V[0],.55,V[1]+(e.fw?e.fw/2+2:14)),n.add(z)}this.buildTrees(n,e)}pointFromGreen(t){let e=this.hole,[n,s]=e.pin,r=null,o=e.path;for(let a=o.length-1;a>0;a--){let[l,c]=o[a-1],[h,u]=o[a];for(let d=1;d>=0;d-=.02){let f=l+(h-l)*d,m=c+(u-c)*d,x=Math.hypot(f-n,m-s);if(x>=t)return r&&x-t>3?r:[f,m];r=[f,m]}}return null}buildTrees(t,e){let n=Is(this.seed+"trees"+this.index),s=[],r=e.path.reduce((v,y,w)=>w?v+Math.hypot(y[0]-e.path[w-1][0],y[1]-e.path[w-1][1]):0,0);for(let v=-10;v<r+40;v+=7){let y=0,w=0,S=0,T=0,R=1;for(let _=0;_<e.path.length-1;_++){let[b,C]=e.path[_],[L,k]=e.path[_+1],D=Math.hypot(L-b,k-C);if(v<=y+D||_===e.path.length-2){let V=Math.max(-.2,Math.min(1.3,(v-y)/D));w=b+(L-b)*V,S=C+(k-C)*V,T=-(k-C)/D,R=(L-b)/D;break}y+=D}for(let _ of[-1,1])for(let b=0;b<2;b++){let C=(e.fw||24)/2+20+n()*34+b*14,L=w+T*_*C+(n()-.5)*6,k=S+R*_*C+(n()-.5)*6,D=Eu(e,L,k);(D==="rough"||D==="ob")&&s.push([L,k,.8+n()*.7,n()])}}for(let v=0;v<26;v++){let y=(n()-.5)*2.4,w=e.green.r+28+n()*40;s.push([e.green.x+Math.cos(y)*w,e.green.z+Math.sin(y)*w,.9+n()*.8,n()])}let o=new zt(.25,.4,4,6).translate(0,2,0),a=new Es(3.2,1).scale(1,1.25,1).translate(0,6.4,0),l=new ui(2.6,8,8).translate(0,7,0),c=new cn(o,kt("bark"),s.length),h=new cn(a,kt("leaves",11061392),s.length),u=new cn(l,kt("leaves",7311472),s.length),d=new qt,f=new Re,m=new P,x=new P,g=new P(0,1,0),p=0,M=0;s.forEach(([v,y,w,S],T)=>{f.setFromAxisAngle(g,S*6.28),m.setScalar(w),x.set(v,0,y),d.compose(x,f,m),c.setMatrixAt(T,d),S<.6?h.setMatrixAt(p++,d):u.setMatrixAt(M++,d)}),h.count=p,u.count=M,this.trees=s.map(([v,y,w])=>[v,y,2.6*w,9*w]);for(let v of[c,h,u])v.castShadow=!0,v.receiveShadow=!0,t.add(v)}update(t){this.flag&&(this.flag.rotation.y=Math.sin(t*3.2)*.22)}};function z_(i){let t=Di("grass"),e=new ye({map:i,roughness:.92});return e.onBeforeCompile=n=>{n.uniforms.uDet={value:t.map},n.uniforms.uDetN={value:t.normal},n.vertexShader=`varying vec3 vWp;
`+n.vertexShader.replace("#include <worldpos_vertex>",`#include <worldpos_vertex>
 vWp = (modelMatrix * vec4(transformed, 1.0)).xyz;`),n.fragmentShader=`uniform sampler2D uDet;
uniform sampler2D uDetN;
varying vec3 vWp;
`+n.fragmentShader.replace("#include <map_fragment>",`#include <map_fragment>
        vec3 dA = texture2D(uDet, vWp.xz / 2.2).rgb, dB = texture2D(uDet, vWp.xz / 13.0).rgb;
        float dl = dot(dA, vec3(0.3, 0.59, 0.11)) * 0.6 + dot(dB, vec3(0.3, 0.59, 0.11)) * 0.4;
        diffuseColor.rgb *= 0.55 + dl * 1.25;`).replace("#include <normal_fragment_maps>",`#include <normal_fragment_maps>
        { vec3 dn = texture2D(uDetN, vWp.xz / 2.2).xyz * 2.0 - 1.0;
          vec3 wn = normalize(vec3(dn.x * 0.6, 1.0, dn.y * 0.6));
          normal = normalize((viewMatrix * vec4(wn, 0.0)).xyz); }`)},e.customProgramCacheKey=()=>"course-ground",e}var F_=.004166666666666667,Un=[{id:"DR",carry:230,launch:11,spin:1,roll:1},{id:"3W",carry:210,launch:13.5,spin:1.12,roll:.9},{id:"5W",carry:195,launch:15,spin:1.2,roll:.82},{id:"4I",carry:180,launch:16.5,spin:1.28,roll:.72},{id:"5I",carry:170,launch:18,spin:1.34,roll:.66},{id:"6I",carry:160,launch:20,spin:1.4,roll:.6},{id:"7I",carry:150,launch:22,spin:1.46,roll:.54},{id:"8I",carry:140,launch:24.5,spin:1.52,roll:.48},{id:"9I",carry:128,launch:27,spin:1.58,roll:.42},{id:"PW",carry:115,launch:30,spin:1.64,roll:.36},{id:"AW",carry:100,launch:34,spin:1.7,roll:.3},{id:"SW",carry:82,launch:38,spin:1.76,roll:.24},{id:"LW",carry:62,launch:44,spin:1.82,roll:.18},{id:"PT",carry:0,launch:0,spin:0,roll:1,putter:!0,maxPutt:30}],Ap=2600,is={tee:[.3,.6,2.3,1],fairway:[.3,.6,2.3,1],fringe:[.26,.6,1.4,.97],green:[.22,.55,.65,1],rough:[.16,.42,4.2,.82],bunker:[.02,.08,9,.7],water:[0,0,99,1],ob:[.16,.42,4.2,1]};function Ru({x:i,z:t,dir:e,speed:n,launchDeg:s,spin:r,side:o}){let a=s*Math.PI/180,l=Math.cos(a)*n;return{x:i,y:.02,z:t,vx:Math.cos(e)*l,vy:Math.sin(a)*n,vz:Math.sin(e)*l,spin:r,side:o,phase:n>0&&s>0?"air":"roll",sx:i,sz:t,carry:0,maxY:0,t:0}}function Cu(i,t,e,n,s=1,r=null){let o=[],a=Math.ceil(t/F_),l=t/a;for(;a-- >0&&i.phase!=="rest";)if(i.t+=l,i.phase==="air"){let c=i.vx-n.x,h=i.vz-n.z,u=i.vy,d=Math.hypot(c,u,h),f=Math.hypot(c,h)||1e-6,m=-.0034*d*c,x=-.0034*d*u-9.81,g=-.0034*d*h,p=.0023*i.spin*d;m+=p*(-u*c/f),g+=p*(-u*h/f),x+=p*f;let M=.0023*i.side*d*.5;if(m+=M*-h,g+=M*c,i.vx+=m*l,i.vy+=x*l,i.vz+=g*l,i.x+=i.vx*l,i.y+=i.vy*l,i.z+=i.vz*l,i.spin*=Math.exp(-l/7),i.maxY=Math.max(i.maxY,i.y),i.y<=0&&i.vy<0){i.y=0,i.carry||(i.carry=Math.hypot(i.x-i.sx,i.z-i.sz),o.push("land"));let v=e(i.x,i.z);if(v==="water"){i.phase="rest",o.push("water");break}let[y,w]=is[v],S=w*(1.25-.32*i.spin)*s;i.vy=-i.vy*y,i.vx*=Math.max(.05,S),i.vz*=Math.max(.05,S),i.side*=.3,i.vy<1.2&&(i.vy=0,i.phase="roll")}}else if(i.phase==="roll"){let c=e(i.x,i.z);if(c==="water"){i.phase="rest",o.push("water");break}let h=r&&(c==="green"||c==="fringe")?r(i.x,i.z):null;h&&(i.vx-=9.81*.714*h[0]*l,i.vz-=9.81*.714*h[1]*l);let u=Math.hypot(i.vx,i.vz)||1e-6,d=is[c][2],f=Math.max(0,u-d*l);if(f<=.02&&(!h||9.81*.714*Math.hypot(h[0],h[1])<d*.6)){i.vx=i.vz=0,i.phase="rest";break}if(i.vx*=f/u,i.vz*=f/u,i.x+=i.vx*l,i.z+=i.vz*l,i.onRoll&&i.onRoll(i,c))break}return i.phase==="rest"&&(o.push("rest"),e(i.x,i.z)==="ob"&&o.push("ob")),o}var Au=new Map;function Rp(i,t,e){let n=`${i.toFixed(1)}|${t}|${e}`;if(Au.has(n))return Au.get(n);let s=5,r=120,o={x:0,z:0},a=()=>"fairway";for(let c=0;c<26;c++){let h=(s+r)/2,u=Ru({x:0,z:0,dir:0,speed:h,launchDeg:t,spin:e,side:0});for(;u.phase==="air"&&u.t<20;)Cu(u,1/30,a,o);u.carry<i?s=h:r=h}let l=(s+r)/2;return Au.set(n,l),l}var Cp=(i,t="green")=>Math.sqrt(2*is[t][2]*Math.max(.05,i));var Fr=class{constructor(t,e,{onChange:n,onMsg:s}={}){this.ctx=t,this.game=e,this.key=e,this.slots=[],this.state=null,this.onChange=n||(()=>{}),this.onMsg=s||(()=>{})}get net(){return this.ctx.net}get joined(){return this.slots.some(t=>t.owner===this.net.id)}mine(t){var e;return((e=this.slots[t])==null?void 0:e.owner)===this.net.id}name(t){var e;return((e=this.slots[t])==null?void 0:e.name)??"?"}onInfo(t){var e;this.slots=t.slots||[],this.state=t.state??null,(e=this.state)!=null&&e.seq&&(this.lastSeq=Math.max(this.lastSeq||0,this.state.seq)),this.onChange(this.state)}join(){this.net.send({t:"party_join",game:this.key})}addGuest(t){this.net.send({t:"party_join",game:this.key,guest:t})}removeGuest(t){this.net.send({t:"party_leave",game:this.key,slot:t})}leave(){this.net.send({t:"party_leave",game:this.key})}setKey(t,e){t!==this.key&&(this.joined&&this.leave(),this.key=t,this.slots=[],this.state=null,this.lastSeq=0,this.onChange(null),e&&this.join())}setState(t){var e;return this.lastSeq=Math.max(this.lastSeq||0,((e=this.state)==null?void 0:e.seq)||0)+1,t.seq=this.lastSeq,this.state=t,this.net.send({t:"party_state",game:this.key,state:t}),t}clear(){this.state=null,this.net.send({t:"party_state",game:this.key,state:null}),this.onChange(null)}msg(t){this.net.send({t:"party_msg",game:this.key,d:t})}};var B_=`
.gp { position: fixed; z-index: 12; color: #f4f7fb; background: rgba(14, 20, 30, .74); border: 1px solid rgba(255,255,255,.14);
  border-radius: 14px; box-shadow: 0 8px 28px rgba(0,0,0,.35); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px);
  font-weight: 700; font-size: 13px; user-select: none; -webkit-user-select: none; }
.gp h3 { margin: 0 0 6px; font-size: 12px; letter-spacing: .08em; text-transform: uppercase; opacity: .65; }
.gp .big { font-size: 26px; font-weight: 900; line-height: 1; }
.gp .mid { font-size: 17px; font-weight: 900; }
.gp .dim { opacity: .6; }
.gp .kv { display: grid; grid-template-columns: auto auto; gap: 3px 14px; }
.gp .kv b { text-align: right; font-weight: 900; }
.gp button { font: inherit; color: inherit; cursor: pointer; border: 0; border-radius: 10px; padding: 8px 12px; background: rgba(255,255,255,.12); font-weight: 900; }
.gp button:hover { background: rgba(255,255,255,.2); }
.gp button.sm { padding: 2px 8px; border-radius: 7px; }
.gp-golf-btns button { background: rgba(14,20,30,.72); }
.gp button.on { background: #ffcc33; color: #1b1b1b; }
.gp button.go { background: #2fbf71; color: #fff; }
.gp button.warn { background: #ff6b5c; color: #fff; }
.gp button:disabled { opacity: .35; cursor: default; }
.gp .row { display: flex; gap: 6px; flex-wrap: wrap; align-items: center; }
.gp table { border-collapse: collapse; width: 100%; font-variant-numeric: tabular-nums; }
.gp td, .gp th { padding: 3px 6px; text-align: center; border-bottom: 1px solid rgba(255,255,255,.08); }
.gp th { font-size: 11px; opacity: .6; font-weight: 800; }
.gp td:first-child, .gp th:first-child { text-align: left; }
.gp tr.turn td { background: rgba(255, 204, 51, .18); }
.gp .slot { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 6px 8px; border-radius: 9px; background: rgba(255,255,255,.07); margin: 4px 0; }
.gp .slot .n { width: 22px; height: 22px; border-radius: 50%; display: grid; place-items: center; background: rgba(255,255,255,.18); font-size: 12px; flex-shrink: 0; }
.gp .slot .x { padding: 2px 8px; }
.gp-lobby { left: 50%; top: 50%; transform: translate(-50%, -50%); width: min(360px, calc(100vw - 24px)); padding: 16px; }
.gp-lobby h2 { margin: 0 0 4px; font-size: 20px; }
.gp-lobby .modes { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; margin: 10px 0; }
.gp-lobby .modes button { padding: 10px 4px; }
.gp-lobby .modes small { display: block; font-size: 10px; opacity: .7; font-weight: 700; margin-top: 2px; }
.gp-meter { position: relative; height: 18px; border-radius: 999px; background: rgba(255,255,255,.12); overflow: hidden; }
.gp-meter i { position: absolute; top: 0; bottom: 0; left: 0; background: linear-gradient(90deg, #6ee7b7, #fde047, #f87171); }
.gp-meter .mark { position: absolute; top: -2px; bottom: -2px; width: 3px; background: #fff; box-shadow: 0 0 6px #fff; }
.gp-meter .zone { position: absolute; top: 0; bottom: 0; background: rgba(255,255,255,.25); }
/* golf hole result banner */
.gp-golf-banner .who { font-size: 14px; opacity: .8; }
.gp-golf-banner .name { font-size: 54px; font-weight: 900; letter-spacing: .02em; text-shadow: 0 3px 14px rgba(0,0,0,.5); line-height: 1.1; }
.gp-golf-banner .sub { font-size: 16px; opacity: .85; margin-top: 4px; }
.gp-golf-banner.pop { animation: gbPop .5s cubic-bezier(.2,1.6,.4,1); }
@keyframes gbPop { from { transform: translate(-50%,-50%) scale(.4); opacity: 0; } to { transform: translate(-50%,-50%) scale(1); opacity: 1; } }
/* fishing float close-up */
.gp-fish-pip { border-radius: 14px !important; box-shadow: 0 6px 22px rgba(0,0,0,.4) !important; backdrop-filter: none !important; -webkit-backdrop-filter: none !important; }
.gp-fish-pip .pipLabel { position: absolute; left: 8px; top: 6px; font-size: 12px; text-shadow: 0 1px 3px #000; }
.gp-fish-pip .pipHint { position: absolute; right: 10px; top: 4px; font-size: 26px; animation: pipBlink .3s infinite alternate; }
@keyframes pipBlink { from { opacity: 1; } to { opacity: .3; } }
/* free-view pad (built in main.js), placed per game where nothing else lives */
#viewPad { position: fixed; z-index: 11; display: grid; grid-template-columns: repeat(3, 32px); gap: 3px; padding: 5px;
  background: rgba(14,20,30,.55); border-radius: 12px; backdrop-filter: blur(6px); -webkit-backdrop-filter: blur(6px); user-select: none; -webkit-user-select: none; touch-action: none; }
#viewPad[hidden] { display: none; }
.gp-lobby .slots.two { display: grid; grid-template-columns: 1fr 1fr; column-gap: 8px; }
#viewPad button { width: 32px; height: 30px; padding: 0; border: 0; border-radius: 8px; background: rgba(255,255,255,.14); color: #fff; font: 900 13px system-ui, sans-serif; cursor: pointer; touch-action: none; }
#viewPad button:hover { background: rgba(255,255,255,.26); }
#viewPad button[data-v=reset] { background: rgba(255,200,80,.3); }
body[data-mode=golf] #viewPad { right: 10px; bottom: max(14px, env(safe-area-inset-bottom)); }
body[data-mode=fishing] #viewPad { right: 10px; top: calc(max(10px, env(safe-area-inset-top)) + 268px); }
body[data-mode=billiards] #viewPad { right: 10px; top: calc(max(10px, env(safe-area-inset-top)) + 64px); }
@media (max-width: 720px) {
  #viewPad { grid-template-columns: repeat(3, 28px); gap: 2px; padding: 4px; }
  #viewPad button { width: 28px; height: 26px; font-size: 12px; }
  body[data-mode=golf] #viewPad { bottom: auto; top: calc(max(10px, env(safe-area-inset-top)) + 356px); }
  body[data-mode=fishing] #viewPad { right: auto; left: 8px; top: calc(max(10px, env(safe-area-inset-top)) + 216px); }
  body[data-mode=billiards] #viewPad { right: auto; left: 8px; top: calc(max(10px, env(safe-area-inset-top)) + 200px); }
}
@media (max-width: 720px) {
  .gp { font-size: 12px; } .gp .big { font-size: 20px; } .gp .mid { font-size: 15px; }
  .gp button { padding: 7px 9px; }
  /* golf */
  .gp-golf-bottom { left: 8px !important; right: 124px !important; width: auto !important; transform: none !important; padding: 8px !important; }
  .gp-golf-bottom #gClubs button { padding: 4px 5px !important; font-size: 11px; }
  .gp-golf-bottom #gHelp { display: none; }
  .gp-golf-btns { top: calc(max(10px, env(safe-area-inset-top)) + 150px) !important; bottom: auto !important; }
  .gp-golf-map canvas { width: 92px; height: auto; }
  .gp-golf-map { top: calc(max(10px, env(safe-area-inset-top)) + 186px) !important; }
  .gp-golf-shot { top: calc(max(10px, env(safe-area-inset-top)) + 196px) !important; }
  /* billiards */
  .gp-bill-help { display: none; }
  .gp-bill-board { top: calc(max(10px, env(safe-area-inset-top)) + 96px) !important; padding: 6px 8px !important; }
  .gp-bill-board th:nth-child(5), .gp-bill-board td:nth-child(5) { display: none; }
  .gp-bill-left { width: 124px !important; padding: 8px !important; }
  .gp-bill-left canvas { width: 84px; height: 84px; }
  .gp-bill-right { padding: 8px !important; }
  .gp-bill-right #bGauge { height: 140px !important; width: 46px !important; }
  .gp-bill-right .row button { padding: 6px 7px; }
  /* fishing */
  .gp-fish { width: calc(100vw - 140px) !important; left: 8px !important; transform: none !important; }
  .gp-fish #fHelp { display: none; }
  .gp-fish-pip { width: 150px !important; height: 112px !important; top: calc(max(10px, env(safe-area-inset-top)) + 96px) !important; }
  .gp-fish-card { top: 34% !important; }
}
/* in a game on a phone the chat folds up under the top bar */
@media (max-width: 720px) {
  body.ingame #chat { bottom: auto; left: auto; right: 10px; top: 55%; width: auto; align-items: flex-end; }
  body.ingame #btnGlobe { display: none; }
  body.ingame #chat:not(.open) #log, body.ingame #chat:not(.open) #chatForm { display: none; }
  body.ingame #chat.open { width: calc(100vw - 20px); z-index: 20; }
  body.ingame #chat.open #chatToggle { align-self: flex-end; }
}
`,Pp=!1;function De(i,t=""){if(!Pp){let n=document.createElement("style");n.textContent=B_,document.head.append(n),Pp=!0}let e=document.createElement("div");e.className=`gp ${i}`,e.innerHTML=t,e.hidden=!0;for(let n of["pointerdown","touchstart"])e.addEventListener(n,s=>s.stopPropagation(),{passive:!0});return document.body.append(e),e}function Pe(i){return String(i).replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t])}var Br=class{constructor({title:t,modes:e,onStart:n,onExit:s,max:r=4}){var o;this.max=r,this.el=De("gp-lobby"),this.title=t,this.modes=e,this.mode=(o=e==null?void 0:e[0])==null?void 0:o[0],this.onStart=n,this.onExit=s,this.guestN=1}show(t){this.party=t,this.el.hidden=!1,this.render()}hide(){this.el.hidden=!0}render(){if(this.el.hidden)return;let t=this.party,e=t.slots,n=t.ctx.net.id,s=t.joined,r=`<h2>${Pe(this.title)}</h2><div class="dim">${t.key&&t.key.includes("~")?"\u{1F389} \uC6B0\uB9AC \uD30C\uD2F0\uB07C\uB9AC\uB9CC \uBCF4\uB294 \uC790\uB9AC \xB7 ":""}${U("partyHint",{n:this.max})}</div>`;this.modes&&(r+='<div class="modes">'+this.modes.map(([o,a,l])=>`<button data-mode="${o}" class="${o===this.mode?"on":""}">${Pe(a)}<small>${Pe(l||"")}</small></button>`).join("")+"</div>"),r+=`<h3 style="margin-top:10px">${U("party")} ${e.length}/${this.max}</h3><div class="slots${this.max>4?" two":""}">`;for(let o=0;o<this.max;o++){let a=e[o];if(a){let l=a.owner===n&&a.guest?`<button class="x" data-rm="${o}">\u2715</button>`:"";r+=`<div class="slot"><span class="n">${o+1}</span><span style="flex:1">${Pe(a.name)}${a.guest?` <span class="dim">(${U("guest")})</span>`:""}${a.owner===n&&!a.guest?` <span class="dim">(${U("me")})</span>`:""}</span>${l}</div>`}else r+=`<div class="slot dim"><span class="n">${o+1}</span><span style="flex:1">${U("emptySlot")}</span></div>`}r+="</div>",r+='<div class="row" style="margin-top:10px">',r+=s?`<button data-a="leave">${U("leaveParty")}</button>`:`<button data-a="join" class="on">${U("joinParty")}</button>`,r+=`<button data-a="guest" ${!s||e.length>=this.max?"disabled":""}>\uFF0B ${U("addGuest")}</button>`,r+=`<span style="flex:1"></span><button data-a="exit">${U("exit")}</button>`,r+=`<button data-a="start" class="go" ${s?"":"disabled"}>${U("startGame")}</button></div>`,this.el.innerHTML=r,this.max>4&&(this.el.style.width="min(560px, calc(100vw - 24px))"),this.el.querySelectorAll("[data-mode]").forEach(o=>o.onclick=()=>{this.mode=o.dataset.mode,this.render()}),this.el.querySelectorAll("[data-rm]").forEach(o=>o.onclick=()=>t.removeGuest(+o.dataset.rm)),this.el.querySelectorAll("[data-a]").forEach(o=>o.onclick=()=>{let a=o.dataset.a;a==="join"&&t.join(),a==="leave"&&t.leave(),a==="guest"&&t.addGuest(`${U("guest")} ${++this.guestN-1}`),a==="exit"&&this.onExit(),a==="start"&&this.onStart(this.mode)})}};var El=.03,Ip=.06;function O_(){var e;if(!((e=ze[0])!=null&&e.real))return[["3",U("golf3"),"Par 12"],["1",U("golf1"),"Par 4"],["2",U("golf1b"),"Par 3"]];let i=n=>"Par "+n.reduce((s,r)=>s+r.par,0),t=[["all",`\uC804\uCCB4 ${ze.length}\uD640`,i(ze)]];return ze.length>=18&&t.push(["f9","\uC804\uBC18 9\uD640",i(ze.slice(0,9))],["b9","\uD6C4\uBC18 9\uD640",i(ze.slice(9,18))]),t.push(["1","1\uBC88 \uD640",i(ze.slice(0,1))]),t}var Pu=8,Tl=["#ffffff","#ffe14d","#ff8fa3","#74c0fc","#8ce99a","#ffa94d","#da77f2","#66d9e8"],H_=Tl.map(i=>parseInt(i.slice(1),16));function Iu(i){let t=new Qt,e=i==="wood"?1:i==="iron"?.92:.82,n=new nt(new zt(.008,.012,e,6),Pt(13685978,{metalness:.9,roughness:.25}));n.position.y=-e/2;let s=new nt(new zt(.016,.014,.24,8),Pt(2236962,{roughness:.8}));s.position.y=-.1;let r;return i==="wood"?(r=new nt(new Ce(.06,16,10),Pt(1908516,{metalness:.6,roughness:.25})),r.scale.set(1,.6,1.25)):i==="iron"?(r=new nt(new Xt(.02,.05,.085),Pt(13225686,{metalness:.95,roughness:.2})),r.rotation.x=.3):r=new nt(new Xt(.06,.03,.12),Pt(5593696,{metalness:.9,roughness:.3})),r.position.y=-e,t.add(n,s,r),t}var V_=i=>i.putter?"putter":/W|DR/.test(i.id)&&!/AW|SW|LW|PW/.test(i.id)?"wood":"iron",Al=class{constructor(t){this.ctx=t,this.course=new Sl(t.scene,t.venue.id),this.balls=H_.map(o=>{let a=new nt(new Ce(El,18,12),Pt(16777215,{roughness:.25,emissive:o,emissiveIntensity:o===16777215?0:.25}));return a.castShadow=!0,a.visible=!1,t.scene.add(a),a}),this.tracerPts=new Float32Array(900*3);let e=new ce;e.setAttribute("position",new Oe(this.tracerPts,3)),e.setDrawRange(0,0),this.tracer=new Gn(e,new ki({color:16765503,transparent:!0,opacity:.9})),this.tracer.frustumCulled=!1,t.scene.add(this.tracer),this.aimLine=new Gn(new ce().setFromPoints([new P,new P(1,0,0)]),new Tr({color:16777215,dashSize:1.2,gapSize:.8,transparent:!0,opacity:.75})),this.aimLine.frustumCulled=!1,this.ring=new nt(new yn(.85,1,40),new ke({color:16777215,transparent:!0,opacity:.8,side:Te})),this.ring.rotation.x=-Math.PI/2,this.aimLine.visible=this.ring.visible=!1,t.scene.add(this.aimLine,this.ring);let n=520,s=new ce;s.setAttribute("position",new Oe(new Float32Array(n*6),3));let r=new Float32Array(n*6);for(let o=0;o<n;o++)r.set([1,1,1],o*6),r.set([.42,.62,.3],o*6+3);s.setAttribute("color",new Oe(r,3)),this.flow=new ja(s,new ki({vertexColors:!0,transparent:!0,opacity:.9,depthWrite:!1})),this.flow.frustumCulled=!1,this.flow.visible=!1,this.flowLife=new Float32Array(n),t.scene.add(this.flow),this.props={wood:Iu("wood"),iron:Iu("iron"),putter:Iu("putter")},this.club=0,this.aim=0,this.swing={phase:"idle",v:0,power:0},this.flight=null,this.focus=new P,this.appliedSeq=-1,this.party=new Fr(t,"golf",{onChange:o=>this.onParty(o),onMsg:o=>this.onPartyMsg(o)}),this.buildUI(),addEventListener("keydown",o=>{var a;!this.active||/INPUT|SELECT|TEXTAREA/.test((a=document.activeElement)==null?void 0:a.tagName)||(o.code==="KeyQ"&&this.pickClub(this.club-1),(o.code==="KeyE"||o.code==="KeyR")&&this.pickClub(this.club+1),o.code==="Tab"&&(o.preventDefault(),this.ui.card.hidden=!this.ui.card.hidden,this.renderCard()))}),addEventListener("wheel",o=>{this.active&&this.myTurn()&&this.pickClub(this.club+Math.sign(o.deltaY))},{passive:!0})}buildUI(){var e,n;if(this.uiLang=hn(),this.ui)for(let s of Object.values(this.ui))(e=s.classList)!=null&&e.contains("gp")&&s.remove();(n=this.lobby)==null||n.el.remove(),this.lobby=new Br({title:`\u26F3 ${U("screenGolf")}`,modes:O_(),onStart:s=>this.start(s),onExit:()=>this.ctx.exit(),max:Pu});let t=this.ui={};t.top=De("gp-golf-top",""),t.banner=De("gp-golf-banner",""),t.banner.style.cssText="left:50%;top:30%;transform:translate(-50%,-50%);padding:18px 36px;text-align:center;pointer-events:none;background:rgba(10,16,26,.82)",t.top.style.cssText="left:10px;top:calc(max(10px, env(safe-area-inset-top)) + 54px);padding:10px 14px;min-width:200px",t.info=De("gp-golf-info",""),t.info.style.cssText="right:10px;top:calc(max(10px, env(safe-area-inset-top)) + 54px);padding:10px 14px;text-align:right;min-width:150px",t.mapWrap=De("gp-golf-map",'<canvas width="150" height="230" style="display:block;border-radius:10px"></canvas>'),t.mapWrap.style.cssText="right:10px;top:calc(max(10px, env(safe-area-inset-top)) + 196px);padding:6px",t.map=t.mapWrap.querySelector("canvas"),t.bottom=De("gp-golf-bottom",""),t.bottom.style.cssText="left:50%;transform:translateX(-50%);bottom:max(14px, env(safe-area-inset-bottom));padding:10px 12px;width:min(640px, calc(100vw - 150px))",t.bottom.innerHTML=`<div class="row" id="gClubs" style="justify-content:center;gap:4px"></div>
      <div style="display:flex;align-items:center;gap:10px;margin-top:8px"><div class="gp-meter" style="flex:1" id="gMeter"><span class="zone"></span><i></i><span class="mark"></span></div>
      <div id="gMeterLbl" style="min-width:86px;text-align:right" class="mid"></div></div>
      <div class="dim" id="gHelp" style="margin-top:6px;text-align:center;font-size:11px"></div>`,t.clubs=t.bottom.querySelector("#gClubs"),t.meter=t.bottom.querySelector("#gMeter"),t.meterLbl=t.bottom.querySelector("#gMeterLbl"),t.help=t.bottom.querySelector("#gHelp");for(let s=0;s<Un.length;s++){let r=document.createElement("button");r.textContent=Un[s].id,r.style.padding="6px 7px",r.onclick=()=>this.pickClub(s),t.clubs.append(r)}t.shot=De("gp-golf-shot",""),t.shot.style.cssText="left:10px;top:calc(max(10px, env(safe-area-inset-top)) + 200px);padding:10px 14px;min-width:190px",t.card=De("gp-golf-card",""),t.card.style.cssText="left:50%;top:50%;transform:translate(-50%,-50%);padding:14px;width:min(520px, calc(100vw - 24px))",t.btns=De("gp-golf-btns",`<div class="row"><button data-a="card">\u{1F4CB} ${U("scoreCard")}</button><button data-a="exit">${U("exit")}</button></div>`),t.btns.style.cssText="left:10px;top:calc(max(10px, env(safe-area-inset-top)) + 150px);padding:6px;background:transparent;border:0;box-shadow:none;backdrop-filter:none",t.btns.querySelector("[data-a=card]").onclick=()=>{t.card.hidden=!t.card.hidden,this.renderCard()},t.btns.querySelector("[data-a=exit]").onclick=()=>this.ctx.exit()}showUI(t){for(let e of["top","info","mapWrap","bottom","btns"])this.ui[e].hidden=!t;t||(this.ui.shot.hidden=!0,this.ui.card.hidden=!0,this.ui.banner.hidden=!0)}pickClub(t){var r,o;let e=this.party.state,n=(r=e==null?void 0:e.balls)==null?void 0:r[e.turn],s=n&&this.course.lie(n.x,n.z)==="green";t=Math.max(0,Math.min(Un.length-1,t)),s&&(t=Un.length-1),this.swing.phase==="idle"&&(this.club=t,(o=this.ctx.avatar)==null||o.setProp(this.props[V_(Un[t])]),[...this.ui.clubs.children].forEach((a,l)=>a.classList.toggle("on",l===t)))}autoClub(t,e,n){var o;if(e==="green")return Un.length-1;let s=((o=is[e])==null?void 0:o[3])||1,r=0;for(let a=0;a<Un.length-1;a++)Un[a].carry*s>=t*.97&&(r=a);return r===0&&!n&&(r=1),r}enter(){this.active=!0;let t=this.ctx;t.hud.hide(),this.uiLang!==hn()&&(this.buildUI(),this.mapBg=null),this.course.visible=!0,this.savedFog=[t.scene.fog.near,t.scene.fog.far],t.scene.fog.near=160,t.scene.fog.far=1300,this.savedGrass=t.world.isGrass,t.world.isGrass=(e,n)=>{let s=this.course.lie(e,n);return s==="rough"||s==="ob"},this.course.build(0),t.player.pos.copy(this.course.tee).add(new P(-2,0,-2)),this.focus.copy(this.course.tee),!this.party.joined&&this.party.slots.length<Pu&&!this.party.state&&this.party.join(),this.onParty(this.party.state)}exit(){var e;this.active=!1;let t=this.ctx;this.course.visible=!1,this.savedFog&&(t.scene.fog.near=this.savedFog[0],t.scene.fog.far=this.savedFog[1]),this.savedGrass&&(t.world.isGrass=this.savedGrass),this.party.leave(),this.lobby.hide(),this.showUI(!1),this.balls.forEach(n=>n.visible=!1),this.aimLine.visible=this.ring.visible=this.tracer.visible=!1,Do("#btnPower").hidden=!0,(e=t.avatar)==null||e.setProp(null),t.avatar&&(t.avatar.swingPose=null),this.flight=null,this.swing.phase="idle"}holeIdx(t=this.party.state){return t?t.holes[t.h]:0}myTurn(){let t=this.party.state;return!!t&&t.phase==="play"&&!this.flight&&!t.holeDone&&this.party.mine(t.turn)}start(t){let e=this.party.slots.length;if(!e)return;let n=ze.map((o,a)=>a),r={phase:"play",holes:Array.isArray(t)?t:t==="all"?n:t==="f9"?n.slice(0,9):t==="b9"?n.slice(9,18):t==="1"?[0]:t==="2"?[1]:[0,1,2],h:0,turn:0,balls:[],cards:Array.from({length:e},()=>[])};this.resetHole(r),this.party.setState(r),this.onParty(r)}resetHole(t){let e=this.course.toWorld(0,0),n=Is(`${this.ctx.venue.id}|wind|${t.holes[t.h]}|${t.seq||0}`),s=n()*6,r=n()*Math.PI*2;t.wind={x:+(Math.cos(r)*s).toFixed(2),z:+(Math.sin(r)*s).toFixed(2)},t.balls=this.party.slots.map((o,a)=>({x:e.x,z:e.z+(a-3.5)*.02,s:0,holed:!1,pen:0,prev:null})),t.turn=this.honorOrder(t)[0]??0,t.holeDone=!1}honorOrder(t){let e=t.balls.map((n,s)=>s);return t.h===0?e:e.sort((n,s)=>(t.cards[n][t.h-1]??99)-(t.cards[s][t.h-1]??99)||n-s)}onParty(t){if(!this.active)return;if(!t){this.showUI(!1),this.balls.forEach(n=>n.visible=!1),this.lobby.show(this.party),Do("#btnPower").hidden=!0;return}if(this.lobby.hide(),this.showUI(!0),t.seq===this.appliedSeq)return;this.appliedSeq=t.seq,this.flight&&!this.flight.mine&&(this.flight=null);let e=this.holeIdx(t);this.course.index!==e&&(this.course.build(e),this.renderMapBg(),this.flyT=2.6),(t.phase==="done"||t.holeDone)&&(this.ui.card.hidden=!1),this.prepareTurn(),this.renderCard()}onPartyMsg(t){if(!this.active)return;let e=t.d;e.k==="shot"&&this.startFlight(e.slot,e.p,!1),e.k==="score"&&this.showScore(e)}showScore(t){var o;let e=this.ui.banner,n=t.n-t.par,s=t.n===1?"holeInOne":["sc_m3","sc_m2","sc_m1","sc_0","sc_1","sc_2","sc_3"][Math.max(0,Math.min(6,n+3))],r=t.pickup?"#cbd5e1":n<=-2||t.n===1?"#fde047":n===-1?"#7dd3fc":n===0?"#86efac":"#fca5a5";e.innerHTML=`<div class="who">${Pe(this.party.name(t.slot))}</div>
      <div class="name" style="color:${r}">${t.pickup?U("pickup"):U(s)}${n<0||t.n===1?"!":""}</div>
      <div class="sub">${U("nStrokes",{n:t.n})} \xB7 ${n===0?"E":(n>0?"+":"")+n}</div>`,e.hidden=!1,e.classList.remove("pop"),e.offsetWidth,e.classList.add("pop"),clearTimeout(this.bannerT),this.bannerT=setTimeout(()=>{e.hidden=!0},3200),n<0&&((o=this.ctx.audio)==null||o.chime())}prepareTurn(){var o,a;let t=this.party.state;if(!t||t.phase!=="play")return;let e=t.balls[t.turn];if(!e)return;let n=this.course.pin;this.aim=Math.atan2(n.z-e.z,n.x-e.x);let s=this.course.lie(e.x,e.z),r=Math.hypot(n.x-e.x,n.z-e.z);this.pickClub(this.autoClub(r,s,e.s===0)),this.swing={phase:"idle",v:0,power:0},(a=(o=this.ctx).snap)==null||a.call(o),Do("#btnPower").hidden=!(pt.touch&&this.myTurn()),Do("#btnPower").textContent=U("swing"),this.renderCard()}powerDown(){var n;if(!this.myTurn())return;let t=this.swing,e=Un[this.club];t.phase==="idle"?(t.phase="back",t.v=0,(n=this.ctx.audio)==null||n.click(.3),this.ui.shot.hidden=!0,this.tracer.visible=!1):t.phase==="down"?this.impact(t.v):e.putter&&t.phase}powerUp(){let t=this.swing;if(t.phase==="back"){if(t.power=Math.max(.03,t.v),Un[this.club].putter)return this.impact(0);t.phase="down"}}impact(t){var l,c;let e=this.party.state,n=this.swing,s=Un[this.club],r=e.balls[e.turn],o=this.course.lie(r.x,r.z);n.phase="follow",n.t=0;let a;if(s.putter){let h=n.power*s.maxPutt;a={x:r.x,z:r.z,dir:this.aim,speed:Cp(h,o==="green"||o==="fringe"?o:"fairway"),launchDeg:0,spin:0,side:0,rollMul:1,putt:1}}else{let h=Sp(s),u=Math.max(-.25,Math.min(.25,t))*h.acc,d=Math.min(.3,Math.max(0,Math.abs(u)-.025)*1.6),f=Math.min(1.06,n.power),m=s.carry*h.carry*f*(1-d)*(((l=is[o])==null?void 0:l[3])||1),x=Rp(m,s.launch,s.spin);a={x:r.x,z:r.z,dir:this.aim+u*.09,speed:x,launchDeg:s.launch*(o==="bunker"?1.15:1),spin:s.spin*(.85+f*.15),side:u*4.2,rollMul:s.roll,err:u}}(c=this.ctx.audio)==null||c.click(s.putter?.5:1),this.party.msg({k:"shot",slot:e.turn,p:a}),this.startFlight(e.turn,a,!0),Do("#btnPower").hidden=!0}startFlight(t,e,n){let s=Ru(e),r=this.course.pin,o=this.party.state;s.onRoll=(a,l)=>{if(l!=="green"&&l!=="fringe")return!1;let c=Math.hypot(a.x-r.x,a.z-r.z),h=Math.hypot(a.vx,a.vz);if(c<Ip&&h<1.6)return a.holed=!0,a.phase="rest",a.x=r.x,a.z=r.z,!0;if(c<Ip*1.4&&h>=1.6){let u=(a.x-r.x)/c,d=(a.z-r.z)/c;a.vx+=u*.6,a.vz+=d*.6}return!1},this.flight={s,slot:t,p:e,mine:n,n:0,t:0,from:{x:e.x,z:e.z},dir:e.dir,lastDry:{x:e.x,z:e.z},restT:0},this.tracer.visible=!e.putt,this.tracer.geometry.setDrawRange(0,0),this.swing.phase=this.swing.phase==="follow"?"follow":"idle"}finishShot(t,e){var u;let n=structuredClone(this.party.state),s=n.balls[t.slot],r=t.s;s.prev={x:t.from.x,z:t.from.z},s.s+=1;let o="";if(e.includes("water")){s.s+=1,s.pen++;let d=this.dropPoint(t.lastDry,r);s.x=d.x,s.z=d.z,o=`\u{1F4A6} ${U("penaltyWater")}`}else e.includes("ob")?(s.s+=1,s.pen++,s.x=t.from.x,s.z=t.from.z,o=`\u{1F6A9} ${U("penaltyOB")}`):(s.x=+r.x.toFixed(3),s.z=+r.z.toFixed(3));let a=ze[this.holeIdx(n)].par;if(r.holed?(s.holed=!0,o=this.scoreName(s.s,a)):s.s>=a*2&&(s.holed=!0,s.pickup=!0,o=U("pickup")),r.holed||s.pickup){let d={k:"score",slot:t.slot,n:s.s,par:a,pickup:!!s.pickup};this.party.msg(d),this.showScore(d)}else o&&this.ctx.toast(o);r.holed&&((u=this.ctx.audio)==null||u.chime(),this.ctx.net.event({type:"sink",hole:n.h+1,n:s.s}));let l=n.balls.map((d,f)=>f).filter(d=>!n.balls[d].holed);if(!l.length){n.balls.forEach((f,m)=>{n.cards[m][n.h]=f.s}),n.holeDone=!0,this.party.setState(n),this.onParty(n);let d=n.seq;setTimeout(()=>this.nextHole(d),3800),this.ui.card.hidden=!1,this.renderCard();return}let c=this.course.pin,h=this.honorOrder(n).filter(d=>!n.balls[d].holed&&n.balls[d].s===0);n.turn=h.length?h[0]:l.sort((d,f)=>Math.hypot(n.balls[f].x-c.x,n.balls[f].z-c.z)-Math.hypot(n.balls[d].x-c.x,n.balls[d].z-c.z))[0],this.party.setState(n),this.onParty(n)}nextHole(t){let e=this.party.state;if(!e||e.seq!==t)return;let n=structuredClone(e);n.h+1>=n.holes.length?(n.phase="done",n.holeDone=!1):(n.h++,this.course.build(n.holes[n.h]),this.resetHole(n)),this.ui.card.hidden=n.phase!=="done",this.party.setState(n),this.onParty(n)}dropPoint(t,e){let n=this.course.pin,s=t.x,r=t.z;for(let o=0;o<80&&this.course.lie(s,r)==="water";o++){let a=Math.hypot(s-n.x,r-n.z);s+=(s-n.x)/a,r+=(r-n.z)/a}return{x:+s.toFixed(2),z:+r.toFixed(2)}}toPar(t,e){var o;let n=0,s=0;(o=t.cards[e])==null||o.forEach((a,l)=>{a&&(n+=a,s+=ze[t.holes[l]].par)});let r=n-s;return r===0?"E":(r>0?"+":"")+r}scoreName(t,e){if(t===1)return`\u{1F3C6} ${U("holeInOne")}`;let n=t-e;return`\u26F3 ${U(["sc_m3","sc_m2","sc_m1","sc_0","sc_1","sc_2","sc_3"][Math.max(0,Math.min(6,n+3))])} (${t})`}update(t){var g,p,M,v;let e=this.party.state;this.course.update(performance.now()/1e3);let n=es(),s=this.ctx.camTarget,r=this.ctx.player;if(r.speed=0,!e||e.phase!=="play"){let y=performance.now()/6e3,w=this.course.tee;s.pos.set(w.x-14+Math.cos(y)*4,6,w.z+Math.sin(y)*8),s.look.set(w.x+60,0,w.z),this.balls.forEach(S=>S.visible=!1),this.aimLine.visible=this.ring.visible=this.flow.visible=!1;return}e.balls.forEach((y,w)=>{var T;let S=this.balls[w];S.visible=!y.holed||((T=this.flight)==null?void 0:T.slot)===w,this.flight&&this.flight.slot===w||S.position.set(y.x,El,y.z)});for(let y=e.balls.length;y<Pu;y++)this.balls[y].visible=!1;let o=e.balls[e.turn],a=Un[this.club],l=this.course.pin;if(this.flight)this.updateFlight(t);else if(this.myTurn()){this.aim+=Dr(t)*(a.putter?.25:.5)-n.x*(a.putter?.0012:.0025),this.camPitch=Math.max(-.25,Math.min(1,(this.camPitch||0)+n.y*.003));let y=this.swing;y.phase==="back"?(y.v=Math.min(1.1,y.v+t/(a.putter?1.6:1.05)),y.v>=1.1&&!a.putter&&(y.power=1.1,y.phase="down")):y.phase==="down"&&(y.v-=t*(y.power+.25)/.45,y.v<-.25&&this.impact(-.25))}let c=this.flight?this.flight.from:o,h=this.flight?this.flight.dir:this.aim,u=new P(Math.cos(h),0,Math.sin(h)),d=new P(-u.z,0,u.x);if(this.party.mine(this.flight?this.flight.slot:e.turn))r.pos.set(c.x-d.x*.62,0,c.z-d.z*.62),r.yaw=Math.atan2(d.x,d.z);else{let y=e.balls.findIndex((S,T)=>this.party.mine(T)),w=e.balls[y]||o;r.pos.set(w.x-2.5,0,w.z-2.5)}let f=this.swing,m=this.ctx.avatar;if(m){let y=a.putter?.22:1,w=0;f.phase==="back"?w=-Math.min(1,f.v)*y:f.phase==="down"?w=-Math.max(0,Math.min(1,f.v/Math.max(.05,f.power)))*Math.min(1,f.power)*y:f.phase==="follow"&&(f.t+=t,w=Math.min(1,f.t*5)*y,f.t>2.2&&(f.phase="idle"));let S=this.party.mine(this.flight?this.flight.slot:e.turn);m.swingPose=S||f.phase!=="idle"?w:null}let x=!this.flight&&this.myTurn();if(this.aimLine.visible=this.ring.visible=x,x){let y=this.course.lie(o.x,o.z),w=f.phase==="back"||f.phase==="down"?Math.min(1.06,f.power||f.v):1,S=a.putter?Math.max(.3,(f.phase==="idle"?Math.min(1,Math.hypot(l.x-o.x,l.z-o.z)/a.maxPutt):w)*a.maxPutt):a.carry*w*(((g=is[y])==null?void 0:g[3])||1),T=new P(o.x,.04,o.z),R=T.clone().addScaledVector(u,S);this.aimLine.geometry.setFromPoints([T,R]),this.aimLine.computeLineDistances(),this.aimLine.material.dashSize=a.putter?.15:1.2,this.aimLine.material.gapSize=a.putter?.1:.8,this.ring.position.set(R.x,.05,R.z),this.ring.scale.setScalar(a.putter?.25:Math.max(1.5,S*.05)),this.expect=S}if(this.flyT>0){this.flyT-=t;let y=1-Math.max(0,this.flyT)/2.6,w=y*y*(3-2*y),S=this.course.tee;s.pos.set(l.x+(S.x-8-l.x)*w,60-56*w,l.z+(S.z-l.z)*w),s.look.set(l.x+(S.x+40-l.x)*w*.3,0,l.z+(S.z-l.z)*w*.3),w<.98&&((M=(p=this.ctx).snap)==null||M.call(p))}else if(this.flight)this.flightCamera(s);else{let y=a.putter,w=this.camPitch||0;s.pos.set(o.x,(y?1.25:1.9)+w*(y?3.2:9),o.z).addScaledVector(u,(y?-2.8:-4.6)-w*(y?1.2:4)).addScaledVector(d,y?.5:1.1),s.look.set(o.x,0,o.z).addScaledVector(u,(y?3.5:28)*(1+w*(y?.6:2.2)))}this.focus.set(this.flight?this.flight.s.x:o.x,0,this.flight?this.flight.s.z:o.z),this.updateHud(e,o,a,l);{let y=this.course.lie(o.x,o.z);this.updateFlow(t,(y==="green"||y==="fringe")&&(!this.flight||((v=this.flight.p)==null?void 0:v.putt)))}}updateFlight(t){let e=this.flight,n=e.s,s=this.party.state,r=Cu(n,t,(a,l)=>this.course.lie(a,l),n.phase==="air"?s.wind:{x:0,z:0},e.p.rollMul,(a,l)=>this.course.slopeAt(a,l));if(n.phase==="air"&&this.course.trees){for(let[a,l,c,h]of this.course.trees)if(n.y<h&&n.y>1.5&&Math.hypot(n.x-a,n.z-l)<c*.7){n.vx*=.25,n.vz*=.25,n.vy=Math.min(n.vy,0);break}}e.t+=t,this.course.lie(n.x,n.z)!=="water"&&(e.lastDry.x=n.x,e.lastDry.z=n.z),this.balls[e.slot].position.set(n.x,El+n.y,n.z),this.tracer.visible&&e.n<900&&(e.n===0||n.phase==="air")&&(this.tracerPts.set([n.x,El+n.y,n.z],e.n*3),e.n++,this.tracer.geometry.setDrawRange(0,e.n),this.tracer.geometry.attributes.position.needsUpdate=!0),r.includes("land")&&!e.p.putt&&this.showShotData(e,!1),n.phase==="rest"&&(e.done||(e.done=!0,e.ev=r,this.showShotData(e,!0)),e.restT+=t,e.restT>1.4&&(this.flight=null,e.mine&&this.finishShot(e,e.ev)))}flightCamera(t){let e=this.flight,n=e.s,s=new P(n.x,n.y,n.z);Math.hypot(n.vx,n.vz)>.5&&(e.camDir=Math.atan2(n.vz,n.vx));let o=e.camDir??e.dir,a=new P(Math.cos(o),0,Math.sin(o));if(e.p.putt)t.pos.set(e.from.x,1.4,e.from.z).addScaledVector(a,-2.4).lerp(s.clone().setY(1.2),Math.min(.7,e.t*.25)),t.look.copy(s);else if(e.t<.9)t.pos.set(e.from.x,1.9,e.from.z).addScaledVector(a,-4.8).addScaledVector(new P(-a.z,0,a.x),1.1),t.look.copy(s);else{let l=n.phase==="air"?14:7;t.pos.copy(s).addScaledVector(a,-l),t.pos.y=Math.max(1.6,n.y*.75+3.2),t.look.copy(s)}}showShotData(t,e){let n=t.p,s=t.s,r=this.ui.shot;if(n.putt){if(!e)return;r.innerHTML=`<h3>${U("shotData")}</h3><div class="kv"><span>${U("total")}</span><b>${Math.hypot(s.x-t.from.x,s.z-t.from.z).toFixed(1)} m</b></div>`}else{let o=Math.hypot(s.x-t.from.x,s.z-t.from.z),a=Math.round(n.spin*Ap/50)*50,l=Math.round(n.side*380/10)*10;r.innerHTML=`<h3>${U("shotData")} \xB7 ${this.party.name(t.slot)}</h3><div class="kv">
        <span>${U("ballSpeed")}</span><b>${n.speed.toFixed(1)} m/s</b>
        <span>${U("launchAngle")}</span><b>${n.launchDeg.toFixed(1)}\xB0</b>
        <span>${U("backSpin")}</span><b>${a} rpm</b>
        <span>${U("sideSpin")}</span><b>${l>0?"R ":l<0?"L ":""}${Math.abs(l)} rpm</b>
        <span>${U("apex")}</span><b>${s.maxY.toFixed(1)} m</b>
        <span>${U("carry")}</span><b>${(s.carry||o).toFixed(1)} m</b>
        <span>${U("total")}</span><b>${e?o.toFixed(1)+" m":"\u2026"}</b></div>`}r.hidden=!1}viewPivot(){return this.focus}greenRead(t,e){let n=this.course.slopeAt(t.x,t.z),s=this.course.lie(t.x,t.z);if(!n||s!=="green"&&s!=="fringe")return"";let r=Math.hypot(e.x-t.x,e.z-t.z)||1,o=(e.x-t.x)/r,a=(e.z-t.z)/r,l=(n[0]*o+n[1]*a)*100,c=-(n[0]*-a+n[1]*o)*100,h=Math.abs(l)<.3?U("flat"):`${l>0?U("slopeUp"):U("slopeDown")} ${Math.abs(l).toFixed(1)}%`,u=Math.abs(c)<.3?"":` \xB7 ${c>0?U("breakR"):U("breakL")} ${Math.abs(c).toFixed(1)}%`;return`<div style="margin-top:6px;color:#9be7a5"><span class="dim">${U("greenRead")}</span><br><b>${h}${u}</b></div>`}updateFlow(t,e){let n=this.flow;if(n.visible=e,!e)return;let s=this.course.hole.green,r=this.course.toWorld(s.x,s.z),o=s.r+1,a=n.geometry.attributes.position,l=a.array,c=this.flowLife;for(let h=0;h<c.length;h++){let u=l[h*6],d=l[h*6+2],f=c[h]>0?this.course.slopeAt(u,d):null;if(!f||Math.hypot(u-r.x,d-r.z)>o){let p=o*Math.sqrt(Math.random()),M=Math.random()*Math.PI*2;u=r.x+Math.cos(M)*p,d=r.z+Math.sin(M)*p,c[h]=1.5+Math.random()*2.5}else u-=f[0]*22*t,d-=f[1]*22*t,c[h]-=t;let m=this.course.slopeAt(u,d)||[0,0],x=Math.hypot(m[0],m[1])||1e-6,g=.18+x*14;l[h*6]=u,l[h*6+1]=.03,l[h*6+2]=d,l[h*6+3]=u+m[0]/x*g,l[h*6+4]=.03,l[h*6+5]=d+m[1]/x*g}a.needsUpdate=!0}updateHud(t,e,n,s){var w;let r=this.holeIdx(t),o=ze[r],a=this.party.name(t.turn),l=this.course.lie(e.x,e.z),c=Math.hypot(s.x-e.x,s.z-e.z),h=this.party.mine(t.turn),u=Math.round(Math.hypot(o.pin[0],o.pin[1])),d=`${t.seq}|${this.club}|${Math.round(c*10)}|${!!this.flight}`;if(d!==this.hudKey){this.hudKey=d,this.ui.top.innerHTML=`<div class="row" style="gap:12px;align-items:baseline"><span class="big">${t.h+1}H</span><span class="mid">PAR ${o.par}</span><span class="dim">${u} m</span></div>
        <div style="margin-top:6px"><span style="color:${Tl[t.turn]}">\u25CF</span> <b>${Pe(a)}</b> \xB7 ${U("strokeN",{n:e.s+1})} \xB7 <b>${this.toPar(t,t.turn)}</b>${h?"":` <span class="dim">(${U("spectating")})</span>`}</div>
        <div class="dim" style="margin-top:2px">${U("lie")}: ${U("lie_"+l)}</div>${this.greenRead(e,s)}`,this.ui.btns.style.setProperty("top",`${this.ui.top.offsetTop+this.ui.top.offsetHeight+6}px`,"important");let S=t.wind,T=Math.hypot(S.x,S.z);this.ui.info.innerHTML=`<h3>${U("pinDist")}</h3><div class="big">${c<20?c.toFixed(1):Math.round(c)}<span style="font-size:14px"> m</span></div>
        <div style="margin-top:8px" class="row" style="justify-content:flex-end"><span class="dim">${U("wind")}</span>
        <span id="gWind" style="display:inline-block;font-size:18px">\u2B06</span><b>${T.toFixed(1)} m/s</b></div>
        <div class="dim" style="margin-top:4px">${n.putter?U("putter"):`${n.id} \xB7 ${U("carry")} ${Math.round(n.carry*(((w=is[l])==null?void 0:w[3])||1))} m`}</div>`}let f=t.wind,m=Math.atan2(f.z,f.x)-this.aim,x=this.ui.info.querySelector("#gWind");x&&(x.style.transform=`rotate(${m*180/Math.PI}deg)`);let g=this.swing,p=S=>(S+.25)/1.35*100;this.ui.meter.querySelector("i").style.left=`${p(0)}%`;let M=g.phase==="down"||g.phase==="follow"?g.power:g.phase==="back"?g.v:0;this.ui.meter.querySelector("i").style.width=`${p(Math.min(1.1,M))-p(0)}%`;let v=this.ui.meter.querySelector(".mark");v.style.left=`${p(g.phase==="idle"?0:g.v)}%`;let y=this.ui.meter.querySelector(".zone");y.style.left=`${p(-.025)}%`,y.style.width=`${p(.025)-p(-.025)}%`,y.hidden=n.putter,this.ui.meterLbl.textContent=n.putter?`${(Math.max(0,g.phase==="idle"?0:g.power||g.v)*n.maxPutt).toFixed(1)} m`:`${Math.round((g.phase==="idle"?1:Math.min(1.06,g.power||g.v))*100)}%`,this.ui.help.textContent=h?n.putter?U("puttHelp"):U("swingHelp"):U("waitTurn",{name:a}),this.ui.clubs.style.opacity=h?1:.4,performance.now()-(this.mapT||0)>100&&(this.mapT=performance.now(),this.drawMap(t))}renderMapBg(){let t=this.course,e=t.hole,n=this.ui.map,s=e.path.map(v=>v[0]),r=e.path.map(v=>v[1]),o=-20,a=Math.max(...s)+25,l=(Math.min(...r)+Math.max(...r))/2,c=Math.min((n.height-16)/(a-o),(n.width-10)/130);this.mapXf={xmin:o,zc:l,S:c};let h=document.createElement("canvas");h.width=n.width,h.height=n.height;let u=h.getContext("2d");u.fillStyle="#3a5a2a",u.fillRect(0,0,h.width,h.height);let{x0:d,z0:f,W:m,H:x}=t.mapRect,g=t.mapCanvas,p=m/g.width,M=x/g.height;u.setTransform(0,-p*c,M*c,0,h.width/2+(f-l)*c,h.height-8-(d-o)*c),u.drawImage(g,0,0),u.setTransform(1,0,0,1,0,0),this.mapBg=h}mapPt(t,e){let{xmin:n,zc:s,S:r}=this.mapXf,o=t-this.course.group.position.x,a=e-this.course.group.position.z;return[this.ui.map.width/2+(a-s)*r,this.ui.map.height-8-(o-n)*r]}drawMap(t){this.mapBg||this.renderMapBg();let e=this.ui.map.getContext("2d");e.drawImage(this.mapBg,0,0);let[n,s]=this.mapPt(this.course.pin.x,this.course.pin.z);e.fillStyle="#ff3b30",e.fillRect(n-1,s-9,2,9),e.beginPath(),e.moveTo(n+1,s-9),e.lineTo(n+7,s-6.5),e.lineTo(n+1,s-4),e.fill();let r=t.balls[t.turn];if(r&&!this.flight&&this.expect){let[o,a]=this.mapPt(r.x,r.z),[l,c]=this.mapPt(r.x+Math.cos(this.aim)*this.expect,r.z+Math.sin(this.aim)*this.expect);e.strokeStyle="rgba(255,255,255,.85)",e.setLineDash([3,3]),e.lineWidth=1.2,e.beginPath(),e.moveTo(o,a),e.lineTo(l,c),e.stroke(),e.setLineDash([])}t.balls.forEach((o,a)=>{var u;if(o.holed)return;let l=((u=this.flight)==null?void 0:u.slot)===a?this.flight.s:o,[c,h]=this.mapPt(l.x,l.z);e.fillStyle=Tl[a],e.strokeStyle="#000",e.lineWidth=1,e.beginPath(),e.arc(c,h,a===t.turn?4:3,0,Math.PI*2),e.fill(),e.stroke()})}renderCard(){var o,a,l;let t=this.party.state,e=this.ui.card;if(!t||e.hidden)return;let n=t.holes,s=`<h3>${U("scoreCard")}${t.phase==="done"?" \xB7 "+U("roundDone"):""}</h3><table><tr><th>${U("player")}</th>`;n.forEach((c,h)=>{s+=`<th>${h+1}H<br>P${ze[c].par}</th>`}),s+=`<th>${U("sumTotal")}</th><th>\xB1</th></tr>`;let r=t.cards.map(c=>c.reduce((h,u)=>h+(u||0),0));if(t.cards.forEach((c,h)=>{let u=c.reduce((f,m,x)=>f+(m?ze[n[x]].par:0),0),d=r[h]-u;s+=`<tr class="${h===t.turn&&t.phase==="play"?"turn":""}"><td><span style="color:${Tl[h]}">\u25CF</span> ${Pe(this.party.name(h))}</td>`,n.forEach((f,m)=>{var S;let x=c[m],g=ze[n[m]].par,p=m===t.h&&t.phase==="play"&&!x?((S=t.balls[h])==null?void 0:S.s)||"":x??"",M=x?x<g?"#7dd3fc":x>g?"#fca5a5":"":"",v=x?x-g:0,y=x?v<=-2?"border:3px double currentColor;border-radius:50%":v===-1?"border:2px solid currentColor;border-radius:50%":v===1?"border:2px solid currentColor;border-radius:3px":v>=2?"border:3px double currentColor;border-radius:3px":"":"",w=x?`<div style="font-size:9px;opacity:.75;margin-top:2px">${x===1?U("holeInOne"):U(["sc_m3","sc_m2","sc_m1","sc_0","sc_1","sc_2","sc_3"][Math.max(0,Math.min(6,v+3))])}</div>`:"";s+=`<td style="color:${M}"><span style="display:inline-block;min-width:22px;line-height:20px;${y}">${p}</span>${w}</td>`}),s+=`<td><b>${r[h]||""}</b></td><td>${u?(d>0?"+":"")+(d||"E"):""}</td></tr>`}),s+="</table>",t.phase!=="done")this._paid=!1;else if(!this._paid){this._paid=!0;let c=t.balls.map((h,u)=>u).find(h=>this.party.mine(h));if(c!=null){let h=t.holes.reduce((d,f)=>d+ze[f].par,0),u=Nr(2+(r[c]&&r[c]<=h?2:0));u&&this.ctx.toast(`\u{1F4B0} +${u} P`)}}if(t.phase==="done"){let c=Math.min(...r),h=r.map((u,d)=>u===c?this.party.name(d):null).filter(Boolean);s+=`<div class="mid" style="margin-top:10px;text-align:center">\u{1F3C6} ${Pe(h.join(", "))}</div>
        <div class="row" style="justify-content:center;margin-top:10px"><button class="go" data-a="again">${U("playAgain")}</button><button data-a="lobby">${U("backLobby")}</button></div>`}else s+='<div class="row" style="justify-content:flex-end;margin-top:8px"><button data-a="close">\u2715</button></div>';e.innerHTML=s,(o=e.querySelector("[data-a=again]"))==null||o.addEventListener("click",()=>this.start(t.holes.slice())),(a=e.querySelector("[data-a=lobby]"))==null||a.addEventListener("click",()=>{this.party.clear()}),(l=e.querySelector("[data-a=close]"))==null||l.addEventListener("click",()=>{e.hidden=!0})}netState(){return null}},Do=i=>document.querySelector(i);var No={carp:{h:.3,hx:.36,ped:.11,sn:.8,w:.45,belly:.06,dorsal:[.3,.62,.1],anal:[.66,.76,.08],barbel:1,scales:1},crucian:{h:.37,hx:.4,ped:.12,sn:.72,w:.38,belly:.04,dorsal:[.32,.64,.09],anal:[.66,.76,.08],scales:1},perch:{h:.31,hx:.34,ped:.1,sn:.95,w:.34,belly:.05,dorsal:[.26,.72,.11],spiny:1,anal:[.6,.75,.08],bigMouth:1,scales:1},disc:{h:.5,hx:.42,ped:.1,sn:.7,w:.22,belly:0,dorsal:[.26,.78,.09],spiny:1,anal:[.48,.78,.09],scales:1},torpedo:{h:.22,hx:.4,ped:.075,sn:.9,w:.55,belly:.03,dorsal:[.38,.52,.1],adipose:1,anal:[.66,.74,.06]},salmon:{h:.25,hx:.4,ped:.08,sn:1.05,w:.5,belly:.04,dorsal:[.38,.52,.1],adipose:1,anal:[.66,.74,.06],hookJaw:1},slim:{h:.21,hx:.4,ped:.085,sn:.85,w:.42,belly:.04,dorsal:[.42,.54,.1],anal:[.62,.74,.07],scales:1},tuna:{h:.28,hx:.42,ped:.035,sn:1,w:.75,belly:.02,dorsal:[.28,.42,.12],spiny:1,dorsal2:[.48,.56,.1],anal:[.56,.63,.08],finlets:1},jack:{h:.26,hx:.42,ped:.04,sn:.95,w:.5,belly:.02,dorsal:[.32,.74,.06],anal:[.54,.74,.05]},mackerel:{h:.2,hx:.42,ped:.04,sn:1.05,w:.6,belly:.02,dorsal:[.26,.38,.08],spiny:1,dorsal2:[.5,.58,.07],anal:[.54,.62,.06],finlets:1},pike:{h:.145,hx:.48,ped:.075,sn:1.5,w:.8,belly:.02,dorsal:[.62,.74,.09],anal:[.64,.76,.08],bigMouth:1},snakehead:{h:.16,hx:.35,ped:.1,sn:.8,w:.75,belly:.02,dorsal:[.22,.82,.07],anal:[.48,.82,.06],bigMouth:1},eel:{h:.075,hx:.3,ped:.07,sn:1,w:.9,belly:0,eel:1},ribbon:{h:.09,hx:.25,ped:.01,sn:1.4,w:.25,belly:0,eel:1,taper:1,bigMouth:1},needle:{h:.07,hx:.5,ped:.04,sn:2.4,w:.8,belly:0,dorsal:[.7,.8,.05],anal:[.68,.8,.05],beak:1},cat:{h:.18,hx:.24,ped:.08,sn:.55,w:.9,belly:.05,dorsal:[.28,.35,.11],anal:[.48,.86,.06],barbel:2,bigMouth:1},rock:{h:.31,hx:.32,ped:.1,sn:1,w:.45,belly:.04,dorsal:[.24,.74,.12],spiny:1,anal:[.6,.74,.09],bigMouth:1,scales:1},goby:{h:.18,hx:.22,ped:.09,sn:.55,w:.9,belly:.03,dorsal:[.3,.42,.09],spiny:1,dorsal2:[.48,.76,.07],anal:[.54,.76,.06]},flat:{h:.46,hx:.45,ped:.08,sn:.65,w:.12,belly:0,fringe:1},puffer:{h:.4,hx:.42,ped:.1,sn:.6,w:.85,belly:.08,dorsal:[.68,.76,.09],anal:[.68,.76,.08]},mullet:{h:.22,hx:.4,ped:.08,sn:.75,w:.6,belly:.03,dorsal:[.32,.4,.08],spiny:1,dorsal2:[.56,.64,.07],anal:[.58,.66,.06],scales:1},cod:{h:.23,hx:.35,ped:.06,sn:.85,w:.6,belly:.06,dorsal:[.26,.4,.09],dorsal2:[.44,.58,.08],anal:[.42,.58,.06],whisker:1},mahi:{h:.3,hx:.18,ped:.05,sn:.38,w:.35,belly:.02,dorsal:[.06,.84,.08],anal:[.46,.84,.06]},marlin:{h:.22,hx:.4,ped:.04,sn:1,w:.6,belly:.02,dorsal:[.2,.42,.22],sail:1,dorsal2:[.7,.74,.05],anal:[.58,.64,.07],bill:1},sturgeon:{h:.15,hx:.35,ped:.05,sn:1.6,w:.8,belly:.02,dorsal:[.66,.74,.08],anal:[.66,.74,.07],scutes:1,barbel:1},arapaima:{h:.18,hx:.35,ped:.12,sn:.9,w:.65,belly:.02,dorsal:[.62,.84,.08],anal:[.62,.84,.08],scales:1},arowana:{h:.22,hx:.4,ped:.1,sn:.8,w:.35,belly:-.02,dorsal:[.62,.84,.08],anal:[.52,.84,.08],scales:1,whisker:1}},G_=[["bluegill","\uBE14\uB8E8\uAE38","Bluegill","fresh","all",34,8,25,"disc","trunc","bars",3099196,8231542,15905882,1978202,.18,"mid",["worm","shrimp"],20],["crucian","\uBD95\uC5B4","Crucian Carp","fresh","all",30,10,45,"crucian","fork","plain",4868650,10916949,15260846,7035434,.28,"bot",["worm","paste","corn"],40],["carp","\uC789\uC5B4","Common Carp","fresh","all",16,30,110,"carp","fork","plain",4143650,10519878,15785120,9062954,.72,"bot",["corn","paste","worm"],30],["mirrorcarp","\uD5A5\uC5B4","Mirror Carp","fresh","all",9,35,90,"carp","fork","mirror",4867632,10127962,15655088,8018480,.68,"bot",["paste","corn"],35],["grasscarp","\uCD08\uC5B4","Grass Carp","fresh","all",6,50,140,"slim","fork","plain",4082226,9081438,15131332,5921328,.8,"mid",["corn","paste"],25],["koi","\uBE44\uB2E8\uC789\uC5B4","Koi","fresh","all",2,40,90,"carp","fork","koi",16052714,16052714,16448250,14829610,.6,"mid",["corn","paste"],260],["bass","\uBC30\uC2A4","Largemouth Bass","fresh","all",20,20,65,"perch","trunc","lateral",3099172,8228688,15657160,2306074,.58,"mid",["minnow","softworm","popper","worm"],45],["smallmouth","\uC2A4\uBAB0\uB9C8\uC6B0\uC2A4 \uBC30\uC2A4","Smallmouth Bass","fresh","all",9,20,55,"perch","trunc","bars",5917224,10126416,15129780,3811860,.65,"mid",["minnow","softworm","worm"],55],["mandarin","\uC3D8\uAC00\uB9AC","Mandarin Fish","fresh","warm",6,20,60,"rock","round","marble",6969898,12099680,15919296,2761748,.66,"bot",["minnow","softworm","shrimp"],140],["aucha","\uAEBD\uC9C0","Korean Aucha Perch","fresh","warm",10,10,30,"rock","round","bars",3815972,7236164,14209704,2001096,.4,"bot",["worm","softworm","minnow"],70],["rainbow","\uBB34\uC9C0\uAC1C\uC1A1\uC5B4","Rainbow Trout","fresh","cold",14,20,80,"torpedo","trunc","pinkband",4872762,11843752,15921898,14704762,.55,"mid",["worm","minnow","corn"],60],["masu","\uC0B0\uCC9C\uC5B4","Masu Trout","fresh","cold",8,15,45,"torpedo","trunc","parr",4872786,11056304,15790316,3820138,.45,"mid",["worm","minnow"],90],["lenok","\uC5F4\uBAA9\uC5B4","Lenok","fresh","cold",5,30,70,"torpedo","fork","spots",4864554,10780778,15391944,11550768,.6,"mid",["minnow","worm"],150],["char","\uACE4\uB4E4\uB9E4\uAE30","Arctic Char","fresh","cold",5,25,70,"torpedo","trunc","redspots",3030602,6979204,15231546,16052448,.6,"mid",["minnow","worm"],130],["sweetfish","\uC740\uC5B4","Sweetfish","fresh","all",10,12,30,"slim","fork","plain",4872778,12107952,16053482,15777856,.3,"mid",["minnow","worm"],120],["palechub","\uD53C\uB77C\uBBF8","Pale Chub","fresh","all",34,8,17,"slim","fork","barspink",4872810,12634320,16053492,14707338,.12,"top",["worm","paste"],15],["chub","\uB044\uB9AC","Korean Piscivorous Chub","fresh","warm",14,20,40,"slim","fork","plain",4084328,11845836,16053492,14721120,.45,"top",["minnow","worm"],25],["skygazer","\uAC15\uC900\uCE58","Skygazer","fresh","warm",10,40,100,"slim","fork","plain",5925490,13160660,16185078,9083556,.55,"top",["minnow","popper"],15],["barbel","\uB204\uCE58","Steed Barbel","fresh","warm",12,25,60,"slim","fork","spots",5921354,11184276,15658724,4868666,.5,"bot",["worm","paste"],20],["catfish","\uBA54\uAE30","Far Eastern Catfish","fresh","all",8,30,120,"cat","round","marble",3815980,6183492,14209720,2368026,.75,"bot",["worm","squid","shrimp"],45],["wels","\uC6F0\uC2A4 \uBA54\uAE30","Wels Catfish","fresh","cold",2,80,250,"cat","round","marble",3027496,5921352,13683892,1974296,1,"bot",["squid","worm"],40],["eel","\uBC40\uC7A5\uC5B4","Japanese Eel","fresh","warm",6,40,110,"eel","eel","plain",3029540,5922872,15394504,3817508,.6,"bot",["worm","squid"],220],["snakehead","\uAC00\uBB3C\uCE58","Snakehead","fresh","warm",6,40,100,"snakehead","round","blotch",3817002,8026708,14867648,1711122,.8,"top",["popper","softworm","minnow"],60],["pike","\uAC15\uAF2C\uCE58\uACE0\uAE30","Northern Pike","fresh","cold",6,40,130,"pike","fork","spots",4082218,8030800,15658188,14733424,.82,"mid",["minnow","popper"],50],["tilapia","\uD2F8\uB77C\uD53C\uC544","Tilapia","fresh","trop",18,15,50,"perch","trunc","bars",4869700,9344650,15132380,12599386,.4,"mid",["worm","corn","paste"],25],["peacock","\uD53C\uCF55 \uBC30\uC2A4","Peacock Bass","fresh","trop",8,30,80,"perch","round","bars",5138986,14204992,15788208,2767386,.85,"mid",["minnow","popper"],90],["arowana","\uC544\uB85C\uC640\uB098","Silver Arowana","fresh","trop",4,50,100,"arowana","round","plain",5925488,13161688,15791348,15245488,.7,"top",["popper","minnow"],300],["arapaima","\uD53C\uB77C\uB8E8\uCFE0","Arapaima","fresh","trop",2,100,300,"arapaima","round","redtail",3818552,7240294,13159604,13122090,1,"mid",["minnow","squid"],80],["sturgeon","\uCCA0\uAC11\uC0C1\uC5B4","Sturgeon","fresh","cold",1,80,250,"sturgeon","hetero","scutes",4869710,9080976,15000796,14211276,.95,"bot",["worm","squid"],500],["golden","\uD669\uAE08 \uC789\uC5B4","Golden Koi","fresh","all",1,50,100,"carp","fork","gold",15773728,15773728,16773824,16767072,.88,"mid",["corn","paste"],1500],["mackerel","\uACE0\uB4F1\uC5B4","Chub Mackerel","sea","all",30,20,50,"mackerel","fork","wavy",2775658,10138812,16053488,1714746,.4,"mid",["krill","jig","squid"],25],["horsemackerel","\uC804\uAC31\uC774","Horse Mackerel","sea","all",26,15,45,"jack","fork","scutes",4876906,11846848,16053486,14205024,.35,"mid",["krill","jig","lugworm"],30],["sardine","\uC815\uC5B4\uB9AC","Sardine","sea","all",26,12,25,"slim","fork","spots",2771562,11584720,16185078,1714762,.1,"top",["krill"],15],["rockfish","\uC6B0\uB7ED","Korean Rockfish","sea","all",24,15,60,"rock","trunc","marble",3815994,6972506,13157044,2762274,.42,"bot",["squid","softworm","lugworm","shrimp"],50],["blackrockfish","\uBCFC\uB77D","Dark-banded Rockfish","sea","all",20,12,35,"rock","trunc","bars",3814436,8022602,14208176,2761236,.32,"mid",["shrimp","krill","softworm"],70],["scorpion","\uC3E8\uBC45\uC774","Scorpionfish","sea","warm",12,12,35,"rock","round","marble",9058858,12608586,15780016,5905940,.35,"bot",["squid","lugworm"],80],["greenling","\uC950\uB178\uB798\uBBF8","Fat Greenling","sea","cold",18,20,60,"cod","trunc","marble",5917226,10126422,14997684,3812890,.45,"bot",["lugworm","squid"],45],["flounder","\uAD11\uC5B4","Olive Flounder","sea","all",14,30,100,"flat","round","spots",5917236,9074262,15920352,3812896,.55,"bot",["minnow","softworm","squid"],70],["stoneflounder","\uB3C4\uB2E4\uB9AC","Stone Flounder","sea","all",16,20,45,"flat","round","spots",6969920,10127458,15920352,3813408,.38,"bot",["lugworm"],60],["blackporgy","\uAC10\uC131\uB3D4","Black Porgy","sea","all",12,20,60,"perch","fork","plain",3817028,8291982,14212320,2369580,.62,"mid",["krill","shrimp","corn"],110],["seabream","\uCC38\uB3D4","Red Sea Bream","sea","warm",10,25,100,"perch","fork","bluedots",13126234,15239818,16310492,4235488,.62,"mid",["krill","shrimp","jig","squid"],120],["opaleye","\uBCB5\uC5D0\uB3D4","Largescale Blackfish","sea","warm",10,20,55,"perch","trunc","plain",1976878,4082256,8029834,1731210,.7,"top",["krill"],120],["rockbream","\uB3CC\uB3D4","Striped Beakfish","sea","warm",5,25,70,"disc","trunc","bars7",3815994,13157556,15262936,1710618,.9,"bot",["shrimp","squid"],260],["seabass","\uB18D\uC5B4","Japanese Sea Bass","sea","all",10,30,110,"perch","trunc","spots",4872804,10793144,15921906,2765888,.72,"mid",["minnow","softworm","popper","shrimp"],70],["mullet","\uC22D\uC5B4","Flathead Mullet","sea","all",16,30,80,"mullet","fork","lines",4083290,10793144,15658734,5925498,.55,"top",["paste","krill"],25],["goby","\uB9DD\uB465\uC5B4","Yellowfin Goby","sea","all",28,10,30,"goby","round","spots",6971460,11051136,15262412,3814436,.18,"bot",["lugworm","worm"],15],["filefish","\uC950\uCE58","Filefish","sea","warm",12,15,35,"disc","round","marble",9077862,11841168,14867652,5919808,.35,"mid",["krill","squid"],60],["butterfish","\uBCD1\uC5B4","Silver Pomfret","sea","warm",8,15,40,"disc","lunate","plain",9082532,13423836,16054008,6978186,.3,"mid",["krill"],90],["puffer","\uBCF5\uC5B4","Panther Puffer","sea","all",12,15,45,"puffer","trunc","spots",4868666,9079402,16184558,1710612,.3,"bot",["squid","lugworm","shrimp"],90],["hairtail","\uAC08\uCE58","Hairtail","sea","warm",10,60,150,"ribbon","eel","silver",12109004,14542058,16054008,9085104,.5,"mid",["squid","jig"],110],["needlefish","\uD559\uACF5\uCE58","Halfbeak","sea","all",12,20,40,"needle","fork","lines",3037802,11847888,16185078,15231546,.2,"top",["krill"],50],["croaker","\uBBFC\uC5B4","Brown Croaker","sea","warm",4,40,110,"cod","round","plain",6974042,11578518,15789280,9075290,.7,"bot",["shrimp","squid"],200],["yellowcroaker","\uCC38\uC870\uAE30","Yellow Croaker","sea","warm",10,15,40,"cod","round","plain",9079402,13944970,16048240,11571248,.3,"bot",["lugworm","shrimp"],160],["tilefish","\uC625\uB3D4","Red Tilefish","sea","warm",5,25,50,"cod","trunc","plain",13660266,15246490,16312544,15781968,.45,"bot",["squid","lugworm"],230],["grouper","\uB2A5\uC131\uC5B4","Convict Grouper","sea","warm",4,30,100,"rock","round","bars",5921354,9079412,13947068,2763296,.85,"bot",["squid","softworm","minnow"],220],["redgrouper","\uBD89\uBC14\uB9AC","Red Spotted Grouper","sea","warm",2,25,60,"rock","round","redspots",11037258,13672576,15916232,13647904,.8,"bot",["squid","shrimp"],450],["cod","\uB300\uAD6C","Pacific Cod","sea","cold",10,40,110,"cod","trunc","spots",6970948,11049082,15656660,3813408,.55,"bot",["squid","jig"],60],["pollock","\uBA85\uD0DC","Alaska Pollock","sea","cold",14,30,80,"cod","trunc","lines",5919812,10261628,15525590,3814436,.45,"mid",["jig","squid"],40],["salmon","\uC5F0\uC5B4","Chum Salmon","sea","cold",6,50,110,"salmon","fork","spots",4084322,10135728,15790318,10504794,.82,"mid",["jig","minnow","shrimp"],90],["yellowtail","\uBC29\uC5B4","Japanese Amberjack","sea","all",6,40,120,"jack","fork","yellowline",3824250,11583692,15921904,15781952,.88,"mid",["jig","minnow","squid"],80],["amberjack","\uBD80\uC2DC\uB9AC","Yellowtail Amberjack","sea","warm",4,50,150,"jack","fork","yellowline",4876910,12109508,16053486,15255616,.92,"mid",["jig","popper"],80],["gt","\uBB34\uBA85\uAC08\uC804\uAC31\uC774(GT)","Giant Trevally","sea","trop",3,50,150,"jack","fork","plain",3818568,9082008,14212316,2764852,.98,"top",["popper","jig"],40],["mahi","\uB9CC\uC0C8\uAE30","Mahi-mahi","sea","trop",5,50,150,"mahi","fork","mahi",2787946,10145866,15786058,2781376,.85,"top",["popper","jig","squid"],60],["tuna","\uCC38\uB2E4\uB791\uC5B4","Bluefin Tuna","sea","all",2,80,250,"tuna","lunate","tuna",1977934,8030876,15659250,15781952,1,"mid",["jig","squid"],200],["marlin","\uCCAD\uC0C8\uCE58","Blue Marlin","sea","trop",1,150,380,"marlin","lunate","marlin",1981034,6982320,15659252,4235488,1,"top",["popper","squid"],150],["goldenbream","\uD669\uAE08 \uCC38\uB3D4","Golden Sea Bream","sea","all",1,40,90,"perch","fork","gold",15773728,15773728,16773824,16767072,.9,"mid",["krill","shrimp"],1500]],un={fresh:[],sea:[]},ii={},Lu={ko:{},en:{}};for(let i of G_){let[t,e,n,s,r,o,a,l,c,h,u,d,f,m,x,g,p,M,v]=i,y={id:t,water:s,zone:r,w:o,min:a,max:l,body:c,tail:h,pat:u,back:d,side:f,belly:m,acc:x,fight:g,depth:p,baits:M,price:v};un[s].push(y),ii[t]=y,Lu.ko[t]=e,Lu.en[t]=n}ii.seabreamgold=ii.goldenbream;vp(Lu);var Rl={rod:[{id:"bamboo",ko:"\uB300\uB098\uBB34 \uB09A\uC2EF\uB300",en:"Bamboo Pole",price:0,cast:10,str:1,sens:1,lure:.6,big:.9,col:13148240,len:2.6,icon:"\u{1F38B}"},{id:"carbon",ko:"\uCE74\uBCF8 \uBBFC\uC7A5\uB300 3.6\uCE78",en:"Carbon Pole 6.5 m",price:6e3,cast:12,str:1.15,sens:1.35,lure:.6,big:1,col:2763310,len:3.4,icon:"\u{1F3A3}"},{id:"spinning",ko:"\uC2A4\uD53C\uB2DD \uB8E8\uC5B4\uB300",en:"Spinning Lure Rod",price:12e3,cast:22,str:1.25,sens:1.1,lure:1.6,big:1.05,col:2375786,len:2.4,icon:"\u{1F3A3}"},{id:"iso",ko:"\uAC2F\uBC14\uC704 \uB9B4\uB300 1.5\uD638",en:"Rock Float Rod",price:18e3,cast:22,str:1.4,sens:1.25,lure:.9,big:1.15,col:6954538,len:3.2,icon:"\u{1F3A3}"},{id:"surf",ko:"\uC6D0\uD22C \uB09A\uC2EF\uB300",en:"Surf Casting Rod",price:22e3,cast:32,str:1.5,sens:.95,lure:.8,big:1.25,col:1989178,len:3.4,icon:"\u{1F3A3}"},{id:"jigging",ko:"\uC9C0\uAE45 \uB85C\uB4DC",en:"Jigging Rod",price:45e3,cast:20,str:2.2,sens:.85,lure:1.5,big:1.6,col:1118481,len:1.9,icon:"\u{1F3A3}"},{id:"goldrod",ko:"\uD669\uAE08 \uB09A\uC2EF\uB300",en:"Golden Rod",price:3e5,cast:32,str:2.6,sens:1.5,lure:1.6,big:2,col:14725168,len:3,icon:"\u2728"}],float:[{id:"stick",ko:"\uB9C9\uB300\uCC0C (\uBBFC\uBB3C \uB098\uB178)",en:"Stick Float",price:0,sens:1.35,depth:"mid",vis:1,stick:1,icon:"\u{1F4CD}"},{id:"round",ko:"\uAD6C\uBA4D\uCC0C 0.8\uD638",en:"Round Float",price:3e3,sens:1.1,depth:"mid",vis:1.2,icon:"\u{1F534}"},{id:"shallow",ko:"\uACE0\uCD94\uCC0C (\uC595\uC740 \uC218\uC2EC)",en:"Pepper Float",price:2500,sens:1.2,depth:"top",vis:1,stick:1,icon:"\u{1F336}\uFE0F"},{id:"glow",ko:"\uC804\uC790\uCC0C (\uC57C\uAD11)",en:"Glow Float",price:9e3,sens:1.25,depth:"mid",vis:1.5,stick:1,glow:1,icon:"\u{1F4A1}"},{id:"bigfloat",ko:"\uB300\uBB3C\uCC0C",en:"Big Game Float",price:7e3,sens:.9,depth:"mid",vis:1.4,big:1.25,icon:"\u{1F7E0}"},{id:"sinker",ko:"\uC6D0\uD22C \uBD09\uB3CC (\uBC14\uB2E5)",en:"Bottom Sinker",price:2e3,sens:.95,depth:"bot",vis:0,bell:1,icon:"\u26AB"}],hook:[{id:"h3",ko:"\uBD95\uC5B4\uBC14\uB298 3\uD638",en:"Hook #3 (small)",price:0,size:-1,str:4,hookup:1.15,icon:"\u{1FA9D}"},{id:"h7",ko:"\uC911\uD615\uBC14\uB298 7\uD638",en:"Hook #7 (medium)",price:1500,size:0,str:12,hookup:1,icon:"\u{1FA9D}"},{id:"h12",ko:"\uB300\uBB3C\uBC14\uB298 12\uD638",en:"Hook #12 (large)",price:4e3,size:1,str:40,hookup:.85,icon:"\u{1FA9D}"},{id:"circle",ko:"\uC11C\uD074\uD6C5 16\uD638",en:"Circle Hook 16",price:15e3,size:2,str:300,hookup:.8,icon:"\u2B55"},{id:"treble",ko:"\uD2B8\uB808\uBE14\uD6C5 (\uB8E8\uC5B4\uC6A9)",en:"Treble Hook",price:5e3,size:0,str:15,hookup:1,lureHook:1.35,icon:"\u2693"}],chum:[{id:"none",ko:"\uC5C6\uC74C",en:"None",price:0,uses:0,wait:1,boost:{},icon:"\u2014"},{id:"barley",ko:"\uBCF4\uB9AC \uB5A1\uBC25",en:"Barley Groundbait",price:1200,uses:15,wait:.75,boost:{crucian:2.2,carp:2,mirrorcarp:2,grasscarp:1.6,palechub:1.6,koi:1.8,golden:1.6,tilapia:1.6},icon:"\u{1F33E}"},{id:"fishmeal",ko:"\uC5B4\uBD84 \uB5A1\uBC25",en:"Fishmeal Groundbait",price:2200,uses:15,wait:.65,boost:{carp:2.2,catfish:1.6,crucian:1.6,mirrorcarp:1.8,barbel:1.8,big:1.3},icon:"\u{1F41F}"},{id:"krillchum",ko:"\uD06C\uB9B4 \uBC11\uBC25",en:"Krill Chum",price:2e3,uses:15,wait:.7,boost:{blackporgy:2.4,opaleye:2.6,seabream:1.8,mackerel:2,horsemackerel:2,sardine:2,mullet:1.6,goldenbream:1.6},icon:"\u{1F990}"},{id:"baitball",ko:"\uC9D1\uC5B4\uC81C (\uACE0\uB4F1\uC5B4 \uBC11\uBC25)",en:"Fish Oil Chum",price:3200,uses:12,wait:.7,boost:{yellowtail:2,amberjack:2,tuna:2.2,gt:1.8,mahi:1.8,salmon:1.6,big:1.4},icon:"\u{1F6E2}\uFE0F"}],bait:[{id:"worm",ko:"\uC9C0\uB801\uC774",en:"Earthworm",price:0,pack:0,type:"nat",icon:"\u{1FAB1}"},{id:"corn",ko:"\uC625\uC218\uC218",en:"Sweet Corn",price:600,pack:30,type:"nat",icon:"\u{1F33D}"},{id:"paste",ko:"\uAE00\uB8E8\uD150 \uB5A1\uBC25",en:"Gluten Paste",price:800,pack:30,type:"nat",icon:"\u{1F359}"},{id:"shrimp",ko:"\uBBFC\uBB3C\uC0C8\uC6B0",en:"Live Shrimp",price:1200,pack:20,type:"nat",icon:"\u{1F990}"},{id:"krill",ko:"\uD06C\uB9B4",en:"Krill",price:900,pack:30,type:"nat",icon:"\u{1F990}"},{id:"lugworm",ko:"\uAC2F\uC9C0\uB801\uC774",en:"Lugworm",price:1e3,pack:25,type:"nat",icon:"\u{1FAB1}"},{id:"squid",ko:"\uC624\uC9D5\uC5B4 \uC0B4",en:"Squid Strip",price:1100,pack:25,type:"nat",icon:"\u{1F991}"},{id:"minnow",ko:"\uBBF8\uB178\uC6B0 (\uB8E8\uC5B4)",en:"Minnow Lure",price:4e3,pack:0,type:"lure",icon:"\u{1F420}"},{id:"softworm",ko:"\uC18C\uD504\uD2B8 \uC6DC (\uB8E8\uC5B4)",en:"Soft Plastic Worm",price:2500,pack:0,type:"lure",icon:"\u{1FAB1}"},{id:"popper",ko:"\uD3EC\uD37C (\uC218\uBA74 \uB8E8\uC5B4)",en:"Popper",price:5e3,pack:0,type:"lure",icon:"\u{1FAE7}"},{id:"jig",ko:"\uBA54\uD0C8\uC9C0\uADF8",en:"Metal Jig",price:6e3,pack:0,type:"lure",icon:"\u{1F529}"}]},Lp=["rod","float","hook","chum","bait"],zo=(i,t)=>Rl[i].find(e=>e.id===t)||Rl[i][0],W_={carp:16e-6,crucian:19e-6,perch:15e-6,disc:16e-6,torpedo:1e-5,salmon:11e-6,slim:8e-6,tuna:19e-6,jack:13e-6,mackerel:9e-6,pike:65e-7,snakehead:8e-6,eel:18e-7,ribbon:12e-7,needle:25e-7,cat:9e-6,rock:16e-6,goby:9e-6,flat:13e-6,puffer:2e-5,mullet:1e-5,cod:1e-5,mahi:9e-6,marlin:75e-7,sturgeon:6e-6,arapaima:75e-7,arowana:7e-6},kp=(i,t)=>+((W_[i.body]||12e-6)*t**3).toFixed(2);function Dp(i,t){let e=i.w<=2?3:i.w<=6?2:i.w<=14?1:0,n=(t-i.min)/(i.max-i.min);return Math.min(5,1+e+(n>.8?1:0))}function Fo(i,t,e){return Math.max(1,Math.round(i.price*Math.max(.2,t)*(.7+.15*e)/20))}var $_={all:()=>1,warm:i=>i==="cold"?.25:1,cold:i=>i==="cold"?1.6:i==="tropical"?.1:.55,trop:i=>i==="tropical"?1.8:i==="cold"?0:.15};function Up({water:i,biome:t,rod:e,float:n,hook:s,chum:r,bait:o,castFrac:a,depthZone:l}){let c=un[i]||un.fresh,h=o.type==="lure";return c.map(u=>{let d=u.w*$_[u.zone](t),f=u.baits.indexOf(o.id);d*=f===0?4:f>0?2.6:h?.04:.25;let m=h?o.id==="popper"?"top":o.id==="jig"?"mid":u.depth:n.bell?"bot":l||n.depth;d*=u.depth===m?1.6:u.depth==="mid"||m==="mid"?.75:.35,d*=(r.boost[u.id]||1)*(u.max>80&&r.boost.big||1);let x=u.max>120?2:u.max>70?1:u.max>35?0:-1;return d*=Math.max(.15,1-.32*Math.abs(x-s.size)),h&&(d*=e.lure*(s.lureHook||1)),u.max>80&&(d*=(.6+a*.8)*e.big*(n.big||1)),[u,Math.max(0,d)]}).filter(([,u])=>u>0)}function Np(i,t=Math.random){let e=t()*i.reduce((n,[,s])=>n+s,0);for(let[n,s]of i)if((e-=s)<=0)return n;return i[0][0]}function ni(i,t){let e=i.eel?1:.8,n=Math.min(1,t/e),s=i.hx,r=i.h/2,o=i.ped/i.h,a;if(n<s){let h=(s-n)/s;a=Math.pow(Math.max(0,1-h*h),.5*i.sn)}else{let h=(n-s)/(1-s);a=i.taper?Math.max(.02,1-h)*(1-o)+o:o+(1-o)*Math.pow(Math.cos(h*Math.PI/2),1.25)}let l=r*a*(1-(i.belly||0)),c=r*a*(1+(i.belly||0));return[l,c]}var Uo=i=>"#"+i.toString(16).padStart(6,"0");function Cl(i,t,e){let n=(i>>16&255)*(1-e)+(t>>16&255)*e,s=(i>>8&255)*(1-e)+(t>>8&255)*e,r=(i&255)*(1-e)+(t&255)*e;return`rgb(${n|0},${s|0},${r|0})`}function q_(i,t){return t<1?Cl(i,0,1-t):Cl(i,16777215,t-1)}function X_(i){let t=i>>>0||1;return()=>((t=Math.imul(t^t>>>15,2246822519)^Math.imul(t^t>>>13,3266489917))>>>0)/4294967296}function Y_(i){let t=7;for(let e of i)t=Math.imul(t^e.charCodeAt(0),16777619);return t}function Z_(i){var n;let t=No[i.body],e=Math.max(((n=t.dorsal)==null?void 0:n[2])||0,t.sail?.22:0);return t.h/2+e+.04}function ku(i,t,e,n,s,r=!1){let o=No[t.body],a=X_(Y_(t.id)),l=(_,b)=>[e+_*s,n-b*s],c=o.eel?1:.8,h=40,u=r?"#26303c":t.pat==="gold"?"rgba(255,214,90,0.9)":Cl(t.back,t.acc,.35).replace("rgb","rgba").replace(")",",0.85)"),d=r?"rgba(0,0,0,0)":"rgba(0,0,0,0.18)";i.save(),i.lineJoin="round";let f=([_,b,C],L,k,D)=>{i.beginPath();let[V,z]=l(_,(L?1:-1)*ni(o,_)[L?0:1]*.92);i.moveTo(V,z);let G=10;for(let Q=0;Q<=G;Q++){let ot=_+(b-_)*Q/G,St=ni(o,ot)[L?0:1],Vt=C*(D?Math.sin(Math.min(1,Q/G*1.4)*Math.PI*.55)*(1-Q/G*.6)*1.6:k?1-.35*Q/G:Math.sin(Q/G*Math.PI*.85+.25));k&&Q%2===1&&(Vt*=.72);let[Y,et]=l(ot-C*.15*(Q/G),(L?1:-1)*(St+Math.max(.01,Vt)));i.lineTo(Y,et)}let[F,K]=l(b,(L?1:-1)*ni(o,b)[L?0:1]*.92);if(i.lineTo(F,K),i.closePath(),i.fillStyle=u,i.fill(),!r){i.strokeStyle=d,i.lineWidth=Math.max(.6,s*.003);for(let Q=1;Q<8;Q++){let ot=_+(b-_)*Q/8,St=ni(o,ot)[L?0:1],[Vt,Y]=l(ot,(L?1:-1)*St),[et,Mt]=l(ot-C*.15,(L?1:-1)*(St+C*.8));i.beginPath(),i.moveTo(Vt,Y),i.lineTo(et,Mt),i.stroke()}}};if(o.fringe&&(f([.12,.78,.07],!0,!1),f([.22,.78,.06],!1,!1)),o.dorsal&&f(o.dorsal,!0,o.spiny,o.sail),o.dorsal2&&f(o.dorsal2,!0,!1),o.anal&&f(o.anal,!1,!1),o.eel&&(f([.4,.995,.035],!0,!1),f([.5,.995,.03],!1,!1)),o.adipose){let b=ni(o,.72)[0],[C,L]=l(.72,b);i.beginPath(),i.ellipse(C,L-s*.012,s*.02,s*.016,0,0,Math.PI*2),i.fillStyle=u,i.fill()}if(o.finlets){i.fillStyle=r?"#26303c":Uo(t.acc);for(let _=0;_<6;_++){let b=.62+_*.028;for(let C of[1,-1]){let L=ni(o,b)[C>0?0:1],[k,D]=l(b,C*L);i.beginPath(),i.moveTo(k-s*.008,D),i.lineTo(k+s*.008,D),i.lineTo(k+s*.01,D-C*s*.018),i.fill()}}}if(!o.eel){let[_]=ni(o,c),[b,C]=l(c-.01,_*.95),[L,k]=l(c-.01,-_*.95),D=o.h*(t.tail==="lunate"?.95:t.tail==="hetero"?.6:.62)+.03;if(i.beginPath(),i.moveTo(b,C),t.tail==="fork"||t.tail==="lunate"){let V=t.tail==="lunate"?.06:.1,[z,G]=l(1,D*.55),[F,K]=l(1-V,0),[Q,ot]=l(1,-D*.55),[St,Vt]=l(c+.08,D*.3),[Y,et]=l(c+.08,-D*.3);i.quadraticCurveTo(St,Vt,z,G),i.quadraticCurveTo(...l(1-V*.4,D*.15),F,K),i.quadraticCurveTo(...l(1-V*.4,-D*.15),Q,ot),i.quadraticCurveTo(Y,et,L,k)}else t.tail==="round"?(i.bezierCurveTo(...l(c+.12,D*.62),...l(1,D*.35),...l(1,0)),i.bezierCurveTo(...l(1,-D*.35),...l(c+.12,-D*.62),L,k)):t.tail==="hetero"?(i.quadraticCurveTo(...l(c+.1,D*.25),...l(1,D*.75)),i.quadraticCurveTo(...l(.92,0),...l(.95,-D*.35)),i.quadraticCurveTo(...l(c+.06,-D*.25),L,k)):(i.quadraticCurveTo(...l(c+.08,D*.4),...l(.98,D*.55)),i.quadraticCurveTo(...l(.96,0),...l(.98,-D*.55)),i.quadraticCurveTo(...l(c+.08,-D*.4),L,k));if(i.closePath(),i.fillStyle=u,i.fill(),!r){i.save(),i.clip(),i.strokeStyle=d,i.lineWidth=Math.max(.6,s*.003);for(let V=-4;V<=4;V++){let[z,G]=l(c,0),[F,K]=l(1.02,V/4*D*.6);i.beginPath(),i.moveTo(z,G),i.lineTo(F,K),i.stroke()}i.restore()}}let m=new Path2D,x=[],g=[];for(let _=0;_<=h;_++){let b=_/h*(o.eel?1:c),[C,L]=ni(o,b);x.push(l(b,C)),g.push(l(b,-L))}m.moveTo(...x[0]);for(let _ of x)m.lineTo(..._);for(let _=g.length-1;_>=0;_--)m.lineTo(...g[_]);m.closePath();let[,,p]=[0,0,o.h/2];if(r){i.fillStyle="#26303c",i.fill(m),o.beak&&(i.beginPath(),i.moveTo(...l(.02,-.01)),i.lineTo(...l(-.12,-.012)),i.lineTo(...l(.02,-.025)),i.fill()),o.bill&&(i.beginPath(),i.moveTo(...l(.02,.012)),i.lineTo(...l(-.2,0)),i.lineTo(...l(.02,-.004)),i.fill()),i.restore();return}let M=i.createLinearGradient(0,n-p*s*1.05,0,n+p*s*1.05);t.pat==="gold"?(M.addColorStop(0,"#d89010"),M.addColorStop(.4,"#ffd040"),M.addColorStop(.55,"#fff0a0"),M.addColorStop(1,"#ffe080")):t.pat==="silver"?(M.addColorStop(0,"#9fb0bc"),M.addColorStop(.45,"#f4f8fb"),M.addColorStop(.55,"#ffffff"),M.addColorStop(1,"#c8d2da")):(M.addColorStop(0,Uo(t.back)),M.addColorStop(.38,Uo(t.side)),M.addColorStop(.62,Cl(t.side,t.belly,.5)),M.addColorStop(1,Uo(t.belly))),i.fillStyle=M,i.fill(m),i.save(),i.clip(m);let v=(_,b)=>{let[C,L]=ni(o,_);return b>=0?C*b:L*b},y=_=>`rgba(${t.acc>>16&255},${t.acc>>8&255},${t.acc&255},${_})`,w=_=>`rgba(10,12,10,${_})`;switch(t.pat){case"bars":case"bars7":case"barspink":{let _=t.pat==="bars7"||t.body==="disc"?7:6;for(let b=0;b<_;b++){let C=.16+b*(c-.2)/_;i.fillStyle=t.pat==="barspink"?"rgba(90,110,150,0.45)":t.pat==="bars7"?w(.75):w(.3),i.beginPath(),i.moveTo(...l(C,.4)),i.lineTo(...l(C+.045,.4)),i.lineTo(...l(C+.03+(t.pat==="bars7"?.02:0),-.4)),i.lineTo(...l(C-.015,-.4)),i.fill()}t.pat==="barspink"&&(i.fillStyle="rgba(240,110,140,0.35)",i.fillRect(...l(.1,-.005),s*.7,s*o.h*.25));break}case"lateral":i.fillStyle=w(.42);for(let _=0;_<9;_++){let b=.14+_*.075,[C,L]=l(b,(a()-.5)*.02);i.beginPath(),i.ellipse(C,L,s*.04,s*.022,0,0,7),i.fill()}break;case"spots":case"redspots":for(let _=0;_<70;_++){let b=.08+a()*(c-.06),C=a()*1.6-.45;if(C<-.3&&t.pat!=="redspots")continue;let[L,k]=l(b,v(b,Math.min(.92,C)));i.fillStyle=t.pat==="redspots"?a()<.7?"rgba(220,60,40,0.85)":"rgba(250,230,200,0.8)":w(.42),i.beginPath(),i.arc(L,k,s*(.006+a()*.007),0,7),i.fill()}break;case"marble":for(let _=0;_<22;_++){let b=.06+a()*(c-.04),C=a()*1.6-.6,[L,k]=l(b,v(b,C));i.fillStyle=w(.18+a()*.22),i.beginPath(),i.ellipse(L,k,s*(.025+a()*.04),s*(.012+a()*.03),a()*3,0,7),i.fill()}break;case"blotch":for(let _=0;_<9;_++){let b=.15+_*.075;for(let C of[.45,-.1]){let[L,k]=l(b+(C<0?.035:0),v(b,C));i.fillStyle=w(.5),i.beginPath(),i.ellipse(L,k,s*.03,s*.02,.3,0,7),i.fill()}}break;case"wavy":i.strokeStyle="rgba(10,25,40,0.65)",i.lineWidth=s*.006;for(let _=0;_<16;_++){let b=.14+_*.04;i.beginPath(),i.moveTo(...l(b,v(b,1))),i.quadraticCurveTo(...l(b+.03,v(b,.6)),...l(b-.005,v(b,.15))),i.stroke()}break;case"lines":i.strokeStyle="rgba(30,40,50,0.35)",i.lineWidth=s*.004;for(let _ of[.75,.5,.25,0]){i.beginPath();for(let b=0;b<=20;b++){let C=.12+b*(c-.14)/20,L=l(C,v(C,_));b?i.lineTo(...L):i.moveTo(...L)}i.stroke()}break;case"yellowline":i.strokeStyle="rgba(245,210,60,0.9)",i.lineWidth=s*o.h*.07,i.beginPath();for(let _=0;_<=20;_++){let b=.05+_*(c-.03)/20,C=l(b,v(b,.05));_?i.lineTo(...C):i.moveTo(...C)}i.stroke();break;case"pinkband":i.strokeStyle="rgba(232,96,122,0.55)",i.lineWidth=s*o.h*.22,i.beginPath();for(let _=0;_<=20;_++){let b=.12+_*(c-.12)/20,C=l(b,v(b,-.05));_?i.lineTo(...C):i.moveTo(...C)}i.stroke();for(let _=0;_<60;_++){let b=.1+a()*(c-.04),C=a()*1.1-.1,[L,k]=l(b,v(b,C));i.fillStyle=w(.45),i.beginPath(),i.arc(L,k,s*.005,0,7),i.fill()}break;case"parr":for(let _=0;_<8;_++){let b=.18+_*.07,[C,L]=l(b,0);i.fillStyle="rgba(40,50,80,0.4)",i.beginPath(),i.ellipse(C,L,s*.022,s*o.h*.32,0,0,7),i.fill()}break;case"bluedots":for(let _=0;_<40;_++){let b=.1+a()*(c-.1),C=a()*1.2-.2,[L,k]=l(b,v(b,C));i.fillStyle="rgba(80,190,255,0.9)",i.beginPath(),i.arc(L,k,s*.006,0,7),i.fill()}break;case"koi":for(let _=0;_<4;_++){let b=.1+_*.17+a()*.05,[C,L]=l(b,v(b,.5-a()*.4));i.fillStyle=_===2?"rgba(20,20,20,0.85)":"rgba(226,72,42,0.92)",i.beginPath(),i.ellipse(C,L,s*(.06+a()*.04),s*(.04+a()*.04),a(),0,7),i.fill()}break;case"mirror":for(let _=0;_<9;_++){let b=.2+_*.065,[C,L]=l(b,v(b,.75));i.fillStyle="rgba(255,240,200,0.35)",i.strokeStyle="rgba(60,50,20,0.35)",i.lineWidth=s*.003,i.beginPath(),i.ellipse(C,L,s*.03,s*.024,0,0,7),i.fill(),i.stroke()}break;case"redtail":{let _=i.createLinearGradient(...l(.45,0),...l(c,0));_.addColorStop(0,"rgba(200,58,42,0)"),_.addColorStop(1,"rgba(200,58,42,0.85)"),i.fillStyle=_,i.fillRect(...l(.45,.5),s*.4,s);break}case"scutes":for(let _ of[.85,.2,-.6])for(let b=0;b<12;b++){let C=.18+b*.05,[L,k]=l(C,v(C,_));i.fillStyle="rgba(240,236,220,0.8)",i.beginPath(),i.moveTo(L-s*.01,k),i.lineTo(L,k-s*.01),i.lineTo(L+s*.01,k),i.lineTo(L,k+s*.01),i.fill()}break;case"tuna":i.fillStyle="rgba(70,110,180,0.35)",i.fillRect(...l(.1,v(.4,.35)),s*.7,s*o.h*.12);break;case"mahi":for(let _=0;_<40;_++){let b=.1+a()*.65,C=a()*1.4-.4,[L,k]=l(b,v(b,C));i.fillStyle="rgba(40,110,200,0.7)",i.beginPath(),i.arc(L,k,s*.006,0,7),i.fill()}break;case"marlin":for(let _=0;_<12;_++){let b=.2+_*.05;i.strokeStyle="rgba(140,200,255,0.55)",i.lineWidth=s*.006,i.beginPath(),i.moveTo(...l(b,v(b,.9))),i.lineTo(...l(b+.01,v(b,-.4))),i.stroke()}break}if(o.scales||t.pat==="gold"){i.strokeStyle=t.pat==="gold"?"rgba(160,100,0,0.25)":"rgba(0,0,0,0.12)",i.lineWidth=Math.max(.5,s*.0025);let _=.028;for(let b=.18;b<c;b+=_)for(let C=-1;C<=1;C+=.16){let[L,k]=l(b+(Math.round(C/.16)%2?_/2:0),v(b,C));i.beginPath(),i.arc(L,k,s*_*.55,-1.2,1.2),i.stroke()}}let S=i.createLinearGradient(0,n-p*s,0,n+p*s*.2);S.addColorStop(0,"rgba(255,255,255,0)"),S.addColorStop(.55,"rgba(255,255,255,0.18)"),S.addColorStop(.8,"rgba(255,255,255,0)"),i.fillStyle=S,i.fill(m),i.strokeStyle="rgba(0,0,0,0.18)",i.lineWidth=Math.max(.6,s*.003),i.beginPath();for(let _=0;_<=20;_++){let b=.2+_*(c-.22)/20,C=l(b,v(b,.42-_/20*.4));_?i.lineTo(...C):i.moveTo(...C)}i.stroke();let T=.2+(o.sn<.7?.02:0);i.strokeStyle="rgba(0,0,0,0.28)",i.lineWidth=Math.max(.8,s*.006),i.beginPath(),i.moveTo(...l(T-.02,v(T,.85))),i.quadraticCurveTo(...l(T+.035,0),...l(T-.02,v(T,-.85))),i.stroke(),i.restore(),i.strokeStyle="rgba(0,0,0,0.25)",i.lineWidth=Math.max(.6,s*.004),i.stroke(m);{let[_,b]=l(.24,-o.h*.08);i.save(),i.translate(_,b),i.rotate(.5),i.beginPath(),i.ellipse(s*.04,0,s*.055,s*Math.max(.012,o.h*.1),0,0,7),i.fillStyle=u,i.fill(),i.restore()}i.strokeStyle="rgba(40,20,20,0.55)",i.lineWidth=Math.max(.8,s*.005);let R=o.bigMouth?.075:.03;if(i.beginPath(),i.moveTo(...l(.005,-o.h*.06)),i.quadraticCurveTo(...l(R*.6,-o.h*.12),...l(R,-o.h*.05)),i.stroke(),o.hookJaw&&(i.beginPath(),i.moveTo(...l(0,-o.h*.04)),i.quadraticCurveTo(...l(-.015,o.h*.02),...l(.01,o.h*.05)),i.stroke()),o.beak&&(i.fillStyle="#e86a3a",i.beginPath(),i.moveTo(...l(.02,-.006)),i.lineTo(...l(-.12,-.012)),i.lineTo(...l(.02,-.022)),i.fill()),o.bill&&(i.fillStyle=Uo(t.back),i.beginPath(),i.moveTo(...l(.03,.014)),i.lineTo(...l(-.2,.002)),i.lineTo(...l(.03,-.006)),i.fill()),o.barbel||o.whisker){i.strokeStyle=q_(t.back,.8),i.lineWidth=Math.max(.8,s*.004),i.lineCap="round";let _=o.barbel===2?3:1,b=o.barbel===2?.16:o.whisker?.05:.04;for(let C=0;C<_;C++)i.beginPath(),i.moveTo(...l(.03,-o.h*.08-C*.004)),i.quadraticCurveTo(...l(.04+b*.3,-o.h*.2-C*.02),...l(.03+b*(.6+C*.25),-o.h*.38-C*.04)),i.stroke()}{let _=o.sn<.7?.075:o.sn>1.3?.12:.085,b=Math.max(.012,o.h*.09)*(t.body==="tuna"||t.body==="disc"?1.15:1),[C,L]=l(_,o.h*.12);i.fillStyle=t.pat==="gold"?"#fff3c0":"#f4e7b8",i.beginPath(),i.arc(C,L,s*b,0,7),i.fill(),i.fillStyle="#111",i.beginPath(),i.arc(C-s*b*.1,L,s*b*.66,0,7),i.fill(),i.fillStyle="rgba(255,255,255,0.9)",i.beginPath(),i.arc(C-s*b*.35,L-s*b*.3,s*b*.22,0,7),i.fill()}i.restore()}function Pl(i,t,e,n,s,r,o=!1){let a=Z_(t),l=No[t.body],c=l.bill?.2:l.beak?.12:0,h=Math.min(s/(1.02+c),r/(2*a)),u=e+(s-h*(1+c))/2+h*c;ku(i,t,u,n+r/2,h,o)}var Du=20,Fp="taeil-lounge.fishing.v2",pi=.02,bt=(i,t)=>hn()==="ko"?i:t;function K_(){let i=null;try{i=JSON.parse(localStorage.getItem(Fp))}catch{}if(!i){let t=null;try{t=JSON.parse(localStorage.getItem("taeil-lounge.fishing.v1"))}catch{}i={coins:800,dex:(t==null?void 0:t.dex)||{},net:(t==null?void 0:t.net)||[]}}i.coins??=800,i.own||={rod:["bamboo"],float:["stick"],hook:["h3"],chum:["none"],bait:["worm"]},i.eq||={rod:"bamboo",float:"stick",hook:"h3",chum:"none",bait:"worm"},i.inv||={},i.net=(i.net||[]).filter(t=>ii[t.id]);for(let t of Object.keys(i.dex||{}))ii[t]||delete i.dex[t];return i}function ss(i){try{localStorage.setItem(Fp,JSON.stringify(i))}catch{}}var Uu=new Map,Il=512,Ll=384,zs=440,Nu=40,zu=192;function J_(i){if(Uu.has(i.id))return Uu.get(i.id);let t=document.createElement("canvas");t.width=Il,t.height=Ll,ku(t.getContext("2d"),i,Nu,zu,zs);let e=new nn(t);e.colorSpace=me,e.anisotropy=4;let n=No[i.body],s=n.eel?1:.8,r=30,o=16,a=[],l=[],c=[];for(let g=0;g<=r;g++){let p=g/r*s,[M,v]=ni(n,p),y=(M-v)/2,w=Math.max(5e-4,(M+v)/2),S=w*n.w*(.75+.25*Math.min(1,p*5));for(let T=0;T<=o;T++){let R=T/o*Math.PI*2,_=y+Math.cos(R)*w,b=Math.sin(R)*S;a.push(p-.5,_,b),l.push((Nu+p*zs)/Il,1-(zu-_*zs)/Ll)}}for(let g=0;g<r;g++)for(let p=0;p<o;p++){let M=g*(o+1)+p,v=M+o+1;c.push(M,v,M+1,v,v+1,M+1)}let h=new ce;h.setAttribute("position",new Ht(a,3)),h.setAttribute("uv",new Ht(l,2)),h.setIndex(c),h.computeVertexNormals();let u=i.pat==="gold"||i.pat==="silver",d=kn(new ye({map:e,roughness:.32,metalness:u?.55:.12})),f=new Ln(Il/zs,Ll/zs);f.translate((Il/2-Nu)/zs-.5,(zu-Ll/2)/zs,0);let m=kn(new ye({map:e,alphaTest:.45,side:Te,roughness:.5})),x={body:h,bodyMat:d,fins:f,finMat:m,tex:e};return Uu.set(i.id,x),x}function Fu(i,t){let e=J_(i),n=new Qt,s=new nt(e.body,e.bodyMat),r=new nt(e.fins,e.finMat);return s.castShadow=!0,n.add(s,r),n.scale.setScalar(t),n}function j_(i){let t=new Qt;t.position.set(0,-.06,.05),t.rotation.x=1.86;let e=Pt(i.col,{roughness:.28,metalness:i.id==="goldrod"?.8:.35}),n=Pt(12159573,{roughness:.9}),s=new nt(new zt(.024,.028,.42,8),n);s.position.y=-.12;let r=new nt(new zt(.055,.055,.05,14),Pt(12633290,{metalness:.9,roughness:.25}));r.rotation.z=Math.PI/2,r.position.set(0,0,-.07);let o=new nt(new Xt(.012,.012,.07),Pt(2236962));o.position.set(.04,0,-.07),t.add(s,r,o);let a=4,l=(i.len-.3)/a,c=[],h=t,u=.02;for(let m=0;m<a;m++){let x=Math.max(.004,u*.62),g=new zt(x,u,l,6);g.translate(0,l/2,0);let p=new Qt;p.position.y=m===0?.09:l;let M=new nt(g,e);M.castShadow=!0,p.add(M);let v=new nt(new Ts(u+.012,.003,4,10),Pt(14540253,{metalness:.8}));v.position.set(0,l*.5,-(u+.012)),v.rotation.y=Math.PI/2,p.add(v),h.add(p),c.push(p),h=p,u=x}let d=new nt(new Ce(.009,6,4),Pt(16734778,{emissive:5574912}));d.position.y=l,h.add(d);let f=new We;return f.position.y=l,h.add(f),{root:t,sections:c,tip:f}}function Q_(){let i=document.createElement("canvas");i.width=8,i.height=64;let t=i.getContext("2d");["#ff2d1a","#ffd400","#ff2d1a","#2ee06a","#ff2d1a","#ffd400","#ff2d1a","#ffffff"].forEach((s,r)=>{t.fillStyle=s,t.fillRect(0,r*8,8,8)});let n=new nn(i);return n.colorSpace=me,n}var Bu=null;function t1(i,t){let e=new Qt;if(t.type==="lure"){if(t.id==="popper"){let d=new nt(new zt(.035,.02,.12,10),Pt(16179274,{roughness:.3}));d.rotation.z=Math.PI/2,e.add(d)}else if(t.id==="jig"){let d=new nt(new Xt(.14,.03,.015),Pt(12634320,{metalness:.95,roughness:.15}));e.add(d)}else if(t.id==="softworm"){let d=new nt(new ti(.01,.1,3,6),Pt(6961802,{roughness:.5}));d.rotation.z=Math.PI/2,e.add(d)}else{let d=new nt(new ti(.02,.08,4,8),Pt(6987976,{metalness:.6,roughness:.25}));d.rotation.z=Math.PI/2;let f=new nt(new Xt(.03,.002,.025),Pt(15658734,{transparent:!0,opacity:.7}));f.position.set(-.07,-.01,0),e.add(d,f)}return e.userData.top=.02,e}if(i.id==="sinker"){let d=new nt(new Ce(.03,8,6),Pt(3355443,{metalness:.6}));return e.add(d),e.userData.top=0,e.userData.hidden=!0,e}Bu||=Q_();let s=Pt(16726815,{emissive:3344384,roughness:.4}),r=Pt(16053488,{roughness:.4});if(i.id==="round"||i.id==="bigfloat"){let d=i.id==="bigfloat"?.07:.05,f=new nt(new Ce(d,16,8,0,Math.PI*2,0,Math.PI/2),s),m=new nt(new Ce(d,16,8,0,Math.PI*2,Math.PI/2,Math.PI/2),r),x=new nt(new zt(.005,.005,.12,6),new ye({map:Bu}));return x.position.y=d+.05,e.add(f,m,x),e.userData.top=d+.11,e}let o=i.id==="shallow",a=o?.1:.2,l=o?.12:.3,c=new nt(new ti(o?.022:.016,a,4,10),o?s:Pt(16747034,{roughness:.35}));c.position.y=-a/2-.01;let h=new nt(new zt(.006,.008,l,8),i.glow?new ye({color:10354554,emissive:7012160,emissiveIntensity:1.6}):new ye({map:Bu,roughness:.4}));h.position.y=l/2;let u=new nt(new zt(.003,.003,.1,4),r);return u.position.y=-a-.07,e.add(c,h,u),e.userData.top=l,e}var kl=class{constructor(t){this.ctx=t,this.store=K_(),this.rodHolder=new Qt,this.bobber=new Qt,this.bobber.visible=!1,t.scene.add(this.bobber),this.line=new Gn(new ce().setFromPoints([new P,new P]),kn(new ki({color:16185078,transparent:!0,opacity:.85}))),this.line.frustumCulled=!1,this.line.visible=!1,t.scene.add(this.line),this.ripples=[0,1,2,3].map(()=>{let e=new nt(new yn(.15,.2,32),kn(new ke({color:16777215,transparent:!0,opacity:0,depthWrite:!1})));return e.rotation.x=-Math.PI/2,t.scene.add(e),{m:e,t:9}}),this.marker=new nt(new yn(.5,.75,40),kn(new ke({color:16769354,transparent:!0,opacity:.85,depthWrite:!1}))),this.marker.rotation.x=-Math.PI/2,this.marker.visible=!1,t.scene.add(this.marker),this.shadow=new nt(new sn(.5,16),kn(new ke({color:660504,transparent:!0,opacity:0,depthWrite:!1}))),this.shadow.rotation.x=-Math.PI/2,this.shadow.scale.set(1,.35,1),t.scene.add(this.shadow),this.pip={on:!1,el:null,cam:new Ge(28,4/3,.03,400)},this.buildNet(),this.buildUI(),this.equip(),this.state="idle",this.lean=0}get water(){return this.ctx.venue.water||"fresh"}gear(t){return zo(t,this.store.eq[t])}equip(){var e;let t=this.gear("rod");this.rod&&this.rodHolder.remove(this.rod.root),this.rod=j_(t),this.rodHolder.add(this.rod.root),this.bobber.clear(),this.floatMesh=t1(this.gear("float"),this.gear("bait")),this.bobber.add(this.floatMesh),(e=this.updateGearBar)==null||e.call(this)}buildNet(){let t=this.netGroup=new Qt,e=jt.pier;t.position.set(-50.2,0,e.hw+.55);let n=new nt(new zt(.4,.34,1.2,18,5,!0),new ye({color:2046762,wireframe:!0,transparent:!0,opacity:.75}));n.position.y=-.25;let s=new nt(new Ts(.4,.02,6,24),Pt(2976335));s.rotation.x=Math.PI/2,s.position.y=.35,t.add(n,s),this.netFish=[],this.ctx.scene.add(t),this.refreshNet3D()}refreshNet3D(){for(let t of this.netFish)this.netGroup.remove(t);this.netFish=this.store.net.slice(-8).map((t,e)=>{let n=Fu(ii[t.id],.14+Math.min(.24,t.cm/380));return n.userData.phase=e*1.3,this.netGroup.add(n),n})}buildUI(){this.uiLang=hn();let t=this.ui={};t.bar=De("gp-fish",`
      <div class="mid" id="fStatus" style="text-align:center"></div>
      <div id="fBars" style="margin-top:8px">
        <div class="row" style="justify-content:space-between"><span class="dim" id="fBar1L"></span><span id="fBar1V"></span></div>
        <div class="gp-meter" id="fBar1" style="margin-top:3px"><span class="zone"></span><i></i><span class="mark" hidden></span></div>
        <div id="fFight" hidden>
          <div class="row" style="justify-content:space-between;margin-top:6px"><span class="dim">${U("fishStamina")}</span><span id="fHpV"></span></div>
          <div class="gp-meter" id="fHp" style="margin-top:3px;height:10px"><i style="background:linear-gradient(90deg,#60a5fa,#a78bfa)"></i></div>
          <div class="row" style="justify-content:center;gap:16px;margin-top:6px;font-size:22px"><span id="fL">\u25C0</span><span id="fRod" style="font-size:14px" class="dim"></span><span id="fR">\u25B6</span></div>
        </div>
      </div>
      <div id="fSet" class="row" style="justify-content:center;margin-top:7px;font-size:12px;gap:4px 6px;align-items:center">
        <span id="fDepthW"><span class="dim">${bt("\uC218\uC2EC","Depth")}</span> <button data-d="-1" class="sm">\u2212</button> <b id="fDepth"></b> <button data-d="1" class="sm">\uFF0B</button> <span class="dim" id="fBottom"></span></span>
        <span class="dim">\xB7</span>
        <span><span class="dim">${bt("\uB4DC\uB799","Drag")}</span> <button data-g="-1" class="sm">\u2212</button> <b id="fDrag"></b> <button data-g="1" class="sm">\uFF0B</button></span>
      </div>
      <div id="fGear" class="row" style="justify-content:center;margin-top:7px;font-size:12px;gap:4px 10px"></div>
      <div class="dim" id="fHelp" style="margin-top:5px;text-align:center;font-size:11px"></div>`),t.bar.style.cssText="left:50%;transform:translateX(-50%);bottom:max(14px, env(safe-area-inset-bottom));padding:10px 14px;width:min(500px, calc(100vw - 150px))",t.btns=De("gp-fish-btns",`<div class="row" style="flex-direction:column;align-items:stretch">
      <div class="mid" style="text-align:center;color:#fde047" id="fCoins"></div>
      <button data-a="tackle">\u{1F392} ${bt("\uC7A5\uBE44\xB7\uC0C1\uC810","Tackle shop")}</button>
      <button data-a="net">\u{1F9FA} <span>${U("keepNet")}</span> <b id="fNetN"></b></button>
      <button data-a="dex">\u{1F4D6} ${U("dex")} <b id="fDexN"></b></button>
      <button data-a="exit">${U("exit")}</button></div>`),t.btns.style.cssText="right:10px;top:calc(max(10px, env(safe-area-inset-top)) + 54px);padding:8px",t.btns.querySelector("[data-a=tackle]").onclick=()=>this.toggle("tackle"),t.btns.querySelector("[data-a=net]").onclick=()=>this.toggle("net"),t.btns.querySelector("[data-a=dex]").onclick=()=>this.toggle("dex"),t.btns.querySelector("[data-a=exit]").onclick=()=>this.ctx.exit(),t.pip=De("gp-fish-pip",`<div class="pipLabel">\u{1F50D} ${bt("\uCC0C \uD655\uB300","Float close-up")}</div><div class="pipHint" id="fPipHint"></div>`),t.pip.style.cssText="left:10px;top:calc(max(10px, env(safe-area-inset-top)) + 110px);width:min(300px, 34vw);height:min(225px, 26vw);padding:0;background:transparent;pointer-events:none;border:2px solid rgba(255,255,255,.75);overflow:hidden",this.pip.el=t.pip,t.card=De("gp-fish-card",""),t.card.style.cssText="left:12px;top:50%;transform:translateY(-50%);padding:16px;width:min(320px, calc(100vw - 24px));text-align:center",t.list=De("gp-fish-list",""),t.list.style.cssText="left:50%;top:50%;transform:translate(-50%,-50%);padding:14px;width:min(640px, calc(100vw - 24px));max-height:80vh;overflow:auto",t.status=t.bar.querySelector("#fStatus"),t.bar.querySelectorAll("[data-d]").forEach(e=>e.onclick=()=>this.setDepth(+e.dataset.d)),t.bar.querySelectorAll("[data-g]").forEach(e=>e.onclick=()=>this.setDrag(+e.dataset.g)),this.updateGearBar()}setDepth(t){if(this.state!=="idle"&&this.state!=="returning"){this.ctx.toast(bt("\uB358\uC9C0\uAE30 \uC804\uC5D0 \uC870\uC808\uD558\uC138\uC694","Set it before casting"));return}this.store.depthM=Math.round(Math.max(.3,Math.min(5,(this.store.depthM??1.2)+t*.1))*10)/10,ss(this.store),this.updateSetRow()}setDrag(t){this.store.drag=Math.max(1,Math.min(10,(this.store.drag??7)+t)),ss(this.store),this.updateSetRow()}bottomAt(t){return Math.round((.8+Math.min(1,t/22)*3.4)*10)/10}dragLimit(){return .45+(this.store.drag??7)*.07}updateSetRow(){var s;let t=(s=this.ui)==null?void 0:s.bar.querySelector("#fSet");if(!t)return;let e=this.gear("float"),n=this.gear("bait").type==="lure";t.querySelector("#fDepthW").style.display=n?"none":"",t.querySelector("#fDepth").textContent=e.bell?bt("\uBC14\uB2E5","bottom"):`${(this.store.depthM??1.2).toFixed(1)} m`,t.querySelectorAll("[data-d]").forEach(r=>r.hidden=!!e.bell),t.querySelector("#fBottom").textContent=this.castDist&&this.state!=="idle"?`(${bt("\uBC14\uB2E5","bottom")} ${this.bottomAt(this.castDist).toFixed(1)} m)`:"",t.querySelector("#fDrag").textContent=this.store.drag??7}updateGearBar(){if(!this.ui)return;this.updateSetRow();let t=r=>this.gear(r),e=t("bait"),n=t("chum"),s=e.pack?this.store.inv[e.id]||0:"\u221E";this.ui.bar.querySelector("#fGear").innerHTML=`<span>${t("rod").icon} ${Pe(Ds(t("rod")))}</span><span>${t("float").icon} ${Pe(Ds(t("float")))}</span><span>${t("hook").icon} ${Pe(Ds(t("hook")))}</span><span>${e.icon} ${Pe(Ds(e))} <b>${s}</b></span>`+(n.id!=="none"?`<span>${n.icon} ${Pe(Ds(n))} <b>${this.store.inv[n.id]||0}</b></span>`:""),this.ui.bar.querySelector("#fHelp").textContent=e.type==="lure"?bt("\uC2A4\uD398\uC774\uC2A4(\uBC84\uD2BC) \uB204\uB978 \uCC44 \uB193\uAE30: \uCE90\uC2A4\uD305 \xB7 \uB204\uB974\uACE0 \uC788\uC73C\uBA74 \uB8E8\uC5B4 \uAC10\uAE30 \xB7 \uB35C\uCEE5! \uD558\uBA74 \uD0ED \xB7 \u2190\u2192 \uBC29\uD5A5","Hold & release to cast \xB7 hold to retrieve the lure \xB7 tap when it thumps \xB7 \u2190\u2192 aim"):bt("\uC2A4\uD398\uC774\uC2A4(\uBC84\uD2BC) \uB20C\uB7EC \uAC8C\uC774\uC9C0 \u2192 \uC6D0\uD558\uB294 \uD798\uC5D0\uC11C \uB193\uAE30 \xB7 \uCC0C\uAC00 \uC62C\uB77C\uC624\uAC70\uB098 \uC7A0\uAE30\uBA74 \uD0ED(\uCC54\uC9C8) \xB7 \uD30C\uC774\uD305: \uB204\uB974\uACE0 \uAC10\uAE30 + \u2190\u2192\uB85C \uBC84\uD2F0\uAE30 \xB7 [ ] \uC218\uC2EC \xB7 \u2191\u2193 \uB4DC\uB799","Hold, release at the power you want \xB7 strike when the float rises or dives \xB7 fight: hold to reel, lean \u2190\u2192 \xB7 [ ] depth \xB7 \u2191\u2193 drag"),this.ui.btns&&(this.ui.btns.querySelector("#fCoins").textContent=`\u{1F4B0} ${Us().toLocaleString()}`)}toggle(t){let e=this.ui.list;if(!e.hidden&&this.listMode===t){e.hidden=!0;return}this.listMode=t,e.hidden=!1,t==="net"?this.renderNet():t==="dex"?this.renderDex():this.renderTackle()}renderNet(){var o;let t=this.ui.list,e=this.store.net,n=e.reduce((a,l)=>a+l.kg,0),s=e.reduce((a,l)=>a+Fo(ii[l.id],l.kg,l.st),0),r=`<h3>\u{1F9FA} ${U("keepNet")} ${e.length}/${Du} \xB7 ${U("totalWeight")} ${n.toFixed(2)} kg \xB7 \u{1F4B0} ${s.toLocaleString()}</h3>`;e.length||(r+=`<div class="dim" style="padding:20px;text-align:center">${U("emptyNet")}</div>`),r+='<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px">',e.forEach((a,l)=>{let c=ii[a.id];r+=`<div class="slot" style="flex-direction:column;align-items:stretch"><canvas data-i="${l}" width="280" height="112" style="width:100%"></canvas>
        <b>${Pe(Ni(a.id))}</b><span class="dim">${a.cm} cm \xB7 ${a.kg} kg \xB7 <span style="color:#fde047">${"\u2605".repeat(a.st)}</span></span>
        <div class="row" style="margin-top:4px"><button data-sell="${l}" style="flex:1">\u{1F4B0} ${Fo(c,a.kg,a.st)}</button><button data-rel="${l}">${U("release")}</button></div></div>`}),r+=`</div><div class="row" style="justify-content:flex-end;margin-top:10px">${e.length?`<button data-a="all" class="go">\u{1F4B0} ${bt("\uBAA8\uB450 \uD310\uB9E4","Sell all")} +${s.toLocaleString()}</button>`:""}<button data-a="close">\u2715</button></div>`,t.innerHTML=r,t.querySelectorAll("canvas[data-i]").forEach(a=>Pl(a.getContext("2d"),ii[e[+a.dataset.i].id],6,4,268,104)),t.querySelectorAll("[data-rel]").forEach(a=>a.onclick=()=>{e.splice(+a.dataset.rel,1),this.afterNet(),this.renderNet()}),t.querySelectorAll("[data-sell]").forEach(a=>a.onclick=()=>{let l=e.splice(+a.dataset.sell,1)[0];this.earn(Fo(ii[l.id],l.kg,l.st)),this.afterNet(),this.renderNet()}),(o=t.querySelector("[data-a=all]"))==null||o.addEventListener("click",()=>{e.length=0,this.earn(s),this.afterNet(),this.renderNet()}),t.querySelector("[data-a=close]").onclick=()=>{t.hidden=!0}}earn(t){var n,s;if(!t)return;let e=Nr(t);(s=(n=this.ctx.audio)==null?void 0:n.coin)==null||s.call(n),this.ctx.toast(e?`\u{1F4B0} +${e} P`:bt(`\uC624\uB298 \uBC1B\uC744 \uC218 \uC788\uB294 \uD3EC\uC778\uD2B8(${30} P)\uB97C \uB2E4 \uBC1B\uC558\uC5B4\uC694`,"Daily point limit reached")),ss(this.store),this.updateGearBar()}renderDex(t=this.dexWater||this.water){this.dexWater=t;let e=this.ui.list,n=this.store.dex,s=un[t],r=s.filter(h=>n[h.id]).length,o=un.fresh.length+un.sea.length,a=[...un.fresh,...un.sea].filter(h=>n[h.id]).length,l=`<div class="row" style="justify-content:space-between"><h3 style="margin:0">\u{1F4D6} ${U("dex")} ${a}/${o}</h3>
      <div class="row"><button data-w="fresh" class="${t==="fresh"?"on":""}">${U("freshWater")} ${un.fresh.filter(h=>n[h.id]).length}/${un.fresh.length}</button>
      <button data-w="sea" class="${t==="sea"?"on":""}">${U("seaWater")} ${un.sea.filter(h=>n[h.id]).length}/${un.sea.length}</button></div></div>
      <div class="dim" style="margin:4px 0 8px">${r}/${s.length} \xB7 ${bt("\uC7A1\uC740 \uC5B4\uC885\uC740 \uC88B\uC544\uD558\uB294 \uBBF8\uB07C\uAC00 \uD45C\uC2DC\uB3FC\uC694","Caught species show their favourite baits")}</div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:8px">`,c=h=>h.w<=1?"\u{1F31F}":h.w<=2?"\u{1F48E}":h.w<=6?"\u2B50":"";s.forEach((h,u)=>{let d=n[h.id],f=h.baits.slice(0,2).map(m=>zo("bait",m).icon).join(" ");l+=`<div class="slot" style="flex-direction:column;align-items:stretch;text-align:center;gap:2px"><canvas data-i="${u}" width="260" height="110" style="width:100%"></canvas>
        <b>${c(h)} ${d?Pe(Ni(h.id)):U("unknown")}</b><span class="dim" style="font-size:11px">${d?`${U("best")} ${d.cm} cm \xB7 \xD7${d.n} \xB7 ${f} \xB7 ${{top:bt("\uD45C\uCE35","top"),mid:bt("\uC911\uCE35","mid"),bot:bt("\uBC14\uB2E5","bottom")}[h.depth]}`:`${h.min}\u2013${h.max} cm`}</span></div>`}),l+='</div><div class="row" style="justify-content:flex-end;margin-top:10px"><button data-a="close">\u2715</button></div>',e.innerHTML=l,e.querySelectorAll("canvas[data-i]").forEach(h=>{let u=s[+h.dataset.i];Pl(h.getContext("2d"),u,6,4,248,102,!n[u.id])}),e.querySelectorAll("[data-w]").forEach(h=>h.onclick=()=>this.renderDex(h.dataset.w)),e.querySelector("[data-a=close]").onclick=()=>{e.hidden=!0}}renderTackle(t=this.tackleTab||"rod"){this.tackleTab=t;let e=this.ui.list,n=this.store,s={rod:bt("\uB09A\uC2EF\uB300","Rods"),float:bt("\uCC0C\xB7\uCC44\uBE44","Floats"),hook:bt("\uBC14\uB298","Hooks"),chum:bt("\uB5A1\uBC25\xB7\uBC11\uBC25","Groundbait"),bait:bt("\uBBF8\uB07C\xB7\uB8E8\uC5B4","Bait & lures")},r=`<div class="row" style="justify-content:space-between"><h3 style="margin:0">\u{1F392} ${bt("\uC7A5\uBE44\xB7\uC0C1\uC810","Tackle shop")}</h3><span class="mid" style="color:#fde047">\u{1F4B0} ${Us().toLocaleString()} P</span></div>
      <div class="row" style="margin:8px 0">${Lp.map(l=>`<button data-tab="${l}" class="${l===t?"on":""}">${s[l]}</button>`).join("")}</div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:8px">`,o=l=>un[this.water].filter(c=>c.baits[0]===l||c.baits[1]===l).slice(0,4).map(c=>Ni(c.id)).join(", "),a={top:bt("\uC595\uC740 \uC218\uC2EC","shallow"),mid:bt("\uC911\uCE35","mid-water"),bot:bt("\uBC14\uB2E5","bottom")};for(let l of Rl[t]){let c=n.own[t].includes(l.id),h=n.eq[t]===l.id,u=t==="bait"&&l.pack||t==="chum"&&l.uses?n.inv[l.id]||0:null,d="";t==="rod"&&(d=`${bt("\uCD5C\uB300","max")} ${l.cast} m \xB7 ${bt("\uAC15\uB3C4","power")} \xD7${l.str} \xB7 ${bt("\uAC10\uB3C4","feel")} \xD7${l.sens}${l.lure>1?` \xB7 ${bt("\uB8E8\uC5B4","lures")} \xD7${l.lure}`:""}`),t==="float"&&(d=`${bt("\uAC10\uB3C4","feel")} \xD7${l.sens} \xB7 ${a[l.depth]}${l.stick?bt(" \xB7 \uCC0C\uC62C\uB9BC"," \xB7 rises on bites"):""}${l.bell?bt(" \xB7 \uCD08\uB9BF\uB300 \uBC29\uC6B8"," \xB7 rod-tip bell"):""}${l.glow?bt(" \xB7 \uC57C\uAD11"," \xB7 glow"):""}`),t==="hook"&&(d=`${bt("\uD06C\uAE30","size")} ${["S","M","L","XL"][l.size+1]} \xB7 ${bt("\uCD5C\uB300","holds")} ${l.str} kg${l.lureHook?bt(" \xB7 \uB8E8\uC5B4 \uAC78\uB9BC\u2191"," \xB7 better lure hook-ups"):""}`),t==="chum"&&(d=l.id==="none"?bt("\uBC11\uBC25 \uC5C6\uC774 \uB09A\uC2DC","No groundbait"):`${bt("\uC785\uC9C8 \uB300\uAE30","wait")} \u2212${Math.round((1-l.wait)*100)}% \xB7 ${Object.keys(l.boost).filter(m=>m!=="big").slice(0,3).map(m=>Ni(m)).join(", ")}\u2191 \xB7 ${l.uses}${bt("\uD68C"," casts")}`),t==="bait"&&(d=`${l.type==="lure"?bt("\uB8E8\uC5B4 \xB7 \uBB34\uC81C\uD55C","Lure \xB7 reusable"):`${l.pack?l.pack+bt("\uAC1C"," pcs"):bt("\uBB34\uC81C\uD55C","unlimited")}`} \xB7 ${Pe(o(l.id)||bt("\uC774 \uBB3C\uC5D4 \uC798 \uC548 \uBB34\uB294 \uBBF8\uB07C","few takers here"))}`);let f=!c||u!==null;r+=`<div class="slot" style="flex-direction:column;align-items:stretch;gap:4px;${h?"outline:2px solid #ffcc33":""}">
        <div class="row" style="justify-content:space-between"><b>${l.icon} ${Pe(Ds(l))}</b>${u!==null?`<span class="dim">\xD7${u}</span>`:""}</div>
        <span class="dim" style="font-size:11px;line-height:1.35">${d}</span>
        <div class="row">${c?`<button data-eq="${l.id}" class="${h?"on":""}" style="flex:1">${h?bt("\uC7A5\uCC29 \uC911","Equipped"):bt("\uC7A5\uCC29","Equip")}</button>`:""}
        ${f&&l.price?`<button data-buy="${l.id}" class="go" ${Us()<l.price?"disabled":""} style="flex:1">\u{1F4B0} ${l.price.toLocaleString()}${u!==null?` (+${l.pack||l.uses})`:""}</button>`:""}</div></div>`}r+='</div><div class="row" style="justify-content:flex-end;margin-top:10px"><button data-a="close">\u2715</button></div>',e.innerHTML=r,e.querySelectorAll("[data-tab]").forEach(l=>l.onclick=()=>this.renderTackle(l.dataset.tab)),e.querySelectorAll("[data-eq]").forEach(l=>l.onclick=()=>{if(this.state!=="idle"){this.ctx.toast(bt("\uB09A\uC2EF\uB300\uB97C \uAC70\uB454 \uB4A4\uC5D0 \uBC14\uAFC0 \uC218 \uC788\uC5B4\uC694","Reel in first"));return}n.eq[t]=l.dataset.eq,ss(n),this.equip(),this.renderTackle(t)}),e.querySelectorAll("[data-buy]").forEach(l=>l.onclick=()=>{var h,u;let c=zo(t,l.dataset.buy);Su(c.price)&&(n.own[t].includes(c.id)||n.own[t].push(c.id),(c.pack||c.uses)&&(n.inv[c.id]=(n.inv[c.id]||0)+(c.pack||c.uses)),(u=(h=this.ctx.audio)==null?void 0:h.coin)==null||u.call(h),ss(n),this.updateGearBar(),this.renderTackle(t))}),e.querySelector("[data-a=close]").onclick=()=>{e.hidden=!0}}afterNet(){ss(this.store),this.refreshNet3D(),this.updateCounts()}updateCounts(){this.ui.btns.querySelector("#fNetN").textContent=`${this.store.net.length}/${Du}`;let t=un[this.water];this.ui.btns.querySelector("#fDexN").textContent=`${t.filter(e=>this.store.dex[e.id]).length}/${t.length}`,this.updateGearBar()}enter(){if(this.active=!0,this.state="idle",this.aim=Math.PI,this.dexWater=null,this.ctx.hud.hide(),this.uiLang!==hn()){for(let t of["bar","btns","card","list","pip"])this.ui[t].remove();this.buildUI()}this.equip(),this.ctx.avatar.setProp(this.rodHolder),this.ui.bar.hidden=this.ui.btns.hidden=!1,zp("#btnPower").hidden=!pt.touch,this.updateCounts(),this.setStatus(`\u{1F3A3} ${U("cast")}`)}exit(){var t;this.active=!1,this.state="idle",this.bobber.visible=this.line.visible=this.marker.visible=!1,this.pip.on=!1,this.shadow.material.opacity=0,this.dropHooked(),this.held&&((t=this.held.parent)==null||t.remove(this.held),this.held=null),this.ctx.avatar.armLOverride=null,this.ctx.avatar.setProp(null);for(let e of["bar","btns","card","list","pip"])this.ui[e].hidden=!0;zp("#btnPower").hidden=!0}setStatus(t){this.statusText!==t&&(this.statusText=t,this.ui.status.textContent=t)}powerDown(){switch(this.state){case"idle":{this.ui.list.hidden||(this.ui.list.hidden=!0);let t=this.gear("bait");t.pack&&!(this.store.inv[t.id]>0)&&(this.store.eq.bait="worm",this.equip(),this.ctx.toast(bt("\uBBF8\uB07C\uAC00 \uB5A8\uC5B4\uC838\uC11C \uC9C0\uB801\uC774\uB85C \uBC14\uAFE8\uC5B4\uC694","Out of bait, switched to worms"))),this.state="charging",this.chargePhase=0,this.charge=0;break}case"bite":this.strike();break;case"waiting":if(this.isLure)break;this.nibbleT>0?this.reelIn(U("tooEarly")):this.reelIn();break;case"landed":this.decide(!0);break}}powerUp(){this.state==="charging"&&this.release()}castTarget(t){let e=this.gear("rod"),n=this.gear("float"),s=e.cast*(n.id==="sinker"?1.15:1),r=2.5+t*(s-2.5),o=new P(Math.cos(this.aim),0,Math.sin(this.aim)),a=this.ctx.player.pos,l=new P(a.x,pi,a.z).addScaledVector(o,r+.8),c=jt.lake,h=l.x-c.x,u=l.z-c.z,d=Math.hypot(h,u);return d>c.r-1&&l.set(c.x+h/d*(c.r-1),pi,c.z+u/d*(c.r-1)),l}release(){var t;this.state="casting",this.castT=0,this.castTo=this.castTarget(this.charge),this.castCharge=this.charge,this.marker.visible=!1,(t=this.ctx.audio)==null||t.whoosh()}launch(){let t=this.tipWorld(),e=Math.hypot(this.castTo.x-t.x,this.castTo.z-t.z);this.flight={from:t,to:this.castTo.clone(),t:0,dur:.45+e*.04,peak:1.2+e*.16},this.bobber.position.copy(t),this.state="flying",this.bobber.visible=!this.floatMesh.userData.hidden||!0,this.line.visible=!0;let n=this.gear("bait"),s=this.gear("chum");n.pack&&(this.store.inv[n.id]=Math.max(0,(this.store.inv[n.id]||0)-1)),this.chumOn=s.id!=="none"&&(this.store.inv[s.id]||0)>0,this.chumOn?this.store.inv[s.id]--:s.id!=="none"&&(this.store.eq.chum="none"),ss(this.store),this.updateGearBar()}viewPivot(){return(this._piv||=new P).copy(this.ctx.player.pos).setY(this.ctx.player.pos.y+1.2)}tipWorld(){return this.rod.tip.getWorldPosition(new P)}startWait(){var d;let t=this.gear("bait"),e=this.gear("float"),n=this.gear("rod"),s=this.gear("hook"),r=this.chumOn?this.gear("chum"):zo("chum","none");this.isLure=t.type==="lure",this.state=this.isLure?"waiting":"settling",this.settleT=0;let o=this.ctx.player.pos;this.castDist=Math.hypot(this.bobber.position.x-o.x,this.bobber.position.z-o.z);let a=this.bottomAt(this.castDist),l=this.store.depthM??1.2,c=l/a,h=c>.75?"bot":c<.35?"top":"mid";this.floatFlat=!this.isLure&&!e.bell&&l>a+.15;let u=Up({water:this.water,biome:this.ctx.venue.biome,rod:n,float:e,hook:s,chum:r,bait:t,castFrac:Math.min(1,this.castDist/22),depthZone:h});this.sp=Np(u),this.updateSetRow(),this.waitT=(3+Math.random()*6+(this.sp.w<=2?4:0))*r.wait*(this.isLure?.8:1)*(this.floatFlat?1.8:1),this.nibbles=this.isLure?[]:Array.from({length:Math.floor(Math.random()*3)+1},()=>Math.random()*(this.waitT-1.2)+.4).sort((f,m)=>m-f),this.nibbleT=0,this.biteKind=this.isLure?"thump":e.id==="sinker"?"bell":e.stick&&["carp","crucian","slim"].includes(this.sp.body)?"rise":"sink",this.shadow.position.set(this.bobber.position.x+4,-.05,this.bobber.position.z+2),this.setStatus(U("waiting")),(d=this.ctx.audio)==null||d.splash(.5),this.splash(this.bobber.position,.9)}strike(){let t=this.gear("float"),e=this.gear("hook"),n=this.gear("rod"),s=1;this.biteKind==="rise"?s=Math.min(1,.35+this.biteP*.9):s=Math.max(.4,1-this.biteP*.5);let r=Math.min(.97,(.5+.45*s)*e.hookup*(.9+.1*n.sens));if(Math.random()>r){this.reelIn(`\u{1F4A8} ${bt("\uD5DB\uCC54\uC9C8! \uBC14\uB298\uC5D0 \uC548 \uAC78\uB838\uC5B4\uC694","Missed the strike")}`);return}this.hook()}hook(){var c,h;let t=this.sp,e=this.gear("rod"),s=1.9-this.gear("hook").size*.25-(e.big-1)*.6,r=Math.min(1,Math.pow(Math.random(),Math.max(.8,s))+(this.castDist>14?.06:0)),o=Math.round(t.min+r*(t.max-t.min)),a=kp(t,o),l=(o-t.min)/(t.max-t.min);this.fish={sp:t,cm:o,kg:a,stamina:1,big:l,power:t.fight*(.55+.45*l)*(1+Math.log10(1+a)*.35)/e.str,dist:Math.max(4,this.castDist),ang:0,dir:0,runT:.6,restT:0,jumpT:0},this.tension=.3,this.slackT=0,this.overT=0,this.hookStrain=0,this.state="fight",this.shadow.material.opacity=0,(c=this.ctx.audio)==null||c.click(1),(h=navigator.vibrate)==null||h.call(navigator,60),this.ctx.toast(`\u{1F3A3} ${U("hooked")}`),this.ui.bar.querySelector("#fFight").hidden=!1,this.dropHooked(),this.hooked=Fu(t,Math.min(1.6,o/100)),this.ctx.scene.add(this.hooked)}dropHooked(){this.hooked&&(this.ctx.scene.remove(this.hooked),this.hooked=null)}reelIn(t){this.state="returning",this.retT=0,this.shadow.material.opacity=0,this.dropHooked(),this.ui.bar.querySelector("#fFight").hidden=!0,t&&this.ctx.toast(t)}splash(t,e=1){let n=this.ripples.find(s=>s.t>1)||this.ripples[0];n.t=0,n.k=e,n.m.position.set(t.x,.035,t.z)}update(t){var x,g,p,M,v,y;let e=es(),n=performance.now()/1e3;["idle","charging"].includes(this.state)&&(this.aim+=Dr(t)-e.x*.004),this.aim=Math.max(Math.PI-1.1,Math.min(Math.PI+1.1,this.aim));{let w=this.ctx.input.keys;this.setKeyT=Math.max(0,(this.setKeyT||0)-t),this.setKeyT||(w.has("BracketLeft")?(this.setDepth(-1),this.setKeyT=.15):w.has("BracketRight")?(this.setDepth(1),this.setKeyT=.15):w.has("Minus")?(this.setDrag(-1),this.setKeyT=.2):w.has("Equal")&&(this.setDrag(1),this.setKeyT=.2))}this.camPitch=Math.max(-.5,Math.min(.7,(this.camPitch||0)+e.y*.004)),this.lastLookX=e.x*.012;let s=this.ctx.player;s.pos.set(-50.8,0,0),s.yaw=Math.atan2(Math.cos(this.aim),Math.sin(this.aim)),s.speed=0;let r=this.ctx.avatar,o=r.armR,a=this.ui.bar.querySelector("#fBar1"),l=(w,S,T,R)=>{this.ui.bar.querySelector("#fBar1L").textContent=w,this.ui.bar.querySelector("#fBar1V").textContent=T;let _=a.querySelector("i");_.style.width=`${Math.min(100,S*100)}%`,_.style.background=R?S>.88?"#f87171":S<.12?"#94a3b8":"linear-gradient(90deg,#6ee7b7,#34d399)":"";let b=a.querySelector(".zone");b.hidden=!R,R&&(b.style.left="40%",b.style.width="45%",b.style.background="rgba(110,231,183,.25)")},c=this.floatMesh,h=-.5;switch(this.pip.on=!1,this.state){case"idle":o.rotation.x=-.9,l(U("cast"),0,"",!1),this.setStatus(`\u{1F3A3} ${U("cast")}`);break;case"charging":{this.chargePhase+=t*.85;let w=this.chargePhase%2;this.charge=w<1?w:2-w;let S=this.castTarget(this.charge);l(U("cast"),this.charge,`${Math.round(Math.hypot(S.x-s.pos.x,S.z-s.pos.z))} m`,!1),o.rotation.x+=(-3.15-o.rotation.x)*Math.min(1,t*10),h=-1.3,this.marker.visible=!0,this.marker.position.set(S.x,.05,S.z),this.marker.scale.setScalar(1+Math.sin(n*6)*.08);break}case"casting":{this.castT+=t/.24;let w=Math.min(1,this.castT);o.rotation.x=-3.15+(3.15-.55)*(1-Math.pow(1-w,2.2)),h=-1.3+w*.8,w>.45&&!((x=this.flight)!=null&&x.live)&&(this.launch(),this.flight.live=!0),w>=1&&(this.state="flying"),l(U("cast"),this.castCharge,"",!1);break}case"flying":{let w=this.flight;w.t+=t/w.dur;let S=Math.min(1,w.t);this.bobber.position.lerpVectors(w.from,w.to,S),this.bobber.position.y=w.from.y+(w.to.y-w.from.y)*S+Math.sin(S*Math.PI)*w.peak,this.bobber.rotation.set(0,0,Math.PI/2*S),o.rotation.x+=(-.75-o.rotation.x)*Math.min(1,t*6),S>=1&&(this.flight=null,this.startWait());break}case"settling":{this.settleT+=t/.9;let w=Math.min(1,this.settleT);this.bobber.rotation.z=Math.PI/2*(1-w*w),this.bobber.position.y=pi+(1-w)*.02-w*0,o.rotation.x=-.9,this.pip.on=!c.userData.hidden,this.floatFlat&&(this.bobber.rotation.z=Math.max(this.bobber.rotation.z,1.35)),w>=1&&(this.state="waiting",this.bobber.rotation.z=this.floatFlat?1.35:0,this.floatFlat&&this.ctx.toast(`\u2198 ${bt("\uCC0C\uAC00 \uB204\uC6E0\uC5B4\uC694: \uC218\uC2EC\uC774 \uBC14\uB2E5\uBCF4\uB2E4 \uAE4A\uC5B4\uC694. \uC218\uC2EC\uC744 \uC904\uC5EC \uBCF4\uC138\uC694","The float is lying flat: deeper than the bottom. Reduce the depth")}`)),l(U("waiting"),0,"",!1);break}case"waiting":{if(this.waitT-=t*(this.isLure&&!pt.power?.35:1),this.nibbleT=Math.max(0,this.nibbleT-t),this.nibbles.length&&this.waitT<this.nibbles[0]&&(this.nibbles.shift(),this.nibbleT=.35,this.splash(this.bobber.position,.3),this.setStatus(`\u{1F4A7} ${U("nibble")}`),this.biteKind==="bell"&&((g=this.ctx.audio)==null||g.click(.4))),this.isLure){let S=s.pos,T=this.bobber.position,R=Math.hypot(T.x-S.x,T.z-S.z);if(pt.power){let _=1.6*t;T.x+=(S.x-T.x)/R*_,T.z+=(S.z-T.z)/R*_,Math.random()<t*4&&((p=this.ctx.audio)==null||p.reel())}if(T.y=this.gear("bait").id==="popper"?pi+Math.abs(Math.sin(n*6))*.01:-.03+Math.sin(n*3)*.01,this.bobber.rotation.set(0,Math.atan2(-(S.z-T.z),S.x-T.x)+Math.PI,Math.sin(n*9)*(pt.power?.25:.05)),R<2.2){this.reelIn(bt("\uC785\uC9C8 \uC5C6\uC774 \uB8E8\uC5B4\uB97C \uD68C\uC218\uD588\uC5B4\uC694","No takers, lure retrieved"));break}this.setStatus(pt.power?`\u{1F300} ${bt("\uB8E8\uC5B4 \uAC10\uB294 \uC911\u2026","Retrieving\u2026")}`:`\u23F8 ${bt("\uB204\uB974\uACE0 \uC788\uC73C\uBA74 \uB8E8\uC5B4\uB97C \uAC10\uC544\uC694","Hold to retrieve")}`)}else{let S=Math.sin(n*1.7)*.006,T=this.nibbleT>0?Math.sin((.35-this.nibbleT)/.35*Math.PI)*.045:0;this.bobber.position.y=pi+S-T,this.biteKind==="bell"&&(this.tipShake=T*6),this.nibbleT||this.setStatus(U("waiting"))}let w=Math.max(0,1-this.waitT/3);if(this.shadow.material.opacity=w*.4,this.shadow.position.lerp(new P(this.bobber.position.x+.3,-.05,this.bobber.position.z),t*.9),this.shadow.rotation.z=Math.atan2(this.bobber.position.z-this.shadow.position.z,this.bobber.position.x-this.shadow.position.x),this.shadow.scale.setScalar(.5+this.sp.max/160),this.waitT<0){this.state="bite",this.biteT=0;let S=this.gear("float"),T=this.gear("rod"),R=this.biteKind==="rise"?1.5:this.biteKind==="thump"?.7:.8;this.biteDur=R*S.sens*T.sens*(this.sp.w<=4?.8:1),this.setStatus(this.biteKind==="rise"?`\u2B06\uFE0F ${bt("\uCC0C\uC62C\uB9BC! \uC62C\uB77C\uC62C \uB54C \uCC54\uC9C8!","The float is rising! Strike!")}`:this.biteKind==="thump"?`\u{1F4A5} ${bt("\uB35C\uCEE5! \uC9C0\uAE08 \uCC54\uC9C8!","Thump! Strike!")}`:this.biteKind==="bell"?`\u{1F514} ${bt("\uBC29\uC6B8\uC774 \uC6B8\uB824\uC694! \uCC54\uC9C8!","The bell rings! Strike!")}`:`\u2757 ${U("biteNow")}`),this.splash(this.bobber.position,this.biteKind==="rise"?.5:1.2),this.biteKind==="bell"?(M=this.ctx.audio)==null||M.bell():(v=this.ctx.audio)==null||v.plop(),(y=navigator.vibrate)==null||y.call(navigator,100)}o.rotation.x=this.isLure?-.7+Math.sin(n*9)*(pt.power?.06:0):-.9,this.pip.on=!c.userData.hidden||this.biteKind==="bell"||this.isLure,l(U("waiting"),0,"",!1);break}case"bite":{this.biteT+=t,this.biteP=Math.min(1,this.biteT/this.biteDur);let w=this.biteP;this.biteKind==="rise"?this.bobber.position.y=pi+Math.sin(w*Math.PI/2)*.14+Math.sin(n*20)*.003:this.biteKind==="sink"?this.bobber.position.y=pi-Math.min(1,w*4)*.4+Math.sin(n*30)*.01:this.biteKind==="bell"?this.tipShake=Math.sin(n*40)*.6:this.tipShake=Math.max(0,1-w*3)*1.2,o.rotation.x=-.9,this.pip.on=!0,l(bt("\uCC54\uC9C8 \uD0C0\uC774\uBC0D","Strike timing"),this.biteKind==="rise"?w:1-w,"",!1),this.biteT>this.biteDur&&this.reelIn(U("missed"));break}case"fight":this.updateFight(t,n,l,o),this.pip.on=!0;break;case"landed":o.rotation.x=-2.4;break;case"returning":{this.retT+=t*2.5,this.bobber.position.lerp(this.tipWorld(),Math.min(1,this.retT)),this.retT>=1&&(this.state="idle",this.bobber.visible=this.line.visible=!1,this.bobber.rotation.set(0,0,0));break}}this.state!=="charging"&&(this.marker.visible=!1),r.armLOverride=this.held?-1.25:h,c.visible=!c.userData.hidden;for(let w of this.ripples){if(w.t>1){w.m.material.opacity=0;continue}w.t+=t*.9,w.m.scale.setScalar(1+w.t*6*(w.k||1)),w.m.material.opacity=(1-w.t)*.7}this.netFish.forEach((w,S)=>{let T=n*.6+w.userData.phase;w.position.set(Math.cos(T)*.2,-.15-S%4*.13,Math.sin(T)*.2),w.rotation.set(0,-T+Math.PI/2+Math.sin(n*6+S)*.15,0)}),this.tipShake=(this.tipShake||0)*Math.pow(.02,t);let u=this.state==="fight"?this.tension:0;if(this.rod.sections.forEach((w,S)=>{w.rotation.x=-u*(.08+S*.07)-(this.tipShake||0)*.05*(S+1)*Math.sin(n*35),w.rotation.z=this.state==="fight"?this.lean*.04*(S+1):0}),this.line.visible){let w=this.tipWorld(),S=this.bobber.position,T=w.clone().lerp(S,.5);T.y-=this.state==="fight"?.05*(1-Math.min(1,this.tension)):this.state==="flying"||this.state==="casting"?.1:.6,this.line.geometry.setFromPoints(new _o(w,T,S).getPoints(16))}let d=this.ctx.camTarget,f=new P(Math.cos(this.aim),0,Math.sin(this.aim)),m=new P(-f.z,0,f.x);if(this.state==="landed"){let w=new P(Math.sin(s.yaw),0,Math.cos(s.yaw));d.pos.set(s.pos.x,1.8,s.pos.z).addScaledVector(w,3.2).add(new P(w.z*.6,0,-w.x*.6)),d.look.set(s.pos.x,1.3,s.pos.z)}else{let w=this.state==="charging"?this.marker.position:["flying","settling","waiting","bite","fight"].includes(this.state)?this.bobber.position:null;d.pos.set(s.pos.x,0,s.pos.z).addScaledVector(f,-3.6).addScaledVector(m,-1.9),d.pos.y=4+this.camPitch*3,w?d.look.set(w.x,0,w.z).lerp(new P(s.pos.x,.6,s.pos.z),.2):d.look.set(s.pos.x,.4,s.pos.z).addScaledVector(f,9),d.look.y-=this.camPitch*2}if(this.ui.pip.hidden=!this.pip.on,this.pip.on){let w=this.pip.cam,S=this.bobber.position,T=new P(s.pos.x-S.x,0,s.pos.z-S.z).normalize();if(this.biteKind==="bell"&&this.state!=="fight"){let R=this.tipWorld();w.position.copy(R).addScaledVector(m,1.1).add(new P(0,.15,0)).addScaledVector(f,-.3),w.lookAt(R.x,R.y-.1,R.z),this.ui.pip.querySelector(".pipLabel").textContent=`\u{1F514} ${bt("\uCD08\uB9BF\uB300","Rod tip")}`}else{let R=this.state==="fight"?.8:this.isLure?.9:.32,_=this.state==="fight"?2.4:this.isLure?2.2:1.25;w.position.set(S.x,pi+R,S.z).addScaledVector(T,_).addScaledVector(m,.15),w.lookAt(S.x,this.isLure||this.state==="fight"?pi:pi+(c.userData.top||.1)*.45,S.z),this.ui.pip.querySelector(".pipLabel").textContent=`\u{1F50D} ${this.isLure?bt("\uB8E8\uC5B4","Lure"):bt("\uCC0C \uD655\uB300","Float close-up")}`}this.ui.pip.querySelector("#fPipHint").textContent=this.state==="bite"?"\u2757":""}}updateFight(t,e,n,s){var b,C,L,k,D,V;let r=this.fish,o=this.gear("hook"),a=this.ctx.input.keys,l=0;(a.has("ArrowLeft")||a.has("KeyA"))&&(l-=1),(a.has("ArrowRight")||a.has("KeyD"))&&(l+=1),this.dragLean=Math.max(-1,Math.min(1,(this.dragLean||0)*Math.pow(.2,t)+(this.lastLookX||0))),this.lastLookX=0,l===0&&(l=this.dragLean),this.lean+=(l-this.lean)*Math.min(1,t*8),r.runT-=t,r.runT<=0&&(r.dir!==0||Math.random()<.3?(r.dir=0,r.runT=.8+Math.random()*1.4*r.stamina):(r.dir=Math.random()<.5?-1:1,r.runT=.8+Math.random()*2*r.stamina,(b=this.ctx.audio)==null||b.click(.2),(r.sp.depth==="top"||r.sp.fight>.75)&&Math.random()<.4&&r.dist>3&&(r.jumpT=.9)));let c=r.dir!==0,h=c?-r.dir*this.lean:0,u=r.power*(c?1:.35)*(.45+.55*r.stamina)*(.85+.3*Math.sin(e*5.3));u*=1-.55*Math.max(0,h)+.6*Math.max(0,-h);let d=this.ctx.input.power;d&&Math.random()<t*6&&((C=this.ctx.audio)==null||C.reel());let f=Math.min(1.3,(d?.38:.04)+u*.85),m=this.dragLimit(),x=0;f>m&&(x=f-m,f=m+x*.2),this.tension+=(f-this.tension)*Math.min(1,t*2.6),x>.02&&(r.dist+=x*3.2*t,Math.random()<t*14&&((L=this.ctx.audio)==null||L.reel())),this.dragSlip=x,a.has("ArrowUp")||a.has("KeyW")?(this.dragKeyT||this.setDrag(1),this.dragKeyT=.25):(a.has("ArrowDown")||a.has("KeyS"))&&(this.dragKeyT||this.setDrag(-1),this.dragKeyT=.25),this.dragKeyT=Math.max(0,(this.dragKeyT||0)-t),r.dist+=(d?-(1.7-u*1.6)*(x>.02?.3:1):u*1.3)*t,r.ang+=r.dir*t*.18*(1-Math.max(0,h)*.7),r.ang=Math.max(-.9,Math.min(.9,r.ang*(1-t*.15)));let g=this.tension>.4&&this.tension<.85;r.stamina=Math.max(0,r.stamina-t*(.03+(g?.075:.012)*(d?1:.4)+Math.max(0,h)*.03)/(.7+r.kg/25)),this.overT=this.tension>1?this.overT+t:Math.max(0,this.overT-t),this.slackT=this.tension<.1?this.slackT+t:0,r.kg>o.str&&this.tension>.7&&(this.hookStrain+=t*(r.kg/o.str)*.4);let p=this.ctx.player,M=this.aim+r.ang,v=jt.lake,y=p.pos.x+Math.cos(M)*r.dist,w=p.pos.z+Math.sin(M)*r.dist,S=y-v.x,T=w-v.z,R=Math.hypot(S,T);if(R>v.r-.8&&(y=v.x+S/R*(v.r-.8),w=v.z+T/R*(v.r-.8)),this.bobber.position.set(y,-.04+Math.sin(e*14)*.03,w),Math.random()<t*(c?6:2)&&this.splash(this.bobber.position,.35+u*.4),this.hooked){r.jumpT=Math.max(0,r.jumpT-t);let z=new P(y-p.pos.x,0,w-p.pos.z).normalize(),G=new P(-z.z*r.dir,0,z.x*r.dir).addScaledVector(z,c?.5:.2).normalize(),F=this.hooked.scale.x,K=r.jumpT>0?Math.sin((1-r.jumpT/.9)*Math.PI):0;this.hooked.position.set(y+z.x*F*.5,-.12-F*.08+K*(.5+F*.6),w+z.z*F*.5),this.hooked.rotation.set(0,Math.atan2(G.z,-G.x),K*.9*(r.dir||1)),this.hooked.rotation.x=Math.sin(e*14)*.12,r.jumpT>0&&r.jumpT<t*1.5&&(this.splash(this.hooked.position,1.4),(k=this.ctx.audio)==null||k.splash(1))}s.rotation.x=-1.1-this.tension*.6+Math.sin(e*22)*.04*this.tension,n(U("tension"),this.tension/1.1,`${this.dragSlip>.02?`\u{1F300} ${bt("\uB4DC\uB799 \uD480\uB9BC","drag slipping")} \xB7 `:""}${Math.round(this.tension*100)}% \xB7 ${U("lineLeft")} ${Math.max(0,r.dist).toFixed(1)} m`,!0);let _=this.ui.bar;_.querySelector("#fHp i").style.width=`${r.stamina*100}%`,_.querySelector("#fHpV").textContent=`${Math.round(r.stamina*100)}%`,_.querySelector("#fL").style.opacity=r.dir===1?1:.25,_.querySelector("#fR").style.opacity=r.dir===-1?1:.25,_.querySelector("#fL").style.color=r.dir===1?"#fde047":"",_.querySelector("#fR").style.color=r.dir===-1?"#fde047":"",_.querySelector("#fRod").textContent=c?r.dir===1?U("pullLeft"):U("pullRight"):"",this.setStatus(r.jumpT>0?`\u{1F41F}\u203C\uFE0F ${bt("\uC810\uD504!","Jump!")}`:c?`\u{1F41F}\u{1F4A8} ${U("running")}`:`\u{1F3A3} ${U("reel")}\u2026`),this.overT>.55||r.dist>40?((D=navigator.vibrate)==null||D.call(navigator,200),(V=this.ctx.audio)==null||V.snap(),this.reelIn(r.dist>40?`\u{1F4A5} ${bt("\uC904\uC774 \uB2E4 \uD480\uB824 \uB04A\uC5B4\uC84C\uC5B4\uC694! \uB4DC\uB799\uC744 \uC870\uAE08 \uC870\uC5EC \uBCF4\uC138\uC694","Spooled! Tighten the drag a little")}`:`\u{1F4A5} ${U("snapped")}`)):this.hookStrain>1?this.reelIn(`\u{1FA9D} ${bt("\uBC14\uB298\uC774 \uD3B4\uC84C\uC5B4\uC694! \uB354 \uD070 \uBC14\uB298\uC774 \uD544\uC694\uD574\uC694","The hook straightened! Use a bigger hook")}`):this.slackT>2.4?this.reelIn(U("escaped")):r.dist<=1.3&&(r.stamina<.3?this.land():(r.dist=1.3,r.dir=Math.random()<.5?-1:1,r.runT=1.2))}land(){var c,h,u;let t=this.fish,e=t.sp;this.state="landed",this.dropHooked(),this.bobber.visible=this.line.visible=!1,this.ui.bar.querySelector("#fFight").hidden=!0,(c=this.ctx.audio)==null||c.chime(),(u=(h=this.ctx).snap)==null||u.call(h);let n=this.store.dex[e.id],s=!n,r=n&&t.cm>n.cm;this.store.dex[e.id]={cm:Math.max((n==null?void 0:n.cm)||0,t.cm),n:((n==null?void 0:n.n)||0)+1},ss(this.store),this.updateCounts();let o=Math.max(.45,Math.min(1.3,t.cm/100));this.held=Fu(e,o),this.held.rotation.set(0,0,.35),this.held.position.set(-.05,.78+o*.12,.34),this.ctx.avatar.body.add(this.held),t.st=Dp(e,t.cm),this.ctx.net.event({type:"catch",fish:e.id,kg:t.kg});let a=this.ui.card,l=Fo(e,t.kg,t.st);a.innerHTML=`${s?`<div class="mid" style="color:#fde047">\u2728 ${U("newSpecies")}</div>`:r?`<div class="mid" style="color:#7dd3fc">\u{1F3C5} ${U("newRecord")}</div>`:""}
      <canvas width="560" height="240" style="width:100%;max-width:290px"></canvas>
      <div class="big" style="margin-top:4px">${Pe(Ni(e.id))}</div>
      <div style="color:#fde047;font-size:18px;margin:4px 0">${"\u2605".repeat(t.st)}<span style="opacity:.25">${"\u2605".repeat(5-t.st)}</span></div>
      <div class="kv" style="justify-content:center"><span>${U("length")}</span><b>${t.cm} cm</b><span>${U("weight")}</span><b>${t.kg} kg</b><span>\u{1F4B0}</span><b>${l.toLocaleString()}</b></div>
      <div class="row" style="justify-content:center;margin-top:12px"><button class="go" data-a="keep">\u{1F9FA} ${U("keep")}</button><button data-a="sell">\u{1F4B0} ${bt("\uBC14\uB85C \uD310\uB9E4","Sell")}</button><button data-a="rel">${U("release")}</button></div>`,Pl(a.querySelector("canvas").getContext("2d"),e,14,10,532,220),a.querySelector("[data-a=keep]").onclick=()=>this.decide(!0),a.querySelector("[data-a=sell]").onclick=()=>{this.earn(l),this.decide(!1,!0)},a.querySelector("[data-a=rel]").onclick=()=>this.decide(!1),a.hidden=!1,this.setStatus(`\u{1F41F} ${Ni(e.id)} ${t.cm} cm`)}decide(t,e=!1){var s,r;if(this.state!=="landed")return;let n=this.fish;if(t){if(this.store.net.length>=Du){this.ctx.toast(U("netFull"));return}this.store.net.push({id:n.sp.id,cm:n.cm,kg:n.kg,st:n.st}),this.afterNet()}else e||(this.ctx.toast(`\u{1F30A} ${U("released")}`),this.splash(new P(this.ctx.player.pos.x-1.5,0,this.ctx.player.pos.z),.6),(s=this.ctx.audio)==null||s.splash(.6));this.held&&((r=this.held.parent)==null||r.remove(this.held),this.held=null),this.ui.card.hidden=!0,this.state="idle"}},zp=i=>document.querySelector(i);var e1=(i,t)=>hn()==="ko"?i:t,mi={pool:{L:2.24,W:1.12,R:.028575,cloth:2062925,rail:5977120,pockets:!0,cushE:.74,roll:.3,drag:.1,vmax:6.5},carom:{L:2.844,W:1.422,R:.03075,cloth:2051471,rail:7029800,pockets:!1,cushE:.8,roll:.22,drag:.075,vmax:7.5}},Bo={carom3:"carom",carom4:"carom",pool8:"pool"},n1=1/600,i1=.94,s1=[16777215,16106776,2052049,14034984,6958225,16219904,2792779,9117214,1118481,16106776,2052049,14034984,6958225,16219904,2792779,9117214],r1=[16448250,16241214,14100014,14100014];function o1(i,t,e){let n=document.createElement("canvas");n.width=256,n.height=128;let s=n.getContext("2d"),r="#"+i.toString(16).padStart(6,"0");if(!e&&t>=9?(s.fillStyle="#f8f8f4",s.fillRect(0,0,256,128),s.fillStyle=r,s.fillRect(0,36,256,56)):(s.fillStyle=r,s.fillRect(0,0,256,128)),!e&&t>0)for(let a of[64,192])s.fillStyle="#fff",s.beginPath(),s.arc(a,64,22,0,Math.PI*2),s.fill(),s.fillStyle="#111",s.font="bold 26px sans-serif",s.textAlign="center",s.textBaseline="middle",s.fillText(String(t),a,66);if(e||t===0){s.fillStyle=t===0&&!e?"#d33":"rgba(0,0,0,.35)";for(let[a,l]of[[64,64],[192,64],[128,10],[128,118]])s.beginPath(),s.arc(a,l,5,0,7),s.fill()}let o=new nn(n);return o.colorSpace=me,o.anisotropy=4,o}function Bp(i){let t=mi[Bo[i]],e=t.L,n=t.R,s=(l,c,h)=>[l,+c.toFixed(4),+h.toFixed(4),0];if(i==="carom3")return[s(0,-e/4,.152),s(1,-e/4,0),s(2,e/4,0)];if(i==="carom4")return[s(0,-e/4,.152),s(1,-e/4,0),s(2,e/4,0),s(3,0,0)];let r=[s(0,-e/4,0)],o=[1,9,2,10,8,3,11,4,12,5,13,6,14,7,15],a=0;for(let l=0;l<5;l++)for(let c=0;c<=l;c++)r.push(s(o[a++],e/4+l*n*1.74,(c-l/2)*n*2.01));return r}function Op(i){return[[-i.L/2,-i.W/2,.07],[0,-i.W/2-.012,.06],[i.L/2,-i.W/2,.07],[-i.L/2,i.W/2,.07],[0,i.W/2+.012,.06],[i.L/2,i.W/2,.07]]}var Hu=class{constructor(t,e,n){this.T=mi[t],this.P=this.T.pockets?Op(this.T):[],this.balls=e.map(([s,r,o,a])=>({n:s,x:r,z:o,vx:0,vz:0,in:!!a,top:0,side:0,rot:new Re})),this.cueN=n,this.ev={seq:[],cushions:{},first:null,pocketed:[],railAfter:!1}}ball(t){return this.balls.find(e=>e.n===t)}moving(){return this.balls.some(t=>!t.in&&t.vx*t.vx+t.vz*t.vz>1e-6)}strike(t,e,n,s,r=0){let o=this.ball(this.cueN),a=r*Math.PI/180;o.masse=n*e*Math.sin(a)*1.15,s-=Math.sin(a)*.25;let l=t-n*.03;o.vx=Math.cos(l)*e,o.vz=Math.sin(l)*e,o.top=s*e*.8,o.side=n*e*.65,o.preHit=!0}step(t){let e=Math.ceil(t/n1),n=t/e;for(;e-- >0;)this.sub(n)}sub(t){let e=this.T,n=e.R,s=e.L/2-n,r=e.W/2-n,o=this.balls.filter(a=>!a.in);for(let a of o){let l=Math.hypot(a.vx,a.vz);if(l>0){let u=Math.max(0,l-(e.roll+e.drag*l)*t);u<.004?a.vx=a.vz=0:(a.vx*=u/l,a.vz*=u/l),a.x+=a.vx*t,a.z+=a.vz*t;let d=u*t/n;d>0&&a.rot.premultiply(new Re().setFromAxisAngle(new P(a.vz,0,-a.vx).normalize(),d))}if(a.masse&&l>.02){let u=-a.vz/l,d=a.vx/l;a.vx+=u*a.masse*t,a.vz+=d*a.masse*t,a.masse*=Math.exp(-t*1.1)}a.top*=Math.exp(-t*.9),a.side*=Math.exp(-t*.25);let c=!1;for(let[u,d,f]of this.P){let m=Math.hypot(a.x-u,a.z-d);if(m<f){a.in=!0,a.vx=a.vz=0,this.ev.pocketed.push(a.n),this.ev.seq.push(["p",a.n,l]);break}m<f+.05&&(c=!0)}if(a.in||c)continue;let h=(u,d)=>{let f=u==="x"?a.vx:a.vz;if(f*d<=0)return;u==="x"?(a.x=d*s,a.vx=-a.vx*e.cushE):(a.z=d*r,a.vz=-a.vz*e.cushE),a.vx*=.97,a.vz*=.97;let m=Math.hypot(a.vx,a.vz)||1,x=-a.vz/m,g=a.vx/m,p=a.side*.32*Math.min(1,Math.abs(f)/2);u==="x"?a.vz+=g*p*2:a.vx+=x*p*2,a.side*=.55,a.top*=.6,this.ev.cushions[a.n]=(this.ev.cushions[a.n]||0)+1,this.ev.seq.push(["c",a.n,Math.abs(f)]),this.ev.first!=null&&(this.ev.railAfter=!0)};a.x>s?h("x",1):a.x<-s&&h("x",-1),a.z>r?h("z",1):a.z<-r&&h("z",-1)}for(let a=0;a<o.length;a++)for(let l=a+1;l<o.length;l++){let c=o[a],h=o[l];if(c.in||h.in)continue;let u=h.x-c.x,d=h.z-c.z,f=u*u+d*d,m=2*n;if(f>=m*m||f<1e-12)continue;let x=Math.sqrt(f),g=u/x,p=d/x,M=(c.vx-h.vx)*g+(c.vz-h.vz)*p,v=(m-x)/2;if(c.x-=g*v,c.z-=p*v,h.x+=g*v,h.z+=p*v,M<=0)continue;let y=[c,h].map(S=>[S.vx,S.vz]),w=M*(1+i1)/2;c.vx-=w*g,c.vz-=w*p,h.vx+=w*g,h.vz+=w*p;for(let[S,T]of[[0,c],[1,h]]){if(T.preHit&&T.top){let[R,_]=y[S],b=Math.hypot(R,_)||1;T.vx+=R/b*T.top*.55,T.vz+=_/b*T.top*.55,T.top*=.3}T.preHit=!1}(c.n===this.cueN||h.n===this.cueN)&&this.ev.first==null&&(this.ev.first=c.n===this.cueN?h.n:c.n),this.ev.seq.push(["b",c.n,h.n,M])}}pack(){return this.balls.map(t=>[t.n,+t.x.toFixed(4),+t.z.toFixed(4),t.in?1:0])}},Dl=class{constructor(t){this.ctx=t,this.hideAvatar=!0,this.group=new Qt;let e=jt.table;this.group.position.set(e.x,e.y,e.z),t.scene.add(this.group),this.focus=new P(e.x,0,e.z),this.tableKey=null,this.mode="pool8",this.meshes={},this.view="top",this.fpPitch=.32,this.fpDist=.95,addEventListener("wheel",n=>{!this.active||this.view!=="cue"||(this.fpDist=Math.max(.35,Math.min(2.6,this.fpDist*(n.deltaY>0?1.1:.9))))},{passive:!0}),this.guideOn=!0,this.ox=0,this.oy=0,this.chalk=1,this.aim=0,this.power=0,this.sim=null,this.appliedSeq=-1,this.buildCue(),this.buildTable("pool"),this.party=new Fr(t,"billiards",{onChange:n=>this.onParty(n),onMsg:n=>this.onPartyMsg(n)}),this.buildUI(),this.raycaster=new hl,ks("pointerDown",()=>this.onPointer(!0)),ks("pointerUp",()=>this.onPointer(!1)),addEventListener("keydown",n=>{var r;if(!this.active||/INPUT|SELECT|TEXTAREA/.test((r=document.activeElement)==null?void 0:r.tagName))return;let s=.12;n.code==="ArrowUp"&&this.setTip(this.ox,this.oy+s),n.code==="ArrowDown"&&this.setTip(this.ox,this.oy-s),n.code==="KeyZ"&&this.setTip(this.ox-s,this.oy),n.code==="KeyX"&&this.setTip(this.ox+s,this.oy),n.code==="KeyC"&&this.doChalk(),n.code==="BracketLeft"&&this.setElev(-5),n.code==="BracketRight"&&this.setElev(5),n.code==="KeyV"&&this.toggleView(),n.code==="KeyG"&&(this.guideOn=!this.guideOn),n.code==="Comma"&&this.nudge(-1),n.code==="Period"&&this.nudge(1)})}buildTable(t){if(this.tableKey===t)return;this.tableKey=t,this.table&&this.group.remove(this.table);let e=mi[t],n=jt.pavilion,s=this.table=new Qt,r=.05,o=.12,a=e.L+2*(r+o),l=e.W+2*(r+o),c=kt("wood",e.rail,{roughness:.35}),h=kt("felt",e.cloth),d=jt.table.y-n.y-.16;s.add(bn(new Xt(a-.06,.2,l-.06),c,0,-.13,0));for(let[v,y]of[[-1,-1],[1,-1],[-1,1],[1,1],[0,-1],[0,1]])v===0&&t==="pool"||s.add(bn(new Xt(.17,d,.17),c,v*(a/2-.22),-.23-d/2,y*(l/2-.22)));s.add(bn(new Xt(e.L+2*r,.03,e.W+2*r),h,0,-.015,0,!1));let f=e.R*1.3,m=kt("felt",new wt(e.cloth).multiplyScalar(.85).getHex());s.add(bn(new Xt(e.L,f,r),m,0,f/2,-e.W/2-r/2)),s.add(bn(new Xt(e.L,f,r),m,0,f/2,e.W/2+r/2)),s.add(bn(new Xt(r,f,e.W),m,-e.L/2-r/2,f/2,0)),s.add(bn(new Xt(r,f,e.W),m,e.L/2+r/2,f/2,0));let x=f+.012;s.add(bn(new Xt(a,x,o),c,0,x/2,-l/2+o/2)),s.add(bn(new Xt(a,x,o),c,0,x/2,l/2-o/2)),s.add(bn(new Xt(o,x,l),c,-a/2+o/2,x/2,0)),s.add(bn(new Xt(o,x,l),c,a/2-o/2,x/2,0));let g=Pt(16052194,{roughness:.3,metalness:.3}),p=new zt(.009,.009,.004,4);for(let v=1;v<8;v++){if(v===4&&t==="pool")continue;let y=-e.L/2+e.L/8*v;for(let w of[-1,1])s.add(bn(p,g,y,x+.002,w*(l/2-o/2),!1))}for(let v=1;v<4;v++){let y=-e.W/2+e.W/4*v;for(let w of[-1,1])s.add(bn(p,g,w*(a/2-o/2),x+.002,y,!1))}let M=new nt(new sn(.006,10),new ke({color:16777215}));for(let v of[-e.L/4,0,e.L/4]){let y=M.clone();y.rotation.x=-Math.PI/2,y.position.set(v,.0012,0),s.add(y)}if(e.pockets){let v=new ke({color:657930});for(let[y,w,S]of Op(e)){let T=new nt(new sn(S*1.05,20),v);T.rotation.x=-Math.PI/2,T.position.set(y,.002,w),s.add(T);let R=bn(new zt(S*1.05,S*.9,x+.004,20,1,!0),Pt(1118481,{side:Te}),y,x/2-.002,w,!1);s.add(R)}}this.group.add(s),this.makeBalls(t)}makeBalls(t){for(let o of Object.values(this.meshes))this.group.remove(o);this.meshes={};let e=mi[t],n=t==="carom",s=new Ce(e.R,28,18),r=n?4:16;for(let o=0;o<r;o++){let a=new nt(s,new sl({map:o1(n?r1[o]:s1[o],o,n),roughness:.12,clearcoat:1,clearcoatRoughness:.04}));a.castShadow=!0,a.visible=!1,this.group.add(a),this.meshes[o]=a}}paintCue(){let t=Dn("cue");this.cueId===t.id||!this.cueParts||(this.cueId=t.id,this.cueParts.shaft.material=kt("wood",t.col??15321504,{roughness:.3}),this.cueParts.butt.material=Pt(t.butt??1842210,{roughness:.35,metalness:.2}),this.tipMat.color.setHex(t.tip??3829720))}buildCue(){let t=this.cue=new Qt,e=1.45,n=Dn("cue");this.cueId=n.id;let s=new nt(new zt(.0065,.0145,e,14),kt("wood",n.col??15321504,{roughness:.3}));s.rotation.z=Math.PI/2,s.position.x=-e/2;let r=new nt(new zt(.0145,.016,.5,14),Pt(n.butt??1842210,{roughness:.35,metalness:.2}));r.rotation.z=Math.PI/2,r.position.x=-e+.25;let o=new nt(new zt(.0065,.0065,.02,12),Pt(16052712));o.rotation.z=Math.PI/2,o.position.x=-.012,this.tipMat=new ye({color:n.tip??3829720,roughness:.9});let a=new nt(new zt(.0062,.0065,.008,12),this.tipMat);a.rotation.z=Math.PI/2,a.position.x=-.002,t.add(s,r,o,a),this.cueParts={shaft:s,butt:r},t.traverse(c=>{c.castShadow=!0}),t.visible=!1,this.group.add(t),this.chalkCube=new nt(new Xt(.022,.022,.022),Pt(3043286,{roughness:.9})),this.chalkCube.visible=!1,this.group.add(this.chalkCube);let l=new Tr({color:16777215,dashSize:.02,gapSize:.014,transparent:!0,opacity:.85});this.guide=new Gn(new ce().setFromPoints([new P,new P(1,0,0)]),l),this.guide2=new Gn(new ce().setFromPoints([new P,new P(1,0,0)]),l.clone()),this.guide2.material.color.set(16769126),this.guide3=new Gn(new ce().setFromPoints([new P,new P(1,0,0)]),l.clone()),this.guide3.material.opacity=.45,this.ghost=new nt(new yn(.026,.03,24),new ke({color:16777215,transparent:!0,opacity:.8})),this.ghost.rotation.x=-Math.PI/2;for(let c of[this.guide,this.guide2,this.guide3,this.ghost])c.visible=!1,c.frustumCulled=!1,this.group.add(c)}buildUI(){var r,o;if(this.uiLang=hn(),this.ui)for(let a of Object.values(this.ui))(r=a.classList)!=null&&r.contains("gp")&&a.remove();(o=this.lobby)==null||o.el.remove(),this.lobby=new Br({title:`\u{1F3B1} ${U("billiards")}`,modes:[["carom3",U("carom3"),U("carom3s")],["carom4",U("carom4"),U("carom4s")],["pool8",U("pool8"),U("pool8s")]],onStart:a=>this.start(a),onExit:()=>this.ctx.exit()});let t=this.ui={};t.board=De("gp-bill-board",""),t.board.style.cssText="left:50%;transform:translateX(-50%);top:calc(max(10px, env(safe-area-inset-top)) + 52px);padding:8px 12px;min-width:min(420px, calc(100vw - 24px))",t.left=De("gp-bill-left",`
      <h3>${U("tipOffset")}</h3>
      <canvas id="bTip" width="120" height="120" style="display:block;margin:0 auto;touch-action:none;cursor:crosshair"></canvas>
      <div class="dim" id="bTipTxt" style="text-align:center;margin:4px 0;font-size:11px"></div>
      <div class="row" style="justify-content:center">
        <button data-a="chalk">\u{1F9CA} ${U("chalk")} <b id="bChalk"></b></button>
        <button data-a="center">\u2299</button>
      </div>
      <div class="row" style="justify-content:center;align-items:center;margin-top:6px;gap:3px;flex-wrap:nowrap;white-space:nowrap">
        <span class="dim" style="font-size:11px">${e1("\uAC01\uB3C4","Angle")}</span>
        <button data-a="el-" class="sm">\u2212</button><b id="bEl" style="min-width:30px;text-align:center"></b><button data-a="el+" class="sm">\uFF0B</button>
      </div>
      <div class="row" style="justify-content:center;margin-top:6px">
        <button data-a="view">\u{1F3A5} <span id="bView"></span></button>
        <button data-a="guide">\u{1F4D0}</button>
      </div>`),t.left.style.cssText="left:10px;bottom:max(14px, env(safe-area-inset-bottom));padding:10px;width:156px",t.right=De("gp-bill-right",`
      <h3 style="text-align:center">${U("power")}</h3>
      <div id="bGauge" style="position:relative;width:54px;height:200px;margin:0 auto;border-radius:12px;background:rgba(255,255,255,.1);touch-action:none;cursor:ns-resize;overflow:hidden">
        <i style="position:absolute;left:0;right:0;top:0;height:0;background:linear-gradient(#6ee7b7,#fde047,#f87171)"></i>
        <span style="position:absolute;left:0;right:0;bottom:6px;text-align:center;font-size:11px;opacity:.7">\u25BC ${U("pullBack")}</span>
      </div>
      <div class="mid" id="bPow" style="text-align:center;margin:4px 0">0%</div>
      <div class="row" style="justify-content:center;gap:4px">
        <button data-a="l2">\u23EA</button><button data-a="l1">\u25C0</button><button data-a="r1">\u25B6</button><button data-a="r2">\u23E9</button>
      </div>`),t.right.style.cssText="right:10px;bottom:max(14px, env(safe-area-inset-bottom));padding:10px",t.top=De("gp-bill-top",`<div class="row"><button data-a="exit">${U("exit")}</button><button data-a="rack">\u21BA ${U("rack")}</button></div>`),t.top.style.cssText="left:10px;top:calc(max(10px, env(safe-area-inset-top)) + 52px);padding:6px;background:transparent;border:0;box-shadow:none;backdrop-filter:none",t.help=De("gp-bill-help",""),t.help.style.cssText="left:50%;transform:translateX(-50%);bottom:max(14px, env(safe-area-inset-bottom));padding:6px 12px;font-size:11px;max-width:calc(100vw - 380px);text-align:center",t.tip=t.left.querySelector("#bTip");let e=a=>{let l=t.tip.getBoundingClientRect(),c=(a.clientX-l.left)/l.width*2-1,h=-((a.clientY-l.top)/l.height*2-1);this.setTip(c/.82,h/.82)};t.tip.addEventListener("pointerdown",a=>{t.tip.setPointerCapture(a.pointerId),this.tipDrag=!0,e(a)}),t.tip.addEventListener("pointermove",a=>{this.tipDrag&&e(a)}),t.tip.addEventListener("pointerup",()=>{this.tipDrag=!1}),t.left.querySelector("[data-a=chalk]").onclick=()=>this.doChalk(),t.left.querySelector("[data-a=center]").onclick=()=>this.setTip(0,0),t.left.querySelector('[data-a="el-"]').onclick=()=>this.setElev(-5),t.left.querySelector('[data-a="el+"]').onclick=()=>this.setElev(5),this.setElev(0),t.left.querySelector("[data-a=view]").onclick=()=>this.toggleView(),t.left.querySelector("[data-a=guide]").onclick=()=>{this.guideOn=!this.guideOn},t.top.querySelector("[data-a=exit]").onclick=()=>this.ctx.exit(),t.top.querySelector("[data-a=rack]").onclick=()=>{this.party.joined&&this.party.clear()};let n=t.right.querySelector("#bGauge");n.addEventListener("pointerdown",a=>{this.canShoot()&&(n.setPointerCapture(a.pointerId),this.gaugeDrag={y0:a.clientY,h:n.getBoundingClientRect().height})}),n.addEventListener("pointermove",a=>{this.gaugeDrag&&(this.power=Math.max(0,Math.min(1,(a.clientY-this.gaugeDrag.y0)/(this.gaugeDrag.h*.85))))});let s=()=>{this.gaugeDrag&&(this.gaugeDrag=null,this.power>.02?this.shoot():this.power=0)};n.addEventListener("pointerup",s),n.addEventListener("pointercancel",()=>{this.gaugeDrag=null,this.power=0});for(let[a,l]of[["l2",-5],["l1",-1],["r1",1],["r2",5]]){let c=t.right.querySelector(`[data-a=${a}]`),h=null,u=()=>{clearInterval(h),h=null};c.addEventListener("pointerdown",()=>{this.nudge(l),u(),h=setInterval(()=>this.nudge(l),90)}),c.addEventListener("pointerup",u),c.addEventListener("pointerleave",u),c.addEventListener("pointercancel",u)}this.drawTip()}showUI(t){for(let e of["board","left","right","top","help"])this.ui[e].hidden=!t}setTip(t,e){let n=Math.hypot(t,e),s=.9;n>s&&(t*=s/n,e*=s/n),this.ox=Math.round(t*100)/100,this.oy=Math.round(e*100)/100,this.drawTip()}drawTip(){let t=this.ui.tip,e=t.getContext("2d"),n=t.width,s=n/2,r=n*.41;e.clearRect(0,0,n,n);let o=e.createRadialGradient(s-r*.3,s-r*.3,r*.1,s,s,r);o.addColorStop(0,"#ffffff"),o.addColorStop(1,"#cfcfc8"),e.fillStyle=o,e.beginPath(),e.arc(s,s,r,0,7),e.fill(),e.strokeStyle="rgba(0,0,0,.25)",e.lineWidth=1;for(let h of[.33,.66])e.beginPath(),e.arc(s,s,r*h,0,7),e.stroke();e.beginPath(),e.moveTo(s-r,s),e.lineTo(s+r,s),e.moveTo(s,s-r),e.lineTo(s,s+r),e.stroke(),e.strokeStyle="rgba(239,68,68,.6)",e.setLineDash([3,3]),e.beginPath(),e.arc(s,s,r*.72,0,7),e.stroke(),e.setLineDash([]);let a=s+this.ox*r*.82/.82*.82,l=s-this.oy*r*.82/.82*.82;e.fillStyle="#ef4444",e.beginPath(),e.arc(a,l,7,0,7),e.fill(),e.strokeStyle="#fff",e.lineWidth=2,e.stroke();let c=[];this.oy>.08&&c.push(`${U("follow")} ${Math.round(this.oy*100)}`),this.oy<-.08&&c.push(`${U("draw")} ${Math.round(-this.oy*100)}`),this.ox>.08&&c.push(`${U("rightEng")} ${Math.round(this.ox*100)}`),this.ox<-.08&&c.push(`${U("leftEng")} ${Math.round(-this.ox*100)}`),this.ui.left.querySelector("#bTipTxt").textContent=c.join(" \xB7 ")||U("centerBall")}doChalk(){var t,e;this.chalkAnim>0||(this.chalkAnim=1.1,(e=(t=this.ctx.audio)==null?void 0:t.chalk)==null||e.call(t))}setElev(t){var n;this.elev=Math.max(0,Math.min(60,(this.elev||0)+t));let e=(n=this.ui)==null?void 0:n.left.querySelector("#bEl");e&&(e.textContent=`${this.elev}\xB0`)}toggleView(){var t,e,n,s;this.view=this.view==="top"?"cue":"top",(e=(t=this.ctx).resetView)==null||e.call(t),(s=(n=this.ctx).snap)==null||s.call(n)}nudge(t){this.canAim()&&(this.aim+=t*.0012)}enter(){var t,e;this.active=!0,this.ctx.hud.hide(),this.uiLang!==hn()&&this.buildUI(),this.paintCue(),this.cue.visible=!1;for(let n of[this.ctx.world.lamp,this.ctx.world.pavilionRoof])n&&(n.visible=!1);this.ctx.player.pos.set(jt.table.x,0,jt.table.z+1.4),!this.party.joined&&this.party.slots.length<4&&!this.party.state&&this.party.join(),this.onParty(this.party.state),(e=(t=this.ctx).snap)==null||e.call(t)}exit(){this.active=!1,this.party.leave(),this.lobby.hide(),this.showUI(!1),this.cue.visible=this.chalkCube.visible=!1;for(let t of[this.guide,this.guide2,this.guide3,this.ghost])t.visible=!1;this.ctx.camTarget.up.set(0,1,0);for(let t of[this.ctx.world.lamp,this.ctx.world.pavilionRoof])t&&(t.visible=!0);this.sim=null}start(t){let e=this.party.slots.length;if(!e)return;let n={phase:"play",mode:t,balls:Bp(t),turn:0,scores:Array(e).fill(0),innings:Array(e).fill(0),runs:Array(e).fill(0),high:Array(e).fill(0),target:t==="pool8"?0:e>2?8:10,groups:null,ballInHand:t==="pool8",winner:null,msg:"",last:null};n.innings[0]=1,this.party.setState(n),this.onParty(n)}onParty(t){var e,n;if(!this.active){t&&(this.buildTable(Bo[t.mode]),this.showBalls(t.balls));return}if(!t){this.showUI(!1),this.lobby.show(this.party),this.buildTable("pool"),this.showBalls(Bp("pool8"));return}if(this.lobby.hide(),this.ui.board.hidden&&((n=(e=this.ctx).snap)==null||n.call(e)),this.showUI(!0),t.seq===this.appliedSeq){this.renderBoard();return}this.appliedSeq=t.seq,this.buildTable(Bo[t.mode]),(!this.sim||!this.sim.mine)&&(this.sim=null,this.showBalls(t.balls)),(this.prevTurn!==t.turn||this.prevMode!==t.mode)&&(this.aimAtTarget(t),this.setTip(0,0)),this.prevTurn=t.turn,this.prevMode=t.mode,this.renderBoard()}onPartyMsg(t){if(!this.active)return;let e=t.d;e.k==="shot"&&this.runShot(e,!1)}cueN(t=this.party.state){return t?t.mode==="pool8"?0:t.turn%2:0}team(t){return t%2}canAim(){let t=this.party.state;return!!t&&t.phase==="play"&&!this.sim&&this.party.mine(t.turn)}canShoot(){return this.canAim()&&!this.chalkAnim}aimAtTarget(t){let e=t.balls.find(r=>r[0]===this.cueN(t)),n=null,s=1e9;for(let r of t.balls)if(r[0]!==e[0]&&!r[3]){let o=Math.hypot(r[1]-e[1],r[2]-e[2]);o<s&&(s=o,n=r)}n&&(this.aim=Math.atan2(n[2]-e[2],n[1]-e[1]))}shoot(){if(!this.canShoot())return;let t=this.party.state,e=Math.hypot(this.ox,this.oy),n=Math.max(0,e-.55)*2.2*(1.3-this.chalk)+(e>.72?.35:0),s=Math.random()<n,r={k:"shot",slot:t.turn,aim:this.aim,power:this.power,ox:this.ox,oy:this.oy,el:this.elev||0,miscue:s,balls:this.currentBalls()};this.chalk=Math.max(0,this.chalk-.18-e*.15),this.party.msg(r),this.runShot(r,!0),this.power=0}currentBalls(){return this.party.state.balls.map(t=>[...t])}runShot(t,e){var h,u;let n=this.party.state,s=mi[Bo[n.mode]],r=n.mode==="pool8"?0:t.slot%2;this.sim=new Hu(Bo[n.mode],t.balls,r),this.sim.mine=e,this.sim.slot=t.slot;let o=.35+Math.pow(t.power,1.25)*(s.vmax-.35),a=t.aim,l=t.ox,c=t.oy;t.miscue&&(o*=.2,a+=(Math.random()-.5)*.25,l=c=0,this.ctx.toast(`\u{1F4A5} ${U("miscue")}`)),this.strikeAnim={t:0,aim:t.aim,el:t.el||0,cue:t.balls.find(d=>d[0]===r)};{let d=t.balls.find(f=>f[0]===r);this.fpAnchor={x:d[1],z:d[2],aim:t.aim}}this.sim.strike(a,o,l,c,t.miscue?0:t.el||0),(u=(h=this.ctx.audio)==null?void 0:h.cue)==null||u.call(h,.35+t.power*.65),this.restT=0}finishShot(){let t=this.sim,e=structuredClone(this.party.state);e.balls=t.pack(),e.ballInHand=!1;let n=this.party.slots.length,s=t.slot,r=t.ev,o=t.cueN,a=!1,l="";if(e.mode==="carom3"||e.mode==="carom4"){let c=e.balls.map(m=>m[0]).filter(m=>m!==o),h=e.mode==="carom4"?1-o:null,u=[],d=0,f=-1;for(let m of r.seq)if(m[0]==="c"&&m[1]===o&&d++,m[0]==="b"&&(m[1]===o||m[2]===o)){let x=m[1]===o?m[2]:m[1];u.includes(x)||(u.push(x),u.length===2&&(f=d))}if(e.mode==="carom3")u.length>=2&&f>=3?(e.scores[s]++,a=!0,l=`\u{1F3AF} ${U("point")}!`):l=u.length>=2?U("needCush",{n:f}):U("miss");else{let m=c.filter(g=>g!==h);u.includes(h)?(e.scores[s]=e.scores[s]-1,l=`\u26A0\uFE0F ${U("foulOpp")} \u22121`):u.length?m.every(g=>u.includes(g))?(e.scores[s]++,a=!0,l=`\u{1F3AF} ${U("point")}!`):l=U("miss"):(e.scores[s]=e.scores[s]-1,l=`\u26A0\uFE0F ${U("foulNone")} \u22121`)}e.scores[s]>=e.target&&(e.winner=s,e.phase="done",l=`\u{1F3C6} ${this.party.name(s)} ${U("wins")}`)}else{let c=this.team(s),h=p=>p>=1&&p<=7,u=p=>p>=9,d=r.pocketed,f=d.includes(0),m=e.groups?e.groups[c]:null,x=p=>e.balls.filter(M=>!M[3]&&(p==="solid"?h(M[0]):u(M[0]))).length,g="";if(f?g=U("scratch"):r.first==null?g=U("foulNone"):m&&r.first!==8&&m==="solid"!==h(r.first)?g=U("foulWrong"):m&&r.first===8&&x(m)+d.filter(p=>m==="solid"?h(p):u(p)).length>0?g=U("foulWrong"):!m&&r.first===8?g=U("foulWrong"):!d.length&&!r.railAfter&&(g=U("foulRail")),d.includes(8)){let p=m&&x(m)===0,M=p&&!g?c:1-c;e.phase="done",e.winner=n===1?M===c?s:-1:M,e.winnerTeam=M,l=M===c&&n>0&&p&&!g?`\u{1F3C6} ${U("eightWin")}`:`\u{1F480} ${U("eightLose")}`}else{let p=d.filter(v=>v!==0&&v!==8);if(!g&&!e.groups&&p.length){let v=h(p[0])?"solid":"stripe";e.groups={},e.groups[c]=v,e.groups[1-c]=v==="solid"?"stripe":"solid",l=`${U(v)} ${U("assigned")}`}let M=e.groups?p.filter(v=>e.groups[c]==="solid"===h(v)):p;if(e.scores[s]+=p.length?M.length:0,g){if(l=`\u26A0\uFE0F ${U("foul")}: ${g} \xB7 ${U("ballInHand")}`,e.ballInHand=!0,f){let v=e.balls.find(y=>y[0]===0);v[1]=-mi.pool.L/4,v[2]=0,v[3]=0,this.unblock(e,v)}}else M.length?(a=!0,l=l||`\u{1F3AF} ${U("potted",{n:M.length})}`):l||(l=U("miss"))}}a&&e.phase==="play"?(e.runs[s]++,e.high[s]=Math.max(e.high[s],e.runs[s])):(e.runs[s]=0,e.phase==="play"&&n>1?(e.turn=(s+1)%n,e.innings[e.turn]++):e.phase==="play"&&e.innings[s]++),e.msg=l,e.last=s,this.sim=null,this.party.setState(e),this.onParty(e),l&&this.ctx.toast(l)}unblock(t,e){let n=mi.pool.R;for(let s=0;s<40;s++){if(!t.balls.some(r=>r!==e&&!r[3]&&Math.hypot(r[1]-e[1],r[2]-e[2])<2.05*n))return;e[1]-=n}}tablePoint(){let t=pt.pointer;this.raycaster.setFromCamera(new rt(t.x,t.y),this.ctx.camera);let e=new Pn(new P(0,1,0),-(jt.table.y+mi[this.tableKey].R)),n=new P;return this.raycaster.ray.intersectPlane(e,n)?{x:n.x-this.group.position.x,z:n.z-this.group.position.z}:null}onPointer(t){if(!this.active||this.view!=="top"){this.dragBall=!1;return}if(!t){this.dragBall=!1;return}if(!this.canAim())return;let e=this.party.state,n=this.tablePoint();if(!n)return;let s=e.balls.find(r=>r[0]===this.cueN(e));e.ballInHand&&Math.hypot(n.x-s[1],n.z-s[2])<.09&&(this.dragBall=!0)}update(t){let e=this.party.state,n=es(),s=mi[this.tableKey];if(e&&e.phase!=="lobby"&&this.sim&&(this.sim.step(t),this.playSounds(),this.showBalls(this.sim.balls),this.sim.moving()||(this.restT+=t,this.restT>.35&&(this.sim.mine?this.finishShot():(this.sim=null,e&&this.showBalls(e.balls))))),this.chalkAnim>0&&(this.chalkAnim-=t,this.chalkAnim<=0&&(this.chalk=1,this.chalkAnim=0)),this.canAim()){let o=e.balls.find(a=>a[0]===this.cueN(e));if(this.dragBall&&pt.pointer.down){let a=this.tablePoint();if(a){let l=s.R,c=s.L/2-l,h=s.W/2-l,u=Math.max(-c,Math.min(c,a.x)),d=Math.max(-h,Math.min(h,a.z));e.balls.some(f=>f!==o&&!f[3]&&Math.hypot(f[1]-u,f[2]-d)<2.02*l)||(o[1]=+u.toFixed(4),o[2]=+d.toFixed(4)),this.showBalls(e.balls)}}else if(this.view==="top"&&pt.pointer.down&&!this.gaugeDrag&&!this.tipDrag){let a=this.tablePoint();a&&Math.hypot(a.x-o[1],a.z-o[2])>.03&&(this.aim=Math.atan2(a.z-o[2],a.x-o[1]))}else this.view==="cue"&&(this.aim-=n.x*.0018*(pt.keys.has("ShiftLeft")?.25:1));this.aim+=Dr(t)*.12*(pt.keys.has("ShiftLeft")?.25:1)*-1,pt.power&&!this.gaugeDrag&&(this.power=Math.min(1,(this.power||0)+t/1.6))}this.view==="cue"&&(this.fpPitch=Math.max(.04,Math.min(1.35,this.fpPitch+n.y*.004))),this.updateCue(t,e,s),this.updateCamera(e,s),this.updateHud(e);let r=this.ctx.player;if(e){let o=e.balls.find(a=>a[0]===this.cueN(e));if(o&&this.party.mine(e.turn)){let a=o[1],l=o[2];for(let c=0;c<60&&Math.abs(a)<s.L/2+.5&&Math.abs(l)<s.W/2+.5;c++)a-=Math.cos(this.aim)*.05,l-=Math.sin(this.aim)*.05;r.pos.set(this.group.position.x+a,0,this.group.position.z+l),r.yaw=Math.atan2(Math.cos(this.aim),Math.sin(this.aim))}}r.speed=0}playSounds(){var n,s,r;let t=this.sim.ev.seq,e=this.ctx.audio;if(e){for(let o=this.sim.sndIdx||0;o<t.length;o++){let a=t[o];a[0]==="b"?(n=e.clack)==null||n.call(e,Math.min(1,(a[3]||1)/2.2)):a[0]==="c"?(s=e.cushion)==null||s.call(e,Math.min(1,(a[2]||1)/2.5)):a[0]==="p"&&((r=e.pocket)==null||r.call(e))}this.sim.sndIdx=t.length}}powerDown(){}powerUp(){this.power>.02&&!this.gaugeDrag&&this.shoot()}showBalls(t){let e=mi[this.tableKey];for(let n of Object.values(this.meshes))n.visible=!1;for(let n of t){let s=Array.isArray(n)?n[0]:n.n,r=Array.isArray(n)?n[1]:n.x,o=Array.isArray(n)?n[2]:n.z,a=Array.isArray(n)?n[3]:n.in,l=this.meshes[s];l&&(l.visible=!a,l.position.set(r,e.R,o),Array.isArray(n)||l.quaternion.copy(n.rot))}}updateCue(t,e,n){var z;let s=!!e&&e.phase==="play"&&(this.canAim()||this.strikeAnim);this.cue.visible=s;let r=[this.guide,this.guide2,this.guide3,this.ghost];if(!s){r.forEach(G=>G.visible=!1),this.chalkCube.visible=!1;return}let o,a,l=this.aim,c;if(this.strikeAnim){let G=this.strikeAnim;G.t+=t,o=G.cue[1],a=G.cue[2],l=G.aim,c=Math.max(-.02,.01+(.08-G.t*1.2)),G.t>.6&&(this.strikeAnim=null)}else{let G=e.balls.find(F=>F[0]===this.cueN(e));o=G[1],a=G[2],c=.012+this.power*.28+(this.chalkAnim?.12:0)}let h=Math.cos(l),u=Math.sin(l),d=-u,f=h,m=(((z=this.strikeAnim)==null?void 0:z.el)??this.elev??0)*Math.PI/180,x=Math.cos(m),g=Math.sin(m),p=o-h*(n.R+c)*x+d*this.ox*n.R*.8,M=a-u*(n.R+c)*x+f*this.ox*n.R*.8,v=n.R+this.oy*n.R*.8+(n.R*.6+c)*g;if(this.cue.position.set(p,v,M),this.cue.rotation.set(0,-l,0),this.cue.rotateZ(-.09-m),this.tipMat.color.setHSL(.6,.65*this.chalk+.1,.25+.3*(1-this.chalk)),this.chalkAnim>0){let G=1-this.chalkAnim/1.1;this.chalkCube.visible=!0;let F=p,K=M;this.chalkCube.position.set(F+Math.cos(G*30)*.004,v+.012+Math.sin(G*Math.PI)*.05,K+Math.sin(G*30)*.004),this.chalkCube.rotation.set(0,G*18,0)}else this.chalkCube.visible=!1;let y=this.guideOn&&!this.strikeAnim&&this.canAim();if(r.forEach(G=>G.visible=!1),!y)return;let w=n.R,S=n.L/2-w,T=n.W/2-w,R=null,_=1e9;for(let G of e.balls){if(G[3]||G[0]===this.cueN(e))continue;let F=G[1]-o,K=G[2]-a,Q=F*h+K*u;if(Q<=0)continue;let ot=F*F+K*K-Q*Q;if(ot>4*w*w)continue;let St=Q-Math.sqrt(4*w*w-ot);St<_&&(_=St,R=G)}let b=h>0?(S-o)/h:h<0?(-S-o)/h:1e9,C=u>0?(T-a)/u:u<0?(-T-a)/u:1e9,L=Math.min(b,C),k=.004,D=Dn("cue").guide||1,V=(G,F)=>{G.geometry.setFromPoints(F.map(([K,Q])=>new P(K,k,Q))),G.computeLineDistances(),G.visible=!0};if(R&&_<L){let G=o+h*_,F=a+u*_;V(this.guide,[[o,a],[G,F]]),this.ghost.position.set(G,k,F),this.ghost.visible=!0,this.ghost.scale.setScalar(w/.028);let K=R[1]-G,Q=R[2]-F,ot=Math.hypot(K,Q);V(this.guide2,[[R[1],R[2]],[R[1]+K/ot*.35*D,R[2]+Q/ot*.35*D]]);let St=h-(h*K+u*Q)/ot*K/ot,Vt=u-(h*K+u*Q)/ot*Q/ot;St+=h*this.oy*.6,Vt+=u*this.oy*.6;let Y=Math.hypot(St,Vt)||1;V(this.guide3,[[G,F],[G+St/Y*.25*D,F+Vt/Y*.25*D]])}else{let G=o+h*L,F=a+u*L;V(this.guide,[[o,a],[G,F]]);let K=b<C?-h:h,Q=b<C?u:-u;V(this.guide3,[[G,F],[G+K*.4,F+Q*.4]])}}updateCamera(t,e){let n=this.ctx.camTarget,s=this.ctx.camera,r=this.group.position;if(this.view==="cue"&&t&&t.phase==="play"){let h=this.sim&&this.fpAnchor?this.fpAnchor:(()=>{let g=t.balls.find(p=>p[0]===this.cueN(t));return{x:g[1],z:g[2],aim:this.aim}})(),u=Math.cos(h.aim),d=Math.sin(h.aim),f=this.fpPitch,m=this.fpDist;n.up.set(0,1,0),n.pos.set(r.x+h.x-u*m*Math.cos(f),r.y+e.R+.05+m*Math.sin(f),r.z+h.z-d*m*Math.cos(f));let x=.15+.75*Math.max(0,1-f/1.3);n.look.set(r.x+h.x+u*x,r.y+e.R,r.z+h.z+d*x);return}let o=Math.tan(Cr.degToRad(s.fov/2)),a=s.aspect,l=e.L+.36,c=e.W+.36;if(a>=1){let h=Math.max(l*1.12/(2*o*a)*(1+320/innerWidth),c*1.75/(2*o));n.up.set(0,0,-1),n.pos.set(r.x,r.y+h,r.z+h*.18),n.look.set(r.x,r.y,r.z+h*.03)}else{let h=Math.max(l*1.6/(2*o),c*1.15/(2*o*a));n.up.set(1,0,0),n.pos.set(r.x-h*.15,r.y+h,r.z),n.look.set(r.x-h*.03,r.y,r.z)}}updateHud(t){if(!t)return;let e=this.ui,n=e.right.querySelector("#bGauge i");n.style.height=`${this.power*100}%`,e.right.querySelector("#bPow").textContent=`${Math.round(this.power*100)}%`,e.left.querySelector("#bChalk").textContent=`${Math.round(this.chalk*100)}%`,e.left.querySelector("#bView").textContent=this.view==="top"?U("viewTop"):U("viewCue");let s=this.canAim();e.right.style.opacity=e.left.style.opacity=s||this.sim?1:.45;let r=s?t.ballInHand?U("ballInHandHelp"):this.view==="cue"?U("billCueHelp"):U("billHelp2"):t.phase==="play"?U("waitTurn",{name:this.party.name(t.turn)}):"";e.help.textContent!==r&&(e.help.textContent=r)}renderBoard(){var r,o;let t=this.party.state,e=this.ui.board;if(!t)return;let s=`<div class="row" style="justify-content:space-between"><b>\u{1F3B1} ${{carom3:U("carom3"),carom4:U("carom4"),pool8:U("pool8")}[t.mode]}</b><span class="dim">${t.target?`${U("target")} ${t.target}`:U("pool8s")}</span></div>`;if(s+=`<table style="margin-top:4px"><tr><th>${U("player")}</th><th>${t.mode==="pool8"?U("group"):U("ball")}</th><th>${U("score")}</th><th>${U("innings")}</th><th>${U("highRun")}</th></tr>`,this.party.slots.forEach((a,l)=>{var u;if(l>=t.scores.length)return;let c;if(t.mode==="pool8"){let d=(u=t.groups)==null?void 0:u[this.team(l)];c=d?U(d):U("open")}else c=`<span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:${l%2?"#f7d23e":"#fafafa"};vertical-align:-2px"></span>`;let h=t.phase==="done"&&(t.mode==="pool8"?t.winnerTeam===this.team(l):t.winner===l);s+=`<tr class="${l===t.turn&&t.phase==="play"?"turn":""}"><td>${h?"\u{1F3C6} ":""}${Pe(a.name)}${t.mode==="pool8"&&this.party.slots.length>2?` <span class="dim">T${this.team(l)+1}</span>`:""}</td><td>${c}</td><td><b class="mid">${t.scores[l]}</b></td><td>${t.innings[l]}</td><td>${t.high[l]}</td></tr>`}),s+="</table>",t.msg&&(s+=`<div style="margin-top:4px;text-align:center">${Pe(t.msg)}</div>`),t.phase!=="done")this._paid=!1;else if(!this._paid){this._paid=!0;let a=this.party.slots.findIndex((l,c)=>this.party.mine(c));if(a>=0){let l=this.party.slots.length>1&&(t.mode==="pool8"?t.winnerTeam===this.team(a):t.winner===a),c=Nr(1+(l?2:0));c&&this.ctx.toast(`\u{1F4B0} +${c} P`)}}t.phase==="done"&&(s+=`<div class="row" style="justify-content:center;margin-top:6px"><button class="go" data-a="again">${U("playAgain")}</button><button data-a="lobby">${U("backLobby")}</button></div>`),e.innerHTML=s,(r=e.querySelector("[data-a=again]"))==null||r.addEventListener("click",()=>this.start(t.mode)),(o=e.querySelector("[data-a=lobby]"))==null||o.addEventListener("click",()=>this.party.clear())}netState(){return null}};function bn(i,t,e,n,s,r=!0){let o=new nt(i,t);return o.position.set(e,n,s),o.castShadow=r,o.receiveShadow=!0,o}var Or=.16;function Oo(i,t,e){let n=Math.imul(i|0,374761393)^Math.imul(t|0,668265263)^Math.imul(e,2147483647);return n=Math.imul(n^n>>>13,1274126177),((n^n>>>16)>>>0)/4294967296}var Ul=class{constructor(t,e,{count:n,radius:s,tint:r}){this.world=e,this.radius=s,this.max=n;let o=new ce,a=[],l=[],c=[],h=3,u=.022,d=new wt(3099164),f=new wt(10270826).multiply(new wt(r));for(let x=0;x<=h;x++){let g=x/h,p=u*(1-g*.85),M=d.clone().lerp(f,g);if(a.push(-p,g,g*g*.12,p,g,g*g*.12),l.push(M.r,M.g,M.b,M.r,M.g,M.b),x<h){let v=x*2;c.push(v,v+1,v+2,v+1,v+3,v+2)}}o.setAttribute("position",new Ht(a,3)),o.setAttribute("color",new Ht(l,3)),o.setIndex(c),o.computeVertexNormals(),this.time={value:0};let m=new ye({vertexColors:!0,roughness:.85,side:Te});m.onBeforeCompile=x=>{x.uniforms.uTime=this.time,x.uniforms.uBend=Ps,x.vertexShader=`uniform float uTime;
uniform float uBend;
`+x.vertexShader.replace("#include <beginnormal_vertex>","vec3 objectNormal = vec3(0.0, 1.0, 0.0);").replace("#include <project_vertex>",`
          vec4 gw = instanceMatrix * vec4(transformed, 1.0);
          gw = modelMatrix * gw;
          float sway = sin(uTime * 1.7 + gw.x * 0.35 + gw.z * 0.25) * 0.5 + sin(uTime * 3.1 + gw.x * 1.3) * 0.2;
          gw.x += sway * position.y * position.y * 0.18;
          gw.z += sway * position.y * position.y * 0.08;
          vec2 dxz = gw.xz - cameraPosition.xz;
          gw.y -= dot(dxz, dxz) * uBend;
          vec4 mvPosition = viewMatrix * gw;
          gl_Position = projectionMatrix * mvPosition;`)},m.customProgramCacheKey=()=>"grass",this.mesh=new cn(o,m,n),this.mesh.frustumCulled=!1,this.mesh.receiveShadow=!0,this.mesh.count=0,t.add(this.mesh),this.center=new rt(1e9,1e9)}scatter(t,e){let n=new qt,s=new Re,r=new P,o=new P,a=new P(0,1,0),l=this.radius,c=l*l,h=0,u=Math.floor((t-l)/Or),d=Math.ceil((t+l)/Or),f=Math.floor((e-l)/Or),m=Math.ceil((e+l)/Or);for(let x=f;x<=m&&h<this.max;x++)for(let g=u;g<=d&&h<this.max;g++){let p=(g+Oo(g,x,1))*Or,M=(x+Oo(g,x,2))*Or,v=p-t,y=M-e,w=v*v+y*y;if(w>c||Oo(g,x,3)>1.15-w/c||!this.world.isGrass(p,M))continue;let S=.12+Oo(g,x,4)*.22;s.setFromAxisAngle(a,Oo(g,x,5)*Math.PI*2),r.set(1,S,1),o.set(p,0,M),n.compose(o,s,r),this.mesh.setMatrixAt(h++,n)}this.mesh.count=h,this.mesh.instanceMatrix.needsUpdate=!0,this.center.set(t,e)}update(t,e){this.time.value+=t,Math.hypot(e.x-this.center.x,e.z-this.center.y)>this.radius*.3&&this.scatter(e.x,e.z)}};var Vu={\uC11C\uC6B8:"\uC885\uB85C\uAD6C \uC911\uAD6C \uC6A9\uC0B0\uAD6C \uC131\uB3D9\uAD6C \uAD11\uC9C4\uAD6C \uB3D9\uB300\uBB38\uAD6C \uC911\uB791\uAD6C \uC131\uBD81\uAD6C \uAC15\uBD81\uAD6C \uB3C4\uBD09\uAD6C \uB178\uC6D0\uAD6C \uC740\uD3C9\uAD6C \uC11C\uB300\uBB38\uAD6C \uB9C8\uD3EC\uAD6C \uC591\uCC9C\uAD6C \uAC15\uC11C\uAD6C \uAD6C\uB85C\uAD6C \uAE08\uCC9C\uAD6C \uC601\uB4F1\uD3EC\uAD6C \uB3D9\uC791\uAD6C \uAD00\uC545\uAD6C \uC11C\uCD08\uAD6C \uAC15\uB0A8\uAD6C \uC1A1\uD30C\uAD6C \uAC15\uB3D9\uAD6C",\uBD80\uC0B0:"\uC911\uAD6C \uC11C\uAD6C \uB3D9\uAD6C \uC601\uB3C4\uAD6C \uBD80\uC0B0\uC9C4\uAD6C \uB3D9\uB798\uAD6C \uB0A8\uAD6C \uBD81\uAD6C \uD574\uC6B4\uB300\uAD6C \uC0AC\uD558\uAD6C \uAE08\uC815\uAD6C \uAC15\uC11C\uAD6C \uC5F0\uC81C\uAD6C \uC218\uC601\uAD6C \uC0AC\uC0C1\uAD6C \uAE30\uC7A5\uAD70",\uB300\uAD6C:"\uC911\uAD6C \uB3D9\uAD6C \uC11C\uAD6C \uB0A8\uAD6C \uBD81\uAD6C \uC218\uC131\uAD6C \uB2EC\uC11C\uAD6C \uB2EC\uC131\uAD70 \uAD70\uC704\uAD70",\uC778\uCC9C:"\uC911\uAD6C \uB3D9\uAD6C \uBBF8\uCD94\uD640\uAD6C \uC5F0\uC218\uAD6C \uB0A8\uB3D9\uAD6C \uBD80\uD3C9\uAD6C \uACC4\uC591\uAD6C \uC11C\uAD6C \uAC15\uD654\uAD70 \uC639\uC9C4\uAD70",\uAD11\uC8FC:"\uB3D9\uAD6C \uC11C\uAD6C \uB0A8\uAD6C \uBD81\uAD6C \uAD11\uC0B0\uAD6C",\uB300\uC804:"\uB3D9\uAD6C \uC911\uAD6C \uC11C\uAD6C \uC720\uC131\uAD6C \uB300\uB355\uAD6C",\uC6B8\uC0B0:"\uC911\uAD6C \uB0A8\uAD6C \uB3D9\uAD6C \uBD81\uAD6C \uC6B8\uC8FC\uAD70",\uC138\uC885:"\uC138\uC885\uC2DC",\uACBD\uAE30:"\uC218\uC6D0\uC2DC \uC131\uB0A8\uC2DC \uC758\uC815\uBD80\uC2DC \uC548\uC591\uC2DC \uBD80\uCC9C\uC2DC \uAD11\uBA85\uC2DC \uD3C9\uD0DD\uC2DC \uB3D9\uB450\uCC9C\uC2DC \uC548\uC0B0\uC2DC \uACE0\uC591\uC2DC \uACFC\uCC9C\uC2DC \uAD6C\uB9AC\uC2DC \uB0A8\uC591\uC8FC\uC2DC \uC624\uC0B0\uC2DC \uC2DC\uD765\uC2DC \uAD70\uD3EC\uC2DC \uC758\uC655\uC2DC \uD558\uB0A8\uC2DC \uC6A9\uC778\uC2DC \uD30C\uC8FC\uC2DC \uC774\uCC9C\uC2DC \uC548\uC131\uC2DC \uAE40\uD3EC\uC2DC \uD654\uC131\uC2DC \uAD11\uC8FC\uC2DC \uC591\uC8FC\uC2DC \uD3EC\uCC9C\uC2DC \uC5EC\uC8FC\uC2DC \uC5F0\uCC9C\uAD70 \uAC00\uD3C9\uAD70 \uC591\uD3C9\uAD70",\uAC15\uC6D0:"\uCD98\uCC9C\uC2DC \uC6D0\uC8FC\uC2DC \uAC15\uB989\uC2DC \uB3D9\uD574\uC2DC \uD0DC\uBC31\uC2DC \uC18D\uCD08\uC2DC \uC0BC\uCC99\uC2DC \uD64D\uCC9C\uAD70 \uD6A1\uC131\uAD70 \uC601\uC6D4\uAD70 \uD3C9\uCC3D\uAD70 \uC815\uC120\uAD70 \uCCA0\uC6D0\uAD70 \uD654\uCC9C\uAD70 \uC591\uAD6C\uAD70 \uC778\uC81C\uAD70 \uACE0\uC131\uAD70 \uC591\uC591\uAD70",\uCDA9\uBD81:"\uCCAD\uC8FC\uC2DC \uCDA9\uC8FC\uC2DC \uC81C\uCC9C\uC2DC \uBCF4\uC740\uAD70 \uC625\uCC9C\uAD70 \uC601\uB3D9\uAD70 \uC99D\uD3C9\uAD70 \uC9C4\uCC9C\uAD70 \uAD34\uC0B0\uAD70 \uC74C\uC131\uAD70 \uB2E8\uC591\uAD70",\uCDA9\uB0A8:"\uCC9C\uC548\uC2DC \uACF5\uC8FC\uC2DC \uBCF4\uB839\uC2DC \uC544\uC0B0\uC2DC \uC11C\uC0B0\uC2DC \uB17C\uC0B0\uC2DC \uACC4\uB8E1\uC2DC \uB2F9\uC9C4\uC2DC \uAE08\uC0B0\uAD70 \uBD80\uC5EC\uAD70 \uC11C\uCC9C\uAD70 \uCCAD\uC591\uAD70 \uD64D\uC131\uAD70 \uC608\uC0B0\uAD70 \uD0DC\uC548\uAD70",\uC804\uBD81:"\uC804\uC8FC\uC2DC \uAD70\uC0B0\uC2DC \uC775\uC0B0\uC2DC \uC815\uC74D\uC2DC \uB0A8\uC6D0\uC2DC \uAE40\uC81C\uC2DC \uC644\uC8FC\uAD70 \uC9C4\uC548\uAD70 \uBB34\uC8FC\uAD70 \uC7A5\uC218\uAD70 \uC784\uC2E4\uAD70 \uC21C\uCC3D\uAD70 \uACE0\uCC3D\uAD70 \uBD80\uC548\uAD70",\uC804\uB0A8:"\uBAA9\uD3EC\uC2DC \uC5EC\uC218\uC2DC \uC21C\uCC9C\uC2DC \uB098\uC8FC\uC2DC \uAD11\uC591\uC2DC \uB2F4\uC591\uAD70 \uACE1\uC131\uAD70 \uAD6C\uB840\uAD70 \uACE0\uD765\uAD70 \uBCF4\uC131\uAD70 \uD654\uC21C\uAD70 \uC7A5\uD765\uAD70 \uAC15\uC9C4\uAD70 \uD574\uB0A8\uAD70 \uC601\uC554\uAD70 \uBB34\uC548\uAD70 \uD568\uD3C9\uAD70 \uC601\uAD11\uAD70 \uC7A5\uC131\uAD70 \uC644\uB3C4\uAD70 \uC9C4\uB3C4\uAD70 \uC2E0\uC548\uAD70",\uACBD\uBD81:"\uD3EC\uD56D\uC2DC \uACBD\uC8FC\uC2DC \uAE40\uCC9C\uC2DC \uC548\uB3D9\uC2DC \uAD6C\uBBF8\uC2DC \uC601\uC8FC\uC2DC \uC601\uCC9C\uC2DC \uC0C1\uC8FC\uC2DC \uBB38\uACBD\uC2DC \uACBD\uC0B0\uC2DC \uC758\uC131\uAD70 \uCCAD\uC1A1\uAD70 \uC601\uC591\uAD70 \uC601\uB355\uAD70 \uCCAD\uB3C4\uAD70 \uACE0\uB839\uAD70 \uC131\uC8FC\uAD70 \uCE60\uACE1\uAD70 \uC608\uCC9C\uAD70 \uBD09\uD654\uAD70 \uC6B8\uC9C4\uAD70 \uC6B8\uB989\uAD70",\uACBD\uB0A8:"\uCC3D\uC6D0\uC2DC \uC9C4\uC8FC\uC2DC \uD1B5\uC601\uC2DC \uC0AC\uCC9C\uC2DC \uAE40\uD574\uC2DC \uBC00\uC591\uC2DC \uAC70\uC81C\uC2DC \uC591\uC0B0\uC2DC \uC758\uB839\uAD70 \uD568\uC548\uAD70 \uCC3D\uB155\uAD70 \uACE0\uC131\uAD70 \uB0A8\uD574\uAD70 \uD558\uB3D9\uAD70 \uC0B0\uCCAD\uAD70 \uD568\uC591\uAD70 \uAC70\uCC3D\uAD70 \uD569\uCC9C\uAD70",\uC81C\uC8FC:"\uC81C\uC8FC\uC2DC \uC11C\uADC0\uD3EC\uC2DC"},Vp=(i,t)=>i.localeCompare(t,"ko"),Gp=Object.keys(Vu).sort(Vp),Wp=i=>(Vu[i]||"").split(" ").filter(Boolean).sort(Vp),Hr=[["seoul","\uC11C\uC6B8",["\uC11C\uC6B8"]],["gg-n","\uACBD\uAE30 \uBD81\uBD80",["\uACBD\uAE30:\uACE0\uC591\uC2DC \uD30C\uC8FC\uC2DC \uC758\uC815\uBD80\uC2DC \uC591\uC8FC\uC2DC \uB3D9\uB450\uCC9C\uC2DC \uD3EC\uCC9C\uC2DC \uC5F0\uCC9C\uAD70 \uAC00\uD3C9\uAD70 \uB0A8\uC591\uC8FC\uC2DC \uAD6C\uB9AC\uC2DC"]],["gg-e","\uACBD\uAE30 \uB3D9\uBD80",["\uACBD\uAE30:\uC131\uB0A8\uC2DC \uD558\uB0A8\uC2DC \uAD11\uC8FC\uC2DC \uC774\uCC9C\uC2DC \uC5EC\uC8FC\uC2DC \uC591\uD3C9\uAD70"]],["gg-w","\uACBD\uAE30 \uC11C\uBD80",["\uACBD\uAE30:\uBD80\uCC9C\uC2DC \uAE40\uD3EC\uC2DC \uC2DC\uD765\uC2DC \uC548\uC0B0\uC2DC \uAD11\uBA85\uC2DC","\uC778\uCC9C"]],["gg-s","\uACBD\uAE30 \uB0A8\uBD80",["\uACBD\uAE30:\uC218\uC6D0\uC2DC \uC6A9\uC778\uC2DC \uD654\uC131\uC2DC \uC624\uC0B0\uC2DC \uD3C9\uD0DD\uC2DC \uC548\uC131\uC2DC \uC548\uC591\uC2DC \uAD70\uD3EC\uC2DC \uC758\uC655\uC2DC \uACFC\uCC9C\uC2DC"]],["gw","\uAC15\uC6D0\uB3C4",["\uAC15\uC6D0"]],["cb","\uCDA9\uCCAD\uBD81\uB3C4",["\uCDA9\uBD81"]],["cn","\uCDA9\uCCAD\uB0A8\uB3C4",["\uCDA9\uB0A8","\uB300\uC804","\uC138\uC885"]],["jb","\uC804\uB77C\uBD81\uB3C4",["\uC804\uBD81"]],["jn","\uC804\uB77C\uB0A8\uB3C4",["\uC804\uB0A8","\uAD11\uC8FC"]],["gb","\uACBD\uC0C1\uBD81\uB3C4",["\uACBD\uBD81","\uB300\uAD6C"]],["gn","\uACBD\uC0C1\uB0A8\uB3C4",["\uACBD\uB0A8","\uBD80\uC0B0","\uC6B8\uC0B0"]],["jj","\uC81C\uC8FC\uB3C4",["\uC81C\uC8FC"]]].map(([i,t,e])=>({id:i,name:t,parts:e})),Hp={\uC778\uCC9C:"\uC778\uCC9C",\uB300\uC804:"\uB300\uC804\xB7\uC138\uC885",\uC138\uC885:"",\uAD11\uC8FC:"\uAD11\uC8FC",\uB300\uAD6C:"\uB300\uAD6C",\uBD80\uC0B0:"\uBD80\uC0B0\xB7\uC6B8\uC0B0",\uC6B8\uC0B0:""};Hr.forEach(i=>{let t=i.parts.filter(e=>!e.includes(":")&&Hp[e]).map(e=>Hp[e]);i.label=t.length?`${i.name} \xB7 ${t.join("\xB7")}`:i.name});function a1(i,t){for(let e of Hr)for(let n of e.parts){let[s,r]=n.split(":");if(s===i&&(!r||r.split(" ").includes(t)))return e}return i==="\uACBD\uAE30"?Hr[4]:null}var Gu=i=>`dong-${i.id}`,$p=i=>Hr.find(t=>t.id===i)||null,qp=(i,t)=>{let e=a1(i,t);return e?Gu(e):null};var Nl=new URL("ocr/",location.href).href,zl=null,Wu=null;function l1(i){return new Promise((t,e)=>{let n=document.createElement("script");n.src=i,n.onload=t,n.onerror=()=>e(new Error("\uAE00\uC790 \uC77D\uAE30 \uB3C4\uAD6C\uB97C \uBD88\uB7EC\uC624\uC9C0 \uBABB\uD588\uC5B4\uC694.")),document.head.appendChild(n)})}function Zp(){return zl||(zl=(async()=>{window.Tesseract||await l1(Nl+"tesseract.min.js");let i=await window.Tesseract.createWorker("eng",1,{workerPath:Nl+"worker.min.js",corePath:Nl+"tesseract-core-simd-lstm.wasm.js",langPath:Nl.replace(/\/$/,""),gzip:!0,workerBlobURL:!1,cacheMethod:"none",logger:t=>Wu&&Wu(t)});return await i.setParameters({tessedit_char_whitelist:"ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789<",tessedit_pageseg_mode:"6"}),i})().catch(i=>{throw zl=null,i})),zl}var Kp=()=>Zp().catch(()=>null);function Jp(i){return new Promise((t,e)=>{let n=URL.createObjectURL(i),s=new Image;s.onload=()=>{URL.revokeObjectURL(n),t(s)},s.onerror=()=>{URL.revokeObjectURL(n),e(new Error("\uC0AC\uC9C4\uC744 \uC5F4\uC9C0 \uBABB\uD588\uC5B4\uC694. JPG\xB7PNG \uC0AC\uC9C4\uC73C\uB85C \uB2E4\uC2DC \uACE8\uB77C \uC8FC\uC138\uC694."))},s.src=n})}function jp(i,t=1600,e=.8){let n=Math.min(1,t/Math.max(i.naturalWidth,i.naturalHeight)),s=document.createElement("canvas");s.width=Math.round(i.naturalWidth*n),s.height=Math.round(i.naturalHeight*n),s.getContext("2d").drawImage(i,0,0,s.width,s.height);let r=s.toDataURL("image/jpeg",e);return r.length>15e5&&(r=s.toDataURL("image/jpeg",.6)),r}function c1(i,{top:t=0,h:e=1,rot:n=0}){let s=i.naturalWidth,r=i.naturalHeight,o=n%180?r:s,a=n%180?s:r,l=document.createElement("canvas");l.width=o,l.height=a;let c=l.getContext("2d");c.translate(o/2,a/2),c.rotate(n*Math.PI/180),c.drawImage(i,-s/2,-r/2);let h=Math.round(a*t),u=Math.round(a*e),d=Math.min(3,Math.max(1,2e3/o)),f=document.createElement("canvas");f.width=Math.round(o*d),f.height=Math.round(u*d);let m=f.getContext("2d",{willReadFrequently:!0});m.imageSmoothingQuality="high",m.drawImage(l,0,h,o,u,0,0,f.width,f.height);let x=m.getImageData(0,0,f.width,f.height),g=x.data,p=255,M=0,v=new Uint8ClampedArray(g.length/4);for(let R=0,_=0;R<g.length;R+=4,_++){let b=g[R]*.299+g[R+1]*.587+g[R+2]*.114|0;v[_]=b}let y=new Uint32Array(256);v.forEach(R=>y[R]++);let w=0,S=v.length;for(let R=0;R<256;R++)if(w+=y[R],p===255&&w>S*.02&&(p=R),w>S*.98){M=R;break}let T=255/Math.max(1,M-p);for(let R=0,_=0;R<g.length;R+=4,_++){let b=Math.max(0,Math.min(255,(v[_]-p)*T));g[R]=g[R+1]=g[R+2]=b}return m.putImageData(x,0,0),f}var h1=[7,3,1],u1=i=>i==="<"?0:/\d/.test(i)?+i:i.charCodeAt(0)-55,Fl=i=>String([...i].reduce((t,e,n)=>t+u1(e)*h1[n%3],0)%10),d1={O:"0",Q:"0",D:"0",U:"0",I:"1",L:"1",T:"1",Z:"2",S:"5",B:"8",G:"6",A:"4","<":"0"},Ho=i=>[...i].map(t=>d1[t]||t).join(""),Xp={0:"O",O:"0",1:"I",I:"1",5:"S",S:"5",8:"B",B:"8",2:"Z",Z:"2",6:"G",G:"6",D:"0",Q:"0"};function f1(i,t){if(Fl(i)===t)return i;let e=[...i].map((n,s)=>Xp[n]?s:-1).filter(n=>n>=0).slice(0,8);for(let n=1;n<1<<e.length;n++){let s=[...i];e.forEach((o,a)=>{n&1<<a&&(s[o]=Xp[s[o]])});let r=s.join("");if(Fl(r)===t)return r}return null}function Yp(i,t){if(!/^\d{6}$/.test(i))return"";let e=+i.slice(0,2),n=+i.slice(2,4),s=+i.slice(4,6);if(n<1||n>12||s<1||s>31)return"";let r=new Date().getFullYear()%100;return`${t==="exp"?2e3+e:(e>r?1900:2e3)+e}-${i.slice(2,4)}-${i.slice(4,6)}`}function p1(i){return i.toUpperCase().replace(/[«‹]/g,"<").replace(/[^A-Z0-9<]/g,"")}function m1(i){let t=String(i||"").split(/\n+/).map(p1).filter(n=>n.length>=28),e=null;for(let n=0;n<t.length;n++){let s=t[n];if(!/\d/.test(s))continue;s.length>44?s=s.slice(0,44):s=s.padEnd(44,"<");let r=s.slice(0,9),o=Ho(s[9]),a=Ho(s.slice(13,19)),l=Ho(s[19]),c=Ho(s.slice(21,27)),h=Ho(s[27]),u=0,d=f1(r,o);d&&u++,Fl(a)===l&&u++,Fl(c)===h&&u++;let f=Yp(a,"birth"),m=Yp(c,"exp");if(!f&&!m)continue;let x=n>0?t[n-1]:"",g="",p=s.slice(10,13).replace(/[^A-Z]/g,"");if(/^P/.test(x)){let v=x.slice(5),[y,w=""]=v.split(/<<+/);g=[y,w.replace(/</g," ")].map(S=>S.replace(/</g," ").trim()).filter(Boolean).join(" ")}let M={no:(d||r).replace(/</g,""),birth:f,exp:m,sex:s[20]==="F"?"F":s[20]==="M"?"M":"",nat:p,name:g,ok:u};(!e||M.ok>e.ok)&&(e=M)}return e}async function Qp(i,t){Wu=r=>t&&r.status==="recognizing text"&&t(r.progress);let e=await Zp(),n=[{top:.55,h:.45},{top:.3,h:.7},{top:0,h:1},{top:.55,h:.45,rot:180},{top:.3,h:.7,rot:180},{top:.55,h:.45,rot:90},{top:.55,h:.45,rot:270}],s=null;for(let r of n){let{data:o}=await e.recognize(c1(i,r)),a=m1(o.text);if(a&&(!s||a.ok>s.ok)&&(s=a),s&&s.ok===3)break}return s}var _t=(i,t=document)=>t.querySelector(i),g1=new URLSearchParams(location.search),Xu=(g1.get("server")||window.LOUNGE_API||"https://tigc.co.kr/lounge").replace(/\/$/,""),x1="https://tigc.co.kr/#/signup",$o="taeil-lounge-token",sm="taeil-lounge-block",at=i=>String(i??"").replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]),Os={get(i){try{return localStorage.getItem(i)}catch{return null}},set(i,t){try{t==null?localStorage.removeItem(i):localStorage.setItem(i,t)}catch{}}},Yt={token:Os.get($o),user:null,profile:null},$u=["#ff8a5c","#4aa3ff","#5cc9a7","#f783ac","#ffd43b","#9775fa","#20c997","#ff6b6b","#868e96","#2b8a3e"];async function He(i,t){let e=await fetch(Xu+i,{method:t===void 0?"GET":"POST",headers:{"content-type":"application/json",...Yt.token?{authorization:"Bearer "+Yt.token}:{}},body:t===void 0?void 0:JSON.stringify(t)}),n={};try{n=await e.json()}catch{}if(e.status===428&&i!=="/api/passport"&&setTimeout(()=>location.reload(),1500),!e.ok)throw Object.assign(new Error(n.error||`\uC11C\uBC84 \uC624\uB958 (${e.status})`),{status:e.status,until:n.until});return n}function qo(){window.parent!==window?window.parent.postMessage({lounge:"close"},"*"):location.href="about:blank"}function y1(i){window.parent!==window?window.parent.postMessage({lounge:"open",url:i},"*"):window.open(i,"_blank","noopener")}var Vo=new Set;try{Vo=new Set(JSON.parse(Os.get(sm)||"[]"))}catch{}var Bs=i=>!!i&&Vo.has(i);function v1(i,t){t?Vo.add(i):Vo.delete(i),Os.set(sm,JSON.stringify([...Vo]))}var zi=_t("#sheet");function wn(i,t=""){return zi.className="sheet "+t,zi.innerHTML=`<div class="card sheet-in"><button class="x" aria-label="\uB2EB\uAE30">\u2715</button>${i}</div>`,zi.hidden=!1,_t(".x",zi).onclick=_n,zi.onclick=e=>{e.target===zi&&_n()},_t(".sheet-in",zi)}function _n(){zi.hidden=!0,zi.innerHTML=""}var Mn=(i,t)=>{i&&(i.disabled=t,i.dataset.t??=i.textContent,i.textContent=t?"\uC7A0\uC2DC\uB9CC\uC694\u2026":i.dataset.t)},Ye=(i,t)=>{i.textContent=t?t.message||String(t):"",i.hidden=!t};function rm(i,t,e){let n=_t("[name=sido]",i),s=_t("[name=sgg]",i);n.innerHTML='<option value="">\uC2DC\xB7\uB3C4</option>'+Gp.map(o=>`<option${o===t?" selected":""}>${o}</option>`).join("");let r=o=>{s.innerHTML='<option value="">\uC2DC\xB7\uAD70\xB7\uAD6C</option>'+Wp(n.value).map(a=>`<option${a===o?" selected":""}>${a}</option>`).join("")};n.onchange=()=>r(""),r(e)}function Bl(i,t){let e=_t("#login .card");e.innerHTML=`
    <img class="logo" src="logo.png" alt="\uD0DC\uC77C\uACE8\uD504">
    <h1>\uD0DC\uC77C\uACE8\uD504 \uB77C\uC6B4\uC9C0</h1>
    <p class="sub">\uD68C\uC6D0\uB07C\uB9AC \uB9CC\uB098\uC11C \uBBF8\uB2C8\uAC8C\uC784 \uD558\uACE0, \uC6B0\uB9AC \uB3D9\uB124 \uACE8\uD504 \uBAA8\uC784\uB3C4 \uCC3E\uB294 \uACF3</p>
    <form id="lf" autocomplete="on">
      <div class="field"><label>\uD0DC\uC77C\uACE8\uD504 \uD68C\uC6D0 \uC774\uBA54\uC77C</label><input name="email" type="email" required autocomplete="username"></div>
      <div class="field"><label>\uBE44\uBC00\uBC88\uD638</label><input name="password" type="password" required autocomplete="current-password"></div>
      <p class="err" hidden></p>
      <button class="btn" type="submit">\uB85C\uADF8\uC778\uD558\uACE0 \uC785\uC7A5</button>
    </form>
    <p class="small">\uC544\uC9C1 \uD68C\uC6D0\uC774 \uC544\uB2C8\uBA74 <a href="#" id="su">tigc.co.kr \uD68C\uC6D0\uAC00\uC785</a> \uD6C4 \uAC19\uC740 \uC774\uBA54\uC77C\uB85C \uB85C\uADF8\uC778\uD558\uC138\uC694.</p>
    <button class="btn ghost back" type="button" id="lb">\u2190 \uC9C0\uAD6C\uBCF8\uC73C\uB85C</button>`;let n=_t("#lf"),s=_t(".err",n);t&&Ye(s,{message:t}),_t("#su").onclick=r=>{r.preventDefault(),y1(x1)},_t("#lb").onclick=qo,n.onsubmit=async r=>{r.preventDefault();let o=_t("button[type=submit]",n);Mn(o,!0),Ye(s);try{let a=await He("/api/login",{email:n.email.value.trim(),password:n.password.value});Yt.token=a.token,Os.set($o,a.token),await om(i)}catch(a){Ye(s,a.status===401?{message:"\uC774\uBA54\uC77C \uB610\uB294 \uBE44\uBC00\uBC88\uD638\uAC00 \uB9DE\uC9C0 \uC54A\uC544\uC694."}:a.message==="Failed to fetch"?{message:"\uB77C\uC6B4\uC9C0 \uC11C\uBC84\uC5D0 \uC5F0\uACB0\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694. \uC778\uD130\uB137 \uC5F0\uACB0\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694."}:a)}Mn(o,!1)}}async function om(i){let t=await He("/api/me");if(Yt.user=t.user,Yt.profile=t.profile,t.ban){let e=t.ban.until?new Date(t.ban.until).toLocaleString("ko-KR")+"\uAE4C\uC9C0":"";return Yt.token=null,Os.set($o,null),Bl(i,`\uB77C\uC6B4\uC9C0 \uC774\uC6A9\uC774 \uC81C\uD55C\uB41C \uACC4\uC815\uC774\uC5D0\uC694 ${e}. \uBB38\uC758\uB294 \uD0DC\uC77C\uACE8\uD504 \uCE74\uCE74\uC624\uD1A1 \uCC44\uB110\uB85C \uD574 \uC8FC\uC138\uC694.`)}if(Yt.passport=t.passport||{ok:!1},!Yt.passport.ok&&!["admin","staff"].includes(Yt.user&&Yt.user.role))return M1(i);if(!Yt.profile||!Yt.profile.nick||!Yt.profile.sgg)return Yu(i,!0);i(Yt.profile)}var b1=`<b>[\uD544\uC218] \uAC1C\uC778\uC815\uBCF4 \uC218\uC9D1\xB7\uC774\uC6A9 \uB3D9\uC758</b>
  <ul><li><b>\uC218\uC9D1 \uD56D\uBAA9</b>: \uC5EC\uAD8C \uC0AC\uC9C4\uBA74 \uC0AC\uC9C4(\uC0AC\uC9C4\xB7\uC774\uB984\xB7\uAD6D\uC801\xB7\uC131\uBCC4\xB7\uC0DD\uB144\uC6D4\uC77C\xB7\uC5EC\uAD8C\uBC88\uD638\xB7\uB9CC\uB8CC\uC77C \uB4F1 \uC5EC\uAD8C\uC5D0 \uC801\uD78C \uB0B4\uC6A9), \uC0DD\uB144\uC6D4\uC77C, \uC5EC\uAD8C \uB9CC\uB8CC\uC77C</li>
  <li><b>\uBAA9\uC801</b>: \uB300\uAE30\uC2E4(\uD68C\uC6D0\uB07C\uB9AC \uB9CC\uB098\uB294 \uACF3)\uC758 \uC548\uC804\uACFC \uBC94\uC8C4 \uC608\uBC29 \u2014 \uBCF8\uC778 \uD655\uC778, \uB9CC 19\uC138 \uC774\uC0C1 \uD655\uC778, 1\uC778 1\uACC4\uC815, \uC774\uC6A9 \uC81C\uD55C\uB41C \uD68C\uC6D0\uC758 \uC7AC\uAC00\uC785 \uBC29\uC9C0, \uC0AC\uACE0\xB7\uBC94\uC8C4 \uBC1C\uC0DD \uC2DC \uB300\uC751</li>
  <li><b>\uBCF4\uC720 \uAE30\uAC04</b>: \uB300\uAE30\uC2E4 \uC774\uC6A9 \uD574\uC9C0(\uB0B4 \uC815\uBCF4 \u2192 \uC5EC\uAD8C \uB4F1\uB85D \uC9C0\uC6B0\uAE30)\xB7\uD68C\uC6D0 \uD0C8\uD1F4 \uC2DC \uBC14\uB85C \uD30C\uAE30. 1\uB144 \uB3D9\uC548 \uB300\uAE30\uC2E4\uC744 \uC4F0\uC9C0 \uC54A\uC73C\uBA74 \uC790\uB3D9 \uD30C\uAE30. \uB2E8, \uC774\uC6A9 \uC81C\uD55C \uC911\uC778 \uD68C\uC6D0\uC740 \uC7AC\uAC00\uC785 \uBC29\uC9C0\uB97C \uC704\uD574 \uC81C\uD55C\uC774 \uB05D\uB09C \uB4A4 1\uB144(\uC601\uAD6C \uC81C\uD55C\uC740 \uCD5C\uB300 6\uB144)\uAE4C\uC9C0 \uBCF4\uAD00 \uD6C4 \uD30C\uAE30</li>
  <li><b>\uB3D9\uC758\uB97C \uAC70\uBD80\uD560 \uAD8C\uB9AC</b>: \uB3D9\uC758\uD558\uC9C0 \uC54A\uC544\uB3C4 \uB3FC\uC694. \uC774 \uACBD\uC6B0 \uB300\uAE30\uC2E4\uB9CC \uC774\uC6A9\uD560 \uC218 \uC5C6\uACE0, \uC9C0\uAD6C\uBCF8\xB7\uC608\uC57D \uB4F1 \uB2E4\uB978 \uAE30\uB2A5\uC740 \uADF8\uB300\uB85C \uC4F8 \uC218 \uC788\uC5B4\uC694.</li></ul>`,_1=`<b>[\uD544\uC218] \uACE0\uC720\uC2DD\uBCC4\uC815\uBCF4(\uC5EC\uAD8C\uBC88\uD638) \uCC98\uB9AC \uB3D9\uC758</b>
  <ul><li><b>\uD56D\uBAA9</b>: \uC5EC\uAD8C\uBC88\uD638 \xB7 <b>\uBAA9\uC801\xB7\uBCF4\uC720 \uAE30\uAC04</b>: \uC704\uC640 \uAC19\uC74C</li>
  <li><b>\uBCF4\uD638 \uBC29\uBC95</b>: \uC5EC\uAD8C\uBC88\uD638\uB294 \uB418\uB3CC\uB9B4 \uC218 \uC5C6\uB294 \uC554\uD638\uAC12\uC73C\uB85C\uB9CC \uC800\uC7A5\uD558\uACE0, \uC5EC\uAD8C \uC0AC\uC9C4\uC740 \uC554\uD638\uD654\uD574\uC11C \uD0DC\uC77C \uACE8\uD504\uCEE4\uBBA4\uB2C8\uCF00\uC774\uC158 \uC11C\uBC84(Cloudflare, \uD574\uC678 \uB370\uC774\uD130\uC13C\uD130 \uD3EC\uD568)\uC5D0 \uBCF4\uAD00\uD574\uC694. \uAD00\uB9AC\uC790\uB9CC \uC5F4\uB78C \uC0AC\uC720\uB97C \uB0A8\uAE30\uACE0 \uBCFC \uC218 \uC788\uACE0, \uC5F4\uB78C \uAE30\uB85D\uC774 \uB0A8\uC544\uC694.</li>
  <li><b>\uC81C3\uC790 \uC81C\uACF5</b>: \uBC95\uB839\uC5D0 \uB530\uB978 \uC218\uC0AC\uAE30\uAD00 \uC694\uCCAD \uB4F1 \uBC95\uC774 \uC815\uD55C \uACBD\uC6B0 \uC678\uC5D0\uB294 \uB2E4\uB978 \uACF3\uC5D0 \uC8FC\uC9C0 \uC54A\uC544\uC694.</li>
  <li><b>\uB3D9\uC758\uB97C \uAC70\uBD80\uD560 \uAD8C\uB9AC</b>: \uC704\uC640 \uAC19\uC544\uC694 (\uB300\uAE30\uC2E4\uB9CC \uC774\uC6A9 \uBD88\uAC00).</li></ul>`;function M1(i){let t=_t("#login .card");_t("#login").classList.add("tall");let e=Yt.passport&&Yt.passport.expired;t.innerHTML=`
    <h2>\u{1F6C2} \uC5EC\uAD8C \uC548\uC804 \uB4F1\uB85D</h2>
    <p class="small">${e?"\uB4F1\uB85D\uD55C \uC5EC\uAD8C\uC758 \uC720\uD6A8\uAE30\uAC04\uC774 \uB05D\uB0AC\uC5B4\uC694. \uC0C8 \uC5EC\uAD8C\uC73C\uB85C \uB2E4\uC2DC \uB4F1\uB85D\uD574 \uC8FC\uC138\uC694.":"\uB300\uAE30\uC2E4\uC740 \uD68C\uC6D0\uB07C\uB9AC \uC9C1\uC811 \uB9CC\uB098 \uB77C\uC6B4\uB529\xB7\uBAA8\uC784\uC744 \uD558\uB294 \uACF3\uC774\uB77C, <b>\uC548\uC804\uACFC \uBC94\uC8C4 \uC608\uBC29</b>\uC744 \uC704\uD574 \uCC98\uC74C \uD55C \uBC88 \uC5EC\uAD8C\uC73C\uB85C \uBCF8\uC778 \uD655\uC778\uC744 \uD574\uC694."}</p>
    <ul class="why"><li>\u2705 \uC2E4\uC81C \uBCF8\uC778 \uD655\uC778\uB41C \uD68C\uC6D0\uB9CC \uC785\uC7A5</li><li>\u2705 \uB9CC 19\uC138 \uC774\uC0C1\uB9CC \uC774\uC6A9</li><li>\u2705 \uD55C \uC5EC\uAD8C = \uD55C \uACC4\uC815 (\uAC00\uC9DC\xB7\uC911\uBCF5 \uACC4\uC815 \uB9C9\uAE30)</li><li>\u2705 \uBB38\uC81C\uB97C \uC77C\uC73C\uCF1C \uC81C\uD55C\uB41C \uD68C\uC6D0\uC740 \uB2E4\uC2DC \uBABB \uB4E4\uC5B4\uC640\uC694</li><li>\u{1F512} \uB2E4\uB978 \uD68C\uC6D0\uC5D0\uAC8C\uB294 \uC808\uB300 \uBCF4\uC774\uC9C0 \uC54A\uC544\uC694</li></ul>
    <form id="ppf">
      <label class="shot" id="shot"><input type="file" accept="image/*" capture="environment" hidden>
        <span id="shotTxt">\u{1F4F7} \uC5EC\uAD8C \uC0AC\uC9C4 \uCC0D\uAE30 \xB7 \uACE0\uB974\uAE30</span><img id="shotImg" alt="" hidden></label>
      <p class="small">\uC5EC\uAD8C <b>\uC0AC\uC9C4\uC774 \uC788\uB294 \uBA74</b> \uC804\uCCB4\uAC00 \uB098\uC624\uAC8C, \uB9E8 \uC544\uB798 \uB450 \uC904(<code>P&lt;KOR\u2026&lt;&lt;&lt;</code>)\uC774 \uC120\uBA85\uD558\uAC8C \uCC0D\uC5B4 \uC8FC\uC138\uC694. \uAE00\uC790\uB294 \uC774 \uAE30\uAE30 \uC548\uC5D0\uC11C \uC77D\uC5B4\uC11C \uC790\uB3D9\uC73C\uB85C \uCC44\uC6CC\uC838\uC694.</p>
      <p class="ocr" id="ocr" hidden></p>
      <div class="field"><label>\uC5EC\uAD8C\uBC88\uD638</label><input name="no" required maxlength="9" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="M12345678"></div>
      <div class="two"><div class="field"><label>\uC0DD\uB144\uC6D4\uC77C</label><input name="birth" type="date" required></div>
        <div class="field"><label>\uC5EC\uAD8C \uB9CC\uB8CC\uC77C</label><input name="exp" type="date" required></div></div>
      <details class="cs"><summary><label><input type="checkbox" name="a1"> \uAC1C\uC778\uC815\uBCF4 \uC218\uC9D1\xB7\uC774\uC6A9 \uB3D9\uC758 (\uD544\uC218)</label></summary>${b1}</details>
      <details class="cs"><summary><label><input type="checkbox" name="a2"> \uACE0\uC720\uC2DD\uBCC4\uC815\uBCF4(\uC5EC\uAD8C\uBC88\uD638) \uCC98\uB9AC \uB3D9\uC758 (\uD544\uC218)</label></summary>${_1}</details>
      <label class="all"><input type="checkbox" id="aAll"> \uC704 \uB0B4\uC6A9\uC744 \uBAA8\uB450 \uC77D\uC5C8\uACE0 \uBAA8\uB450 \uB3D9\uC758\uD574\uC694</label>
      <p class="err" hidden></p>
      <button class="btn" type="submit">\uB4F1\uB85D\uD558\uACE0 \uC785\uC7A5</button>
    </form>
    <button class="btn ghost back" type="button" id="pb">\uB098\uC911\uC5D0 \uD560\uAC8C\uC694 (\uC9C0\uAD6C\uBCF8\uC73C\uB85C)</button>`;let n=_t("#ppf",t),s=_t(".err",n),r=_t("#ocr",t),o=_t("input[type=file]",t),a="";Kp(),_t("#pb",t).onclick=qo,_t("#aAll",t).onchange=c=>{n.a1.checked=n.a2.checked=c.target.checked},[n.a1,n.a2].forEach(c=>c.onchange=()=>{_t("#aAll",t).checked=n.a1.checked&&n.a2.checked}),n.no.oninput=()=>{n.no.value=n.no.value.toUpperCase().replace(/[^A-Z0-9]/g,"")};let l=(c,h="")=>{r.hidden=!c,r.className="ocr "+h,r.innerHTML=c};o.onchange=async()=>{let c=o.files&&o.files[0];if(o.value="",!c)return;Ye(s);let h;try{h=await Jp(c)}catch(u){return Ye(s,u)}a=jp(h),_t("#shotImg",t).src=a,_t("#shotImg",t).hidden=!1,_t("#shotTxt",t).textContent="\u{1F4F7} \uB2E4\uC2DC \uCC0D\uAE30",l("\u{1F50D} \uC5EC\uAD8C \uAE00\uC790\uB97C \uC77D\uB294 \uC911\uC774\uC5D0\uC694\u2026 (\uCC98\uC74C\uC5D4 10\uCD08\uCBE4 \uAC78\uB824\uC694)");try{let u=await Qp(h,d=>l(`\u{1F50D} \uC5EC\uAD8C \uAE00\uC790\uB97C \uC77D\uB294 \uC911\uC774\uC5D0\uC694\u2026 ${Math.round(d*100)}%`));if(!u||u.ok===0)return l("\uAE00\uC790\uB97C \uC77D\uC9C0 \uBABB\uD588\uC5B4\uC694. \uBC1D\uC740 \uACF3\uC5D0\uC11C \uC544\uB798 \uB450 \uC904\uC774 \uC798 \uBCF4\uC774\uAC8C \uB2E4\uC2DC \uCC0D\uAC70\uB098, \uC544\uB798 \uCE78\uC5D0 \uC9C1\uC811 \uB123\uC5B4 \uC8FC\uC138\uC694.","warn");u.no&&(n.no.value=u.no),u.birth&&(n.birth.value=u.birth),u.exp&&(n.exp.value=u.exp),l(u.ok===3?`\u2705 \uC790\uB3D9\uC73C\uB85C \uCC44\uC6E0\uC5B4\uC694${u.name?` \u2014 <b>${at(u.name)}</b>`:""}. \uC5EC\uAD8C\uACFC \uAC19\uC740\uC9C0 \uD55C \uBC88\uB9CC \uD655\uC778\uD574 \uC8FC\uC138\uC694.`:`\u26A0 \uC77C\uBD80\uB9CC \uC77D\uC5C8\uC5B4\uC694${u.name?` (${at(u.name)})`:""}. \uC544\uB798 \uCE78\uC744 \uC5EC\uAD8C\uACFC \uBE44\uAD50\uD574\uC11C \uACE0\uCCD0 \uC8FC\uC138\uC694.`,u.ok===3?"good":"warn")}catch{l("\uC790\uB3D9 \uC77D\uAE30\uB97C \uC4F8 \uC218 \uC5C6\uC5B4\uC694. \uC544\uB798 \uCE78\uC5D0 \uC9C1\uC811 \uB123\uC5B4 \uC8FC\uC138\uC694.","warn")}},n.onsubmit=async c=>{if(c.preventDefault(),Ye(s),!a)return Ye(s,{message:"\uC5EC\uAD8C \uC0AC\uC9C4\uC744 \uBA3C\uC800 \uCC0D\uC5B4 \uC62C\uB824 \uC8FC\uC138\uC694."});if(!(n.a1.checked&&n.a2.checked))return Ye(s,{message:"\uD544\uC218 \uB3D9\uC758 \uB450 \uAC00\uC9C0\uC5D0 \uBAA8\uB450 \uCCB4\uD06C\uD574 \uC8FC\uC138\uC694."});let h=_t("button[type=submit]",n);Mn(h,!0);try{let u=await He("/api/passport",{no:n.no.value,birth:n.birth.value,exp:n.exp.value,photo:a,agree:!0,agreeId:!0});if(Yt.passport=u.passport,_t("#login").classList.remove("tall"),!Yt.profile||!Yt.profile.nick||!Yt.profile.sgg)return Yu(i,!0);i(Yt.profile)}catch(u){Ye(s,u),Mn(h,!1)}}}async function w1(){if(confirm(`\uC5EC\uAD8C \uB4F1\uB85D\uC744 \uC9C0\uC6B8\uAE4C\uC694?
\uC5EC\uAD8C \uC0AC\uC9C4\uACFC \uC815\uBCF4\uAC00 \uD30C\uAE30\uB418\uACE0, \uB300\uAE30\uC2E4\uC5D0 \uB2E4\uC2DC \uB4E4\uC5B4\uC624\uB824\uBA74 \uC5EC\uAD8C\uC744 \uC0C8\uB85C \uB4F1\uB85D\uD574\uC57C \uD574\uC694.`))try{await He("/api/passport/delete",{}),alert("\uC5EC\uAD8C \uC815\uBCF4\uB97C \uC9C0\uC6E0\uC5B4\uC694."),location.reload()}catch(i){alert(i.message)}}function Yu(i,t){let e=Yt.profile||{},n=`
    <h2>${t?"\uB77C\uC6B4\uC9C0\uC5D0\uC11C \uC4F8 \uC774\uB984\uACFC \uB3D9\uB124":"\uB0B4 \uC815\uBCF4"}</h2>
    <p class="small">\uB2E4\uB978 \uD68C\uC6D0\uC5D0\uAC8C\uB294 <b>\uB2C9\uB124\uC784\uACFC \uB3D9\uB124(\uC2DC\xB7\uAD70\xB7\uAD6C)</b>\uB9CC \uBCF4\uC5EC\uC694. \uC2E4\uBA85\xB7\uC5F0\uB77D\uCC98\uB294 \uBCF4\uC774\uC9C0 \uC54A\uC544\uC694. \uC704\uCE58(GPS)\uB294 \uC4F0\uC9C0 \uC54A\uC544\uC694.</p>
    <form id="pf">
      <div class="field"><label>\uB2C9\uB124\uC784 (2~12\uC790)</label><input name="nick" maxlength="12" required value="${at(e.nick||"")}"></div>
      <div class="field"><label>\uC6B0\uB9AC \uB3D9\uB124</label><div class="two"><select name="sido" required></select><select name="sgg" required></select></div></div>
      <div class="field"><label>\uCE90\uB9AD\uD130 \uC0C9\uC0C1</label><div class="swatches">${$u.map(l=>`<button type="button" data-c="${l}" style="background:${l}" class="${l===(e.color||$u[0])?"on":""}"></button>`).join("")}</div></div>
      <p class="err" hidden></p>
      <button class="btn" type="submit">${t?"\uC800\uC7A5\uD558\uACE0 \uC785\uC7A5":"\uC800\uC7A5"}</button>
      ${t?"":'<button class="btn ghost" type="button" id="lo">\uB85C\uADF8\uC544\uC6C3</button><button class="btn ghost" type="button" id="pdel">\u{1F6C2} \uC5EC\uAD8C \uB4F1\uB85D \uC9C0\uC6B0\uAE30 (\uB300\uAE30\uC2E4 \uC774\uC6A9 \uD574\uC9C0)</button>'}
    </form>`,s=t?_t("#login .card"):wn(n);t&&(s.innerHTML=n);let r=_t("#pf",s),o=_t(".err",r);rm(r,e.sido,e.sgg);let a=e.color||$u[0];r.querySelectorAll("[data-c]").forEach(l=>l.onclick=()=>{a=l.dataset.c,r.querySelectorAll("[data-c]").forEach(c=>c.classList.toggle("on",c===l))}),t||(_t("#lo",r).onclick=()=>{Os.set($o,null),Yt.token=null,location.reload()},_t("#pdel",r).onclick=w1),r.onsubmit=async l=>{l.preventDefault();let c=_t("button[type=submit]",r);Mn(c,!0),Ye(o);try{let h=await He("/api/profile",{nick:r.nick.value.trim(),sido:r.sido.value,sgg:r.sgg.value,color:a}),u=Yt.profile&&(Yt.profile.sgg!==h.profile.sgg||Yt.profile.nick!==h.profile.nick||Yt.profile.color!==h.profile.color);Yt.profile=h.profile,t?i(Yt.profile):(_n(),u&&location.reload())}catch(h){Ye(o,h)}Mn(c,!1)}}var am=()=>Yu(null,!1);async function lm(i){if(!Yt.token)return Bl(i);try{await om(i)}catch(t){if(t.status===401)return Yt.token=null,Os.set($o,null),Bl(i,"\uB85C\uADF8\uC778\uC774 \uB05D\uB0AC\uC5B4\uC694. \uB2E4\uC2DC \uB85C\uADF8\uC778\uD574 \uC8FC\uC138\uC694.");Bl(i,t.message==="Failed to fetch"?"\uB77C\uC6B4\uC9C0 \uC11C\uBC84\uC5D0 \uC5F0\uACB0\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694. \uC778\uD130\uB137 \uC5F0\uACB0\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694.":t.message)}}function cm(i){if(i.startsWith("dong-")){let t=$p(i.slice(5));return{id:i,kind:"dong",name:`\u{1F3D8} ${t?t.label:"\uC9C0\uC5ED"} \uBC29`}}if(i.startsWith("club-")){let t=new URLSearchParams(location.search).get("rname");return{id:i,kind:"club",name:`\u{1F465} ${t?t.slice(0,20):"\uB3D9\uD638\uD68C"} \uBC29`}}if(i.startsWith("meet-"))return{id:i,kind:"meet",name:"\u{1F4C5} \uBAA8\uC784 \uB300\uD654\uBC29"};if(i.startsWith("course-")){let t=new URLSearchParams(location.search).get("cname");return{id:i,kind:"course",name:`\u26F3 ${t?t.slice(0,30):"\uACE8\uD504\uC7A5"} \uB77C\uC6B4\uB4DC`}}return{id:"hub",kind:"hub",name:"\u26F3 \uD0DC\uC77C\uACE8\uD504 \uB77C\uC6B4\uC9C0 \uAD11\uC7A5"}}function Zu(i,t){let e=new URLSearchParams(location.search);e.set("room",i),t?e.set("rname",t):e.delete("rname"),location.search=e.toString()}var tm=i=>(i<0?"m":"")+Math.round(Math.abs(i)*1e3),hm=(i,t)=>`course-${tm(i)}_${tm(t)}`,S1=()=>Yt.profile&&Yt.profile.sgg?qp(Yt.profile.sido,Yt.profile.sgg):null,um=["\uACE8\uD504","\uC2A4\uD06C\uB9B0\uACE8\uD504","\uD30C\uD06C\uACE8\uD504","\uC5F0\uC2B5\uC7A5","\uACE8\uD504\uC5EC\uD589","\uB2F9\uAD6C","\uB09A\uC2DC","\uC6B4\uB3D9\xB7\uC0B0\uCC45","\uCE5C\uBAA9","\uAE30\uD0C0"],E1=["\u26F3","\u{1F3CC}","\u{1F3CC}\uFE0F\u200D\u2640\uFE0F","\u{1F3AF}","\u{1F3C6}","\u2708","\u{1F3B1}","\u{1F3A3}","\u{1F6B6}","\u2615","\u{1F333}","\u{1F525}","\u2B50","\u{1F340}","\u{1F42F}","\u{1F985}"],T1=["\uB204\uAD6C\uB098","20\xB730\uB300","30\xB740\uB300","40\xB750\uB300","50\xB760\uB300","60\uB300 \uC774\uC0C1"],em=["#2b8a3e","#1971c2","#e8590c","#c2255c","#6741d9","#0c8599","#5c940d","#495057"],nm={owner:"\u{1F451} \uBAA8\uC784\uC7A5",manager:"\u2B50 \uC6B4\uC601\uC9C4",member:"",pending:"\uC2B9\uC778 \uB300\uAE30"},dm='<div class="safety">\u{1F6E1} <b>\uC548\uC804\uD558\uAC8C \uB9CC\uB098\uC694</b> \xB7 \uCC98\uC74C \uB9CC\uB098\uB294 \uBD84\uACFC\uB294 \uC0AC\uB78C\uC774 \uB9CE\uC740 \uACF5\uAC1C\uB41C \uC7A5\uC18C\uC5D0\uC11C \uB9CC\uB098\uC138\uC694. \uD68C\uBE44\xB7\uB3C8\uC744 \uAC1C\uC778 \uACC4\uC88C\uB85C \uBA3C\uC800 \uBCF4\uB0B4 \uB2EC\uB77C\uACE0 \uD558\uBA74 \uBC14\uB85C \uC2E0\uACE0\uD574 \uC8FC\uC138\uC694. \uD68C\uC6D0\uB07C\uB9AC\uC758 \uB3D9\uD638\uD68C \uD65C\uB3D9\uC740 \uCC38\uAC00\uC790 \uC2A4\uC2A4\uB85C \uCC45\uC784\uC9C0\uACE0 \uC9C4\uD589\uD574\uC694.</div>',qu=i=>{let[t,e,n]=i.split("-").map(Number),s=new Date(Date.UTC(t,e-1,n)).getUTCDay();return`${e}/${n}(${"\uC77C\uC6D4\uD654\uC218\uBAA9\uAE08\uD1A0"[s]})`},im=i=>{let t=(Date.now()-i)/6e4;return t<60?`${Math.max(1,t|0)}\uBD84 \uC804`:t<1440?`${t/60|0}\uC2DC\uAC04 \uC804`:t<43200?`${t/1440|0}\uC77C \uC804`:new Date(i).toLocaleDateString("ko-KR")},fm=i=>`<span class="cl-em" style="background:${at(i.color)}">${at(i.emoji)}</span>`,Ue={scope:"mine",cat:"",q:"",sort:""};async function si(){let i=Yt.profile||{},t=wn(`
    <h2>\u{1F465} \uB3D9\uD638\uD68C</h2>
    <p class="small">\uD55C \uBC88 \uAC00\uC785\uD558\uBA74 \uACC4\uC18D \uD568\uAED8\uD558\uB294 \uC6B0\uB9AC \uB3D9\uB124 \uBAA8\uC784\uC774\uC5D0\uC694. \uAC8C\uC2DC\uD310, \uC815\uBAA8 \uC77C\uC815, \uB3D9\uD638\uD68C \uC804\uC6A9 \uBC29\uC774 \uC788\uC5B4\uC694.</p>
    <div class="tabs"><button data-s="mine">\uB0B4 \uB3D9\uD638\uD68C</button><button data-s="dong">${at(i.sgg||"\uC6B0\uB9AC \uB3D9\uB124")}</button><button data-s="sido">${at(i.sido||"\uC2DC\xB7\uB3C4")} \uC804\uCCB4</button><button data-s="all">\uC804\uAD6D</button></div>
    <div class="cl-filter"><select id="cfCat"><option value="">\uC804\uCCB4 \uC885\uB958</option>${um.map(s=>`<option${s===Ue.cat?" selected":""}>${s}</option>`).join("")}</select>
      <select id="cfSort"><option value="">\uCD5C\uADFC \uD65C\uB3D9\uC21C</option><option value="big"${Ue.sort==="big"?" selected":""}>\uD68C\uC6D0 \uB9CE\uC740 \uC21C</option><option value="new"${Ue.sort==="new"?" selected":""}>\uC0C8\uB85C \uC0DD\uAE34 \uC21C</option></select>
      <input id="cfQ" maxlength="20" placeholder="\uC774\uB984\uC73C\uB85C \uCC3E\uAE30" value="${at(Ue.q)}"></div>
    <div class="mt-list"><p class="small">\uBD88\uB7EC\uC624\uB294 \uC911\u2026</p></div>
    <div class="row-end"><button class="btn" id="clNew">\uFF0B \uB3D9\uD638\uD68C \uB9CC\uB4E4\uAE30</button></div>`,"wide");t.querySelectorAll("[data-s]").forEach(s=>{s.classList.toggle("on",s.dataset.s===Ue.scope),s.onclick=()=>{Ue.scope=s.dataset.s,si()}}),_t("#cfCat",t).onchange=s=>{Ue.cat=s.target.value,si()},_t("#cfSort",t).onchange=s=>{Ue.sort=s.target.value,si()};let e;_t("#cfQ",t).oninput=s=>{clearTimeout(e),e=setTimeout(()=>{Ue.q=s.target.value.trim(),Ue.scope==="mine"&&(Ue.scope="all"),si().then(()=>{let r=_t("#cfQ");r&&(r.focus(),r.setSelectionRange(99,99))})},400)},_t("#clNew",t).onclick=()=>pm();let n=_t(".mt-list",t);try{let s=new URLSearchParams;Ue.scope==="mine"&&!Ue.q&&s.set("mine","1"),Ue.scope==="dong"&&(s.set("sido",i.sido||""),s.set("sgg",i.sgg||"")),Ue.scope==="sido"&&s.set("sido",i.sido||""),Ue.cat&&s.set("cat",Ue.cat),Ue.q&&s.set("q",Ue.q),Ue.sort&&s.set("sort",Ue.sort);let{clubs:r}=await He("/api/clubs?"+s);if(!r.length){n.innerHTML=Ue.scope==="mine"?'<p class="empty">\uC544\uC9C1 \uAC00\uC785\uD55C \uB3D9\uD638\uD68C\uAC00 \uC5C6\uC5B4\uC694.<br>\uC704\uC5D0\uC11C \uC6B0\uB9AC \uB3D9\uB124 \uB3D9\uD638\uD68C\uB97C \uCC3E\uC544\uBCF4\uAC70\uB098 \uC9C1\uC811 \uB9CC\uB4E4\uC5B4 \uBCF4\uC138\uC694!</p>':'<p class="empty">\uC870\uAC74\uC5D0 \uB9DE\uB294 \uB3D9\uD638\uD68C\uAC00 \uC5C6\uC5B4\uC694.<br>\uCCAB \uB3D9\uD638\uD68C\uB97C \uB9CC\uB4E4\uC5B4 \uBCF4\uC138\uC694!</p>';return}n.innerHTML=r.map(o=>`
      <button class="cl" data-id="${o.id}">${fm(o)}
        <span class="cl-t"><b>${at(o.name)}</b>${o.role?` <span class="cl-r">${o.role==="pending"?"\uC2B9\uC778 \uB300\uAE30":"\uAC00\uC785\uD568"}</span>`:""}</span>
        <span class="cl-d">${at(o.cat)} \xB7 ${at(o.sido)} ${at(o.sgg)} \xB7 \uD68C\uC6D0 ${o.count}${o.max?"/"+o.max:""}\uBA85 \xB7 ${at(o.ages)}${o.mode==="approve"?" \xB7 \uC2B9\uC778\uC81C":""}</span>
        <span class="cl-i">${at(o.intro.split(`
`)[0].slice(0,60))}</span>
        ${o.next?`<span class="cl-n">\u{1F4C5} \uB2E4\uC74C \uC815\uBAA8 ${qu(o.next.date)} ${at(o.next.time||"")} \xB7 ${at(o.next.title)}</span>`:""}
      </button>`).join(""),n.querySelectorAll("[data-id]").forEach(o=>o.onclick=()=>rs(+o.dataset.id))}catch(s){n.innerHTML=`<p class="err">${at(s.message)}</p>`}}function pm(i){let t=Yt.profile||{},e=i||{emoji:"\u26F3",color:em[0],cat:"\uACE8\uD504",ages:"\uB204\uAD6C\uB098",mode:"open",max:100,sido:t.sido,sgg:t.sgg},n=wn(`
    <h2>${i?"\uB3D9\uD638\uD68C \uC815\uBCF4 \uBC14\uAFB8\uAE30":"\u{1F465} \uB3D9\uD638\uD68C \uB9CC\uB4E4\uAE30"}</h2>
    <form id="cf">
      <div class="field"><label>\uB3D9\uD638\uD68C \uC774\uB984 (2~20\uC790)</label><input name="name" maxlength="20" required value="${at(e.name||"")}" placeholder="\uC608: \uAC15\uB3D9 \uC8FC\uB9D0 \uACE8\uD504\uD68C"></div>
      <div class="field"><label>\uB300\uD45C \uADF8\uB9BC\uACFC \uC0C9</label><div class="em-pick">${E1.map(c=>`<button type="button" data-e="${c}" class="${c===e.emoji?"on":""}">${c}</button>`).join("")}</div>
        <div class="swatches">${em.map(c=>`<button type="button" data-c="${c}" style="background:${c}" class="${c===e.color?"on":""}"></button>`).join("")}</div></div>
      <div class="two"><div class="field"><label>\uC885\uB958</label><select name="cat">${um.map(c=>`<option${c===e.cat?" selected":""}>${c}</option>`).join("")}</select></div>
        <div class="field"><label>\uC5F0\uB839\uB300</label><select name="ages">${T1.map(c=>`<option${c===e.ages?" selected":""}>${c}</option>`).join("")}</select></div></div>
      <div class="field"><label>\uD65C\uB3D9 \uB3D9\uB124</label><div class="two"><select name="sido" required></select><select name="sgg" required></select></div></div>
      <div class="field"><label>\uC18C\uAC1C (10\uC790 \uC774\uC0C1)</label><textarea name="intro" maxlength="1000" rows="5" required placeholder="\uC5B4\uB5A4 \uB3D9\uD638\uD68C\uC778\uC9C0, \uC8FC\uB85C \uC5B8\uC81C\xB7\uC5B4\uB514\uC11C \uBAA8\uC774\uB294\uC9C0, \uC2E4\uB825\xB7\uBD84\uC704\uAE30, \uD68C\uBE44\uAC00 \uC788\uB2E4\uBA74 \uC4F0\uB294 \uACF3 \uB4F1\uC744 \uC801\uC5B4 \uC8FC\uC138\uC694. \uC804\uD654\uBC88\uD638\xB7\uACC4\uC88C\uB294 \uC801\uC9C0 \uB9C8\uC138\uC694.">${at(e.intro||"")}</textarea></div>
      <div class="two"><div class="field"><label>\uAC00\uC785 \uBC29\uC2DD</label><select name="mode"><option value="open"${e.mode==="open"?" selected":""}>\uB204\uAD6C\uB098 \uBC14\uB85C \uAC00\uC785</option><option value="approve"${e.mode==="approve"?" selected":""}>\uC6B4\uC601\uC9C4 \uC2B9\uC778 \uD6C4 \uAC00\uC785</option></select></div>
        <div class="field"><label>\uC815\uC6D0 (5~300\uBA85)</label><input name="max" type="number" min="5" max="300" value="${e.max||100}"></div></div>
      <div class="field" id="qf"><label>\uAC00\uC785 \uC9C8\uBB38 (\uC2B9\uC778\uC81C\uC77C \uB54C, \uC120\uD0DD)</label><input name="question" maxlength="100" value="${at(e.question||"")}" placeholder="\uC608: \uD3C9\uADE0 \uD0C0\uC218\uC640 \uC8FC\uB85C \uCE58\uB294 \uC694\uC77C\uC744 \uC54C\uB824 \uC8FC\uC138\uC694"></div>
      <p class="err" hidden></p>
      <button class="btn" type="submit">${i?"\uC800\uC7A5":"\uB3D9\uD638\uD68C \uB9CC\uB4E4\uAE30"}</button>
      <button class="btn ghost" type="button" id="cb">\u2190 \uB3CC\uC544\uAC00\uAE30</button>
    </form>`,"wide"),s=_t("#cf",n),r=_t(".err",s);rm(s,e.sido,e.sgg);let o=e.emoji,a=e.color;s.querySelectorAll("[data-e]").forEach(c=>c.onclick=()=>{o=c.dataset.e,s.querySelectorAll("[data-e]").forEach(h=>h.classList.toggle("on",h===c))}),s.querySelectorAll("[data-c]").forEach(c=>c.onclick=()=>{a=c.dataset.c,s.querySelectorAll("[data-c]").forEach(h=>h.classList.toggle("on",h===c))});let l=()=>{_t("#qf",s).hidden=s.mode.value!=="approve"};s.mode.onchange=l,l(),_t("#cb",s).onclick=()=>i?rs(i.id):si(),s.onsubmit=async c=>{c.preventDefault();let h=_t("button[type=submit]",s);Mn(h,!0),Ye(r);try{let u={...Object.fromEntries(new FormData(s)),emoji:o,color:a},d=i?await He(`/api/clubs/${i.id}/edit`,u):await He("/api/clubs",u);rs(d.club.id)}catch(u){Ye(r,u),Mn(h,!1)}}}var Fs="home";async function rs(i,t){t&&(Fs=t);let e=wn('<p class="small">\uBD88\uB7EC\uC624\uB294 \uC911\u2026</p>',"wide"),n;try{n=(await He("/api/clubs/"+i)).club}catch(m){e.innerHTML+=`<p class="err">${at(m.message)}</p>`;return}if(!n){e.innerHTML+='<p class="err">\uC5C6\uC5B4\uC9C4 \uB3D9\uD638\uD68C\uC608\uC694.</p><button class="btn ghost" id="bk">\u2190 \uBAA9\uB85D</button>',_t("#bk",e).onclick=si;return}let s=n.role&&n.role!=="pending",r=/owner|manager/.test(n.role||"")||n.staff,o=n.role==="owner"||n.staff;!s&&!n.staff&&(Fs="home");let a=s||n.staff?`<div class="tabs">${[["home","\uC18C\uAC1C"],["board","\uAC8C\uC2DC\uD310"],["meet",`\uC815\uBAA8 \uC77C\uC815${n.meetups&&n.meetups.length?" "+n.meetups.length:""}`],["people",`\uD68C\uC6D0 ${n.count}${n.pending&&n.pending.length?` \xB7 \uC2E0\uCCAD ${n.pending.length}`:""}`]].map(([m,x])=>`<button data-t="${m}" class="${m===Fs?"on":""}">${x}</button>`).join("")}</div>`:"",l="";Fs==="home"?l=`${n.notices.length?`<div class="cl-notice">${n.notices.map(m=>`<div>\u{1F4E2} ${at(m.body)}</div>`).join("")}</div>`:""}
      <p class="mt-body">${at(n.intro)}</p>
      <dl class="mt-info"><dt>\uD65C\uB3D9 \uB3D9\uB124</dt><dd>${at(n.sido)} ${at(n.sgg)}</dd><dt>\uC5F0\uB839\uB300</dt><dd>${at(n.ages)}</dd>
        <dt>\uC6B4\uC601\uC9C4</dt><dd>${n.leaders.map(m=>`${m.role==="owner"?"\u{1F451}":"\u2B50"} ${at(m.nick)}`).join(", ")}</dd>
        <dt>\uAC00\uC785</dt><dd>${n.mode==="approve"?"\uC6B4\uC601\uC9C4 \uC2B9\uC778 \uD6C4 \uAC00\uC785":"\uB204\uAD6C\uB098 \uBC14\uB85C \uAC00\uC785"} \xB7 \uC815\uC6D0 ${n.max}\uBA85</dd>
        ${n.next?`<dt>\uB2E4\uC74C \uC815\uBAA8</dt><dd>${qu(n.next.date)} ${at(n.next.time||"")} \xB7 ${at(n.next.title)}</dd>`:""}</dl>
      ${n.role?n.role==="pending"?'<p class="cl-wait">\uAC00\uC785 \uC2E0\uCCAD\uC744 \uBCF4\uB0C8\uC5B4\uC694. \uC6B4\uC601\uC9C4\uC774 \uC2B9\uC778\uD558\uBA74 \uD65C\uB3D9\uD560 \uC218 \uC788\uC5B4\uC694.</p>':"":`<form id="jf">${n.mode==="approve"?`<div class="field"><label>${at(n.question||"\uAC00\uC785 \uC778\uC0AC (\uC6B4\uC601\uC9C4\uC5D0\uAC8C \uBCF4\uC5EC\uC694)")}</label><textarea name="msg" maxlength="200" rows="2" placeholder="\uAC04\uB2E8\uD55C \uC790\uAE30\uC18C\uAC1C\uB97C \uC801\uC5B4 \uC8FC\uC138\uC694"></textarea></div>`:""}
        <button class="btn" type="submit">${n.mode==="approve"?"\uAC00\uC785 \uC2E0\uCCAD\uD558\uAE30":"\uAC00\uC785\uD558\uAE30"}</button></form>`}`:Fs==="board"?l=`<form id="pf2" class="cl-write"><textarea name="body" maxlength="1000" rows="2" required placeholder="\uD68C\uC6D0\uB4E4\uC5D0\uAC8C \uD558\uACE0 \uC2F6\uC740 \uB9D0 (\uB77C\uC6B4\uB529 \uD6C4\uAE30, \uC870\uC778 \uAD6C\uD574\uC694, \uC9C8\uBB38 \uB4F1)"></textarea>
        <div class="row-end">${r?'<label class="rd"><input type="checkbox" name="notice"> \uACF5\uC9C0\uB85C \uC62C\uB9AC\uAE30</label>':""}<button class="btn" type="submit">\uC62C\uB9AC\uAE30</button></div></form>
      <div class="cl-posts">${(n.posts||[]).map(m=>`<div class="cl-post ${m.notice?"nt":""}"><div class="cl-ph"><b>${m.notice?"\u{1F4E2} ":""}${at(m.nick)}</b><span>${im(m.created)}</span>${m.mine||r?`<button data-del="${m.id}">\uC9C0\uC6B0\uAE30</button>`:""}</div><div class="cl-pb">${at(m.body)}</div></div>`).join("")||'<p class="empty">\uC544\uC9C1 \uAE00\uC774 \uC5C6\uC5B4\uC694. \uCCAB \uAE00\uC744 \uB0A8\uACA8 \uBCF4\uC138\uC694!</p>'}</div>`:Fs==="meet"?l=`<div class="mt-list">${(n.meetups||[]).map(m=>`
      <button class="mt" data-m="${m.id}"><span class="mt-k">${qu(m.date)}</span><b>${at(m.title)}</b>
        <span class="mt-d">${at(m.time||"")} \xB7 ${at(m.place)}</span>
        <span class="mt-n ${m.count>=m.max?"full":""}">${m.status!=="open"?"\uB9C8\uAC10":`${m.count}/${m.max}\uBA85`}${m.joined?" \xB7 \uCC38\uC11D":""}</span></button>`).join("")||'<p class="empty">\uC7A1\uD78C \uC815\uBAA8\uAC00 \uC5C6\uC5B4\uC694.</p>'}</div>
      ${n.mode!=="approve"||r?'<div class="row-end"><button class="btn" id="mkm">\uFF0B \uC815\uBAA8 \uC77C\uC815 \uB9CC\uB4E4\uAE30</button></div>':""}`:Fs==="people"&&(l=`${r&&n.pending&&n.pending.length?`<h3>\uAC00\uC785 \uC2E0\uCCAD ${n.pending.length}\uBA85</h3><div class="col">${n.pending.map(m=>`<div class="cl-m"><b>${at(m.nick)}</b><span class="small">${im(m.at)}${m.msg?" \xB7 "+at(m.msg):""}</span><span><button class="btn green sm" data-u="${at(m.uid)}" data-a="approve">\uC2B9\uC778</button> <button class="btn ghost sm" data-u="${at(m.uid)}" data-a="reject">\uAC70\uC808</button></span></div>`).join("")}</div><h3>\uD68C\uC6D0</h3>`:""}
      <div class="col">${(n.members||[]).map(m=>`<div class="cl-m"><b>${at(m.nick)}${m.me?" (\uB098)":""}</b><span class="cl-r">${nm[m.role]||""}</span>
        ${r&&m.uid&&!m.me&&m.role!=="owner"?`<span>${o?`<button class="btn ghost sm" data-u="${at(m.uid)}" data-a="${m.role==="manager"?"member":"manager"}">${m.role==="manager"?"\uC6B4\uC601\uC9C4 \uD574\uC81C":"\uC6B4\uC601\uC9C4\uC73C\uB85C"}</button> `:""}${o&&n.role==="owner"?`<button class="btn ghost sm" data-u="${at(m.uid)}" data-a="owner">\uBAA8\uC784\uC7A5 \uB118\uAE30\uAE30</button> `:""}${m.role!=="manager"||o?`<button class="btn ghost sm" data-u="${at(m.uid)}" data-a="kick">\uB0B4\uBCF4\uB0B4\uAE30</button>`:""}</span>`:""}</div>`).join("")}</div>`),e.innerHTML=`<button class="x" aria-label="\uB2EB\uAE30">\u2715</button>
    <div class="cl-head" style="--c:${at(n.color)}">${fm(n)}<div><h2>${at(n.name)}</h2><p>${at(n.cat)} \xB7 ${at(n.sido)} ${at(n.sgg)} \xB7 \uD68C\uC6D0 ${n.count}\uBA85${n.role?` \xB7 ${nm[n.role]||"\uD68C\uC6D0"}`:""}</p></div></div>
    ${s||n.staff?'<div class="row-end cl-act"><button class="btn green" data-x="room">\u{1F4AC} \uB3D9\uD638\uD68C\uBC29 \uC785\uC7A5</button></div>':""}
    ${a}${l}
    <p class="err" hidden></p>
    <div class="row-end">
      ${o?'<button class="btn ghost" data-x="edit">\uC815\uBCF4 \uBC14\uAFB8\uAE30</button><button class="btn ghost" data-x="delete">\uB3D9\uD638\uD68C \uC5C6\uC560\uAE30</button>':""}
      ${n.role&&n.role!=="owner"?`<button class="btn ghost" data-x="leave">${n.role==="pending"?"\uC2E0\uCCAD \uCDE8\uC18C":"\uD0C8\uD1F4"}</button>`:""}
      ${n.role!=="owner"?'<button class="btn ghost" data-x="report">\u{1F6A8} \uC2E0\uACE0</button>':""}
      <button class="btn ghost" data-x="back">\u2190 \uBAA9\uB85D</button>
    </div>${dm}`,_t(".x",e).onclick=_n;let c=_t(".err",e),h=async(m,x,g)=>{Mn(g,!0),Ye(c);try{if(!(await He(`/api/clubs/${n.id}/${m}`,x||{})).club)return si();rs(n.id)}catch(p){Ye(c,p),Mn(g,!1)}};e.querySelectorAll("[data-t]").forEach(m=>m.onclick=()=>rs(n.id,m.dataset.t)),e.querySelectorAll("[data-x]").forEach(m=>m.onclick=()=>{let x=m.dataset.x;if(x==="back")return si();if(x==="room")return Zu("club-"+n.id,n.name);if(x==="edit")return pm(n);if(x==="report")return Ku({club:n.id,nick:n.name});x==="delete"&&!confirm(`'${n.name}' \uB3D9\uD638\uD68C\uB97C \uC5C6\uC568\uAE4C\uC694? \uAC8C\uC2DC\uD310\xB7\uC815\uBAA8 \uC77C\uC815\uB3C4 \uD568\uAED8 \uC9C0\uC6CC\uC838\uC694.`)||x==="leave"&&!confirm(n.role==="pending"?"\uAC00\uC785 \uC2E0\uCCAD\uC744 \uCDE8\uC18C\uD560\uAE4C\uC694?":"\uC774 \uB3D9\uD638\uD68C\uC5D0\uC11C \uD0C8\uD1F4\uD560\uAE4C\uC694?")||h(x,{},m)});let u=_t("#jf",e);u&&(u.onsubmit=m=>{m.preventDefault(),h("join",{msg:u.msg?u.msg.value:""},_t("button",u))});let d=_t("#pf2",e);d&&(d.onsubmit=m=>{m.preventDefault(),h("post",{body:d.body.value,notice:d.notice&&d.notice.checked},_t("button[type=submit]",d))}),e.querySelectorAll("[data-del]").forEach(m=>m.onclick=()=>{confirm("\uC774 \uAE00\uC744 \uC9C0\uC6B8\uAE4C\uC694?")&&h("unpost",{id:+m.dataset.del},m)}),e.querySelectorAll("[data-u]").forEach(m=>m.onclick=()=>{let x=m.dataset.a;x==="kick"&&!confirm("\uC774 \uD68C\uC6D0\uC744 \uB0B4\uBCF4\uB0BC\uAE4C\uC694?")||x==="owner"&&!confirm("\uBAA8\uC784\uC7A5\uC744 \uB118\uAE38\uAE4C\uC694? \uB098\uB294 \uC6B4\uC601\uC9C4\uC774 \uB3FC\uC694.")||h("member",{uid:m.dataset.u,act:x},m)}),e.querySelectorAll("[data-m]").forEach(m=>m.onclick=()=>mm(+m.dataset.m));let f=_t("#mkm",e);f&&(f.onclick=()=>A1(n))}function A1(i){let t=new Date(Date.now()+324e5).toISOString().slice(0,10),e=wn(`
    <h2>\u{1F4C5} \uC815\uBAA8 \uC77C\uC815 \uB9CC\uB4E4\uAE30</h2><p class="small">${at(i.name)} \uD68C\uC6D0\uB9CC \uBCF4\uACE0 \uCC38\uC11D\uD560 \uC218 \uC788\uC5B4\uC694.</p>
    <form id="mf">
      <div class="field"><label>\uC81C\uBAA9</label><input name="title" maxlength="40" required placeholder="\uC608: 11\uC6D4 \uC815\uAE30 \uB77C\uC6B4\uB529"></div>
      <div class="two"><div class="field"><label>\uB0A0\uC9DC</label><input name="date" type="date" min="${t}" required></div><div class="field"><label>\uC2DC\uAC04</label><input name="time" type="time"></div></div>
      <div class="two"><div class="field"><label>\uC7A5\uC18C (\uACF5\uAC1C \uC7A5\uC18C)</label><input name="place" maxlength="60" required placeholder="\uC608: \u25CB\u25CBCC, \u25CB\u25CB\uC5ED \uC2A4\uD06C\uB9B0\uACE8\uD504"></div><div class="field"><label>\uC778\uC6D0 (\uB098 \uD3EC\uD568)</label><input name="max" type="number" min="2" max="50" value="8"></div></div>
      <div class="field"><label>\uC548\uB0B4 (\uC120\uD0DD)</label><textarea name="body" maxlength="500" rows="3" placeholder="\uC900\uBE44\uBB3C, \uBE44\uC6A9 \uB098\uB204\uB294 \uBC29\uBC95 \uB4F1. \uC804\uD654\uBC88\uD638\xB7\uACC4\uC88C\uB294 \uC801\uC9C0 \uB9C8\uC138\uC694."></textarea></div>
      <p class="err" hidden></p>
      <button class="btn" type="submit">\uC77C\uC815 \uC62C\uB9AC\uAE30</button>
      <button class="btn ghost" type="button" id="mb">\u2190 \uB3D9\uD638\uD68C\uB85C</button>
    </form>`,"wide"),n=_t("#mf",e),s=_t(".err",n);_t("#mb",n).onclick=()=>rs(i.id),n.onsubmit=async r=>{r.preventDefault();let o=_t("button[type=submit]",n);Mn(o,!0),Ye(s);try{await He(`/api/clubs/${i.id}/meetup`,Object.fromEntries(new FormData(n))),rs(i.id,"meet")}catch(a){Ye(s,a),Mn(o,!1)}}}async function mm(i){let t=wn('<p class="small">\uBD88\uB7EC\uC624\uB294 \uC911\u2026</p>',"wide"),e;try{e=(await He("/api/meetups/"+i)).meetup}catch(o){t.innerHTML+=`<p class="err">${at(o.message)}</p>`;return}if(!e){t.innerHTML+='<p class="err">\uC9C0\uC6CC\uC9C4 \uC77C\uC815\uC774\uC5D0\uC694.</p>';return}let n=()=>e.club?rs(e.club,"meet"):si(),s=Yt.user&&/admin|staff/.test(Yt.user.role);t.innerHTML=`<button class="x" aria-label="\uB2EB\uAE30">\u2715</button>
    <span class="mt-k">${at(e.kind)}</span>${e.status!=="open"?' <span class="mt-k gray">\uB9C8\uAC10</span>':""}
    <h2>${at(e.title)}</h2>
    <dl class="mt-info">
      <dt>\uC5B8\uC81C</dt><dd>${at(e.date)} ${at(e.time||"")}</dd>
      <dt>\uC5B4\uB514\uC11C</dt><dd>${at(e.place)}</dd>
      <dt>\uB9CC\uB4E0 \uC0AC\uB78C</dt><dd>${at(e.hostNick)}</dd>
      <dt>\uCC38\uC11D</dt><dd>${e.count}/${e.max}\uBA85 \xB7 ${(e.members||[]).map(at).join(", ")}</dd>
    </dl>
    ${e.body?`<p class="mt-body">${at(e.body)}</p>`:""}
    <p class="err" hidden></p>
    <div class="row-end">
      ${e.joined?'<button class="btn green" data-a="room">\u{1F4AC} \uC815\uBAA8 \uB300\uD654\uBC29</button>':""}
      ${!e.joined&&e.status==="open"&&e.count<e.max?'<button class="btn" data-a="join">\uCC38\uC11D\uD558\uAE30</button>':""}
      ${e.joined&&!e.mine?'<button class="btn ghost" data-a="leave">\uCC38\uC11D \uCDE8\uC18C</button>':""}
      ${e.mine||s?`<button class="btn ghost" data-a="close">${e.status==="open"?"\uBAA8\uC9D1 \uB9C8\uAC10":"\uB2E4\uC2DC \uBAA8\uC9D1"}</button><button class="btn ghost" data-a="delete">\uC77C\uC815 \uC9C0\uC6B0\uAE30</button>`:""}
      ${e.mine?"":'<button class="btn ghost" data-a="report">\u{1F6A8} \uC2E0\uACE0</button>'}
      <button class="btn ghost" data-a="back">\u2190 \uB3CC\uC544\uAC00\uAE30</button>
    </div>${dm}`,_t(".x",t).onclick=_n;let r=_t(".err",t);t.querySelectorAll("[data-a]").forEach(o=>o.onclick=async()=>{let a=o.dataset.a;if(a==="back")return n();if(a==="room")return Zu("meet-"+e.id);if(a==="report")return Ku({meetup:e.id,nick:e.hostNick});if(!(a==="delete"&&!confirm("\uC774 \uC77C\uC815\uC744 \uC9C0\uC6B8\uAE4C\uC694?"))){Mn(o,!0);try{await He(`/api/meetups/${e.id}/${a}`,{}),a==="delete"?n():mm(e.id)}catch(l){Ye(r,l),Mn(o,!1)}}})}function gm(i,t,e){wn(`
    <h2>${at(i.name)}</h2>
    <p class="small">${at(i.dong||"")}${i.staff?" \xB7 \uD0DC\uC77C\uACE8\uD504 \uC9C1\uC6D0":""}</p>
    <div class="col">
      ${t&&!t.offline?'<button class="btn green" data-a="invite">\u{1F389} \uD30C\uD2F0 \uCD08\uB300</button>':""}
      <button class="btn ghost" data-a="block">${Bs(i.uid)?"\uCC28\uB2E8 \uD480\uAE30":"\u{1F648} \uCC28\uB2E8 (\uB0B4 \uD654\uBA74\uC5D0\uC11C \uC228\uAE30\uAE30)"}</button>
      <button class="btn ghost" data-a="report">\u{1F6A8} \uC2E0\uACE0\uD558\uAE30</button>
      ${e?'<hr><b>\uC9C1\uC6D0 \uBA54\uB274</b><button class="btn ghost" data-a="kick">\uB0B4\uBCF4\uB0B4\uAE30</button><button class="btn ghost" data-a="ban1">\uB0B4\uBCF4\uB0B4\uACE0 \uD558\uB8E8 \uC81C\uD55C</button><button class="btn ghost" data-a="ban0">\uB0B4\uBCF4\uB0B4\uACE0 \uC601\uAD6C \uC81C\uD55C</button>':""}
    </div>`).querySelectorAll("[data-a]").forEach(s=>s.onclick=()=>{let r=s.dataset.a;if(r==="invite"){t.send({t:"ginv",id:i.id}),_n();return}if(r==="block"){v1(i.uid,!Bs(i.uid)),_n(),window.dispatchEvent(new Event("lounge-block"));return}if(r==="report")return Ku({id:i.id,uid:i.uid,nick:i.name},t);r==="kick"&&t.send({t:"kick",id:i.id}),r==="ban1"&&t.send({t:"kick",id:i.id,ban:!0,hours:24}),r==="ban0"&&confirm("\uC601\uAD6C \uC81C\uD55C\uD560\uAE4C\uC694?")&&t.send({t:"kick",id:i.id,ban:!0,hours:0}),_n()})}function Ku(i,t){let e=wn(`
    <h2>\u{1F6A8} ${at(i.nick||"")} \uC2E0\uACE0</h2>
    <p class="small">\uD0DC\uC77C\uACE8\uD504 \uC9C1\uC6D0\uC774 \uD655\uC778\uD558\uACE0 \uC870\uCE58\uD574\uC694. \uBC29 \uC548\uC758 \uC2E0\uACE0\uB294 \uCD5C\uADFC \uB300\uD654\uAC00 \uD568\uAED8 \uC804\uB2EC\uB3FC\uC694.</p>
    <form id="rf">
      <div class="col">${["\uC695\uC124\xB7\uBE44\uD558","\uC131\uD76C\uB871\xB7\uBD88\uCF8C\uD55C \uB9D0","\uAD11\uACE0\xB7\uB3C4\uBC30","\uB3C8\xB7\uACC4\uC88C \uC694\uAD6C (\uC0AC\uAE30 \uC758\uC2EC)","\uBAA8\uC784\uC5D0\uC11C \uBB38\uC81C \uD589\uB3D9","\uAE30\uD0C0"].map((r,o)=>`<label class="rd"><input type="radio" name="r" value="${r}" ${o?"":"checked"}> ${r}</label>`).join("")}</div>
      <div class="field"><label>\uC790\uC138\uD788 (\uC120\uD0DD)</label><textarea name="d" maxlength="250" rows="2"></textarea></div>
      <p class="err" hidden></p>
      <button class="btn" type="submit">\uC2E0\uACE0\uD558\uAE30</button>
    </form>`),n=_t("#rf",e),s=_t(".err",n);n.onsubmit=async r=>{r.preventDefault();let o=n.r.value+(n.d.value.trim()?" \u2014 "+n.d.value.trim():"");if(t&&i.id){t.send({t:"report",id:i.id,uid:i.uid,nick:i.nick,reason:o}),_n();return}try{await He("/api/report",{meetup:i.meetup,club:i.club,target:i.uid,targetNick:i.nick,reason:o}),_n(),Ol==null||Ol("\uC2E0\uACE0\uD588\uC5B4\uC694. \uD655\uC778 \uD6C4 \uC870\uCE58\uD560\uAC8C\uC694.")}catch(a){Ye(s,a)}}}var Ol=null,xm=i=>{Ol=i};async function Go(){let i=wn('<h2>\u{1F6E1} \uB77C\uC6B4\uC9C0 \uAD00\uB9AC</h2><p class="small">\uBD88\uB7EC\uC624\uB294 \uC911\u2026</p>',"wide"),t;try{t=await He("/api/admin/reports")}catch(n){i.innerHTML+=`<p class="err">${at(n.message)}</p>`;return}let e=n=>new Date(n).toLocaleString("ko-KR",{month:"numeric",day:"numeric",hour:"2-digit",minute:"2-digit"});i.innerHTML=`<button class="x" aria-label="\uB2EB\uAE30">\u2715</button><h2>\u{1F6E1} \uB77C\uC6B4\uC9C0 \uAD00\uB9AC</h2>
    <h3>\uC2E0\uACE0 (${t.reports.filter(n=>n.status==="new").length}\uAC74 \uC0C8\uB85C)</h3>
    <div class="adm">${t.reports.map(n=>`<div class="ar ${n.status}">
      <div><b>${at(n.target_nick||"(\uBAA8\uC784)")}</b> \u2190 ${at(n.reporter_nick)} \xB7 ${e(n.at)} \xB7 ${at(n.room)}</div>
      <div>${at(n.reason)}</div>${n.log?`<pre>${at(n.log)}</pre>`:""}
      <div class="row-end">${n.target?`<button class="btn ghost" data-ban="${at(n.target)}" data-h="24">\uD558\uB8E8 \uC81C\uD55C</button><button class="btn ghost" data-ban="${at(n.target)}" data-h="168">7\uC77C \uC81C\uD55C</button><button class="btn ghost" data-ban="${at(n.target)}" data-h="0">\uC601\uAD6C \uC81C\uD55C</button><button class="btn ghost" data-pp="${at(n.target)}">\u{1F6C2} \uC5EC\uAD8C \uBCF4\uAE30</button>`:""}${n.status==="new"?`<button class="btn ghost" data-done="${n.id}">\uCC98\uB9AC \uC644\uB8CC</button>`:""}</div>
    </div>`).join("")||'<p class="empty">\uC2E0\uACE0\uAC00 \uC5C6\uC5B4\uC694.</p>'}</div>
    <h3>\u{1F6C2} \uC5EC\uAD8C \uB4F1\uB85D (${t.pass?t.pass.count:0}\uBA85 \xB7 \uC81C\uD55C\uC73C\uB85C \uBCF4\uAD00 \uC911\uC778 \uC0AC\uC9C4 ${t.pass?t.pass.kept:0}\uC7A5)</h3>
    <p class="small">\uC5EC\uAD8C \uC0AC\uC9C4\uC740 \uC2E0\uACE0\xB7\uC0AC\uACE0 \uD655\uC778\uCC98\uB7FC \uAF2D \uD544\uC694\uD560 \uB54C\uB9CC \uC5EC\uC138\uC694. \uC5F4\uB78C\uD560 \uB54C\uB9C8\uB2E4 \uC0AC\uC720\uC640 \uC5F4\uB78C\uC790\uAC00 \uAE30\uB85D\uB3FC\uC694.</p>
    <div class="adm">${t.pass&&t.pass.log.length?t.pass.log.map(n=>`<div class="ar">${e(n.at)} \xB7 ${at(n.admin)} \u2192 <b>${at(n.tnick||n.target)}</b> \xB7 ${at(n.reason)}</div>`).join(""):'<p class="empty">\uC5F4\uB78C \uAE30\uB85D\uC774 \uC5C6\uC5B4\uC694.</p>'}</div>
    <h3>\uC774\uC6A9 \uC81C\uD55C</h3>
    <div class="adm">${t.bans.map(n=>`<div class="ar"><b>${at(n.nick||n.uid)}</b> \xB7 ${n.until?e(n.until)+"\uAE4C\uC9C0":"\uC601\uAD6C"} \xB7 ${at(n.reason)} <button class="btn ghost" data-unban="${at(n.uid)}">\uD480\uAE30</button> <button class="btn ghost" data-pp="${at(n.uid)}">\u{1F6C2} \uC5EC\uAD8C \uBCF4\uAE30</button></div>`).join("")||'<p class="empty">\uC5C6\uC5B4\uC694.</p>'}</div>`,_t(".x",i).onclick=_n,i.querySelectorAll("[data-ban]").forEach(n=>n.onclick=async()=>{await He("/api/admin/ban",{uid:n.dataset.ban,hours:+n.dataset.h,reason:"\uC2E0\uACE0 \uD655\uC778"}).catch(s=>alert(s.message)),Go()}),i.querySelectorAll("[data-unban]").forEach(n=>n.onclick=async()=>{await He("/api/admin/unban",{uid:n.dataset.unban}).catch(s=>alert(s.message)),Go()}),i.querySelectorAll("[data-done]").forEach(n=>n.onclick=async()=>{await He("/api/admin/report-done",{id:+n.dataset.done}).catch(s=>alert(s.message)),Go()}),i.querySelectorAll("[data-pp]").forEach(n=>n.onclick=()=>R1(n.dataset.pp))}async function R1(i){let t=prompt("\uC5EC\uAD8C \uC0AC\uC9C4\uC744 \uC5EC\uB294 \uC774\uC720\uB97C \uC801\uC5B4 \uC8FC\uC138\uC694 (\uAE30\uB85D\uC5D0 \uB0A8\uC544\uC694). \uC608: \uC2E0\uACE0 #12 \uBCF8\uC778 \uD655\uC778");if(!t||t.trim().length<4)return t==null?null:alert("\uC774\uC720\uB97C 4\uC790 \uC774\uC0C1 \uC801\uC5B4 \uC8FC\uC138\uC694.");let e;try{e=await He("/api/admin/passport-photo",{uid:i,reason:t.trim()})}catch(s){return alert(s.message)}let n=wn(`<h2>\u{1F6C2} ${at(e.nick||i)} \uC5EC\uAD8C</h2><p class="small">\uB4F1\uB85D ${new Date(e.at).toLocaleDateString("ko-KR")} \xB7 \uB9CC\uB8CC ${at(e.exp)} \xB7 \uD654\uBA74\uC744 \uB2EB\uC73C\uBA74 \uC0AC\uB77C\uC838\uC694. \uC800\uC7A5\xB7\uCEA1\uCC98\xB7\uC678\uBD80 \uACF5\uC720 \uAE08\uC9C0.</p><img class="ppimg" alt="\uC5EC\uAD8C \uC0AC\uC9C4">`,"wide");_t(".ppimg",n).src=e.photo}async function ym(i){let t=S1(),e=(s,r)=>`<button class="btn ${i===s?"green":"ghost"} rm" data-r="${at(s)}">${r}${s===t?' <i class="me">\uC6B0\uB9AC \uC9C0\uC5ED</i>':""} <span class="n" data-n="${at(s)}"></span></button>`,n=wn(`<h2>\u{1F6AA} \uBC29 \uBC14\uAFB8\uAE30</h2><div class="col">${e("hub","\u26F3 \uB77C\uC6B4\uC9C0 \uAD11\uC7A5 (\uC804\uAD6D \uD68C\uC6D0)")}</div>
    <h3>\uC9C0\uC5ED\uBC29</h3><div class="rm-grid">${Hr.map(s=>e(Gu(s),at(s.label))).join("")}</div>`,"wide");n.querySelectorAll("[data-r]").forEach(s=>s.onclick=()=>Zu(s.dataset.r));try{let{rooms:s}=await He("/api/rooms");for(let r of s){let o=n.querySelector(`[data-n="${CSS.escape(r.room)}"]`);o&&(o.textContent=`${r.n}\uBA85`)}}catch{}}var C1=i=>{let t=[];return i.carry&&i.carry>1&&t.push(`\uBE44\uAC70\uB9AC +${Math.round((i.carry-1)*100)}%`),i.acc&&i.acc<1&&t.push(`\uBE57\uB9DE\uC74C \u2212${Math.round((1-i.acc)*100)}%`),i.guide&&i.guide>1&&t.push(`\uAC00\uC774\uB4DC\uC120 +${Math.round((i.guide-1)*100)}%`),i.look&&t.push("\uAFB8\uBBF8\uAE30 (\uB2A5\uB825\uCE58 \uC5C6\uC74C)"),t.join(" \xB7 ")||(i.price?"\uAFB8\uBBF8\uAE30":"\uAE30\uBCF8 \uC7A5\uBE44")};function Wo(i="driver"){let t=Object.keys(ko),e=Dn(i).id,n=wn(`<div class="row-end" style="justify-content:space-between;margin:0 44px 0 0"><h2 style="margin:0">\u{1F6D2} \uC7A5\uBE44 \uC0C1\uC810</h2><b>\u{1F4B0} ${Us().toLocaleString()} P</b></div>
    <p class="small">\uD3EC\uC778\uD2B8\uB294 \uB09A\uC2DC\xB7\uACE8\uD504\xB7\uB2F9\uAD6C\uB97C \uD558\uBA74 \uC870\uAE08\uC529 \uC313\uC5EC\uC694 (\uD558\uB8E8 \uCD5C\uB300 ${30} P, \uC624\uB298 ${_p()} P \uB354 \uBC1B\uC744 \uC218 \uC788\uC5B4\uC694). \uD3EC\uC778\uD2B8\uB294 \uAC8C\uC784 \uC548\uC5D0\uC11C\uB9CC \uC4F0\uACE0, <b>\uD604\uAE08\xB7\uC0C1\uD488\uC73C\uB85C \uBC14\uAFB8\uAC70\uB098 \uB2E4\uB978 \uD68C\uC6D0\uC5D0\uAC8C \uC904 \uC218 \uC5C6\uC5B4\uC694.</b> \uB09A\uC2DC \uC7A5\uBE44\uB294 \uB09A\uC2DC\uD130\uC758 \u{1F392} \uC7A5\uBE44\xB7\uC0C1\uC810\uC5D0\uC11C \uAC19\uC740 \uD3EC\uC778\uD2B8\uB85C \uC0AC\uC694.</p>
    <div class="tabs">${t.map(s=>`<button class="pill${s===i?" on":""}" data-tab="${s}">${ko[s].ko}</button>`).join("")}</div>
    <div class="shop">${ko[i].items.map(s=>{let r=Ml(i,s.id),o=e===s.id;return`<div class="si${o?" on":""}"><div class="ic">${s.icon}</div><div class="nm"><b>${at(s.ko)}</b><span>${C1(s)}</span></div>
        ${r?`<button class="btn ghost" data-eq="${s.id}" ${o?"disabled":""}>${o?"\uC0AC\uC6A9 \uC911":"\uC4F0\uAE30"}</button>`:`<button class="btn" data-buy="${s.id}" ${Us()<s.price?"disabled":""}>\u{1F4B0} ${s.price.toLocaleString()} P</button>`}</div>`}).join("")}</div>`,"wide");n.querySelectorAll("[data-tab]").forEach(s=>s.onclick=()=>Wo(s.dataset.tab)),n.querySelectorAll("[data-eq]").forEach(s=>s.onclick=()=>{wp(i,s.dataset.eq),Wo(i)}),n.querySelectorAll("[data-buy]").forEach(s=>s.onclick=()=>{let r=Dn(i,s.dataset.buy);if(confirm(`${r.ko}\uC744(\uB97C) ${r.price.toLocaleString()} P\uB85C \uC0B4\uAE4C\uC694?`)){if(!Mp(i,r.id))return alert("\uD3EC\uC778\uD2B8\uAC00 \uBAA8\uC790\uB77C\uC694.");Wo(i)}})}var I1=["https://overpass-api.de/api/interpreter","https://overpass.kumi.systems/api/interpreter","https://maps.mail.ru/osm/tools/overpass/api/interpreter"];function L1(i,t,e=1600){let n=`(around:${e},${i},${t})`;return`[out:json][timeout:25];(way${n}[golf~"^(hole|green|fairway|bunker|tee|water_hazard|lateral_water_hazard)$"];way${n}[natural=water];relation${n}[golf~"^(fairway|green|water_hazard|lateral_water_hazard)$"];relation${n}[natural=water];);out geom;`}async function k1(i){let t;for(let e of I1)try{let n=new AbortController,s=setTimeout(()=>n.abort(),3e4),r=await fetch(e,{method:"POST",body:"data="+encodeURIComponent(i),headers:{"content-type":"application/x-www-form-urlencoded"},signal:n.signal});if(clearTimeout(s),!r.ok){t=new Error("overpass "+r.status);continue}return await r.json()}catch(n){t=n}throw t||new Error("overpass")}async function bm(i,t,e){let n=`taeil-lounge-course-${(+i).toFixed(4)},${(+t).toFixed(4)}`;try{let o=JSON.parse(localStorage.getItem(n)||"null");if(o&&o.at>Date.now()-7*864e5&&o.v===2)return o.course}catch{}let s=await k1(L1(i,t)),r=N1(s,+i,+t,e);try{localStorage.setItem(n,JSON.stringify({v:2,at:Date.now(),course:r}))}catch{}return r}var Ju=i=>{let t=0;for(let e=0,n=i.length-1;e<i.length;n=e++)t+=(i[n][0]+i[e][0])*(i[n][1]-i[e][1]);return Math.abs(t/2)},Vr=i=>{let t=0,e=0;for(let n of i)t+=n[0],e+=n[1];return[t/i.length,e/i.length]},vm=i=>i.reduce((t,e,n)=>n?t+Math.hypot(e[0]-i[n-1][0],e[1]-i[n-1][1]):0,0);function D1(i,t,e){let n=1e9,s=0,r=0;for(let o=0;o<e.length-1;o++){let[a,l]=e[o],[c,h]=e[o+1],u=c-a,d=h-l,f=u*u+d*d||1e-9,m=Math.sqrt(f),x=Math.max(0,Math.min(1,((i-a)*u+(t-l)*d)/f)),g=Math.hypot(i-a-u*x,t-l-d*x);g<n&&(n=g,s=r+x*m),r+=m}return[n,s]}function U1(i,t=1.2){let e=[i[0]];for(let n of i){let s=e[e.length-1];Math.hypot(n[0]-s[0],n[1]-s[1])>=t&&e.push(n)}return e.length>=3?e:i}var Sn=i=>Math.round(i*10)/10;function N1(i,t,e,n){let s=111320*Math.cos(t*Math.PI/180),r=110540,o=u=>[(u.lon-e)*s,-(u.lat-t)*r],a=[],l={green:[],fairway:[],bunker:[],tee:[],water:[]};for(let u of i.elements||[]){let d=u.tags||{},f=d.golf==="lateral_water_hazard"||d.golf==="water_hazard"||d.natural==="water"?"water":d.golf,m=[];if(u.type==="way"&&u.geometry&&m.push(u.geometry.map(o)),u.type==="relation")for(let x of u.members||[])x.role!=="inner"&&x.geometry&&m.push(x.geometry.map(o));if(f==="hole")m[0]&&m[0].length>=2&&a.push({path:m[0],ref:parseInt(d.ref,10)||0,par:parseInt(d.par,10)||0,name:d.name||""});else if(l[f])for(let x of m)x.length>=4&&l[f].push(x)}let c=!1;if(a.length<3&&l.green.length&&l.tee.length){c=!0,a.length=0;let u=l.green.map(Vr),d=l.tee.map(Vr),f=new Set;u.forEach((p,M)=>{let v=-1,y=1e9;d.forEach((w,S)=>{if(f.has(S))return;let T=Math.hypot(w[0]-p[0],w[1]-p[1]);T>90&&T<600&&T<y&&(y=T,v=S)}),v>=0&&(f.add(v),a.push({path:[d[v],p],ref:0,par:0,name:"",gi:M}))});let m=[],x=a.slice(),g=x.sort((p,M)=>Math.hypot(...p.path[0])-Math.hypot(...M.path[0])).shift();for(;g;){m.push(g);let p=g.path[g.path.length-1];x.sort((M,v)=>Math.hypot(M.path[0][0]-p[0],M.path[0][1]-p[1])-Math.hypot(v.path[0][0]-p[0],v.path[0][1]-p[1])),g=x.shift()}a.splice(0,a.length,...m)}a.sort((u,d)=>(u.ref||99)-(d.ref||99));let h=[];for(let u of a.slice(0,36)){let d=z1(u,l);d&&h.push(d)}return{name:n||"",holes:h,guessed:c,at:Date.now()}}function z1(i,t){let e=i.path,n=vm(e);if(n<60||n>700)return null;let[s,r]=e[0],o=e[e.length-1],a=Math.atan2(o[1]-r,o[0]-s),l=Math.cos(-a),c=Math.sin(-a),h=([V,z])=>{let G=V-s,F=z-r;return[Sn(G*l-F*c),Sn(G*c+F*l)]},u=e.map(h),d=(V,z=70)=>V.map(G=>G.map(h)).filter(G=>{let[F,K]=Vr(G),[Q,ot]=D1(F,K,u);return Q<z&&ot>-30&&ot<n+50&&F>-40}).map(G=>U1(G)),f=d(t.green,45),m=u[u.length-1],x=null,g=1e9;for(let V of f){let[z,G]=Vr(V),F=Math.hypot(z-m[0],G-m[1]);F<g&&(g=F,x=V)}(!x||g>40)&&(x=Array.from({length:20},(z,G)=>[Sn(m[0]+Math.cos(G/20*6.283)*14),Sn(m[1]+Math.sin(G/20*6.283)*14*.85)]));let[p,M]=Vr(x),v=Math.max(8,Math.min(24,Math.sqrt(Ju(x)/Math.PI))),y=d(t.fairway,80),w=d(t.bunker,60),S=d(t.water,90).filter(V=>Ju(V)>30),T=d(t.tee,30).filter(V=>{let[z]=Vr(V);return z<60});u[u.length-1]=[Sn(p),Sn(M)];let R=vm(u),_=i.par>=3&&i.par<=6?i.par:R<230?3:R<430?4:5,b=y.reduce((V,z)=>V+Ju(z),0),C=y.length?Math.max(20,Math.min(60,b/Math.max(80,R-60))):_===3?0:30,L=(i.ref||R)*2.4,k=[Sn(p+Math.cos(L)*v*.35),Sn(M+Math.sin(L)*v*.35)],D=V=>Math.sin((i.ref||1)*12.9898+V*78.233)*.02;return{par:_,real:!0,ref:i.ref,path:u,fw:Sn(C),green:{x:Sn(p),z:Sn(M),r:Sn(v),slope:[Sn(D(1)*1e3)/1e3,Sn(D(2)*1e3)/1e3],crown:.01},pin:k,bunkers:[],water:[],polys:{green:[x],fairway:y,bunker:w,water:S,tee:T}}}var Xo=null;function ju(){if(!Xo)try{Xo=new(window.AudioContext||window.webkitAudioContext)}catch{return null}return Xo.state==="suspended"&&Xo.resume(),Xo}function Je(i,t,e="sine",n=.2,s=0){let r=ju();if(!r)return;let o=r.createOscillator(),a=r.createGain();o.type=e,o.frequency.setValueAtTime(i,r.currentTime),s&&o.frequency.exponentialRampToValueAtTime(Math.max(30,i+s),r.currentTime+t),a.gain.setValueAtTime(n,r.currentTime),a.gain.exponentialRampToValueAtTime(1e-4,r.currentTime+t),o.connect(a).connect(r.destination),o.start(),o.stop(r.currentTime+t)}var Hl=null;function gi(i,{type:t="bandpass",freq:e=2e3,q:n=1,vol:s=.3,attack:r=.002,at:o=0}={}){let a=ju();if(!a)return;if(!Hl){Hl=a.createBuffer(1,a.sampleRate,a.sampleRate);let d=Hl.getChannelData(0);for(let f=0;f<d.length;f++)d[f]=Math.random()*2-1}let l=a.currentTime+o,c=a.createBufferSource();c.buffer=Hl;let h=a.createBiquadFilter();h.type=t,h.frequency.value=e,h.Q.value=n;let u=a.createGain();u.gain.setValueAtTime(1e-4,l),u.gain.exponentialRampToValueAtTime(s,l+r),u.gain.exponentialRampToValueAtTime(1e-4,l+i),c.connect(h).connect(u).connect(a.destination),c.start(l,Math.random()*.5),c.stop(l+i+.02)}var _m=0,Hs={clack:(i=1)=>{let t=performance.now();t-_m<25||(_m=t,i=Math.min(1,Math.max(.08,i)),gi(.05,{freq:3800,q:2.5,vol:.9*i}),Je(2350+Math.random()*300,.06,"sine",.35*i),Je(4200,.03,"triangle",.12*i))},cue:(i=1)=>{i=Math.min(1,Math.max(.15,i)),gi(.04,{freq:1600,q:1.4,vol:.7*i}),Je(780,.07,"triangle",.3*i,-200)},cushion:(i=1)=>{i=Math.min(1,Math.max(.05,i)),Je(150,.12,"sine",.4*i,-60),gi(.06,{type:"lowpass",freq:600,vol:.35*i})},pocket:()=>{Je(110,.25,"sine",.35,-40),gi(.18,{type:"lowpass",freq:400,vol:.3,at:.03}),gi(.05,{freq:2500,vol:.15,at:.12})},chalk:()=>gi(.18,{type:"highpass",freq:3e3,vol:.12,attack:.02}),splash:(i=1)=>{gi(.35*i+.1,{type:"lowpass",freq:1200,vol:.35*i}),gi(.15,{freq:3e3,q:.7,vol:.12*i,at:.02})},reel:()=>{for(let i=0;i<3;i++)gi(.012,{freq:4500,q:4,vol:.12,at:i*.03})},bell:()=>{Je(2637,.4,"sine",.15),setTimeout(()=>Je(2637,.4,"sine",.12),140)},snap:()=>{gi(.08,{type:"highpass",freq:2500,vol:.5}),Je(1200,.15,"square",.08,-900)},coin:()=>{Je(1568,.08,"square",.06),setTimeout(()=>Je(2093,.2,"square",.06),70)},unlock:ju,click:(i=.5)=>Je(900,.06,"triangle",.25*i),plop:()=>Je(500,.18,"sine",.25,-350),whoosh:()=>Je(300,.35,"sawtooth",.04,500),chime:()=>{Je(784,.25,"triangle",.18),setTimeout(()=>Je(1047,.35,"triangle",.18),120),setTimeout(()=>Je(1319,.5,"triangle",.15),240)},pop:()=>Je(660,.08,"sine",.12,200)};var xt=i=>document.querySelector(i),xi=new URLSearchParams(location.search),cs=(()=>{let i=/^(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)$/.exec(xi.get("course")||"");return i?{lat:+i[1],lng:+i[2],name:(xi.get("cname")||"").slice(0,40)}:null})();function F1(){let i=cs?hm(cs.lat,cs.lng):xi.get("room")||"hub",t=cm(/^(hub|dong-[0-9A-Za-z가-힣_-]{1,40}|meet-\d{1,9}|club-\d{1,9}|course-m?\d{1,6}_m?\d{1,6})$/.test(i)?i:"hub");return{...hp,id:t.id,kind:t.kind,name:t.name,country:"KR"}}var hs=F1(),B1=pt.touch||/Android|iPhone|iPad/i.test(navigator.userAgent),Mm={low:{shadows:!1,shadowMap:512,trees:90,flowers:200,maxDpr:1,reflect:!1,grass:0,grassR:0},mid:{shadows:!0,shadowMap:1024,trees:160,flowers:400,maxDpr:1.5,reflect:!1,grass:18e3,grassR:11},high:{shadows:!0,shadowMap:2048,trees:240,flowers:700,maxDpr:2,reflect:!0,grass:4e4,grassR:16}},O1=xi.get("q")||location.hash.slice(1)||"mid",Ws={...Mm[O1]||Mm.mid};for(let i of["grass","shadows","reflect","trees"])xi.has(i)&&(Ws[i]=i==="shadows"||i==="reflect"?xi.get(i)!=="0":+xi.get(i));var Cm=xt("#game"),Se=new qa({canvas:Cm,antialias:!B1,powerPreference:"high-performance"});Se.outputColorSpace=me;Se.toneMapping=su;Se.toneMappingExposure=.62;Se.shadowMap.enabled=Ws.shadows;Se.shadowMap.type=iu;var as=1;function ql(){Se.setPixelRatio(Math.min(devicePixelRatio,Ws.maxDpr)*as),Se.setSize(innerWidth,innerHeight,!1),rn.aspect=innerWidth/innerHeight,rn.updateProjectionMatrix()}var yi=new Sr,rn=new Ge(55,innerWidth/innerHeight,.05,1200);addEventListener("resize",ql);ql();var ri=new xl(yi,hs,Ws,Se),Zo=Ws.grass?new Ul(yi,ri,{count:Ws.grass,radius:Ws.grassR,tint:ri.biome.tint}):null;Zo&&ri.noReflect&&ri.noReflect.push(Zo.mesh);var ls=K1(),ae={pos:new P,yaw:0,speed:0},fn=null,wm={hub:[0,0,13],golf:[44,0,3],fishing:[-35,0,2.5]}[hs.type]||[0,0,6];ae.pos.set(wm[0]+(Math.random()-.5)*3,0,wm[2]+(Math.random()-.5)*3);var Nn={yaw:Math.PI,pitch:.38,dist:7.5},on={pos:new P,look:new P,up:new P(0,1,0)},Xl=new P,Pm={show({title:i,help:t,power:e,powerLabel:n,tension:s,extra:r=[]}){xt("#hud").hidden=!1,xt("#hudTitle").textContent=i,xt("#hudHelp").textContent=t,xt("#hudInfo").textContent="",xt("#powerBar").hidden=!e,xt("#tensionBar").hidden=!0,xt("#btnPower").hidden=!e,xt("#btnPower").textContent=n||U("power");let o=xt("#hudRow");o.innerHTML="";for(let[l,c]of r){let h=document.createElement("button");h.className="btn ghost",h.textContent=l,h.onclick=c,o.append(h)}let a=document.createElement("button");a.className="btn",a.textContent=U("exit"),a.onclick=()=>Wr("hub"),o.append(a),this.tensionOn=s},hide(){xt("#hud").hidden=!0,xt("#btnPower").hidden=!0},info(i){xt("#hudInfo").textContent=i},power(i,t){xt("#powerBar i").style.width=`${Math.round(i*100)}%`,t&&(xt("#btnPower").textContent=t)},tension(i,t){let e=xt("#tensionBar");if(i===null){e.hidden=!0,xt("#powerBar").hidden=!1;return}e.hidden=!1,xt("#powerBar").hidden=!0,e.querySelector("i").style.width=`${Math.min(100,i*100)}%`,e.classList.toggle("hot",i>.7),this.info(`${U("tension")} ${Math.round(i*100)}% \xB7 ${U("distance")} ${t.toFixed(1)}m`)}},Sm=0;function Im(i){let t=xt("#toast");t.textContent=i,t.classList.add("on"),clearTimeout(Sm),Sm=setTimeout(()=>t.classList.remove("on"),2400)}var Fn=new Map,Yo=new Map,Ie;function Em(i){var s;if(i.id===Ie.id||Fn.has(i.id))return;let t=new Lo({name:i.name,color:i.color,flag:""});yi.add(t.root),t.root.userData.hiddenByBlock=Bs(i.uid);let e=new nt(new Ce(.06,10,8),new ye({color:16777215,roughness:.35,emissive:i.color,emissiveIntensity:.15}));e.visible=!1,yi.add(e);let n={info:i,avatar:t,target:new P,yaw:0,ball:e,speed:0};(s=i.s)!=null&&s.p&&(n.target.fromArray(i.s.p),t.root.position.copy(n.target)),Fn.set(i.id,n)}function H1(i){let t=Fn.get(i);t&&(yi.remove(t.avatar.root,t.ball),t.avatar.dispose(),Fn.delete(i))}function Lm(i){var t;return i===Ie.id?ls.name:(t=Fn.get(i))==null?void 0:t.info.name}function Wl(){xt("#statusText").textContent=Ie.offline?U("offline"):`${Fn.size+1} ${U("players")}`,xt("#status").classList.toggle("off",Ie.offline)}var sd={scene:yi,world:ri,venue:hs,player:ae,camTarget:on,hud:Pm,toast:Im,audio:Hs,input:pt,get avatar(){return fn},get net(){return Ie},remoteName:Lm,camera:rn,exit:()=>Wr("hub"),snap:()=>{Zl=!0},resetView:()=>Yl()};function V1(i){var t,e,n,s,r;switch(i.t){case"welcome":for(let o of i.players)Em(o);for(let o of i.parties||[])(t=Qu(o.game))==null||t.onInfo(o);Wl(),i.offline?Tn("\u{1F310} \uB77C\uC6B4\uC9C0 \uC11C\uBC84\uC5D0 \uC5F0\uACB0\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694 \xB7 \uD63C\uC790 \uC5F0\uC2B5 \uBAA8\uB4DC (\uAC8C\uC2A4\uD2B8\uC640 \uAC19\uC774 \uD558\uAE30\uB294 \uB3FC\uC694)"):(id=!!((e=i.me)!=null&&e.staff),xt("#btnAdmin").hidden=!id,Tn(`${hs.name}\uC5D0 \uB4E4\uC5B4\uC654\uC5B4\uC694. \uC774\uB984\uC744 \uB204\uB974\uBA74 \uCC28\uB2E8\xB7\uC2E0\uACE0\uD560 \uC218 \uC788\uC5B4\uC694.`));break;case"join":Em(i.p),Wl(),Tn(U("joined",{name:i.p.name}));break;case"leave":{let o=Lm(i.id);(n=document.querySelector(`.inv[data-from="${i.id}"]`))==null||n.remove(),H1(i.id),Wl(),o&&Tn(U("left",{name:o}));break}case"plang":{let o=Fn.get(i.id);o&&(o.info.lang=i.lang);break}case"states":for(let[o,a]of i.s){let l=Fn.get(o);!l||!a||(l.target.fromArray(a.p),l.yaw=a.r,l.activity=a.a,a.b?(l.ball.visible=!0,l.ball.position.set(a.b[0],jt.green.y+.06,a.b[1])):l.ball.visible=!1)}break;case"chat":G1(i);break;case"chat_tr":{let o=Yo.get(i.id);o&&(o.tr=i.tr,rd(o));break}case"event":W1(i);break;case"sys":Tn(i.text||(i.key==="reported"?"\uC2E0\uACE0\uD588\uC5B4\uC694. \uC9C1\uC6D0\uC774 \uD655\uC778 \uD6C4 \uC870\uCE58\uD560\uAC8C\uC694.":U(i.key)));break;case"kicked":alert("\uC6B4\uC601 \uC815\uCC45 \uC704\uBC18\uC73C\uB85C \uB77C\uC6B4\uC9C0\uC5D0\uC11C \uB098\uAC00\uAC8C \uB418\uC5C8\uC5B4\uC694. \uBB38\uC758\uB294 \uD0DC\uC77C\uACE8\uD504 \uCE74\uCE74\uC624\uD1A1 \uCC44\uB110\uB85C \uD574 \uC8FC\uC138\uC694."),qo();break;case"party":(s=Qu(i.game))==null||s.onInfo(i);break;case"party_msg":(r=Qu(i.game))==null||r.onMsg(i);break;case"group":$1(i.g);break;case"ginv":q1(i);break;case"gplay":Tn(`\u{1F389} ${i.by}\uB2D8\uC774 \uD30C\uD2F0 \uAC8C\uC784\uC744 \uC2DC\uC791\uD588\uC5B4\uC694.`),Bi="party",od(),Kl(i.game);break}}var os=xt("#log");function km(i){let t=os.scrollTop+os.clientHeight>=os.scrollHeight-30;for(os.append(i);os.children.length>80;)os.firstChild.remove();t&&(os.scrollTop=os.scrollHeight)}function Tn(i){let t=document.createElement("div");t.className="msg sys",t.textContent=i,km(t)}function G1(i){var n;if(i.from!==Ie.id&&Bs((n=Fn.get(i.from))==null?void 0:n.info.uid))return;let t=document.createElement("div");t.className="msg";let e={m:i,el:t,tr:null,showOrig:!1};Yo.set(i.id,e),Yo.size>120&&Yo.delete(Yo.keys().next().value),rd(e),km(t)}function rd(i){var h;let{m:t}=i,e=t.from===Ie.id,n=!e&&t.lang!==hn(),s=n?(h=i.tr)==null?void 0:h[hn()]:null,r=s&&!i.showOrig?s:t.text,o=Fn.get(t.from),a=o!=null&&o.info.staff?"\u{1F3F7}":"";i.el.innerHTML="";let l=document.createElement("b");if(l.textContent=`${a} ${t.name}: `,l.style.color=e?ls.color:(o==null?void 0:o.info.color)||"#555",l.style.filter="brightness(0.75)",!e&&o&&(l.className="who",l.title="\uCC28\uB2E8\xB7\uC2E0\uACE0",l.onclick=()=>gm({...o.info,id:t.from},Ie,id)),t.party){let u=document.createElement("span");u.className="ptag",u.textContent="\uD30C\uD2F0",i.el.append(u),i.el.classList.add("pmsg")}if(i.el.append(l,document.createTextNode(r)),n){let u=document.createElement("span");u.className="tag",u.textContent=s?i.showOrig?U("translated"):`${t.lang.toUpperCase()} \u2192 ${U("showOrig")}`:"\u2026",u.onclick=()=>{i.showOrig=!i.showOrig,rd(i)},i.el.append(u)}let c=e?fn:o==null?void 0:o.avatar;e||Hs.pop(),c&&(s||!n||!i.bubbled)&&(c.say(r,performance.now()),i.bubbled=!0)}function W1(i){let t=i.e||{},e="";t.type==="catch"?e=`\u{1F41F} ${U("evCatch",{name:i.name,fish:Ni(t.fish),kg:t.kg})}`:t.type==="sink"?e=`\u26F3 ${U("evSink",{name:i.name,hole:t.hole,n:t.n})}`:t.type==="pot"&&(e=`\u{1F3B1} ${U("evPot",{name:i.name,n:t.n})}`),e&&Tn(e)}xt("#chatForm").addEventListener("submit",i=>{i.preventDefault();let t=xt("#chatIn").value.trim();t&&(Bi==="party"&&En?Ie.send({t:"gchat",text:t}):Ie.chat(t),xt("#chatIn").value="",pt.touch&&xt("#chatIn").blur())});xt("#chatToggle").onclick=()=>{xt("#chat").classList.toggle("collapsed"),xt("#chat").classList.toggle("open")};addEventListener("keydown",i=>{i.key==="Enter"&&document.activeElement!==xt("#chatIn")&&!xt("#top").hidden&&(i.preventDefault(),xt("#chatIn").focus()),i.key==="Escape"&&(document.activeElement===xt("#chatIn")?xt("#chatIn").blur():Fe!=="hub"&&Wr("hub"))});var Gr=new Al(sd),Dm=new kl(sd),Ko=new Dl(sd),zn={golf:Gr,fishing:Dm,billiards:Ko},En=null,Bi="all",Qu=i=>{let t=zn[String(i).split("~")[0]];return t!=null&&t.party&&t.party.key===i?t.party:null},$l=i=>String(i??"").replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]);function od(){En||(Bi="all");let i=xt("#chatTo");i.hidden=!En,i.textContent=Bi==="party"?"\u{1F389} \uD30C\uD2F0":"\uC804\uCCB4",i.classList.toggle("on",Bi==="party"),xt("#chatIn").placeholder=Bi==="party"?"\uD30C\uD2F0\uC6D0\uC5D0\uAC8C\uB9CC \uBCF4\uB0B4\uAE30":"\uBA54\uC2DC\uC9C0 \uC785\uB825 \xB7 \uC774\uB984\uC744 \uB204\uB974\uBA74 \uD30C\uD2F0 \uCD08\uB300\xB7\uCC28\uB2E8\xB7\uC2E0\uACE0"}function $1(i){let t=En;En=i;for(let[n,s]of Object.entries(zn))s.party&&s.party.setKey(i?`${n}~${i.id}`:n,Fe===n);i&&!t&&(Bi="party",Tn("\u{1F389} \uD30C\uD2F0\uAC00 \uB9CC\uB4E4\uC5B4\uC84C\uC5B4\uC694. \uCC44\uD305 \uC606 [\u{1F389} \uD30C\uD2F0]\uB97C \uB204\uB974\uBA74 \uC804\uCCB4/\uD30C\uD2F0 \uCC44\uD305\uC744 \uBC14\uAFD4\uC694.")),od();let e=i?i.members.length:0;xt("#btnParty").classList.toggle("on",!!i),xt("#btnParty").querySelector(".lb").textContent=i?`\uD30C\uD2F0 ${e}\uBA85`:"\uD30C\uD2F0",!xt("#sheet").hidden&&xt("#sheet .pt-panel")&&Um()}function q1(i){var s;let t=xt("#invites");(s=t.querySelector(`[data-from="${i.from}"]`))==null||s.remove();let e=document.createElement("div");e.className="card inv",e.dataset.from=i.from,e.innerHTML=`<b>\u{1F389} ${$l(i.name)}</b>\uB2D8\uC774 \uD30C\uD2F0\uC5D0 \uCD08\uB300\uD588\uC5B4\uC694${i.n>1?` (\uC9C0\uAE08 ${i.n}\uBA85)`:""}<div class="row"><button class="btn green" data-ok="1">\uC218\uB77D</button><button class="btn ghost" data-ok="0">\uAC70\uC808</button></div>`;let n=r=>{Ie.send({t:"gans",from:i.from,ok:r}),e.remove()};e.querySelectorAll("[data-ok]").forEach(r=>r.onclick=()=>n(r.dataset.ok==="1")),t.append(e),Hs.pop(),setTimeout(()=>{e.isConnected&&e.remove()},6e4)}function Um(){let i=Ie==null?void 0:Ie.id,t=[...Fn.entries()].filter(([,o])=>!Bs(o.info.uid)).map(([o,a])=>({id:o,name:a.info.name,dong:a.info.dong})),e=o=>En&&En.members.some(a=>a.id===o),n=En&&En.leader===i,s=wn(`<div class="pt-panel">
    <h2>\u{1F389} \uD30C\uD2F0</h2>
    <p class="small">\uAC19\uC774 \uB180 \uC0AC\uB78C\uC744 \uCD08\uB300\uD558\uC138\uC694. \uC0C1\uB300\uAC00 \uC218\uB77D\uD558\uBA74 \uD30C\uD2F0\uAC00 \uB3FC\uC694. \uD30C\uD2F0\uC6D0\uB07C\uB9AC\uB9CC \uBCF4\uB294 \uCC44\uD305\uC774 \uC0DD\uAE30\uACE0, \uD30C\uD2F0\uC7A5\uC774 \uAC8C\uC784\uC744 \uACE0\uB974\uBA74 \uD30C\uD2F0\uC6D0\uC774 \uD55C \uD300\uC73C\uB85C \uAC19\uC774 \uB4E4\uC5B4\uAC00\uC694. (\uCD5C\uB300 8\uBA85)</p>
    ${En?`<h3>\uB0B4 \uD30C\uD2F0 ${En.members.length}/8</h3><div class="col">${En.members.map(o=>`<div class="cl-m"><b>${o.id===En.leader?"\u{1F451} ":""}${$l(o.name)}${o.id===i?" (\uB098)":""}</b>${n&&o.id!==i?`<span><button class="btn ghost sm" data-lead="${o.id}">\uD30C\uD2F0\uC7A5 \uB118\uAE30\uAE30</button> <button class="btn ghost sm" data-kick="${o.id}">\uB0B4\uBCF4\uB0B4\uAE30</button></span>`:""}</div>`).join("")}</div>
      ${n?'<h3>\uAC19\uC774 \uAC8C\uC784\uD558\uAE30</h3><div class="row-end" style="justify-content:flex-start"><button class="btn" data-play="golf">\u26F3 \uD30C\uD2F0 \uC2A4\uD06C\uB9B0\uACE8\uD504</button><button class="btn" data-play="billiards">\u{1F3B1} \uD30C\uD2F0 \uB2F9\uAD6C</button></div>':'<p class="small">\uD30C\uD2F0\uC7A5\uC774 \uAC8C\uC784\uC744 \uACE0\uB974\uBA74 \uB2E4 \uAC19\uC774 \uB4E4\uC5B4\uAC00\uC694.</p>'}
      <div class="row-end"><button class="btn ghost" data-a="leave">\uD30C\uD2F0 \uB098\uAC00\uAE30</button></div>`:""}
    <h3>\uC774 \uBC29\uC5D0 \uC788\uB294 \uC0AC\uB78C ${t.length}\uBA85</h3>
    <div class="col">${t.filter(o=>!e(o.id)).map(o=>`<div class="cl-m"><b>${$l(o.name)}</b><span class="small">${$l(o.dong||"")}</span><span><button class="btn green sm" data-inv="${o.id}">\uCD08\uB300\uD558\uAE30</button></span></div>`).join("")||'<p class="empty">\uCD08\uB300\uD560 \uC0AC\uB78C\uC774 \uC544\uC9C1 \uC5C6\uC5B4\uC694.</p>'}</div></div>`,"wide");s.querySelectorAll("[data-inv]").forEach(o=>o.onclick=()=>{Ie.send({t:"ginv",id:+o.dataset.inv}),o.disabled=!0,o.textContent="\uBCF4\uB0C8\uC5B4\uC694"}),s.querySelectorAll("[data-kick]").forEach(o=>o.onclick=()=>{confirm("\uD30C\uD2F0\uC5D0\uC11C \uB0B4\uBCF4\uB0BC\uAE4C\uC694?")&&Ie.send({t:"gkick",id:+o.dataset.kick})}),s.querySelectorAll("[data-lead]").forEach(o=>o.onclick=()=>Ie.send({t:"glead",id:+o.dataset.lead})),s.querySelectorAll("[data-play]").forEach(o=>o.onclick=()=>{Ie.send({t:"gplay",game:o.dataset.play}),_n()});let r=s.querySelector("[data-a=leave]");r&&(r.onclick=()=>{Ie.send({t:"gleave"}),_n()})}var Fe="hub",dn={yaw:0,pitch:0,zoom:1},Fi={x:0,y:0,z:0};function Yl(){dn.yaw=dn.pitch=0,dn.zoom=1}(function(){let t=document.createElement("div");t.id="viewPad",t.hidden=!0,t.innerHTML=`<button data-v="zi" title="zoom in (O)">\uFF0B</button><button data-v="u" title="up (I)">\u25B2</button><button data-v="zo" title="zoom out (U)">\uFF0D</button>
    <button data-v="l" title="left (J)">\u25C0</button><button data-v="reset" title="reset (H)">\u27F2</button><button data-v="r" title="right (L)">\u25B6</button>
    <span></span><button data-v="d" title="down (K)">\u25BC</button><span></span>`,document.body.appendChild(t);let e=(n,s)=>{let r=s?1:0;n==="l"&&(Fi.x=r),n==="r"&&(Fi.x=-r),n==="u"&&(Fi.y=r),n==="d"&&(Fi.y=-r),n==="zi"&&(Fi.z=-r),n==="zo"&&(Fi.z=r)};t.querySelectorAll("button").forEach(n=>{let s=n.dataset.v;n.addEventListener("pointerdown",o=>{if(o.preventDefault(),s==="reset"){Yl();return}n.setPointerCapture(o.pointerId),e(s,!0)});let r=()=>e(s,!1);n.addEventListener("pointerup",r),n.addEventListener("pointercancel",r),n.addEventListener("lostpointercapture",r)}),addEventListener("keydown",n=>{var s;n.code==="KeyH"&&Fe!=="hub"&&!/INPUT|TEXTAREA|SELECT/.test((s=document.activeElement)==null?void 0:s.tagName)&&Yl()})})();var Vs=new P,td=new P,Gs=new P,Vl=new Re,Tm=new Re,Am=new P(0,1,0),Rm=document.getElementById("viewPad");function X1(i){var c;let t=((c=zn[Fe])==null?void 0:c.lobby)&&!zn[Fe].lobby.el.hidden;Rm.hidden!==!!t&&(Rm.hidden=!!t);let e=gp(),n=pt.keys,s=(h,u)=>(n.has(h)?1:0)-(n.has(u)?1:0);if(dn.yaw+=-e.x*.006+(s("KeyJ","KeyL")+Fi.x)*1.5*i,dn.pitch+=e.y*.004+(s("KeyI","KeyK")+Fi.y)*.9*i,dn.zoom=Math.max(.3,Math.min(3,dn.zoom*e.zoom*Math.pow(2,(s("KeyO","KeyU")+Fi.z)*i))),!dn.yaw&&!dn.pitch&&dn.zoom===1)return;let r=zn[Fe],o=r!=null&&r.viewPivot?r.viewPivot():on.look;Vs.copy(on.pos).sub(o),td.copy(on.look).sub(o);let a=Vs.length();if(a<1e-4)return;let l=Math.asin(Math.max(-1,Math.min(1,Vs.y/a)));dn.pitch=Math.max(.06-l,Math.min(1.45-l,dn.pitch)),Gs.subVectors(on.look,on.pos).setY(0),Gs.lengthSq()<1e-8&&Gs.set(Vs.x,0,Vs.z).negate(),Gs.lengthSq()<1e-8&&Gs.set(0,0,-1),Gs.normalize().cross(Am).normalize(),Vl.setFromAxisAngle(Gs,-dn.pitch),Tm.setFromAxisAngle(Am,dn.yaw),Vl.premultiply(Tm),Vs.applyQuaternion(Vl).multiplyScalar(dn.zoom),td.applyQuaternion(Vl),on.pos.copy(o).add(Vs),on.look.copy(o).add(td),on.up.set(0,1,0)}var Zl=!1,Oi=null;function Wr(i){var t;if(i!==Fe)if(Zl=!0,(t=zn[Fe])==null||t.exit(),Fe=i,Yl(),document.body.classList.toggle("ingame",i!=="hub"),document.body.dataset.mode=i,xt("#viewPad").hidden=i==="hub",i==="hub"){Pm.hide(),xt("#joy").hidden=!pt.touch;let e=Po.find(n=>n.id===(Oi==null?void 0:Oi.id))||Po[0];e.id==="golf"&&ae.pos.set(e.x-3,0,e.z+1),e.id==="fishing"&&ae.pos.set(e.x+4,0,0),e.id==="billiards"&&ae.pos.set(e.x,0,e.z+2.5),Nn.yaw=Math.atan2(-(rn.position.x-ae.pos.x),-(rn.position.z-ae.pos.z))+Math.PI}else xt("#btnAction").hidden=!0,xt("#joy").hidden=!0,zn[i].enter()}ks("action",()=>{Fe==="hub"&&Oi&&(Hs.unlock(),Wr(Oi.id))});ks("powerDown",()=>{var i;Hs.unlock(),(i=zn[Fe])==null||i.powerDown()});ks("powerUp",()=>{var i;return(i=zn[Fe])==null?void 0:i.powerUp()});var nd=new P;function Y1(i){let t=es();Nn.yaw-=t.x*.006,Nn.pitch=Math.max(.08,Math.min(1.1,Nn.pitch+t.y*.004));let e=mp(),n=e.run?6:3.6,s=-Math.sin(Nn.yaw),r=-Math.cos(Nn.yaw),o=-r,a=s,l=s*e.y+o*e.x,c=r*e.y+a*e.x,h=Math.hypot(l,c);if(ae.speed=h*n,h>.01){ae.pos.x+=l/Math.max(1,h)*n*i,ae.pos.z+=c/Math.max(1,h)*n*i;let f=Math.atan2(l,c)-ae.yaw;f=Math.atan2(Math.sin(f),Math.cos(f)),ae.yaw+=f*Math.min(1,i*12)}ri.resolve(ae.pos);let u=null;for(let d of Po)Math.hypot(ae.pos.x-d.x,ae.pos.z-d.z)<d.r&&(u=d);if(u!==Oi){Oi=u;let d=xt("#btnAction");d.hidden=!u,u&&(d.textContent=`${{golf:"\u26F3",fishing:"\u{1F3A3}",billiards:"\u{1F3B1}"}[u.id]} ${U(u.id)} ${U("play")}${pt.touch?"":" (E)"}`)}nd.set(Math.sin(Nn.yaw)*Math.cos(Nn.pitch),Math.sin(Nn.pitch),Math.cos(Nn.yaw)*Math.cos(Nn.pitch)).multiplyScalar(Nn.dist),on.pos.copy(ae.pos).add(nd),on.pos.y=Math.max(on.pos.y,.6),on.look.copy(ae.pos).add(new P(0,1.3,0))}var ad=new cl,Gl=0,ed=0,Z1=xi.has("fps");function ld(){var s,r,o,a;let i=Math.min(ad.getDelta(),.05),t=performance.now(),e=t/1e3;if(fn){Fe==="hub"?Y1(i):(zn[Fe].update(i),X1(i)),ae.pos.y=ri.groundHeight(ae.pos.x,ae.pos.z),fn.root.position.copy(ae.pos),fn.root.rotation.y=ae.yaw,fn.root.visible=!((s=zn[Fe])!=null&&s.hideAvatar),fn.tag&&(fn.tag.visible=Fe==="hub"),fn.animate(i,ae.speed,t);let l=1-Math.pow(5e-4,i),c=Zl?1:Fe==="hub"?Math.min(1,l*2):l;Zl=!1,rn.position.lerp(on.pos,c),Xl.lerp(on.look,c),rn.up.copy(on.up),rn.lookAt(Xl),ri.follow(((r=zn[Fe])==null?void 0:r.focus)||ae.pos),ri.sky.position.set(rn.position.x,0,rn.position.z),Zo==null||Zo.update(i,ae.pos),Ie.state({p:[+ae.pos.x.toFixed(2),+ae.pos.y.toFixed(2),+ae.pos.z.toFixed(2)],r:+ae.yaw.toFixed(2),a:Fe,b:Gr.netState()},t)}(o=Ko.tick)==null||o.call(Ko,i);for(let l of Fn.values()){let c=l.avatar.root.position,h=nd.copy(c),u=h.x,d=h.z;c.lerp(l.target,1-Math.pow(1e-4,i)),c.distanceToSquared(l.target)>400&&c.copy(l.target);let f=Math.hypot(c.x-u,c.z-d)/Math.max(i,.001);l.speed+=(f-l.speed)*Math.min(1,i*8);let m=l.yaw-l.avatar.root.rotation.y;m=Math.atan2(Math.sin(m),Math.cos(m)),l.avatar.root.rotation.y+=m*Math.min(1,i*10),l.avatar.root.visible=!l.avatar.root.userData.hiddenByBlock,l.avatar.animate(i,l.speed,t),l.avatar.curveFix(rn.position,Ps.value)}fn==null||fn.curveFix(rn.position,Ps.value),ri.update(e,i),Se.render(yi,rn);let n=(a=zn[Fe])==null?void 0:a.pip;if(n!=null&&n.on&&n.el&&!n.el.hidden){let l=n.el.getBoundingClientRect(),c=Se.domElement,h=c.clientHeight;if(l.width>10&&l.height>10){n.cam.aspect=l.width/l.height,n.cam.updateProjectionMatrix(),Se.setScissorTest(!0),Se.setScissor(l.left,h-l.bottom,l.width,l.height),Se.setViewport(l.left,h-l.bottom,l.width,l.height);let u=Se.shadowMap.autoUpdate;Se.shadowMap.autoUpdate=!1,Se.render(yi,n.cam),Se.shadowMap.autoUpdate=u,Se.setScissorTest(!1),Se.setViewport(0,0,c.clientWidth,h)}}if(Gl+=i,ed++,Gl>2){let l=ed/Gl;l<45&&as>.6?(as=Math.max(.6,as-.1),ql()):l>58&&as<1&&(as=Math.min(1,as+.05),ql()),Z1&&(xt("#fps").textContent=`${l.toFixed(0)} fps \xB7 x${as.toFixed(2)} \xB7 ${Se.info.render.calls} calls`),Gl=0,ed=0}}Se.setAnimationLoop(ld);document.addEventListener("visibilitychange",()=>{Se.setAnimationLoop(document.hidden?null:ld),ad.getDelta()});function K1(){return{name:"",lang:"ko",color:lp.shirts[0],country:""}}function Nm(){document.documentElement.lang=hn(),document.querySelectorAll("[data-i18n]").forEach(i=>{i.textContent=U(i.dataset.i18n)}),xt("#chatIn").placeholder="\uBA54\uC2DC\uC9C0 \uC785\uB825 \xB7 \uC774\uB984\uC744 \uB204\uB974\uBA74 \uD30C\uD2F0 \uCD08\uB300\xB7\uCC28\uB2E8\xB7\uC2E0\uACE0",xt("#venueName").textContent=hs.name,Ie&&Wl(),Oi=null}yp("ko");Nm();rn.position.set(14,7,14);Xl.set(0,1,0);rn.lookAt(Xl);var id=!1;function J1(i){ls.name=i.nick,ls.color=i.color||ls.color,Hs.unlock(),xt("#login").hidden=!0,xt("#top").hidden=!1,xt("#chat").hidden=!1,xt("#joy").hidden=!pt.touch,pt.touch&&xt("#chat").classList.add("collapsed"),fn=new Lo({name:ls.name,color:ls.color,flag:""}),yi.add(fn.root),Nn.yaw=Math.atan2(ae.pos.x,ae.pos.z),Ie=new yl({message:V1,disconnected:e=>{if(xt("#status").classList.add("off"),e===4e3){Tn("\u26A0\uFE0F \uB2E4\uB978 \uCC3D\uC5D0\uC11C \uB77C\uC6B4\uC9C0\uC5D0 \uB4E4\uC5B4\uC640\uC11C \uC5EC\uAE30\uB294 \uC5F0\uACB0\uC744 \uB04A\uC5C8\uC5B4\uC694.");return}e!==4003&&(Tn("\u26A0\uFE0F \uC5F0\uACB0\uC774 \uB04A\uACBC\uC5B4\uC694. \uB2E4\uC2DC \uC5F0\uACB0\uD558\uB294 \uC911\u2026"),setTimeout(()=>location.reload(),3e3))}}),Ie.connect(ls,hs,Xu,Yt.token),Nm();let t=xi.get("play");if(cs){j1();return}t&&setTimeout(()=>Kl(t),300)}async function j1(){let i=cs.name||"\uC774 \uACE8\uD504\uC7A5";Tn(`\u26F3 ${i} \uCF54\uC2A4 \uBAA8\uC591\uC744 \uBD88\uB7EC\uC624\uB294 \uC911\u2026`);let t=null;try{t=await bm(cs.lat,cs.lng,cs.name)}catch(e){console.warn(e)}t&&t.holes.length?(ze.splice(0,ze.length,...t.holes),Gr.course.index=-1,Gr.mapBg=null,Gr.buildUI(),Tn(`\u26F3 ${i} ${t.holes.length}\uD640\uC744 \uC2E4\uC81C \uBAA8\uC591\uC73C\uB85C \uB9CC\uB4E4\uC5C8\uC5B4\uC694${t.guessed?" (\uD640 \uC21C\uC11C\uB294 \uB300\uB7B5\uC774\uC5D0\uC694)":""}. \uCF54\uC2A4 \uBAA8\uC591 \xA9 OpenStreetMap \uAE30\uC5EC\uC790`),t.holes.length<9&&Tn("\uC9C0\uB3C4\uC5D0 \uC544\uC9C1 \uC77C\uBD80 \uD640\uB9CC \uADF8\uB824\uC838 \uC788\uB294 \uACE8\uD504\uC7A5\uC774\uC5D0\uC694.")):Tn(t?"\uC774 \uACE8\uD504\uC7A5\uC740 \uC9C0\uB3C4\uC5D0 \uD640 \uBAA8\uC591\uC774 \uC544\uC9C1 \uC5C6\uC5B4\uC11C \uAE30\uBCF8 \uC5F0\uC2B5 \uCF54\uC2A4\uB85C \uCCD0\uC694.":"\uCF54\uC2A4 \uBAA8\uC591\uC744 \uBC1B\uC9C0 \uBABB\uD588\uC5B4\uC694 (\uC778\uD130\uB137 \uD655\uC778). \uAE30\uBCF8 \uC5F0\uC2B5 \uCF54\uC2A4\uB85C \uCCD0\uC694."),Kl("golf")}function Kl(i){let t=Po.find(e=>e.id===i);!t||!fn||(Fe!=="hub"&&Wr("hub"),ae.pos.set(t.x,0,t.z),Oi=t,Wr(i))}xm(Im);lm(J1);pp(Cm);xt("#btnRooms").onclick=()=>ym(hs.id);xt("#btnMeet").onclick=()=>si();xt("#btnParty").onclick=()=>Um();xt("#chatTo").onclick=()=>{En&&(Bi=Bi==="party"?"all":"party",od())};xt("#btnMe").onclick=()=>am();xt("#btnShop").onclick=()=>Wo();xt("#btnAdmin").onclick=()=>Go();xt("#btnExit").onclick=()=>qo();addEventListener("lounge-block",()=>{for(let i of Fn.values())i.avatar.root.userData.hiddenByBlock=Bs(i.info.uid)});window.addEventListener("message",i=>{let t=i.data;t&&t.lounge==="pause"&&Se.setAnimationLoop(null),t&&t.lounge==="resume"&&(ad.getDelta(),Se.setAnimationLoop(ld))});window.TaeilLounge={play:Kl,get venue(){return hs}};xi.has("debug")&&(window.TaeilLounge._dbg={golf:Gr,fishing:Dm,billiards:Ko,player:ae,world:ri,camera:rn,scene:yi});})();

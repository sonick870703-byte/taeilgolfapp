(()=>{var Ch="170";var Dp=0,zu=1,kp=2;var ef=1,Ph=2,fi=3,jn=0,Ke=1,Te=2,Oi=0,Qs=1,Fu=2,Bu=3,Ou=4,Up=5,cs=100,Np=101,zp=102,Fp=103,Bp=104,Op=200,Hp=201,Vp=202,Gp=203,rc=204,oc=205,Wp=206,$p=207,qp=208,Xp=209,Yp=210,Zp=211,Kp=212,Jp=213,jp=214,ac=0,lc=1,cc=2,ir=3,hc=4,uc=5,dc=6,fc=7,nf=0,Qp=1,tm=2,Hi=0,em=1,nm=2,im=3,Ih=4,sm=5,rm=6,om=7;var sf=300,sr=301,rr=302,pc=303,mc=304,$a=306,ds=1e3,us=1001,gc=1002,_n=1003,am=1004;var Lo=1005;var In=1006,El=1007;var pi=1008;var xi=1009,rf=1010,of=1011,Yr=1012,Lh=1013,fs=1014,Kn=1015,ho=1016,Dh=1017,kh=1018,or=1020,af=35902,lf=1021,cf=1022,Hn=1023,hf=1024,uf=1025,tr=1026,ar=1027,Uh=1028,Nh=1029,df=1030,zh=1031;var Fh=1033,ca=33776,ha=33777,ua=33778,da=33779,xc=35840,yc=35841,vc=35842,bc=35843,_c=36196,Mc=37492,wc=37496,Sc=37808,Ec=37809,Tc=37810,Ac=37811,Rc=37812,Cc=37813,Pc=37814,Ic=37815,Lc=37816,Dc=37817,kc=37818,Uc=37819,Nc=37820,zc=37821,fa=36492,Fc=36494,Bc=36495,ff=36283,Oc=36284,Hc=36285,Vc=36286;var pa=2300,Gc=2301,Tl=2302,Hu=2400,Vu=2401,Gu=2402;var lm=3200,cm=3201;var pf=0,hm=1,Fi="",me="srgb",fr="srgb-linear",qa="linear",pe="srgb";var Ls=7680;var Wu=519,um=512,dm=513,fm=514,mf=515,pm=516,mm=517,gm=518,xm=519,Wc=35044;var $u="300 es",mi=2e3,ma=2001,Vi=class{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){if(this._listeners===void 0)return!1;let n=this._listeners;return n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){if(this._listeners===void 0)return;let s=this._listeners[t];if(s!==void 0){let r=s.indexOf(e);r!==-1&&s.splice(r,1)}}dispatchEvent(t){if(this._listeners===void 0)return;let n=this._listeners[t.type];if(n!==void 0){t.target=this;let s=n.slice(0);for(let r=0,o=s.length;r<o;r++)s[r].call(this,t);t.target=null}}},Ye=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],qu=1234567,Vr=Math.PI/180,Zr=180/Math.PI;function Jn(){let i=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Ye[i&255]+Ye[i>>8&255]+Ye[i>>16&255]+Ye[i>>24&255]+"-"+Ye[t&255]+Ye[t>>8&255]+"-"+Ye[t>>16&15|64]+Ye[t>>24&255]+"-"+Ye[e&63|128]+Ye[e>>8&255]+"-"+Ye[e>>16&255]+Ye[e>>24&255]+Ye[n&255]+Ye[n>>8&255]+Ye[n>>16&255]+Ye[n>>24&255]).toLowerCase()}function Fe(i,t,e){return Math.max(t,Math.min(e,i))}function Bh(i,t){return(i%t+t)%t}function ym(i,t,e,n,s){return n+(i-t)*(s-n)/(e-t)}function vm(i,t,e){return i!==t?(e-i)/(t-i):0}function Gr(i,t,e){return(1-e)*i+e*t}function bm(i,t,e,n){return Gr(i,t,1-Math.exp(-e*n))}function _m(i,t=1){return t-Math.abs(Bh(i,t*2)-t)}function Mm(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*(3-2*i))}function wm(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*i*(i*(i*6-15)+10))}function Sm(i,t){return i+Math.floor(Math.random()*(t-i+1))}function Em(i,t){return i+Math.random()*(t-i)}function Tm(i){return i*(.5-Math.random())}function Am(i){i!==void 0&&(qu=i);let t=qu+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function Rm(i){return i*Vr}function Cm(i){return i*Zr}function Pm(i){return(i&i-1)===0&&i!==0}function Im(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function Lm(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function Dm(i,t,e,n,s){let r=Math.cos,o=Math.sin,a=r(e/2),l=o(e/2),c=r((t+n)/2),h=o((t+n)/2),u=r((t-n)/2),d=o((t-n)/2),f=r((n-t)/2),g=o((n-t)/2);switch(s){case"XYX":i.set(a*h,l*u,l*d,a*c);break;case"YZY":i.set(l*d,a*h,l*u,a*c);break;case"ZXZ":i.set(l*u,l*d,a*h,a*c);break;case"XZX":i.set(a*h,l*g,l*f,a*c);break;case"YXY":i.set(l*f,a*h,l*g,a*c);break;case"ZYZ":i.set(l*g,l*f,a*h,a*c);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function On(i,t){switch(t.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("Invalid component type.")}}function de(i,t){switch(t.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("Invalid component type.")}}var pr={DEG2RAD:Vr,RAD2DEG:Zr,generateUUID:Jn,clamp:Fe,euclideanModulo:Bh,mapLinear:ym,inverseLerp:vm,lerp:Gr,damp:bm,pingpong:_m,smoothstep:Mm,smootherstep:wm,randInt:Sm,randFloat:Em,randFloatSpread:Tm,seededRandom:Am,degToRad:Rm,radToDeg:Cm,isPowerOfTwo:Pm,ceilPowerOfTwo:Im,floorPowerOfTwo:Lm,setQuaternionFromProperEuler:Dm,normalize:de,denormalize:On},rt=class i{constructor(t=0,e=0){i.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){let e=this.x,n=this.y,s=t.elements;return this.x=s[0]*e+s[3]*n+s[6],this.y=s[1]*e+s[4]*n+s[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(Fe(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){let n=Math.cos(e),s=Math.sin(e),r=this.x-t.x,o=this.y-t.y;return this.x=r*n-o*s+t.x,this.y=r*s+o*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},Gt=class i{constructor(t,e,n,s,r,o,a,l,c){i.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,s,r,o,a,l,c)}set(t,e,n,s,r,o,a,l,c){let h=this.elements;return h[0]=t,h[1]=s,h[2]=a,h[3]=e,h[4]=r,h[5]=l,h[6]=n,h[7]=o,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){let e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,s=e.elements,r=this.elements,o=n[0],a=n[3],l=n[6],c=n[1],h=n[4],u=n[7],d=n[2],f=n[5],g=n[8],x=s[0],m=s[3],p=s[6],M=s[1],v=s[4],y=s[7],w=s[2],S=s[5],A=s[8];return r[0]=o*x+a*M+l*w,r[3]=o*m+a*v+l*S,r[6]=o*p+a*y+l*A,r[1]=c*x+h*M+u*w,r[4]=c*m+h*v+u*S,r[7]=c*p+h*y+u*A,r[2]=d*x+f*M+g*w,r[5]=d*m+f*v+g*S,r[8]=d*p+f*y+g*A,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],o=t[4],a=t[5],l=t[6],c=t[7],h=t[8];return e*o*h-e*a*c-n*r*h+n*a*l+s*r*c-s*o*l}invert(){let t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],o=t[4],a=t[5],l=t[6],c=t[7],h=t[8],u=h*o-a*c,d=a*l-h*r,f=c*r-o*l,g=e*u+n*d+s*f;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);let x=1/g;return t[0]=u*x,t[1]=(s*c-h*n)*x,t[2]=(a*n-s*o)*x,t[3]=d*x,t[4]=(h*e-s*l)*x,t[5]=(s*r-a*e)*x,t[6]=f*x,t[7]=(n*l-c*e)*x,t[8]=(o*e-n*r)*x,this}transpose(){let t,e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){let e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,s,r,o,a){let l=Math.cos(r),c=Math.sin(r);return this.set(n*l,n*c,-n*(l*o+c*a)+o+t,-s*c,s*l,-s*(-c*o+l*a)+a+e,0,0,1),this}scale(t,e){return this.premultiply(Al.makeScale(t,e)),this}rotate(t){return this.premultiply(Al.makeRotation(-t)),this}translate(t,e){return this.premultiply(Al.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){let e=this.elements,n=t.elements;for(let s=0;s<9;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}},Al=new Gt;function gf(i){for(let t=i.length-1;t>=0;--t)if(i[t]>=65535)return!0;return!1}function ga(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function km(){let i=ga("canvas");return i.style.display="block",i}var Xu={};function Or(i){i in Xu||(Xu[i]=!0,console.warn(i))}function Um(i,t,e){return new Promise(function(n,s){function r(){switch(i.clientWaitSync(t,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:s();break;case i.TIMEOUT_EXPIRED:setTimeout(r,e);break;default:n()}}setTimeout(r,e)})}function Nm(i){let t=i.elements;t[2]=.5*t[2]+.5*t[3],t[6]=.5*t[6]+.5*t[7],t[10]=.5*t[10]+.5*t[11],t[14]=.5*t[14]+.5*t[15]}function zm(i){let t=i.elements;t[11]===-1?(t[10]=-t[10]-1,t[14]=-t[14]):(t[10]=-t[10],t[14]=-t[14]+1)}var ie={enabled:!0,workingColorSpace:fr,spaces:{},convert:function(i,t,e){return this.enabled===!1||t===e||!t||!e||(this.spaces[t].transfer===pe&&(i.r=gi(i.r),i.g=gi(i.g),i.b=gi(i.b)),this.spaces[t].primaries!==this.spaces[e].primaries&&(i.applyMatrix3(this.spaces[t].toXYZ),i.applyMatrix3(this.spaces[e].fromXYZ)),this.spaces[e].transfer===pe&&(i.r=er(i.r),i.g=er(i.g),i.b=er(i.b))),i},fromWorkingColorSpace:function(i,t){return this.convert(i,this.workingColorSpace,t)},toWorkingColorSpace:function(i,t){return this.convert(i,t,this.workingColorSpace)},getPrimaries:function(i){return this.spaces[i].primaries},getTransfer:function(i){return i===Fi?qa:this.spaces[i].transfer},getLuminanceCoefficients:function(i,t=this.workingColorSpace){return i.fromArray(this.spaces[t].luminanceCoefficients)},define:function(i){Object.assign(this.spaces,i)},_getMatrix:function(i,t,e){return i.copy(this.spaces[t].toXYZ).multiply(this.spaces[e].fromXYZ)},_getDrawingBufferColorSpace:function(i){return this.spaces[i].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(i=this.workingColorSpace){return this.spaces[i].workingColorSpaceConfig.unpackColorSpace}};function gi(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function er(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}var Yu=[.64,.33,.3,.6,.15,.06],Zu=[.2126,.7152,.0722],Ku=[.3127,.329],Ju=new Gt().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),ju=new Gt().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);ie.define({[fr]:{primaries:Yu,whitePoint:Ku,transfer:qa,toXYZ:Ju,fromXYZ:ju,luminanceCoefficients:Zu,workingColorSpaceConfig:{unpackColorSpace:me},outputColorSpaceConfig:{drawingBufferColorSpace:me}},[me]:{primaries:Yu,whitePoint:Ku,transfer:pe,toXYZ:Ju,fromXYZ:ju,luminanceCoefficients:Zu,outputColorSpaceConfig:{drawingBufferColorSpace:me}}});var Ds,$c=class{static getDataURL(t){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let e;if(t instanceof HTMLCanvasElement)e=t;else{Ds===void 0&&(Ds=ga("canvas")),Ds.width=t.width,Ds.height=t.height;let n=Ds.getContext("2d");t instanceof ImageData?n.putImageData(t,0,0):n.drawImage(t,0,0,t.width,t.height),e=Ds}return e.width>2048||e.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",t),e.toDataURL("image/jpeg",.6)):e.toDataURL("image/png")}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){let e=ga("canvas");e.width=t.width,e.height=t.height;let n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);let s=n.getImageData(0,0,t.width,t.height),r=s.data;for(let o=0;o<r.length;o++)r[o]=gi(r[o]/255)*255;return n.putImageData(s,0,0),e}else if(t.data){let e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(gi(e[n]/255)*255):e[n]=gi(e[n]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}},Fm=0,xa=class{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Fm++}),this.uuid=Jn(),this.data=t,this.dataReady=!0,this.version=0}set needsUpdate(t){t===!0&&this.version++}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];let n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let o=0,a=s.length;o<a;o++)s[o].isDataTexture?r.push(Rl(s[o].image)):r.push(Rl(s[o]))}else r=Rl(s);n.url=r}return e||(t.images[this.uuid]=n),n}};function Rl(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?$c.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var Bm=0,hn=class i extends Vi{constructor(t=i.DEFAULT_IMAGE,e=i.DEFAULT_MAPPING,n=us,s=us,r=In,o=pi,a=Hn,l=xi,c=i.DEFAULT_ANISOTROPY,h=Fi){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Bm++}),this.uuid=Jn(),this.name="",this.source=new xa(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=r,this.minFilter=o,this.anisotropy=c,this.format=a,this.internalFormat=null,this.type=l,this.offset=new rt(0,0),this.repeat=new rt(1,1),this.center=new rt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Gt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.pmremVersion=0}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];let n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==sf)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case ds:t.x=t.x-Math.floor(t.x);break;case us:t.x=t.x<0?0:1;break;case gc:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case ds:t.y=t.y-Math.floor(t.y);break;case us:t.y=t.y<0?0:1;break;case gc:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}};hn.DEFAULT_IMAGE=null;hn.DEFAULT_MAPPING=sf;hn.DEFAULT_ANISOTROPY=1;var Me=class i{constructor(t=0,e=0,n=0,s=1){i.prototype.isVector4=!0,this.x=t,this.y=e,this.z=n,this.w=s}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,s){return this.x=t,this.y=e,this.z=n,this.w=s,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){let e=this.x,n=this.y,s=this.z,r=this.w,o=t.elements;return this.x=o[0]*e+o[4]*n+o[8]*s+o[12]*r,this.y=o[1]*e+o[5]*n+o[9]*s+o[13]*r,this.z=o[2]*e+o[6]*n+o[10]*s+o[14]*r,this.w=o[3]*e+o[7]*n+o[11]*s+o[15]*r,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);let e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,s,r,l=t.elements,c=l[0],h=l[4],u=l[8],d=l[1],f=l[5],g=l[9],x=l[2],m=l[6],p=l[10];if(Math.abs(h-d)<.01&&Math.abs(u-x)<.01&&Math.abs(g-m)<.01){if(Math.abs(h+d)<.1&&Math.abs(u+x)<.1&&Math.abs(g+m)<.1&&Math.abs(c+f+p-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;let v=(c+1)/2,y=(f+1)/2,w=(p+1)/2,S=(h+d)/4,A=(u+x)/4,P=(g+m)/4;return v>y&&v>w?v<.01?(n=0,s=.707106781,r=.707106781):(n=Math.sqrt(v),s=S/n,r=A/n):y>w?y<.01?(n=.707106781,s=0,r=.707106781):(s=Math.sqrt(y),n=S/s,r=P/s):w<.01?(n=.707106781,s=.707106781,r=0):(r=Math.sqrt(w),n=A/r,s=P/r),this.set(n,s,r,e),this}let M=Math.sqrt((m-g)*(m-g)+(u-x)*(u-x)+(d-h)*(d-h));return Math.abs(M)<.001&&(M=1),this.x=(m-g)/M,this.y=(u-x)/M,this.z=(d-h)/M,this.w=Math.acos((c+f+p-1)/2),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this.w=e[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this.w=Math.max(t.w,Math.min(e.w,this.w)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this.w=Math.max(t,Math.min(e,this.w)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},qc=class extends Vi{constructor(t=1,e=1,n={}){super(),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=1,this.scissor=new Me(0,0,t,e),this.scissorTest=!1,this.viewport=new Me(0,0,t,e);let s={width:t,height:e,depth:1};n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:In,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1},n);let r=new hn(s,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace);r.flipY=!1,r.generateMipmaps=n.generateMipmaps,r.internalFormat=n.internalFormat,this.textures=[];let o=n.count;for(let a=0;a<o;a++)this.textures[a]=r.clone(),this.textures[a].isRenderTargetTexture=!0;this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.depthTexture=n.depthTexture,this.samples=n.samples}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}setSize(t,e,n=1){if(this.width!==t||this.height!==e||this.depth!==n){this.width=t,this.height=e,this.depth=n;for(let s=0,r=this.textures.length;s<r;s++)this.textures[s].image.width=t,this.textures[s].image.height=e,this.textures[s].image.depth=n;this.dispose()}this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let n=0,s=t.textures.length;n<s;n++)this.textures[n]=t.textures[n].clone(),this.textures[n].isRenderTargetTexture=!0;let e=Object.assign({},t.texture.image);return this.texture.source=new xa(e),this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},Vn=class extends qc{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}},ya=class extends hn{constructor(t=null,e=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=_n,this.minFilter=_n,this.wrapR=us,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}};var Xc=class extends hn{constructor(t=null,e=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=_n,this.minFilter=_n,this.wrapR=us,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var Re=class{constructor(t=0,e=0,n=0,s=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=s}static slerpFlat(t,e,n,s,r,o,a){let l=n[s+0],c=n[s+1],h=n[s+2],u=n[s+3],d=r[o+0],f=r[o+1],g=r[o+2],x=r[o+3];if(a===0){t[e+0]=l,t[e+1]=c,t[e+2]=h,t[e+3]=u;return}if(a===1){t[e+0]=d,t[e+1]=f,t[e+2]=g,t[e+3]=x;return}if(u!==x||l!==d||c!==f||h!==g){let m=1-a,p=l*d+c*f+h*g+u*x,M=p>=0?1:-1,v=1-p*p;if(v>Number.EPSILON){let w=Math.sqrt(v),S=Math.atan2(w,p*M);m=Math.sin(m*S)/w,a=Math.sin(a*S)/w}let y=a*M;if(l=l*m+d*y,c=c*m+f*y,h=h*m+g*y,u=u*m+x*y,m===1-a){let w=1/Math.sqrt(l*l+c*c+h*h+u*u);l*=w,c*=w,h*=w,u*=w}}t[e]=l,t[e+1]=c,t[e+2]=h,t[e+3]=u}static multiplyQuaternionsFlat(t,e,n,s,r,o){let a=n[s],l=n[s+1],c=n[s+2],h=n[s+3],u=r[o],d=r[o+1],f=r[o+2],g=r[o+3];return t[e]=a*g+h*u+l*f-c*d,t[e+1]=l*g+h*d+c*u-a*f,t[e+2]=c*g+h*f+a*d-l*u,t[e+3]=h*g-a*u-l*d-c*f,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,s){return this._x=t,this._y=e,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){let n=t._x,s=t._y,r=t._z,o=t._order,a=Math.cos,l=Math.sin,c=a(n/2),h=a(s/2),u=a(r/2),d=l(n/2),f=l(s/2),g=l(r/2);switch(o){case"XYZ":this._x=d*h*u+c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u-d*f*g;break;case"YXZ":this._x=d*h*u+c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u+d*f*g;break;case"ZXY":this._x=d*h*u-c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u-d*f*g;break;case"ZYX":this._x=d*h*u-c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u+d*f*g;break;case"YZX":this._x=d*h*u+c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u-d*f*g;break;case"XZY":this._x=d*h*u-c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u+d*f*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+o)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){let n=e/2,s=Math.sin(n);return this._x=t.x*s,this._y=t.y*s,this._z=t.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){let e=t.elements,n=e[0],s=e[4],r=e[8],o=e[1],a=e[5],l=e[9],c=e[2],h=e[6],u=e[10],d=n+a+u;if(d>0){let f=.5/Math.sqrt(d+1);this._w=.25/f,this._x=(h-l)*f,this._y=(r-c)*f,this._z=(o-s)*f}else if(n>a&&n>u){let f=2*Math.sqrt(1+n-a-u);this._w=(h-l)/f,this._x=.25*f,this._y=(s+o)/f,this._z=(r+c)/f}else if(a>u){let f=2*Math.sqrt(1+a-n-u);this._w=(r-c)/f,this._x=(s+o)/f,this._y=.25*f,this._z=(l+h)/f}else{let f=2*Math.sqrt(1+u-n-a);this._w=(o-s)/f,this._x=(r+c)/f,this._y=(l+h)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<Number.EPSILON?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(Fe(this.dot(t),-1,1)))}rotateTowards(t,e){let n=this.angleTo(t);if(n===0)return this;let s=Math.min(1,e/n);return this.slerp(t,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){let n=t._x,s=t._y,r=t._z,o=t._w,a=e._x,l=e._y,c=e._z,h=e._w;return this._x=n*h+o*a+s*c-r*l,this._y=s*h+o*l+r*a-n*c,this._z=r*h+o*c+n*l-s*a,this._w=o*h-n*a-s*l-r*c,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);let n=this._x,s=this._y,r=this._z,o=this._w,a=o*t._w+n*t._x+s*t._y+r*t._z;if(a<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,a=-a):this.copy(t),a>=1)return this._w=o,this._x=n,this._y=s,this._z=r,this;let l=1-a*a;if(l<=Number.EPSILON){let f=1-e;return this._w=f*o+e*this._w,this._x=f*n+e*this._x,this._y=f*s+e*this._y,this._z=f*r+e*this._z,this.normalize(),this}let c=Math.sqrt(l),h=Math.atan2(c,a),u=Math.sin((1-e)*h)/c,d=Math.sin(e*h)/c;return this._w=o*u+this._w*d,this._x=n*u+this._x*d,this._y=s*u+this._y*d,this._z=r*u+this._z*d,this._onChangeCallback(),this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){let t=2*Math.PI*Math.random(),e=2*Math.PI*Math.random(),n=Math.random(),s=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(s*Math.sin(t),s*Math.cos(t),r*Math.sin(e),r*Math.cos(e))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},C=class i{constructor(t=0,e=0,n=0){i.prototype.isVector3=!0,this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(Qu.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(Qu.setFromAxisAngle(t,e))}applyMatrix3(t){let e=this.x,n=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[3]*n+r[6]*s,this.y=r[1]*e+r[4]*n+r[7]*s,this.z=r[2]*e+r[5]*n+r[8]*s,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){let e=this.x,n=this.y,s=this.z,r=t.elements,o=1/(r[3]*e+r[7]*n+r[11]*s+r[15]);return this.x=(r[0]*e+r[4]*n+r[8]*s+r[12])*o,this.y=(r[1]*e+r[5]*n+r[9]*s+r[13])*o,this.z=(r[2]*e+r[6]*n+r[10]*s+r[14])*o,this}applyQuaternion(t){let e=this.x,n=this.y,s=this.z,r=t.x,o=t.y,a=t.z,l=t.w,c=2*(o*s-a*n),h=2*(a*e-r*s),u=2*(r*n-o*e);return this.x=e+l*c+o*u-a*h,this.y=n+l*h+a*c-r*u,this.z=s+l*u+r*h-o*c,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){let e=this.x,n=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[4]*n+r[8]*s,this.y=r[1]*e+r[5]*n+r[9]*s,this.z=r[2]*e+r[6]*n+r[10]*s,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){let n=t.x,s=t.y,r=t.z,o=e.x,a=e.y,l=e.z;return this.x=s*l-r*a,this.y=r*o-n*l,this.z=n*a-s*o,this}projectOnVector(t){let e=t.lengthSq();if(e===0)return this.set(0,0,0);let n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return Cl.copy(this).projectOnVector(t),this.sub(Cl)}reflect(t){return this.sub(Cl.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(Fe(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y,s=this.z-t.z;return e*e+n*n+s*s}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){let s=Math.sin(e)*t;return this.x=s*Math.sin(n),this.y=Math.cos(e)*t,this.z=s*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){let e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),s=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=s,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let t=Math.random()*Math.PI*2,e=Math.random()*2-1,n=Math.sqrt(1-e*e);return this.x=n*Math.cos(t),this.y=e,this.z=n*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},Cl=new C,Qu=new Re,yi=class{constructor(t=new C(1/0,1/0,1/0),e=new C(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(zn.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(zn.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){let n=zn.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);let n=t.geometry;if(n!==void 0){let r=n.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let o=0,a=r.count;o<a;o++)t.isMesh===!0?t.getVertexPosition(o,zn):zn.fromBufferAttribute(r,o),zn.applyMatrix4(t.matrixWorld),this.expandByPoint(zn);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),Do.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),Do.copy(n.boundingBox)),Do.applyMatrix4(t.matrixWorld),this.union(Do)}let s=t.children;for(let r=0,o=s.length;r<o;r++)this.expandByObject(s[r],e);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,zn),zn.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(Pr),ko.subVectors(this.max,Pr),ks.subVectors(t.a,Pr),Us.subVectors(t.b,Pr),Ns.subVectors(t.c,Pr),Li.subVectors(Us,ks),Di.subVectors(Ns,Us),ns.subVectors(ks,Ns);let e=[0,-Li.z,Li.y,0,-Di.z,Di.y,0,-ns.z,ns.y,Li.z,0,-Li.x,Di.z,0,-Di.x,ns.z,0,-ns.x,-Li.y,Li.x,0,-Di.y,Di.x,0,-ns.y,ns.x,0];return!Pl(e,ks,Us,Ns,ko)||(e=[1,0,0,0,1,0,0,0,1],!Pl(e,ks,Us,Ns,ko))?!1:(Uo.crossVectors(Li,Di),e=[Uo.x,Uo.y,Uo.z],Pl(e,ks,Us,Ns,ko))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,zn).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(zn).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(li[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),li[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),li[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),li[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),li[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),li[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),li[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),li[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(li),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}},li=[new C,new C,new C,new C,new C,new C,new C,new C],zn=new C,Do=new yi,ks=new C,Us=new C,Ns=new C,Li=new C,Di=new C,ns=new C,Pr=new C,ko=new C,Uo=new C,is=new C;function Pl(i,t,e,n,s){for(let r=0,o=i.length-3;r<=o;r+=3){is.fromArray(i,r);let a=s.x*Math.abs(is.x)+s.y*Math.abs(is.y)+s.z*Math.abs(is.z),l=t.dot(is),c=e.dot(is),h=n.dot(is);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>a)return!1}return!0}var Om=new yi,Ir=new C,Il=new C,Gi=class{constructor(t=new C,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){let n=this.center;e!==void 0?n.copy(e):Om.setFromPoints(t).getCenter(n);let s=0;for(let r=0,o=t.length;r<o;r++)s=Math.max(s,n.distanceToSquared(t[r]));return this.radius=Math.sqrt(s),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){let e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){let n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;Ir.subVectors(t,this.center);let e=Ir.lengthSq();if(e>this.radius*this.radius){let n=Math.sqrt(e),s=(n-this.radius)*.5;this.center.addScaledVector(Ir,s/n),this.radius+=s}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(Il.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(Ir.copy(t.center).add(Il)),this.expandByPoint(Ir.copy(t.center).sub(Il))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}},ci=new C,Ll=new C,No=new C,ki=new C,Dl=new C,zo=new C,kl=new C,Kr=class{constructor(t=new C,e=new C(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,ci)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);let n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){let e=ci.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(ci.copy(this.origin).addScaledVector(this.direction,e),ci.distanceToSquared(t))}distanceSqToSegment(t,e,n,s){Ll.copy(t).add(e).multiplyScalar(.5),No.copy(e).sub(t).normalize(),ki.copy(this.origin).sub(Ll);let r=t.distanceTo(e)*.5,o=-this.direction.dot(No),a=ki.dot(this.direction),l=-ki.dot(No),c=ki.lengthSq(),h=Math.abs(1-o*o),u,d,f,g;if(h>0)if(u=o*l-a,d=o*a-l,g=r*h,u>=0)if(d>=-g)if(d<=g){let x=1/h;u*=x,d*=x,f=u*(u+o*d+2*a)+d*(o*u+d+2*l)+c}else d=r,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;else d=-r,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;else d<=-g?(u=Math.max(0,-(-o*r+a)),d=u>0?-r:Math.min(Math.max(-r,-l),r),f=-u*u+d*(d+2*l)+c):d<=g?(u=0,d=Math.min(Math.max(-r,-l),r),f=d*(d+2*l)+c):(u=Math.max(0,-(o*r+a)),d=u>0?r:Math.min(Math.max(-r,-l),r),f=-u*u+d*(d+2*l)+c);else d=o>0?-r:r,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),s&&s.copy(Ll).addScaledVector(No,d),f}intersectSphere(t,e){ci.subVectors(t.center,this.origin);let n=ci.dot(this.direction),s=ci.dot(ci)-n*n,r=t.radius*t.radius;if(s>r)return null;let o=Math.sqrt(r-s),a=n-o,l=n+o;return l<0?null:a<0?this.at(l,e):this.at(a,e)}intersectsSphere(t){return this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){let e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){let n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){let e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,s,r,o,a,l,c=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(n=(t.min.x-d.x)*c,s=(t.max.x-d.x)*c):(n=(t.max.x-d.x)*c,s=(t.min.x-d.x)*c),h>=0?(r=(t.min.y-d.y)*h,o=(t.max.y-d.y)*h):(r=(t.max.y-d.y)*h,o=(t.min.y-d.y)*h),n>o||r>s||((r>n||isNaN(n))&&(n=r),(o<s||isNaN(s))&&(s=o),u>=0?(a=(t.min.z-d.z)*u,l=(t.max.z-d.z)*u):(a=(t.max.z-d.z)*u,l=(t.min.z-d.z)*u),n>l||a>s)||((a>n||n!==n)&&(n=a),(l<s||s!==s)&&(s=l),s<0)?null:this.at(n>=0?n:s,e)}intersectsBox(t){return this.intersectBox(t,ci)!==null}intersectTriangle(t,e,n,s,r){Dl.subVectors(e,t),zo.subVectors(n,t),kl.crossVectors(Dl,zo);let o=this.direction.dot(kl),a;if(o>0){if(s)return null;a=1}else if(o<0)a=-1,o=-o;else return null;ki.subVectors(this.origin,t);let l=a*this.direction.dot(zo.crossVectors(ki,zo));if(l<0)return null;let c=a*this.direction.dot(Dl.cross(ki));if(c<0||l+c>o)return null;let h=-a*ki.dot(kl);return h<0?null:this.at(h/o,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},Wt=class i{constructor(t,e,n,s,r,o,a,l,c,h,u,d,f,g,x,m){i.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,s,r,o,a,l,c,h,u,d,f,g,x,m)}set(t,e,n,s,r,o,a,l,c,h,u,d,f,g,x,m){let p=this.elements;return p[0]=t,p[4]=e,p[8]=n,p[12]=s,p[1]=r,p[5]=o,p[9]=a,p[13]=l,p[2]=c,p[6]=h,p[10]=u,p[14]=d,p[3]=f,p[7]=g,p[11]=x,p[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new i().fromArray(this.elements)}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){let e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){let e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){let e=this.elements,n=t.elements,s=1/zs.setFromMatrixColumn(t,0).length(),r=1/zs.setFromMatrixColumn(t,1).length(),o=1/zs.setFromMatrixColumn(t,2).length();return e[0]=n[0]*s,e[1]=n[1]*s,e[2]=n[2]*s,e[3]=0,e[4]=n[4]*r,e[5]=n[5]*r,e[6]=n[6]*r,e[7]=0,e[8]=n[8]*o,e[9]=n[9]*o,e[10]=n[10]*o,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){let e=this.elements,n=t.x,s=t.y,r=t.z,o=Math.cos(n),a=Math.sin(n),l=Math.cos(s),c=Math.sin(s),h=Math.cos(r),u=Math.sin(r);if(t.order==="XYZ"){let d=o*h,f=o*u,g=a*h,x=a*u;e[0]=l*h,e[4]=-l*u,e[8]=c,e[1]=f+g*c,e[5]=d-x*c,e[9]=-a*l,e[2]=x-d*c,e[6]=g+f*c,e[10]=o*l}else if(t.order==="YXZ"){let d=l*h,f=l*u,g=c*h,x=c*u;e[0]=d+x*a,e[4]=g*a-f,e[8]=o*c,e[1]=o*u,e[5]=o*h,e[9]=-a,e[2]=f*a-g,e[6]=x+d*a,e[10]=o*l}else if(t.order==="ZXY"){let d=l*h,f=l*u,g=c*h,x=c*u;e[0]=d-x*a,e[4]=-o*u,e[8]=g+f*a,e[1]=f+g*a,e[5]=o*h,e[9]=x-d*a,e[2]=-o*c,e[6]=a,e[10]=o*l}else if(t.order==="ZYX"){let d=o*h,f=o*u,g=a*h,x=a*u;e[0]=l*h,e[4]=g*c-f,e[8]=d*c+x,e[1]=l*u,e[5]=x*c+d,e[9]=f*c-g,e[2]=-c,e[6]=a*l,e[10]=o*l}else if(t.order==="YZX"){let d=o*l,f=o*c,g=a*l,x=a*c;e[0]=l*h,e[4]=x-d*u,e[8]=g*u+f,e[1]=u,e[5]=o*h,e[9]=-a*h,e[2]=-c*h,e[6]=f*u+g,e[10]=d-x*u}else if(t.order==="XZY"){let d=o*l,f=o*c,g=a*l,x=a*c;e[0]=l*h,e[4]=-u,e[8]=c*h,e[1]=d*u+x,e[5]=o*h,e[9]=f*u-g,e[2]=g*u-f,e[6]=a*h,e[10]=x*u+d}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(Hm,t,Vm)}lookAt(t,e,n){let s=this.elements;return yn.subVectors(t,e),yn.lengthSq()===0&&(yn.z=1),yn.normalize(),Ui.crossVectors(n,yn),Ui.lengthSq()===0&&(Math.abs(n.z)===1?yn.x+=1e-4:yn.z+=1e-4,yn.normalize(),Ui.crossVectors(n,yn)),Ui.normalize(),Fo.crossVectors(yn,Ui),s[0]=Ui.x,s[4]=Fo.x,s[8]=yn.x,s[1]=Ui.y,s[5]=Fo.y,s[9]=yn.y,s[2]=Ui.z,s[6]=Fo.z,s[10]=yn.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,s=e.elements,r=this.elements,o=n[0],a=n[4],l=n[8],c=n[12],h=n[1],u=n[5],d=n[9],f=n[13],g=n[2],x=n[6],m=n[10],p=n[14],M=n[3],v=n[7],y=n[11],w=n[15],S=s[0],A=s[4],P=s[8],_=s[12],b=s[1],R=s[5],L=s[9],D=s[13],N=s[2],W=s[6],k=s[10],q=s[14],H=s[3],K=s[7],Q=s[11],at=s[15];return r[0]=o*S+a*b+l*N+c*H,r[4]=o*A+a*R+l*W+c*K,r[8]=o*P+a*L+l*k+c*Q,r[12]=o*_+a*D+l*q+c*at,r[1]=h*S+u*b+d*N+f*H,r[5]=h*A+u*R+d*W+f*K,r[9]=h*P+u*L+d*k+f*Q,r[13]=h*_+u*D+d*q+f*at,r[2]=g*S+x*b+m*N+p*H,r[6]=g*A+x*R+m*W+p*K,r[10]=g*P+x*L+m*k+p*Q,r[14]=g*_+x*D+m*q+p*at,r[3]=M*S+v*b+y*N+w*H,r[7]=M*A+v*R+y*W+w*K,r[11]=M*P+v*L+y*k+w*Q,r[15]=M*_+v*D+y*q+w*at,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[4],s=t[8],r=t[12],o=t[1],a=t[5],l=t[9],c=t[13],h=t[2],u=t[6],d=t[10],f=t[14],g=t[3],x=t[7],m=t[11],p=t[15];return g*(+r*l*u-s*c*u-r*a*d+n*c*d+s*a*f-n*l*f)+x*(+e*l*f-e*c*d+r*o*d-s*o*f+s*c*h-r*l*h)+m*(+e*c*u-e*a*f-r*o*u+n*o*f+r*a*h-n*c*h)+p*(-s*a*h-e*l*u+e*a*d+s*o*u-n*o*d+n*l*h)}transpose(){let t=this.elements,e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){let s=this.elements;return t.isVector3?(s[12]=t.x,s[13]=t.y,s[14]=t.z):(s[12]=t,s[13]=e,s[14]=n),this}invert(){let t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],o=t[4],a=t[5],l=t[6],c=t[7],h=t[8],u=t[9],d=t[10],f=t[11],g=t[12],x=t[13],m=t[14],p=t[15],M=u*m*c-x*d*c+x*l*f-a*m*f-u*l*p+a*d*p,v=g*d*c-h*m*c-g*l*f+o*m*f+h*l*p-o*d*p,y=h*x*c-g*u*c+g*a*f-o*x*f-h*a*p+o*u*p,w=g*u*l-h*x*l-g*a*d+o*x*d+h*a*m-o*u*m,S=e*M+n*v+s*y+r*w;if(S===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let A=1/S;return t[0]=M*A,t[1]=(x*d*r-u*m*r-x*s*f+n*m*f+u*s*p-n*d*p)*A,t[2]=(a*m*r-x*l*r+x*s*c-n*m*c-a*s*p+n*l*p)*A,t[3]=(u*l*r-a*d*r-u*s*c+n*d*c+a*s*f-n*l*f)*A,t[4]=v*A,t[5]=(h*m*r-g*d*r+g*s*f-e*m*f-h*s*p+e*d*p)*A,t[6]=(g*l*r-o*m*r-g*s*c+e*m*c+o*s*p-e*l*p)*A,t[7]=(o*d*r-h*l*r+h*s*c-e*d*c-o*s*f+e*l*f)*A,t[8]=y*A,t[9]=(g*u*r-h*x*r-g*n*f+e*x*f+h*n*p-e*u*p)*A,t[10]=(o*x*r-g*a*r+g*n*c-e*x*c-o*n*p+e*a*p)*A,t[11]=(h*a*r-o*u*r-h*n*c+e*u*c+o*n*f-e*a*f)*A,t[12]=w*A,t[13]=(h*x*s-g*u*s+g*n*d-e*x*d-h*n*m+e*u*m)*A,t[14]=(g*a*s-o*x*s-g*n*l+e*x*l+o*n*m-e*a*m)*A,t[15]=(o*u*s-h*a*s+h*n*l-e*u*l-o*n*d+e*a*d)*A,this}scale(t){let e=this.elements,n=t.x,s=t.y,r=t.z;return e[0]*=n,e[4]*=s,e[8]*=r,e[1]*=n,e[5]*=s,e[9]*=r,e[2]*=n,e[6]*=s,e[10]*=r,e[3]*=n,e[7]*=s,e[11]*=r,this}getMaxScaleOnAxis(){let t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],s=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,s))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){let e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){let n=Math.cos(e),s=Math.sin(e),r=1-n,o=t.x,a=t.y,l=t.z,c=r*o,h=r*a;return this.set(c*o+n,c*a-s*l,c*l+s*a,0,c*a+s*l,h*a+n,h*l-s*o,0,c*l-s*a,h*l+s*o,r*l*l+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,s,r,o){return this.set(1,n,r,0,t,1,o,0,e,s,1,0,0,0,0,1),this}compose(t,e,n){let s=this.elements,r=e._x,o=e._y,a=e._z,l=e._w,c=r+r,h=o+o,u=a+a,d=r*c,f=r*h,g=r*u,x=o*h,m=o*u,p=a*u,M=l*c,v=l*h,y=l*u,w=n.x,S=n.y,A=n.z;return s[0]=(1-(x+p))*w,s[1]=(f+y)*w,s[2]=(g-v)*w,s[3]=0,s[4]=(f-y)*S,s[5]=(1-(d+p))*S,s[6]=(m+M)*S,s[7]=0,s[8]=(g+v)*A,s[9]=(m-M)*A,s[10]=(1-(d+x))*A,s[11]=0,s[12]=t.x,s[13]=t.y,s[14]=t.z,s[15]=1,this}decompose(t,e,n){let s=this.elements,r=zs.set(s[0],s[1],s[2]).length(),o=zs.set(s[4],s[5],s[6]).length(),a=zs.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),t.x=s[12],t.y=s[13],t.z=s[14],Fn.copy(this);let c=1/r,h=1/o,u=1/a;return Fn.elements[0]*=c,Fn.elements[1]*=c,Fn.elements[2]*=c,Fn.elements[4]*=h,Fn.elements[5]*=h,Fn.elements[6]*=h,Fn.elements[8]*=u,Fn.elements[9]*=u,Fn.elements[10]*=u,e.setFromRotationMatrix(Fn),n.x=r,n.y=o,n.z=a,this}makePerspective(t,e,n,s,r,o,a=mi){let l=this.elements,c=2*r/(e-t),h=2*r/(n-s),u=(e+t)/(e-t),d=(n+s)/(n-s),f,g;if(a===mi)f=-(o+r)/(o-r),g=-2*o*r/(o-r);else if(a===ma)f=-o/(o-r),g=-o*r/(o-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return l[0]=c,l[4]=0,l[8]=u,l[12]=0,l[1]=0,l[5]=h,l[9]=d,l[13]=0,l[2]=0,l[6]=0,l[10]=f,l[14]=g,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(t,e,n,s,r,o,a=mi){let l=this.elements,c=1/(e-t),h=1/(n-s),u=1/(o-r),d=(e+t)*c,f=(n+s)*h,g,x;if(a===mi)g=(o+r)*u,x=-2*u;else if(a===ma)g=r*u,x=-1*u;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return l[0]=2*c,l[4]=0,l[8]=0,l[12]=-d,l[1]=0,l[5]=2*h,l[9]=0,l[13]=-f,l[2]=0,l[6]=0,l[10]=x,l[14]=-g,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(t){let e=this.elements,n=t.elements;for(let s=0;s<16;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}},zs=new C,Fn=new Wt,Hm=new C(0,0,0),Vm=new C(1,1,1),Ui=new C,Fo=new C,yn=new C,td=new Wt,ed=new Re,un=class i{constructor(t=0,e=0,n=0,s=i.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=s}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,s=this._order){return this._x=t,this._y=e,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){let s=t.elements,r=s[0],o=s[4],a=s[8],l=s[1],c=s[5],h=s[9],u=s[2],d=s[6],f=s[10];switch(e){case"XYZ":this._y=Math.asin(Fe(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-h,f),this._z=Math.atan2(-o,r)):(this._x=Math.atan2(d,c),this._z=0);break;case"YXZ":this._x=Math.asin(-Fe(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(a,f),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,r),this._z=0);break;case"ZXY":this._x=Math.asin(Fe(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-o,c)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-Fe(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-o,c));break;case"YZX":this._z=Math.asin(Fe(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-u,r)):(this._x=0,this._y=Math.atan2(a,f));break;case"XZY":this._z=Math.asin(-Fe(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(a,r)):(this._x=Math.atan2(-h,f),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return td.makeRotationFromQuaternion(t),this.setFromRotationMatrix(td,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return ed.setFromEuler(this),this.setFromQuaternion(ed,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};un.DEFAULT_ORDER="XYZ";var Jr=class{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}},Gm=0,nd=new C,Fs=new Re,hi=new Wt,Bo=new C,Lr=new C,Wm=new C,$m=new Re,id=new C(1,0,0),sd=new C(0,1,0),rd=new C(0,0,1),od={type:"added"},qm={type:"removed"},Bs={type:"childadded",child:null},Ul={type:"childremoved",child:null},Oe=class i extends Vi{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Gm++}),this.uuid=Jn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=i.DEFAULT_UP.clone();let t=new C,e=new un,n=new Re,s=new C(1,1,1);function r(){n.setFromEuler(e,!1)}function o(){e.setFromQuaternion(n,void 0,!1)}e._onChange(r),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new Wt},normalMatrix:{value:new Gt}}),this.matrix=new Wt,this.matrixWorld=new Wt,this.matrixAutoUpdate=i.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=i.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Jr,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return Fs.setFromAxisAngle(t,e),this.quaternion.multiply(Fs),this}rotateOnWorldAxis(t,e){return Fs.setFromAxisAngle(t,e),this.quaternion.premultiply(Fs),this}rotateX(t){return this.rotateOnAxis(id,t)}rotateY(t){return this.rotateOnAxis(sd,t)}rotateZ(t){return this.rotateOnAxis(rd,t)}translateOnAxis(t,e){return nd.copy(t).applyQuaternion(this.quaternion),this.position.add(nd.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(id,t)}translateY(t){return this.translateOnAxis(sd,t)}translateZ(t){return this.translateOnAxis(rd,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(hi.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?Bo.copy(t):Bo.set(t,e,n);let s=this.parent;this.updateWorldMatrix(!0,!1),Lr.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?hi.lookAt(Lr,Bo,this.up):hi.lookAt(Bo,Lr,this.up),this.quaternion.setFromRotationMatrix(hi),s&&(hi.extractRotation(s.matrixWorld),Fs.setFromRotationMatrix(hi),this.quaternion.premultiply(Fs.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(od),Bs.child=t,this.dispatchEvent(Bs),Bs.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}let e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(qm),Ul.child=t,this.dispatchEvent(Ul),Ul.child=null),this}removeFromParent(){let t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),hi.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),hi.multiply(t.parent.matrixWorld)),t.applyMatrix4(hi),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(od),Bs.child=t,this.dispatchEvent(Bs),Bs.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,s=this.children.length;n<s;n++){let o=this.children[n].getObjectByProperty(t,e);if(o!==void 0)return o}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);let s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Lr,t,Wm),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Lr,$m,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);let e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);let e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);let e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverseVisible(t)}traverseAncestors(t){let e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);let e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].updateMatrixWorld(t)}updateWorldMatrix(t,e){let n=this.parent;if(t===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),e===!0){let s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].updateWorldMatrix(!1,!0)}}toJSON(t){let e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.visibility=this._visibility,s.active=this._active,s.bounds=this._bounds.map(a=>({boxInitialized:a.boxInitialized,boxMin:a.box.min.toArray(),boxMax:a.box.max.toArray(),sphereInitialized:a.sphereInitialized,sphereRadius:a.sphere.radius,sphereCenter:a.sphere.center.toArray()})),s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.geometryCount=this._geometryCount,s.matricesTexture=this._matricesTexture.toJSON(t),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(s.boundingSphere={center:s.boundingSphere.center.toArray(),radius:s.boundingSphere.radius}),this.boundingBox!==null&&(s.boundingBox={min:s.boundingBox.min.toArray(),max:s.boundingBox.max.toArray()}));function r(a,l){return a[l.uuid]===void 0&&(a[l.uuid]=l.toJSON(t)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(t.geometries,this.geometry);let a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){let l=a.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){let u=l[c];r(t.shapes,u)}else r(t.shapes,l)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let a=[];for(let l=0,c=this.material.length;l<c;l++)a.push(r(t.materials,this.material[l]));s.material=a}else s.material=r(t.materials,this.material);if(this.children.length>0){s.children=[];for(let a=0;a<this.children.length;a++)s.children.push(this.children[a].toJSON(t).object)}if(this.animations.length>0){s.animations=[];for(let a=0;a<this.animations.length;a++){let l=this.animations[a];s.animations.push(r(t.animations,l))}}if(e){let a=o(t.geometries),l=o(t.materials),c=o(t.textures),h=o(t.images),u=o(t.shapes),d=o(t.skeletons),f=o(t.animations),g=o(t.nodes);a.length>0&&(n.geometries=a),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),h.length>0&&(n.images=h),u.length>0&&(n.shapes=u),d.length>0&&(n.skeletons=d),f.length>0&&(n.animations=f),g.length>0&&(n.nodes=g)}return n.object=s,n;function o(a){let l=[];for(let c in a){let h=a[c];delete h.metadata,l.push(h)}return l}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){let s=t.children[n];this.add(s.clone())}return this}};Oe.DEFAULT_UP=new C(0,1,0);Oe.DEFAULT_MATRIX_AUTO_UPDATE=!0;Oe.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var Bn=new C,ui=new C,Nl=new C,di=new C,Os=new C,Hs=new C,ad=new C,zl=new C,Fl=new C,Bl=new C,Ol=new Me,Hl=new Me,Vl=new Me,Bi=class i{constructor(t=new C,e=new C,n=new C){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,s){s.subVectors(n,e),Bn.subVectors(t,e),s.cross(Bn);let r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(t,e,n,s,r){Bn.subVectors(s,e),ui.subVectors(n,e),Nl.subVectors(t,e);let o=Bn.dot(Bn),a=Bn.dot(ui),l=Bn.dot(Nl),c=ui.dot(ui),h=ui.dot(Nl),u=o*c-a*a;if(u===0)return r.set(0,0,0),null;let d=1/u,f=(c*l-a*h)*d,g=(o*h-a*l)*d;return r.set(1-f-g,g,f)}static containsPoint(t,e,n,s){return this.getBarycoord(t,e,n,s,di)===null?!1:di.x>=0&&di.y>=0&&di.x+di.y<=1}static getInterpolation(t,e,n,s,r,o,a,l){return this.getBarycoord(t,e,n,s,di)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,di.x),l.addScaledVector(o,di.y),l.addScaledVector(a,di.z),l)}static getInterpolatedAttribute(t,e,n,s,r,o){return Ol.setScalar(0),Hl.setScalar(0),Vl.setScalar(0),Ol.fromBufferAttribute(t,e),Hl.fromBufferAttribute(t,n),Vl.fromBufferAttribute(t,s),o.setScalar(0),o.addScaledVector(Ol,r.x),o.addScaledVector(Hl,r.y),o.addScaledVector(Vl,r.z),o}static isFrontFacing(t,e,n,s){return Bn.subVectors(n,e),ui.subVectors(t,e),Bn.cross(ui).dot(s)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,s){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[s]),this}setFromAttributeAndIndices(t,e,n,s){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,s),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return Bn.subVectors(this.c,this.b),ui.subVectors(this.a,this.b),Bn.cross(ui).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return i.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return i.getBarycoord(t,this.a,this.b,this.c,e)}getInterpolation(t,e,n,s,r){return i.getInterpolation(t,this.a,this.b,this.c,e,n,s,r)}containsPoint(t){return i.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return i.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){let n=this.a,s=this.b,r=this.c,o,a;Os.subVectors(s,n),Hs.subVectors(r,n),zl.subVectors(t,n);let l=Os.dot(zl),c=Hs.dot(zl);if(l<=0&&c<=0)return e.copy(n);Fl.subVectors(t,s);let h=Os.dot(Fl),u=Hs.dot(Fl);if(h>=0&&u<=h)return e.copy(s);let d=l*u-h*c;if(d<=0&&l>=0&&h<=0)return o=l/(l-h),e.copy(n).addScaledVector(Os,o);Bl.subVectors(t,r);let f=Os.dot(Bl),g=Hs.dot(Bl);if(g>=0&&f<=g)return e.copy(r);let x=f*c-l*g;if(x<=0&&c>=0&&g<=0)return a=c/(c-g),e.copy(n).addScaledVector(Hs,a);let m=h*g-f*u;if(m<=0&&u-h>=0&&f-g>=0)return ad.subVectors(r,s),a=(u-h)/(u-h+(f-g)),e.copy(s).addScaledVector(ad,a);let p=1/(m+x+d);return o=x*p,a=d*p,e.copy(n).addScaledVector(Os,o).addScaledVector(Hs,a)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}},xf={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Ni={h:0,s:0,l:0},Oo={h:0,s:0,l:0};function Gl(i,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?i+(t-i)*6*e:e<1/2?t:e<2/3?i+(t-i)*6*(2/3-e):i}var bt=class{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){let s=t;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=me){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,ie.toWorkingColorSpace(this,e),this}setRGB(t,e,n,s=ie.workingColorSpace){return this.r=t,this.g=e,this.b=n,ie.toWorkingColorSpace(this,s),this}setHSL(t,e,n,s=ie.workingColorSpace){if(t=Bh(t,1),e=Fe(e,0,1),n=Fe(n,0,1),e===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+e):n+e-n*e,o=2*n-r;this.r=Gl(o,r,t+1/3),this.g=Gl(o,r,t),this.b=Gl(o,r,t-1/3)}return ie.toWorkingColorSpace(this,s),this}setStyle(t,e=me){function n(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(t)){let r,o=s[1],a=s[2];switch(o){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(t)){let r=s[1],o=r.length;if(o===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(o===6)return this.setHex(parseInt(r,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=me){let n=xf[t.toLowerCase()];return n!==void 0?this.setHex(n,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=gi(t.r),this.g=gi(t.g),this.b=gi(t.b),this}copyLinearToSRGB(t){return this.r=er(t.r),this.g=er(t.g),this.b=er(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=me){return ie.fromWorkingColorSpace(Ze.copy(this),t),Math.round(Fe(Ze.r*255,0,255))*65536+Math.round(Fe(Ze.g*255,0,255))*256+Math.round(Fe(Ze.b*255,0,255))}getHexString(t=me){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=ie.workingColorSpace){ie.fromWorkingColorSpace(Ze.copy(this),e);let n=Ze.r,s=Ze.g,r=Ze.b,o=Math.max(n,s,r),a=Math.min(n,s,r),l,c,h=(a+o)/2;if(a===o)l=0,c=0;else{let u=o-a;switch(c=h<=.5?u/(o+a):u/(2-o-a),o){case n:l=(s-r)/u+(s<r?6:0);break;case s:l=(r-n)/u+2;break;case r:l=(n-s)/u+4;break}l/=6}return t.h=l,t.s=c,t.l=h,t}getRGB(t,e=ie.workingColorSpace){return ie.fromWorkingColorSpace(Ze.copy(this),e),t.r=Ze.r,t.g=Ze.g,t.b=Ze.b,t}getStyle(t=me){ie.fromWorkingColorSpace(Ze.copy(this),t);let e=Ze.r,n=Ze.g,s=Ze.b;return t!==me?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(t,e,n){return this.getHSL(Ni),this.setHSL(Ni.h+t,Ni.s+e,Ni.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(Ni),t.getHSL(Oo);let n=Gr(Ni.h,Oo.h,e),s=Gr(Ni.s,Oo.s,e),r=Gr(Ni.l,Oo.l,e);return this.setHSL(n,s,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){let e=this.r,n=this.g,s=this.b,r=t.elements;return this.r=r[0]*e+r[3]*n+r[6]*s,this.g=r[1]*e+r[4]*n+r[7]*s,this.b=r[2]*e+r[5]*n+r[8]*s,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},Ze=new bt;bt.NAMES=xf;var Xm=0,vi=class extends Vi{static get type(){return"Material"}get type(){return this.constructor.type}set type(t){}constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Xm++}),this.uuid=Jn(),this.name="",this.blending=Qs,this.side=jn,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=rc,this.blendDst=oc,this.blendEquation=cs,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new bt(0,0,0),this.blendAlpha=0,this.depthFunc=ir,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Wu,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Ls,this.stencilZFail=Ls,this.stencilZPass=Ls,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(let e in t){let n=t[e];if(n===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}let s=this[e];if(s===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[e]=n}}toJSON(t){let e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});let n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==Qs&&(n.blending=this.blending),this.side!==jn&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==rc&&(n.blendSrc=this.blendSrc),this.blendDst!==oc&&(n.blendDst=this.blendDst),this.blendEquation!==cs&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==ir&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Wu&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Ls&&(n.stencilFail=this.stencilFail),this.stencilZFail!==Ls&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==Ls&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(r){let o=[];for(let a in r){let l=r[a];delete l.metadata,o.push(l)}return o}if(e){let r=s(t.textures),o=s(t.images);r.length>0&&(n.textures=r),o.length>0&&(n.images=o)}return n}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;let e=t.clippingPlanes,n=null;if(e!==null){let s=e.length;n=new Array(s);for(let r=0;r!==s;++r)n[r]=e[r].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}onBuild(){console.warn("Material: onBuild() has been removed.")}},Le=class extends vi{static get type(){return"MeshBasicMaterial"}constructor(t){super(),this.isMeshBasicMaterial=!0,this.color=new bt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new un,this.combine=nf,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}};var Ue=new C,Ho=new rt,Ne=class{constructor(t,e,n=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=Wc,this.updateRanges=[],this.gpuType=Kn,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[t+s]=e.array[n+s];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)Ho.fromBufferAttribute(this,e),Ho.applyMatrix3(t),this.setXY(e,Ho.x,Ho.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)Ue.fromBufferAttribute(this,e),Ue.applyMatrix3(t),this.setXYZ(e,Ue.x,Ue.y,Ue.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)Ue.fromBufferAttribute(this,e),Ue.applyMatrix4(t),this.setXYZ(e,Ue.x,Ue.y,Ue.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)Ue.fromBufferAttribute(this,e),Ue.applyNormalMatrix(t),this.setXYZ(e,Ue.x,Ue.y,Ue.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)Ue.fromBufferAttribute(this,e),Ue.transformDirection(t),this.setXYZ(e,Ue.x,Ue.y,Ue.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=On(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=de(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=On(e,this.array)),e}setX(t,e){return this.normalized&&(e=de(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=On(e,this.array)),e}setY(t,e){return this.normalized&&(e=de(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=On(e,this.array)),e}setZ(t,e){return this.normalized&&(e=de(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=On(e,this.array)),e}setW(t,e){return this.normalized&&(e=de(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=de(e,this.array),n=de(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,s){return t*=this.itemSize,this.normalized&&(e=de(e,this.array),n=de(n,this.array),s=de(s,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this}setXYZW(t,e,n,s,r){return t*=this.itemSize,this.normalized&&(e=de(e,this.array),n=de(n,this.array),s=de(s,this.array),r=de(r,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==Wc&&(t.usage=this.usage),t}};var va=class extends Ne{constructor(t,e,n){super(new Uint16Array(t),e,n)}};var ba=class extends Ne{constructor(t,e,n){super(new Uint32Array(t),e,n)}};var Ot=class extends Ne{constructor(t,e,n){super(new Float32Array(t),e,n)}},Ym=0,Pn=new Wt,Wl=new Oe,Vs=new C,vn=new yi,Dr=new yi,We=new C,ae=class i extends Vi{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Ym++}),this.uuid=Jn(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(gf(t)?ba:va)(t,1):this.index=t,this}setIndirect(t){return this.indirect=t,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){let e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let r=new Gt().getNormalMatrix(t);n.applyNormalMatrix(r),n.needsUpdate=!0}let s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(t),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return Pn.makeRotationFromQuaternion(t),this.applyMatrix4(Pn),this}rotateX(t){return Pn.makeRotationX(t),this.applyMatrix4(Pn),this}rotateY(t){return Pn.makeRotationY(t),this.applyMatrix4(Pn),this}rotateZ(t){return Pn.makeRotationZ(t),this.applyMatrix4(Pn),this}translate(t,e,n){return Pn.makeTranslation(t,e,n),this.applyMatrix4(Pn),this}scale(t,e,n){return Pn.makeScale(t,e,n),this.applyMatrix4(Pn),this}lookAt(t){return Wl.lookAt(t),Wl.updateMatrix(),this.applyMatrix4(Wl.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Vs).negate(),this.translate(Vs.x,Vs.y,Vs.z),this}setFromPoints(t){let e=this.getAttribute("position");if(e===void 0){let n=[];for(let s=0,r=t.length;s<r;s++){let o=t[s];n.push(o.x,o.y,o.z||0)}this.setAttribute("position",new Ot(n,3))}else{for(let n=0,s=e.count;n<s;n++){let r=t[n];e.setXYZ(n,r.x,r.y,r.z||0)}t.length>e.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),e.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new yi);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new C(-1/0,-1/0,-1/0),new C(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,s=e.length;n<s;n++){let r=e[n];vn.setFromBufferAttribute(r),this.morphTargetsRelative?(We.addVectors(this.boundingBox.min,vn.min),this.boundingBox.expandByPoint(We),We.addVectors(this.boundingBox.max,vn.max),this.boundingBox.expandByPoint(We)):(this.boundingBox.expandByPoint(vn.min),this.boundingBox.expandByPoint(vn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Gi);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new C,1/0);return}if(t){let n=this.boundingSphere.center;if(vn.setFromBufferAttribute(t),e)for(let r=0,o=e.length;r<o;r++){let a=e[r];Dr.setFromBufferAttribute(a),this.morphTargetsRelative?(We.addVectors(vn.min,Dr.min),vn.expandByPoint(We),We.addVectors(vn.max,Dr.max),vn.expandByPoint(We)):(vn.expandByPoint(Dr.min),vn.expandByPoint(Dr.max))}vn.getCenter(n);let s=0;for(let r=0,o=t.count;r<o;r++)We.fromBufferAttribute(t,r),s=Math.max(s,n.distanceToSquared(We));if(e)for(let r=0,o=e.length;r<o;r++){let a=e[r],l=this.morphTargetsRelative;for(let c=0,h=a.count;c<h;c++)We.fromBufferAttribute(a,c),l&&(Vs.fromBufferAttribute(t,c),We.add(Vs)),s=Math.max(s,n.distanceToSquared(We))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let n=e.position,s=e.normal,r=e.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Ne(new Float32Array(4*n.count),4));let o=this.getAttribute("tangent"),a=[],l=[];for(let P=0;P<n.count;P++)a[P]=new C,l[P]=new C;let c=new C,h=new C,u=new C,d=new rt,f=new rt,g=new rt,x=new C,m=new C;function p(P,_,b){c.fromBufferAttribute(n,P),h.fromBufferAttribute(n,_),u.fromBufferAttribute(n,b),d.fromBufferAttribute(r,P),f.fromBufferAttribute(r,_),g.fromBufferAttribute(r,b),h.sub(c),u.sub(c),f.sub(d),g.sub(d);let R=1/(f.x*g.y-g.x*f.y);isFinite(R)&&(x.copy(h).multiplyScalar(g.y).addScaledVector(u,-f.y).multiplyScalar(R),m.copy(u).multiplyScalar(f.x).addScaledVector(h,-g.x).multiplyScalar(R),a[P].add(x),a[_].add(x),a[b].add(x),l[P].add(m),l[_].add(m),l[b].add(m))}let M=this.groups;M.length===0&&(M=[{start:0,count:t.count}]);for(let P=0,_=M.length;P<_;++P){let b=M[P],R=b.start,L=b.count;for(let D=R,N=R+L;D<N;D+=3)p(t.getX(D+0),t.getX(D+1),t.getX(D+2))}let v=new C,y=new C,w=new C,S=new C;function A(P){w.fromBufferAttribute(s,P),S.copy(w);let _=a[P];v.copy(_),v.sub(w.multiplyScalar(w.dot(_))).normalize(),y.crossVectors(S,_);let R=y.dot(l[P])<0?-1:1;o.setXYZW(P,v.x,v.y,v.z,R)}for(let P=0,_=M.length;P<_;++P){let b=M[P],R=b.start,L=b.count;for(let D=R,N=R+L;D<N;D+=3)A(t.getX(D+0)),A(t.getX(D+1)),A(t.getX(D+2))}}computeVertexNormals(){let t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new Ne(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let d=0,f=n.count;d<f;d++)n.setXYZ(d,0,0,0);let s=new C,r=new C,o=new C,a=new C,l=new C,c=new C,h=new C,u=new C;if(t)for(let d=0,f=t.count;d<f;d+=3){let g=t.getX(d+0),x=t.getX(d+1),m=t.getX(d+2);s.fromBufferAttribute(e,g),r.fromBufferAttribute(e,x),o.fromBufferAttribute(e,m),h.subVectors(o,r),u.subVectors(s,r),h.cross(u),a.fromBufferAttribute(n,g),l.fromBufferAttribute(n,x),c.fromBufferAttribute(n,m),a.add(h),l.add(h),c.add(h),n.setXYZ(g,a.x,a.y,a.z),n.setXYZ(x,l.x,l.y,l.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let d=0,f=e.count;d<f;d+=3)s.fromBufferAttribute(e,d+0),r.fromBufferAttribute(e,d+1),o.fromBufferAttribute(e,d+2),h.subVectors(o,r),u.subVectors(s,r),h.cross(u),n.setXYZ(d+0,h.x,h.y,h.z),n.setXYZ(d+1,h.x,h.y,h.z),n.setXYZ(d+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)We.fromBufferAttribute(t,e),We.normalize(),t.setXYZ(e,We.x,We.y,We.z)}toNonIndexed(){function t(a,l){let c=a.array,h=a.itemSize,u=a.normalized,d=new c.constructor(l.length*h),f=0,g=0;for(let x=0,m=l.length;x<m;x++){a.isInterleavedBufferAttribute?f=l[x]*a.data.stride+a.offset:f=l[x]*h;for(let p=0;p<h;p++)d[g++]=c[f++]}return new Ne(d,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let e=new i,n=this.index.array,s=this.attributes;for(let a in s){let l=s[a],c=t(l,n);e.setAttribute(a,c)}let r=this.morphAttributes;for(let a in r){let l=[],c=r[a];for(let h=0,u=c.length;h<u;h++){let d=c[h],f=t(d,n);l.push(f)}e.morphAttributes[a]=l}e.morphTargetsRelative=this.morphTargetsRelative;let o=this.groups;for(let a=0,l=o.length;a<l;a++){let c=o[a];e.addGroup(c.start,c.count,c.materialIndex)}return e}toJSON(){let t={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){let l=this.parameters;for(let c in l)l[c]!==void 0&&(t[c]=l[c]);return t}t.data={attributes:{}};let e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});let n=this.attributes;for(let l in n){let c=n[l];t.data.attributes[l]=c.toJSON(t.data)}let s={},r=!1;for(let l in this.morphAttributes){let c=this.morphAttributes[l],h=[];for(let u=0,d=c.length;u<d;u++){let f=c[u];h.push(f.toJSON(t.data))}h.length>0&&(s[l]=h,r=!0)}r&&(t.data.morphAttributes=s,t.data.morphTargetsRelative=this.morphTargetsRelative);let o=this.groups;o.length>0&&(t.data.groups=JSON.parse(JSON.stringify(o)));let a=this.boundingSphere;return a!==null&&(t.data.boundingSphere={center:a.center.toArray(),radius:a.radius}),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let e={};this.name=t.name;let n=t.index;n!==null&&this.setIndex(n.clone(e));let s=t.attributes;for(let c in s){let h=s[c];this.setAttribute(c,h.clone(e))}let r=t.morphAttributes;for(let c in r){let h=[],u=r[c];for(let d=0,f=u.length;d<f;d++)h.push(u[d].clone(e));this.morphAttributes[c]=h}this.morphTargetsRelative=t.morphTargetsRelative;let o=t.groups;for(let c=0,h=o.length;c<h;c++){let u=o[c];this.addGroup(u.start,u.count,u.materialIndex)}let a=t.boundingBox;a!==null&&(this.boundingBox=a.clone());let l=t.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},ld=new Wt,ss=new Kr,Vo=new Gi,cd=new C,Go=new C,Wo=new C,$o=new C,$l=new C,qo=new C,hd=new C,Xo=new C,nt=class extends Oe{constructor(t=new ae,e=new Le){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}getVertexPosition(t,e){let n=this.geometry,s=n.attributes.position,r=n.morphAttributes.position,o=n.morphTargetsRelative;e.fromBufferAttribute(s,t);let a=this.morphTargetInfluences;if(r&&a){qo.set(0,0,0);for(let l=0,c=r.length;l<c;l++){let h=a[l],u=r[l];h!==0&&($l.fromBufferAttribute(u,t),o?qo.addScaledVector($l,h):qo.addScaledVector($l.sub(e),h))}e.add(qo)}return e}raycast(t,e){let n=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),Vo.copy(n.boundingSphere),Vo.applyMatrix4(r),ss.copy(t.ray).recast(t.near),!(Vo.containsPoint(ss.origin)===!1&&(ss.intersectSphere(Vo,cd)===null||ss.origin.distanceToSquared(cd)>(t.far-t.near)**2))&&(ld.copy(r).invert(),ss.copy(t.ray).applyMatrix4(ld),!(n.boundingBox!==null&&ss.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,ss)))}_computeIntersections(t,e,n){let s,r=this.geometry,o=this.material,a=r.index,l=r.attributes.position,c=r.attributes.uv,h=r.attributes.uv1,u=r.attributes.normal,d=r.groups,f=r.drawRange;if(a!==null)if(Array.isArray(o))for(let g=0,x=d.length;g<x;g++){let m=d[g],p=o[m.materialIndex],M=Math.max(m.start,f.start),v=Math.min(a.count,Math.min(m.start+m.count,f.start+f.count));for(let y=M,w=v;y<w;y+=3){let S=a.getX(y),A=a.getX(y+1),P=a.getX(y+2);s=Yo(this,p,t,n,c,h,u,S,A,P),s&&(s.faceIndex=Math.floor(y/3),s.face.materialIndex=m.materialIndex,e.push(s))}}else{let g=Math.max(0,f.start),x=Math.min(a.count,f.start+f.count);for(let m=g,p=x;m<p;m+=3){let M=a.getX(m),v=a.getX(m+1),y=a.getX(m+2);s=Yo(this,o,t,n,c,h,u,M,v,y),s&&(s.faceIndex=Math.floor(m/3),e.push(s))}}else if(l!==void 0)if(Array.isArray(o))for(let g=0,x=d.length;g<x;g++){let m=d[g],p=o[m.materialIndex],M=Math.max(m.start,f.start),v=Math.min(l.count,Math.min(m.start+m.count,f.start+f.count));for(let y=M,w=v;y<w;y+=3){let S=y,A=y+1,P=y+2;s=Yo(this,p,t,n,c,h,u,S,A,P),s&&(s.faceIndex=Math.floor(y/3),s.face.materialIndex=m.materialIndex,e.push(s))}}else{let g=Math.max(0,f.start),x=Math.min(l.count,f.start+f.count);for(let m=g,p=x;m<p;m+=3){let M=m,v=m+1,y=m+2;s=Yo(this,o,t,n,c,h,u,M,v,y),s&&(s.faceIndex=Math.floor(m/3),e.push(s))}}}};function Zm(i,t,e,n,s,r,o,a){let l;if(t.side===Ke?l=n.intersectTriangle(o,r,s,!0,a):l=n.intersectTriangle(s,r,o,t.side===jn,a),l===null)return null;Xo.copy(a),Xo.applyMatrix4(i.matrixWorld);let c=e.ray.origin.distanceTo(Xo);return c<e.near||c>e.far?null:{distance:c,point:Xo.clone(),object:i}}function Yo(i,t,e,n,s,r,o,a,l,c){i.getVertexPosition(a,Go),i.getVertexPosition(l,Wo),i.getVertexPosition(c,$o);let h=Zm(i,t,e,n,Go,Wo,$o,hd);if(h){let u=new C;Bi.getBarycoord(hd,Go,Wo,$o,u),s&&(h.uv=Bi.getInterpolatedAttribute(s,a,l,c,u,new rt)),r&&(h.uv1=Bi.getInterpolatedAttribute(r,a,l,c,u,new rt)),o&&(h.normal=Bi.getInterpolatedAttribute(o,a,l,c,u,new C),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));let d={a,b:l,c,normal:new C,materialIndex:0};Bi.getNormal(Go,Wo,$o,d.normal),h.face=d,h.barycoord=u}return h}var $t=class i extends ae{constructor(t=1,e=1,n=1,s=1,r=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:s,heightSegments:r,depthSegments:o};let a=this;s=Math.floor(s),r=Math.floor(r),o=Math.floor(o);let l=[],c=[],h=[],u=[],d=0,f=0;g("z","y","x",-1,-1,n,e,t,o,r,0),g("z","y","x",1,-1,n,e,-t,o,r,1),g("x","z","y",1,1,t,n,e,s,o,2),g("x","z","y",1,-1,t,n,-e,s,o,3),g("x","y","z",1,-1,t,e,n,s,r,4),g("x","y","z",-1,-1,t,e,-n,s,r,5),this.setIndex(l),this.setAttribute("position",new Ot(c,3)),this.setAttribute("normal",new Ot(h,3)),this.setAttribute("uv",new Ot(u,2));function g(x,m,p,M,v,y,w,S,A,P,_){let b=y/A,R=w/P,L=y/2,D=w/2,N=S/2,W=A+1,k=P+1,q=0,H=0,K=new C;for(let Q=0;Q<k;Q++){let at=Q*R-D;for(let Ct=0;Ct<W;Ct++){let qt=Ct*b-L;K[x]=qt*M,K[m]=at*v,K[p]=N,c.push(K.x,K.y,K.z),K[x]=0,K[m]=0,K[p]=S>0?1:-1,h.push(K.x,K.y,K.z),u.push(Ct/A),u.push(1-Q/P),q+=1}}for(let Q=0;Q<P;Q++)for(let at=0;at<A;at++){let Ct=d+at+W*Q,qt=d+at+W*(Q+1),Y=d+(at+1)+W*(Q+1),et=d+(at+1)+W*Q;l.push(Ct,qt,et),l.push(qt,Y,et),H+=6}a.addGroup(f,H,_),f+=H,d+=q}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}};function lr(i){let t={};for(let e in i){t[e]={};for(let n in i[e]){let s=i[e][n];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=s.clone():Array.isArray(s)?t[e][n]=s.slice():t[e][n]=s}}return t}function nn(i){let t={};for(let e=0;e<i.length;e++){let n=lr(i[e]);for(let s in n)t[s]=n[s]}return t}function Km(i){let t=[];for(let e=0;e<i.length;e++)t.push(i[e].clone());return t}function yf(i){let t=i.getRenderTarget();return t===null?i.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:ie.workingColorSpace}var mr={clone:lr,merge:nn},Jm=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,jm=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,dn=class extends vi{static get type(){return"ShaderMaterial"}constructor(t){super(),this.isShaderMaterial=!0,this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Jm,this.fragmentShader=jm,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=lr(t.uniforms),this.uniformsGroups=Km(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){let e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(let s in this.uniforms){let o=this.uniforms[s].value;o&&o.isTexture?e.uniforms[s]={type:"t",value:o.toJSON(t).uuid}:o&&o.isColor?e.uniforms[s]={type:"c",value:o.getHex()}:o&&o.isVector2?e.uniforms[s]={type:"v2",value:o.toArray()}:o&&o.isVector3?e.uniforms[s]={type:"v3",value:o.toArray()}:o&&o.isVector4?e.uniforms[s]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?e.uniforms[s]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?e.uniforms[s]={type:"m4",value:o.toArray()}:e.uniforms[s]={value:o}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;let n={};for(let s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}},_a=class extends Oe{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Wt,this.projectionMatrix=new Wt,this.projectionMatrixInverse=new Wt,this.coordinateSystem=mi}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},zi=new C,ud=new rt,dd=new rt,Be=class extends _a{constructor(t=50,e=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){let e=.5*this.getFilmHeight()/t;this.fov=Zr*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){let t=Math.tan(Vr*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return Zr*2*Math.atan(Math.tan(Vr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,e,n){zi.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),e.set(zi.x,zi.y).multiplyScalar(-t/zi.z),zi.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(zi.x,zi.y).multiplyScalar(-t/zi.z)}getViewSize(t,e){return this.getViewBounds(t,ud,dd),e.subVectors(dd,ud)}setViewOffset(t,e,n,s,r,o){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=this.near,e=t*Math.tan(Vr*.5*this.fov)/this.zoom,n=2*e,s=this.aspect*n,r=-.5*s,o=this.view;if(this.view!==null&&this.view.enabled){let l=o.fullWidth,c=o.fullHeight;r+=o.offsetX*s/l,e-=o.offsetY*n/c,s*=o.width/l,n*=o.height/c}let a=this.filmOffset;a!==0&&(r+=t*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,e,e-n,t,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}},Gs=-90,Ws=1,Yc=class extends Oe{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;let s=new Be(Gs,Ws,t,e);s.layers=this.layers,this.add(s);let r=new Be(Gs,Ws,t,e);r.layers=this.layers,this.add(r);let o=new Be(Gs,Ws,t,e);o.layers=this.layers,this.add(o);let a=new Be(Gs,Ws,t,e);a.layers=this.layers,this.add(a);let l=new Be(Gs,Ws,t,e);l.layers=this.layers,this.add(l);let c=new Be(Gs,Ws,t,e);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let t=this.coordinateSystem,e=this.children.concat(),[n,s,r,o,a,l]=e;for(let c of e)this.remove(c);if(t===mi)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(t===ma)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(let c of e)this.add(c),c.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();let{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());let[r,o,a,l,c,h]=this.children,u=t.getRenderTarget(),d=t.getActiveCubeFace(),f=t.getActiveMipmapLevel(),g=t.xr.enabled;t.xr.enabled=!1;let x=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,t.setRenderTarget(n,0,s),t.render(e,r),t.setRenderTarget(n,1,s),t.render(e,o),t.setRenderTarget(n,2,s),t.render(e,a),t.setRenderTarget(n,3,s),t.render(e,l),t.setRenderTarget(n,4,s),t.render(e,c),n.texture.generateMipmaps=x,t.setRenderTarget(n,5,s),t.render(e,h),t.setRenderTarget(u,d,f),t.xr.enabled=g,n.texture.needsPMREMUpdate=!0}},Ma=class extends hn{constructor(t,e,n,s,r,o,a,l,c,h){t=t!==void 0?t:[],e=e!==void 0?e:sr,super(t,e,n,s,r,o,a,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}},Zc=class extends Vn{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;let n={width:t,height:t,depth:1},s=[n,n,n,n,n,n];this.texture=new Ma(s,e.mapping,e.wrapS,e.wrapT,e.magFilter,e.minFilter,e.format,e.type,e.anisotropy,e.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=e.generateMipmaps!==void 0?e.generateMipmaps:!1,this.texture.minFilter=e.minFilter!==void 0?e.minFilter:In}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new $t(5,5,5),r=new dn({name:"CubemapFromEquirect",uniforms:lr(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Ke,blending:Oi});r.uniforms.tEquirect.value=e;let o=new nt(s,r),a=e.minFilter;return e.minFilter===pi&&(e.minFilter=In),new Yc(1,10,this).update(t,o),e.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(t,e,n,s){let r=t.getRenderTarget();for(let o=0;o<6;o++)t.setRenderTarget(this,o),t.clear(e,n,s);t.setRenderTarget(r)}},ql=new C,Qm=new C,t0=new Gt,bn=class{constructor(t=new C(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,s){return this.normal.set(t,e,n),this.constant=s,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){let s=ql.subVectors(n,e).cross(Qm.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(s,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){let t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){let n=t.delta(ql),s=this.normal.dot(n);if(s===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;let r=-(t.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:e.copy(t.start).addScaledVector(n,r)}intersectsLine(t){let e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){let n=e||t0.getNormalMatrix(t),s=this.coplanarPoint(ql).applyMatrix4(t),r=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}},rs=new Gi,Zo=new C,jr=class{constructor(t=new bn,e=new bn,n=new bn,s=new bn,r=new bn,o=new bn){this.planes=[t,e,n,s,r,o]}set(t,e,n,s,r,o){let a=this.planes;return a[0].copy(t),a[1].copy(e),a[2].copy(n),a[3].copy(s),a[4].copy(r),a[5].copy(o),this}copy(t){let e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=mi){let n=this.planes,s=t.elements,r=s[0],o=s[1],a=s[2],l=s[3],c=s[4],h=s[5],u=s[6],d=s[7],f=s[8],g=s[9],x=s[10],m=s[11],p=s[12],M=s[13],v=s[14],y=s[15];if(n[0].setComponents(l-r,d-c,m-f,y-p).normalize(),n[1].setComponents(l+r,d+c,m+f,y+p).normalize(),n[2].setComponents(l+o,d+h,m+g,y+M).normalize(),n[3].setComponents(l-o,d-h,m-g,y-M).normalize(),n[4].setComponents(l-a,d-u,m-x,y-v).normalize(),e===mi)n[5].setComponents(l+a,d+u,m+x,y+v).normalize();else if(e===ma)n[5].setComponents(a,u,x,v).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),rs.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{let e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),rs.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(rs)}intersectsSprite(t){return rs.center.set(0,0,0),rs.radius=.7071067811865476,rs.applyMatrix4(t.matrixWorld),this.intersectsSphere(rs)}intersectsSphere(t){let e=this.planes,n=t.center,s=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(n)<s)return!1;return!0}intersectsBox(t){let e=this.planes;for(let n=0;n<6;n++){let s=e[n];if(Zo.x=s.normal.x>0?t.max.x:t.min.x,Zo.y=s.normal.y>0?t.max.y:t.min.y,Zo.z=s.normal.z>0?t.max.z:t.min.z,s.distanceToPoint(Zo)<0)return!1}return!0}containsPoint(t){let e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function vf(){let i=null,t=!1,e=null,n=null;function s(r,o){e(r,o),n=i.requestAnimationFrame(s)}return{start:function(){t!==!0&&e!==null&&(n=i.requestAnimationFrame(s),t=!0)},stop:function(){i.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){i=r}}}function e0(i){let t=new WeakMap;function e(a,l){let c=a.array,h=a.usage,u=c.byteLength,d=i.createBuffer();i.bindBuffer(l,d),i.bufferData(l,c,h),a.onUploadCallback();let f;if(c instanceof Float32Array)f=i.FLOAT;else if(c instanceof Uint16Array)a.isFloat16BufferAttribute?f=i.HALF_FLOAT:f=i.UNSIGNED_SHORT;else if(c instanceof Int16Array)f=i.SHORT;else if(c instanceof Uint32Array)f=i.UNSIGNED_INT;else if(c instanceof Int32Array)f=i.INT;else if(c instanceof Int8Array)f=i.BYTE;else if(c instanceof Uint8Array)f=i.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)f=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:d,type:f,bytesPerElement:c.BYTES_PER_ELEMENT,version:a.version,size:u}}function n(a,l,c){let h=l.array,u=l.updateRanges;if(i.bindBuffer(c,a),u.length===0)i.bufferSubData(c,0,h);else{u.sort((f,g)=>f.start-g.start);let d=0;for(let f=1;f<u.length;f++){let g=u[d],x=u[f];x.start<=g.start+g.count+1?g.count=Math.max(g.count,x.start+x.count-g.start):(++d,u[d]=x)}u.length=d+1;for(let f=0,g=u.length;f<g;f++){let x=u[f];i.bufferSubData(c,x.start*h.BYTES_PER_ELEMENT,h,x.start,x.count)}l.clearUpdateRanges()}l.onUploadCallback()}function s(a){return a.isInterleavedBufferAttribute&&(a=a.data),t.get(a)}function r(a){a.isInterleavedBufferAttribute&&(a=a.data);let l=t.get(a);l&&(i.deleteBuffer(l.buffer),t.delete(a))}function o(a,l){if(a.isInterleavedBufferAttribute&&(a=a.data),a.isGLBufferAttribute){let h=t.get(a);(!h||h.version<a.version)&&t.set(a,{buffer:a.buffer,type:a.type,bytesPerElement:a.elementSize,version:a.version});return}let c=t.get(a);if(c===void 0)t.set(a,e(a,l));else if(c.version<a.version){if(c.size!==a.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,a,l),c.version=a.version}}return{get:s,remove:r,update:o}}var Mn=class i extends ae{constructor(t=1,e=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:s};let r=t/2,o=e/2,a=Math.floor(n),l=Math.floor(s),c=a+1,h=l+1,u=t/a,d=e/l,f=[],g=[],x=[],m=[];for(let p=0;p<h;p++){let M=p*d-o;for(let v=0;v<c;v++){let y=v*u-r;g.push(y,-M,0),x.push(0,0,1),m.push(v/a),m.push(1-p/l)}}for(let p=0;p<l;p++)for(let M=0;M<a;M++){let v=M+c*p,y=M+c*(p+1),w=M+1+c*(p+1),S=M+1+c*p;f.push(v,y,S),f.push(y,w,S)}this.setIndex(f),this.setAttribute("position",new Ot(g,3)),this.setAttribute("normal",new Ot(x,3)),this.setAttribute("uv",new Ot(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.width,t.height,t.widthSegments,t.heightSegments)}},n0=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,i0=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,s0=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,r0=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,o0=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,a0=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,l0=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,c0=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,h0=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,u0=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,d0=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,f0=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,p0=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,m0=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,g0=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,x0=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,y0=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,v0=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,b0=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,_0=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,M0=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,w0=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,S0=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,E0=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,T0=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,A0=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,R0=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,C0=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,P0=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,I0=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,L0="gl_FragColor = linearToOutputTexel( gl_FragColor );",D0=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,k0=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,U0=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,N0=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,z0=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,F0=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,B0=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,O0=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,H0=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,V0=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,G0=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,W0=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,$0=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,q0=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,X0=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,Y0=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,Z0=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,K0=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,J0=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,j0=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,Q0=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,tg=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,eg=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,ng=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,ig=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,sg=`#if defined( USE_LOGDEPTHBUF )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,rg=`#if defined( USE_LOGDEPTHBUF )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,og=`#ifdef USE_LOGDEPTHBUF
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,ag=`#ifdef USE_LOGDEPTHBUF
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,lg=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,cg=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,hg=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,ug=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,dg=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,fg=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,pg=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,mg=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,gg=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,xg=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,yg=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,vg=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,bg=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,_g=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Mg=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,wg=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Sg=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Eg=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Tg=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Ag=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Rg=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Cg=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Pg=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Ig=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Lg=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Dg=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,kg=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Ug=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Ng=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,zg=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,Fg=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,Bg=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Og=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Hg=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Vg=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Gg=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Wg=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,$g=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,qg=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Xg=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Yg=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Zg=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Kg=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
		
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
		
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		
		#else
		
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Jg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,jg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Qg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,tx=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,ex=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,nx=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,ix=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,sx=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,rx=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,ox=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,ax=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,lx=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,cx=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,hx=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,ux=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,dx=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,fx=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,px=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,mx=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,gx=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,xx=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,yx=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,vx=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,bx=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,_x=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Mx=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,wx=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Sx=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ex=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Tx=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ax=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Rx=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Cx=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Px=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Ix=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Lx=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Dx=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,kx=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Yt={alphahash_fragment:n0,alphahash_pars_fragment:i0,alphamap_fragment:s0,alphamap_pars_fragment:r0,alphatest_fragment:o0,alphatest_pars_fragment:a0,aomap_fragment:l0,aomap_pars_fragment:c0,batching_pars_vertex:h0,batching_vertex:u0,begin_vertex:d0,beginnormal_vertex:f0,bsdfs:p0,iridescence_fragment:m0,bumpmap_pars_fragment:g0,clipping_planes_fragment:x0,clipping_planes_pars_fragment:y0,clipping_planes_pars_vertex:v0,clipping_planes_vertex:b0,color_fragment:_0,color_pars_fragment:M0,color_pars_vertex:w0,color_vertex:S0,common:E0,cube_uv_reflection_fragment:T0,defaultnormal_vertex:A0,displacementmap_pars_vertex:R0,displacementmap_vertex:C0,emissivemap_fragment:P0,emissivemap_pars_fragment:I0,colorspace_fragment:L0,colorspace_pars_fragment:D0,envmap_fragment:k0,envmap_common_pars_fragment:U0,envmap_pars_fragment:N0,envmap_pars_vertex:z0,envmap_physical_pars_fragment:Y0,envmap_vertex:F0,fog_vertex:B0,fog_pars_vertex:O0,fog_fragment:H0,fog_pars_fragment:V0,gradientmap_pars_fragment:G0,lightmap_pars_fragment:W0,lights_lambert_fragment:$0,lights_lambert_pars_fragment:q0,lights_pars_begin:X0,lights_toon_fragment:Z0,lights_toon_pars_fragment:K0,lights_phong_fragment:J0,lights_phong_pars_fragment:j0,lights_physical_fragment:Q0,lights_physical_pars_fragment:tg,lights_fragment_begin:eg,lights_fragment_maps:ng,lights_fragment_end:ig,logdepthbuf_fragment:sg,logdepthbuf_pars_fragment:rg,logdepthbuf_pars_vertex:og,logdepthbuf_vertex:ag,map_fragment:lg,map_pars_fragment:cg,map_particle_fragment:hg,map_particle_pars_fragment:ug,metalnessmap_fragment:dg,metalnessmap_pars_fragment:fg,morphinstance_vertex:pg,morphcolor_vertex:mg,morphnormal_vertex:gg,morphtarget_pars_vertex:xg,morphtarget_vertex:yg,normal_fragment_begin:vg,normal_fragment_maps:bg,normal_pars_fragment:_g,normal_pars_vertex:Mg,normal_vertex:wg,normalmap_pars_fragment:Sg,clearcoat_normal_fragment_begin:Eg,clearcoat_normal_fragment_maps:Tg,clearcoat_pars_fragment:Ag,iridescence_pars_fragment:Rg,opaque_fragment:Cg,packing:Pg,premultiplied_alpha_fragment:Ig,project_vertex:Lg,dithering_fragment:Dg,dithering_pars_fragment:kg,roughnessmap_fragment:Ug,roughnessmap_pars_fragment:Ng,shadowmap_pars_fragment:zg,shadowmap_pars_vertex:Fg,shadowmap_vertex:Bg,shadowmask_pars_fragment:Og,skinbase_vertex:Hg,skinning_pars_vertex:Vg,skinning_vertex:Gg,skinnormal_vertex:Wg,specularmap_fragment:$g,specularmap_pars_fragment:qg,tonemapping_fragment:Xg,tonemapping_pars_fragment:Yg,transmission_fragment:Zg,transmission_pars_fragment:Kg,uv_pars_fragment:Jg,uv_pars_vertex:jg,uv_vertex:Qg,worldpos_vertex:tx,background_vert:ex,background_frag:nx,backgroundCube_vert:ix,backgroundCube_frag:sx,cube_vert:rx,cube_frag:ox,depth_vert:ax,depth_frag:lx,distanceRGBA_vert:cx,distanceRGBA_frag:hx,equirect_vert:ux,equirect_frag:dx,linedashed_vert:fx,linedashed_frag:px,meshbasic_vert:mx,meshbasic_frag:gx,meshlambert_vert:xx,meshlambert_frag:yx,meshmatcap_vert:vx,meshmatcap_frag:bx,meshnormal_vert:_x,meshnormal_frag:Mx,meshphong_vert:wx,meshphong_frag:Sx,meshphysical_vert:Ex,meshphysical_frag:Tx,meshtoon_vert:Ax,meshtoon_frag:Rx,points_vert:Cx,points_frag:Px,shadow_vert:Ix,shadow_frag:Lx,sprite_vert:Dx,sprite_frag:kx},ot={common:{diffuse:{value:new bt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Gt},alphaMap:{value:null},alphaMapTransform:{value:new Gt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Gt}},envmap:{envMap:{value:null},envMapRotation:{value:new Gt},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Gt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Gt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Gt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Gt},normalScale:{value:new rt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Gt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Gt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Gt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Gt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new bt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new bt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Gt},alphaTest:{value:0},uvTransform:{value:new Gt}},sprite:{diffuse:{value:new bt(16777215)},opacity:{value:1},center:{value:new rt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Gt},alphaMap:{value:null},alphaMapTransform:{value:new Gt},alphaTest:{value:0}}},Zn={basic:{uniforms:nn([ot.common,ot.specularmap,ot.envmap,ot.aomap,ot.lightmap,ot.fog]),vertexShader:Yt.meshbasic_vert,fragmentShader:Yt.meshbasic_frag},lambert:{uniforms:nn([ot.common,ot.specularmap,ot.envmap,ot.aomap,ot.lightmap,ot.emissivemap,ot.bumpmap,ot.normalmap,ot.displacementmap,ot.fog,ot.lights,{emissive:{value:new bt(0)}}]),vertexShader:Yt.meshlambert_vert,fragmentShader:Yt.meshlambert_frag},phong:{uniforms:nn([ot.common,ot.specularmap,ot.envmap,ot.aomap,ot.lightmap,ot.emissivemap,ot.bumpmap,ot.normalmap,ot.displacementmap,ot.fog,ot.lights,{emissive:{value:new bt(0)},specular:{value:new bt(1118481)},shininess:{value:30}}]),vertexShader:Yt.meshphong_vert,fragmentShader:Yt.meshphong_frag},standard:{uniforms:nn([ot.common,ot.envmap,ot.aomap,ot.lightmap,ot.emissivemap,ot.bumpmap,ot.normalmap,ot.displacementmap,ot.roughnessmap,ot.metalnessmap,ot.fog,ot.lights,{emissive:{value:new bt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Yt.meshphysical_vert,fragmentShader:Yt.meshphysical_frag},toon:{uniforms:nn([ot.common,ot.aomap,ot.lightmap,ot.emissivemap,ot.bumpmap,ot.normalmap,ot.displacementmap,ot.gradientmap,ot.fog,ot.lights,{emissive:{value:new bt(0)}}]),vertexShader:Yt.meshtoon_vert,fragmentShader:Yt.meshtoon_frag},matcap:{uniforms:nn([ot.common,ot.bumpmap,ot.normalmap,ot.displacementmap,ot.fog,{matcap:{value:null}}]),vertexShader:Yt.meshmatcap_vert,fragmentShader:Yt.meshmatcap_frag},points:{uniforms:nn([ot.points,ot.fog]),vertexShader:Yt.points_vert,fragmentShader:Yt.points_frag},dashed:{uniforms:nn([ot.common,ot.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Yt.linedashed_vert,fragmentShader:Yt.linedashed_frag},depth:{uniforms:nn([ot.common,ot.displacementmap]),vertexShader:Yt.depth_vert,fragmentShader:Yt.depth_frag},normal:{uniforms:nn([ot.common,ot.bumpmap,ot.normalmap,ot.displacementmap,{opacity:{value:1}}]),vertexShader:Yt.meshnormal_vert,fragmentShader:Yt.meshnormal_frag},sprite:{uniforms:nn([ot.sprite,ot.fog]),vertexShader:Yt.sprite_vert,fragmentShader:Yt.sprite_frag},background:{uniforms:{uvTransform:{value:new Gt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Yt.background_vert,fragmentShader:Yt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Gt}},vertexShader:Yt.backgroundCube_vert,fragmentShader:Yt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Yt.cube_vert,fragmentShader:Yt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Yt.equirect_vert,fragmentShader:Yt.equirect_frag},distanceRGBA:{uniforms:nn([ot.common,ot.displacementmap,{referencePosition:{value:new C},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Yt.distanceRGBA_vert,fragmentShader:Yt.distanceRGBA_frag},shadow:{uniforms:nn([ot.lights,ot.fog,{color:{value:new bt(0)},opacity:{value:1}}]),vertexShader:Yt.shadow_vert,fragmentShader:Yt.shadow_frag}};Zn.physical={uniforms:nn([Zn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Gt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Gt},clearcoatNormalScale:{value:new rt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Gt},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Gt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Gt},sheen:{value:0},sheenColor:{value:new bt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Gt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Gt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Gt},transmissionSamplerSize:{value:new rt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Gt},attenuationDistance:{value:0},attenuationColor:{value:new bt(0)},specularColor:{value:new bt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Gt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Gt},anisotropyVector:{value:new rt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Gt}}]),vertexShader:Yt.meshphysical_vert,fragmentShader:Yt.meshphysical_frag};var Ko={r:0,b:0,g:0},os=new un,Ux=new Wt;function Nx(i,t,e,n,s,r,o){let a=new bt(0),l=r===!0?0:1,c,h,u=null,d=0,f=null;function g(M){let v=M.isScene===!0?M.background:null;return v&&v.isTexture&&(v=(M.backgroundBlurriness>0?e:t).get(v)),v}function x(M){let v=!1,y=g(M);y===null?p(a,l):y&&y.isColor&&(p(y,1),v=!0);let w=i.xr.getEnvironmentBlendMode();w==="additive"?n.buffers.color.setClear(0,0,0,1,o):w==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,o),(i.autoClear||v)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function m(M,v){let y=g(v);y&&(y.isCubeTexture||y.mapping===$a)?(h===void 0&&(h=new nt(new $t(1,1,1),new dn({name:"BackgroundCubeMaterial",uniforms:lr(Zn.backgroundCube.uniforms),vertexShader:Zn.backgroundCube.vertexShader,fragmentShader:Zn.backgroundCube.fragmentShader,side:Ke,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(w,S,A){this.matrixWorld.copyPosition(A.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(h)),os.copy(v.backgroundRotation),os.x*=-1,os.y*=-1,os.z*=-1,y.isCubeTexture&&y.isRenderTargetTexture===!1&&(os.y*=-1,os.z*=-1),h.material.uniforms.envMap.value=y,h.material.uniforms.flipEnvMap.value=y.isCubeTexture&&y.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=v.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=v.backgroundIntensity,h.material.uniforms.backgroundRotation.value.setFromMatrix4(Ux.makeRotationFromEuler(os)),h.material.toneMapped=ie.getTransfer(y.colorSpace)!==pe,(u!==y||d!==y.version||f!==i.toneMapping)&&(h.material.needsUpdate=!0,u=y,d=y.version,f=i.toneMapping),h.layers.enableAll(),M.unshift(h,h.geometry,h.material,0,0,null)):y&&y.isTexture&&(c===void 0&&(c=new nt(new Mn(2,2),new dn({name:"BackgroundMaterial",uniforms:lr(Zn.background.uniforms),vertexShader:Zn.background.vertexShader,fragmentShader:Zn.background.fragmentShader,side:jn,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(c)),c.material.uniforms.t2D.value=y,c.material.uniforms.backgroundIntensity.value=v.backgroundIntensity,c.material.toneMapped=ie.getTransfer(y.colorSpace)!==pe,y.matrixAutoUpdate===!0&&y.updateMatrix(),c.material.uniforms.uvTransform.value.copy(y.matrix),(u!==y||d!==y.version||f!==i.toneMapping)&&(c.material.needsUpdate=!0,u=y,d=y.version,f=i.toneMapping),c.layers.enableAll(),M.unshift(c,c.geometry,c.material,0,0,null))}function p(M,v){M.getRGB(Ko,yf(i)),n.buffers.color.setClear(Ko.r,Ko.g,Ko.b,v,o)}return{getClearColor:function(){return a},setClearColor:function(M,v=1){a.set(M),l=v,p(a,l)},getClearAlpha:function(){return l},setClearAlpha:function(M){l=M,p(a,l)},render:x,addToRenderList:m}}function zx(i,t){let e=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},s=d(null),r=s,o=!1;function a(b,R,L,D,N){let W=!1,k=u(D,L,R);r!==k&&(r=k,c(r.object)),W=f(b,D,L,N),W&&g(b,D,L,N),N!==null&&t.update(N,i.ELEMENT_ARRAY_BUFFER),(W||o)&&(o=!1,y(b,R,L,D),N!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,t.get(N).buffer))}function l(){return i.createVertexArray()}function c(b){return i.bindVertexArray(b)}function h(b){return i.deleteVertexArray(b)}function u(b,R,L){let D=L.wireframe===!0,N=n[b.id];N===void 0&&(N={},n[b.id]=N);let W=N[R.id];W===void 0&&(W={},N[R.id]=W);let k=W[D];return k===void 0&&(k=d(l()),W[D]=k),k}function d(b){let R=[],L=[],D=[];for(let N=0;N<e;N++)R[N]=0,L[N]=0,D[N]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:R,enabledAttributes:L,attributeDivisors:D,object:b,attributes:{},index:null}}function f(b,R,L,D){let N=r.attributes,W=R.attributes,k=0,q=L.getAttributes();for(let H in q)if(q[H].location>=0){let Q=N[H],at=W[H];if(at===void 0&&(H==="instanceMatrix"&&b.instanceMatrix&&(at=b.instanceMatrix),H==="instanceColor"&&b.instanceColor&&(at=b.instanceColor)),Q===void 0||Q.attribute!==at||at&&Q.data!==at.data)return!0;k++}return r.attributesNum!==k||r.index!==D}function g(b,R,L,D){let N={},W=R.attributes,k=0,q=L.getAttributes();for(let H in q)if(q[H].location>=0){let Q=W[H];Q===void 0&&(H==="instanceMatrix"&&b.instanceMatrix&&(Q=b.instanceMatrix),H==="instanceColor"&&b.instanceColor&&(Q=b.instanceColor));let at={};at.attribute=Q,Q&&Q.data&&(at.data=Q.data),N[H]=at,k++}r.attributes=N,r.attributesNum=k,r.index=D}function x(){let b=r.newAttributes;for(let R=0,L=b.length;R<L;R++)b[R]=0}function m(b){p(b,0)}function p(b,R){let L=r.newAttributes,D=r.enabledAttributes,N=r.attributeDivisors;L[b]=1,D[b]===0&&(i.enableVertexAttribArray(b),D[b]=1),N[b]!==R&&(i.vertexAttribDivisor(b,R),N[b]=R)}function M(){let b=r.newAttributes,R=r.enabledAttributes;for(let L=0,D=R.length;L<D;L++)R[L]!==b[L]&&(i.disableVertexAttribArray(L),R[L]=0)}function v(b,R,L,D,N,W,k){k===!0?i.vertexAttribIPointer(b,R,L,N,W):i.vertexAttribPointer(b,R,L,D,N,W)}function y(b,R,L,D){x();let N=D.attributes,W=L.getAttributes(),k=R.defaultAttributeValues;for(let q in W){let H=W[q];if(H.location>=0){let K=N[q];if(K===void 0&&(q==="instanceMatrix"&&b.instanceMatrix&&(K=b.instanceMatrix),q==="instanceColor"&&b.instanceColor&&(K=b.instanceColor)),K!==void 0){let Q=K.normalized,at=K.itemSize,Ct=t.get(K);if(Ct===void 0)continue;let qt=Ct.buffer,Y=Ct.type,et=Ct.bytesPerElement,vt=Y===i.INT||Y===i.UNSIGNED_INT||K.gpuType===Lh;if(K.isInterleavedBufferAttribute){let ct=K.data,kt=ct.stride,Bt=K.offset;if(ct.isInstancedInterleavedBuffer){for(let Zt=0;Zt<H.locationSize;Zt++)p(H.location+Zt,ct.meshPerAttribute);b.isInstancedMesh!==!0&&D._maxInstanceCount===void 0&&(D._maxInstanceCount=ct.meshPerAttribute*ct.count)}else for(let Zt=0;Zt<H.locationSize;Zt++)m(H.location+Zt);i.bindBuffer(i.ARRAY_BUFFER,qt);for(let Zt=0;Zt<H.locationSize;Zt++)v(H.location+Zt,at/H.locationSize,Y,Q,kt*et,(Bt+at/H.locationSize*Zt)*et,vt)}else{if(K.isInstancedBufferAttribute){for(let ct=0;ct<H.locationSize;ct++)p(H.location+ct,K.meshPerAttribute);b.isInstancedMesh!==!0&&D._maxInstanceCount===void 0&&(D._maxInstanceCount=K.meshPerAttribute*K.count)}else for(let ct=0;ct<H.locationSize;ct++)m(H.location+ct);i.bindBuffer(i.ARRAY_BUFFER,qt);for(let ct=0;ct<H.locationSize;ct++)v(H.location+ct,at/H.locationSize,Y,Q,at*et,at/H.locationSize*ct*et,vt)}}else if(k!==void 0){let Q=k[q];if(Q!==void 0)switch(Q.length){case 2:i.vertexAttrib2fv(H.location,Q);break;case 3:i.vertexAttrib3fv(H.location,Q);break;case 4:i.vertexAttrib4fv(H.location,Q);break;default:i.vertexAttrib1fv(H.location,Q)}}}}M()}function w(){P();for(let b in n){let R=n[b];for(let L in R){let D=R[L];for(let N in D)h(D[N].object),delete D[N];delete R[L]}delete n[b]}}function S(b){if(n[b.id]===void 0)return;let R=n[b.id];for(let L in R){let D=R[L];for(let N in D)h(D[N].object),delete D[N];delete R[L]}delete n[b.id]}function A(b){for(let R in n){let L=n[R];if(L[b.id]===void 0)continue;let D=L[b.id];for(let N in D)h(D[N].object),delete D[N];delete L[b.id]}}function P(){_(),o=!0,r!==s&&(r=s,c(r.object))}function _(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:a,reset:P,resetDefaultState:_,dispose:w,releaseStatesOfGeometry:S,releaseStatesOfProgram:A,initAttributes:x,enableAttribute:m,disableUnusedAttributes:M}}function Fx(i,t,e){let n;function s(c){n=c}function r(c,h){i.drawArrays(n,c,h),e.update(h,n,1)}function o(c,h,u){u!==0&&(i.drawArraysInstanced(n,c,h,u),e.update(h,n,u))}function a(c,h,u){if(u===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,c,0,h,0,u);let f=0;for(let g=0;g<u;g++)f+=h[g];e.update(f,n,1)}function l(c,h,u,d){if(u===0)return;let f=t.get("WEBGL_multi_draw");if(f===null)for(let g=0;g<c.length;g++)o(c[g],h[g],d[g]);else{f.multiDrawArraysInstancedWEBGL(n,c,0,h,0,d,0,u);let g=0;for(let x=0;x<u;x++)g+=h[x]*d[x];e.update(g,n,1)}}this.setMode=s,this.render=r,this.renderInstances=o,this.renderMultiDraw=a,this.renderMultiDrawInstances=l}function Bx(i,t,e,n){let s;function r(){if(s!==void 0)return s;if(t.has("EXT_texture_filter_anisotropic")===!0){let A=t.get("EXT_texture_filter_anisotropic");s=i.getParameter(A.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function o(A){return!(A!==Hn&&n.convert(A)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function a(A){let P=A===ho&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(A!==xi&&n.convert(A)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE)&&A!==Kn&&!P)}function l(A){if(A==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";A="mediump"}return A==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=e.precision!==void 0?e.precision:"highp",h=l(c);h!==c&&(console.warn("THREE.WebGLRenderer:",c,"not supported, using",h,"instead."),c=h);let u=e.logarithmicDepthBuffer===!0,d=e.reverseDepthBuffer===!0&&t.has("EXT_clip_control"),f=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),g=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),x=i.getParameter(i.MAX_TEXTURE_SIZE),m=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),p=i.getParameter(i.MAX_VERTEX_ATTRIBS),M=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),v=i.getParameter(i.MAX_VARYING_VECTORS),y=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),w=g>0,S=i.getParameter(i.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:l,textureFormatReadable:o,textureTypeReadable:a,precision:c,logarithmicDepthBuffer:u,reverseDepthBuffer:d,maxTextures:f,maxVertexTextures:g,maxTextureSize:x,maxCubemapSize:m,maxAttributes:p,maxVertexUniforms:M,maxVaryings:v,maxFragmentUniforms:y,vertexTextures:w,maxSamples:S}}function Ox(i){let t=this,e=null,n=0,s=!1,r=!1,o=new bn,a=new Gt,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,d){let f=u.length!==0||d||n!==0||s;return s=d,n=u.length,f},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(u,d){e=h(u,d,0)},this.setState=function(u,d,f){let g=u.clippingPlanes,x=u.clipIntersection,m=u.clipShadows,p=i.get(u);if(!s||g===null||g.length===0||r&&!m)r?h(null):c();else{let M=r?0:n,v=M*4,y=p.clippingState||null;l.value=y,y=h(g,d,v,f);for(let w=0;w!==v;++w)y[w]=e[w];p.clippingState=y,this.numIntersection=x?this.numPlanes:0,this.numPlanes+=M}};function c(){l.value!==e&&(l.value=e,l.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function h(u,d,f,g){let x=u!==null?u.length:0,m=null;if(x!==0){if(m=l.value,g!==!0||m===null){let p=f+x*4,M=d.matrixWorldInverse;a.getNormalMatrix(M),(m===null||m.length<p)&&(m=new Float32Array(p));for(let v=0,y=f;v!==x;++v,y+=4)o.copy(u[v]).applyMatrix4(M,a),o.normal.toArray(m,y),m[y+3]=o.constant}l.value=m,l.needsUpdate=!0}return t.numPlanes=x,t.numIntersection=0,m}}function Hx(i){let t=new WeakMap;function e(o,a){return a===pc?o.mapping=sr:a===mc&&(o.mapping=rr),o}function n(o){if(o&&o.isTexture){let a=o.mapping;if(a===pc||a===mc)if(t.has(o)){let l=t.get(o).texture;return e(l,o.mapping)}else{let l=o.image;if(l&&l.height>0){let c=new Zc(l.height);return c.fromEquirectangularTexture(i,o),t.set(o,c),o.addEventListener("dispose",s),e(c.texture,o.mapping)}else return null}}return o}function s(o){let a=o.target;a.removeEventListener("dispose",s);let l=t.get(a);l!==void 0&&(t.delete(a),l.dispose())}function r(){t=new WeakMap}return{get:n,dispose:r}}var wa=class extends _a{constructor(t=-1,e=1,n=1,s=-1,r=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=s,this.near=r,this.far=o,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,s,r,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2,r=n-t,o=n+t,a=s+e,l=s-e;if(this.view!==null&&this.view.enabled){let c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=c*this.view.offsetX,o=r+c*this.view.width,a-=h*this.view.offsetY,l=a-h*this.view.height}this.projectionMatrix.makeOrthographic(r,o,a,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}},Js=4,fd=[.125,.215,.35,.446,.526,.582],hs=20,Xl=new wa,pd=new bt,Yl=null,Zl=0,Kl=0,Jl=!1,ls=(1+Math.sqrt(5))/2,$s=1/ls,md=[new C(-ls,$s,0),new C(ls,$s,0),new C(-$s,0,ls),new C($s,0,ls),new C(0,ls,-$s),new C(0,ls,$s),new C(-1,1,-1),new C(1,1,-1),new C(-1,1,1),new C(1,1,1)],cr=class{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,n=.1,s=100){Yl=this._renderer.getRenderTarget(),Zl=this._renderer.getActiveCubeFace(),Kl=this._renderer.getActiveMipmapLevel(),Jl=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(256);let r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(t,n,s,r),e>0&&this._blur(r,0,0,e),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=yd(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=xd(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(Yl,Zl,Kl),this._renderer.xr.enabled=Jl,t.scissorTest=!1,Jo(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===sr||t.mapping===rr?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),Yl=this._renderer.getRenderTarget(),Zl=this._renderer.getActiveCubeFace(),Kl=this._renderer.getActiveMipmapLevel(),Jl=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;let n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:In,minFilter:In,generateMipmaps:!1,type:ho,format:Hn,colorSpace:fr,depthBuffer:!1},s=gd(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=gd(t,e,n);let{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Vx(r)),this._blurMaterial=Gx(r,t,e)}return s}_compileMaterial(t){let e=new nt(this._lodPlanes[0],t);this._renderer.compile(e,Xl)}_sceneToCubeUV(t,e,n,s){let a=new Be(90,1,e,n),l=[1,-1,1,1,1,1],c=[1,1,1,-1,-1,-1],h=this._renderer,u=h.autoClear,d=h.toneMapping;h.getClearColor(pd),h.toneMapping=Hi,h.autoClear=!1;let f=new Le({name:"PMREM.Background",side:Ke,depthWrite:!1,depthTest:!1}),g=new nt(new $t,f),x=!1,m=t.background;m?m.isColor&&(f.color.copy(m),t.background=null,x=!0):(f.color.copy(pd),x=!0);for(let p=0;p<6;p++){let M=p%3;M===0?(a.up.set(0,l[p],0),a.lookAt(c[p],0,0)):M===1?(a.up.set(0,0,l[p]),a.lookAt(0,c[p],0)):(a.up.set(0,l[p],0),a.lookAt(0,0,c[p]));let v=this._cubeSize;Jo(s,M*v,p>2?v:0,v,v),h.setRenderTarget(s),x&&h.render(g,a),h.render(t,a)}g.geometry.dispose(),g.material.dispose(),h.toneMapping=d,h.autoClear=u,t.background=m}_textureToCubeUV(t,e){let n=this._renderer,s=t.mapping===sr||t.mapping===rr;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=yd()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=xd());let r=s?this._cubemapMaterial:this._equirectMaterial,o=new nt(this._lodPlanes[0],r),a=r.uniforms;a.envMap.value=t;let l=this._cubeSize;Jo(e,0,0,3*l,2*l),n.setRenderTarget(e),n.render(o,Xl)}_applyPMREM(t){let e=this._renderer,n=e.autoClear;e.autoClear=!1;let s=this._lodPlanes.length;for(let r=1;r<s;r++){let o=Math.sqrt(this._sigmas[r]*this._sigmas[r]-this._sigmas[r-1]*this._sigmas[r-1]),a=md[(s-r-1)%md.length];this._blur(t,r-1,r,o,a)}e.autoClear=n}_blur(t,e,n,s,r){let o=this._pingPongRenderTarget;this._halfBlur(t,o,e,n,s,"latitudinal",r),this._halfBlur(o,t,n,n,s,"longitudinal",r)}_halfBlur(t,e,n,s,r,o,a){let l=this._renderer,c=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let h=3,u=new nt(this._lodPlanes[s],c),d=c.uniforms,f=this._sizeLods[n]-1,g=isFinite(r)?Math.PI/(2*f):2*Math.PI/(2*hs-1),x=r/g,m=isFinite(r)?1+Math.floor(h*x):hs;m>hs&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${hs}`);let p=[],M=0;for(let A=0;A<hs;++A){let P=A/x,_=Math.exp(-P*P/2);p.push(_),A===0?M+=_:A<m&&(M+=2*_)}for(let A=0;A<p.length;A++)p[A]=p[A]/M;d.envMap.value=t.texture,d.samples.value=m,d.weights.value=p,d.latitudinal.value=o==="latitudinal",a&&(d.poleAxis.value=a);let{_lodMax:v}=this;d.dTheta.value=g,d.mipInt.value=v-n;let y=this._sizeLods[s],w=3*y*(s>v-Js?s-v+Js:0),S=4*(this._cubeSize-y);Jo(e,w,S,3*y,2*y),l.setRenderTarget(e),l.render(u,Xl)}};function Vx(i){let t=[],e=[],n=[],s=i,r=i-Js+1+fd.length;for(let o=0;o<r;o++){let a=Math.pow(2,s);e.push(a);let l=1/a;o>i-Js?l=fd[o-i+Js-1]:o===0&&(l=0),n.push(l);let c=1/(a-2),h=-c,u=1+c,d=[h,h,u,h,u,u,h,h,u,u,h,u],f=6,g=6,x=3,m=2,p=1,M=new Float32Array(x*g*f),v=new Float32Array(m*g*f),y=new Float32Array(p*g*f);for(let S=0;S<f;S++){let A=S%3*2/3-1,P=S>2?0:-1,_=[A,P,0,A+2/3,P,0,A+2/3,P+1,0,A,P,0,A+2/3,P+1,0,A,P+1,0];M.set(_,x*g*S),v.set(d,m*g*S);let b=[S,S,S,S,S,S];y.set(b,p*g*S)}let w=new ae;w.setAttribute("position",new Ne(M,x)),w.setAttribute("uv",new Ne(v,m)),w.setAttribute("faceIndex",new Ne(y,p)),t.push(w),s>Js&&s--}return{lodPlanes:t,sizeLods:e,sigmas:n}}function gd(i,t,e){let n=new Vn(i,t,e);return n.texture.mapping=$a,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function Jo(i,t,e,n,s){i.viewport.set(t,e,n,s),i.scissor.set(t,e,n,s)}function Gx(i,t,e){let n=new Float32Array(hs),s=new C(0,1,0);return new dn({name:"SphericalGaussianBlur",defines:{n:hs,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:Oh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Oi,depthTest:!1,depthWrite:!1})}function xd(){return new dn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Oh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Oi,depthTest:!1,depthWrite:!1})}function yd(){return new dn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Oh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Oi,depthTest:!1,depthWrite:!1})}function Oh(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function Wx(i){let t=new WeakMap,e=null;function n(a){if(a&&a.isTexture){let l=a.mapping,c=l===pc||l===mc,h=l===sr||l===rr;if(c||h){let u=t.get(a),d=u!==void 0?u.texture.pmremVersion:0;if(a.isRenderTargetTexture&&a.pmremVersion!==d)return e===null&&(e=new cr(i)),u=c?e.fromEquirectangular(a,u):e.fromCubemap(a,u),u.texture.pmremVersion=a.pmremVersion,t.set(a,u),u.texture;if(u!==void 0)return u.texture;{let f=a.image;return c&&f&&f.height>0||h&&f&&s(f)?(e===null&&(e=new cr(i)),u=c?e.fromEquirectangular(a):e.fromCubemap(a),u.texture.pmremVersion=a.pmremVersion,t.set(a,u),a.addEventListener("dispose",r),u.texture):null}}}return a}function s(a){let l=0,c=6;for(let h=0;h<c;h++)a[h]!==void 0&&l++;return l===c}function r(a){let l=a.target;l.removeEventListener("dispose",r);let c=t.get(l);c!==void 0&&(t.delete(l),c.dispose())}function o(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:n,dispose:o}}function $x(i){let t={};function e(n){if(t[n]!==void 0)return t[n];let s;switch(n){case"WEBGL_depth_texture":s=i.getExtension("WEBGL_depth_texture")||i.getExtension("MOZ_WEBGL_depth_texture")||i.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=i.getExtension("EXT_texture_filter_anisotropic")||i.getExtension("MOZ_EXT_texture_filter_anisotropic")||i.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=i.getExtension("WEBGL_compressed_texture_s3tc")||i.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=i.getExtension("WEBGL_compressed_texture_pvrtc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=i.getExtension(n)}return t[n]=s,s}return{has:function(n){return e(n)!==null},init:function(){e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance"),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture"),e("WEBGL_render_shared_exponent")},get:function(n){let s=e(n);return s===null&&Or("THREE.WebGLRenderer: "+n+" extension not supported."),s}}}function qx(i,t,e,n){let s={},r=new WeakMap;function o(u){let d=u.target;d.index!==null&&t.remove(d.index);for(let g in d.attributes)t.remove(d.attributes[g]);for(let g in d.morphAttributes){let x=d.morphAttributes[g];for(let m=0,p=x.length;m<p;m++)t.remove(x[m])}d.removeEventListener("dispose",o),delete s[d.id];let f=r.get(d);f&&(t.remove(f),r.delete(d)),n.releaseStatesOfGeometry(d),d.isInstancedBufferGeometry===!0&&delete d._maxInstanceCount,e.memory.geometries--}function a(u,d){return s[d.id]===!0||(d.addEventListener("dispose",o),s[d.id]=!0,e.memory.geometries++),d}function l(u){let d=u.attributes;for(let g in d)t.update(d[g],i.ARRAY_BUFFER);let f=u.morphAttributes;for(let g in f){let x=f[g];for(let m=0,p=x.length;m<p;m++)t.update(x[m],i.ARRAY_BUFFER)}}function c(u){let d=[],f=u.index,g=u.attributes.position,x=0;if(f!==null){let M=f.array;x=f.version;for(let v=0,y=M.length;v<y;v+=3){let w=M[v+0],S=M[v+1],A=M[v+2];d.push(w,S,S,A,A,w)}}else if(g!==void 0){let M=g.array;x=g.version;for(let v=0,y=M.length/3-1;v<y;v+=3){let w=v+0,S=v+1,A=v+2;d.push(w,S,S,A,A,w)}}else return;let m=new(gf(d)?ba:va)(d,1);m.version=x;let p=r.get(u);p&&t.remove(p),r.set(u,m)}function h(u){let d=r.get(u);if(d){let f=u.index;f!==null&&d.version<f.version&&c(u)}else c(u);return r.get(u)}return{get:a,update:l,getWireframeAttribute:h}}function Xx(i,t,e){let n;function s(d){n=d}let r,o;function a(d){r=d.type,o=d.bytesPerElement}function l(d,f){i.drawElements(n,f,r,d*o),e.update(f,n,1)}function c(d,f,g){g!==0&&(i.drawElementsInstanced(n,f,r,d*o,g),e.update(f,n,g))}function h(d,f,g){if(g===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,f,0,r,d,0,g);let m=0;for(let p=0;p<g;p++)m+=f[p];e.update(m,n,1)}function u(d,f,g,x){if(g===0)return;let m=t.get("WEBGL_multi_draw");if(m===null)for(let p=0;p<d.length;p++)c(d[p]/o,f[p],x[p]);else{m.multiDrawElementsInstancedWEBGL(n,f,0,r,d,0,x,0,g);let p=0;for(let M=0;M<g;M++)p+=f[M]*x[M];e.update(p,n,1)}}this.setMode=s,this.setIndex=a,this.render=l,this.renderInstances=c,this.renderMultiDraw=h,this.renderMultiDrawInstances=u}function Yx(i){let t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,o,a){switch(e.calls++,o){case i.TRIANGLES:e.triangles+=a*(r/3);break;case i.LINES:e.lines+=a*(r/2);break;case i.LINE_STRIP:e.lines+=a*(r-1);break;case i.LINE_LOOP:e.lines+=a*r;break;case i.POINTS:e.points+=a*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",o);break}}function s(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:s,update:n}}function Zx(i,t,e){let n=new WeakMap,s=new Me;function r(o,a,l){let c=o.morphTargetInfluences,h=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,u=h!==void 0?h.length:0,d=n.get(a);if(d===void 0||d.count!==u){let _=function(){A.dispose(),n.delete(a),a.removeEventListener("dispose",_)};d!==void 0&&d.texture.dispose();let f=a.morphAttributes.position!==void 0,g=a.morphAttributes.normal!==void 0,x=a.morphAttributes.color!==void 0,m=a.morphAttributes.position||[],p=a.morphAttributes.normal||[],M=a.morphAttributes.color||[],v=0;f===!0&&(v=1),g===!0&&(v=2),x===!0&&(v=3);let y=a.attributes.position.count*v,w=1;y>t.maxTextureSize&&(w=Math.ceil(y/t.maxTextureSize),y=t.maxTextureSize);let S=new Float32Array(y*w*4*u),A=new ya(S,y,w,u);A.type=Kn,A.needsUpdate=!0;let P=v*4;for(let b=0;b<u;b++){let R=m[b],L=p[b],D=M[b],N=y*w*4*b;for(let W=0;W<R.count;W++){let k=W*P;f===!0&&(s.fromBufferAttribute(R,W),S[N+k+0]=s.x,S[N+k+1]=s.y,S[N+k+2]=s.z,S[N+k+3]=0),g===!0&&(s.fromBufferAttribute(L,W),S[N+k+4]=s.x,S[N+k+5]=s.y,S[N+k+6]=s.z,S[N+k+7]=0),x===!0&&(s.fromBufferAttribute(D,W),S[N+k+8]=s.x,S[N+k+9]=s.y,S[N+k+10]=s.z,S[N+k+11]=D.itemSize===4?s.w:1)}}d={count:u,texture:A,size:new rt(y,w)},n.set(a,d),a.addEventListener("dispose",_)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)l.getUniforms().setValue(i,"morphTexture",o.morphTexture,e);else{let f=0;for(let x=0;x<c.length;x++)f+=c[x];let g=a.morphTargetsRelative?1:1-f;l.getUniforms().setValue(i,"morphTargetBaseInfluence",g),l.getUniforms().setValue(i,"morphTargetInfluences",c)}l.getUniforms().setValue(i,"morphTargetsTexture",d.texture,e),l.getUniforms().setValue(i,"morphTargetsTextureSize",d.size)}return{update:r}}function Kx(i,t,e,n){let s=new WeakMap;function r(l){let c=n.render.frame,h=l.geometry,u=t.get(l,h);if(s.get(u)!==c&&(t.update(u),s.set(u,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",a)===!1&&l.addEventListener("dispose",a),s.get(l)!==c&&(e.update(l.instanceMatrix,i.ARRAY_BUFFER),l.instanceColor!==null&&e.update(l.instanceColor,i.ARRAY_BUFFER),s.set(l,c))),l.isSkinnedMesh){let d=l.skeleton;s.get(d)!==c&&(d.update(),s.set(d,c))}return u}function o(){s=new WeakMap}function a(l){let c=l.target;c.removeEventListener("dispose",a),e.remove(c.instanceMatrix),c.instanceColor!==null&&e.remove(c.instanceColor)}return{update:r,dispose:o}}var Sa=class extends hn{constructor(t,e,n,s,r,o,a,l,c,h=tr){if(h!==tr&&h!==ar)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&h===tr&&(n=fs),n===void 0&&h===ar&&(n=or),super(null,s,r,o,a,l,h,n,c),this.isDepthTexture=!0,this.image={width:t,height:e},this.magFilter=a!==void 0?a:_n,this.minFilter=l!==void 0?l:_n,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.compareFunction=t.compareFunction,this}toJSON(t){let e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}},bf=new hn,vd=new Sa(1,1),_f=new ya,Mf=new Xc,wf=new Ma,bd=[],_d=[],Md=new Float32Array(16),wd=new Float32Array(9),Sd=new Float32Array(4);function gr(i,t,e){let n=i[0];if(n<=0||n>0)return i;let s=t*e,r=bd[s];if(r===void 0&&(r=new Float32Array(s),bd[s]=r),t!==0){n.toArray(r,0);for(let o=1,a=0;o!==t;++o)a+=e,i[o].toArray(r,a)}return r}function He(i,t){if(i.length!==t.length)return!1;for(let e=0,n=i.length;e<n;e++)if(i[e]!==t[e])return!1;return!0}function Ve(i,t){for(let e=0,n=t.length;e<n;e++)i[e]=t[e]}function Xa(i,t){let e=_d[t];e===void 0&&(e=new Int32Array(t),_d[t]=e);for(let n=0;n!==t;++n)e[n]=i.allocateTextureUnit();return e}function Jx(i,t){let e=this.cache;e[0]!==t&&(i.uniform1f(this.addr,t),e[0]=t)}function jx(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(He(e,t))return;i.uniform2fv(this.addr,t),Ve(e,t)}}function Qx(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(i.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(He(e,t))return;i.uniform3fv(this.addr,t),Ve(e,t)}}function ty(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(He(e,t))return;i.uniform4fv(this.addr,t),Ve(e,t)}}function ey(i,t){let e=this.cache,n=t.elements;if(n===void 0){if(He(e,t))return;i.uniformMatrix2fv(this.addr,!1,t),Ve(e,t)}else{if(He(e,n))return;Sd.set(n),i.uniformMatrix2fv(this.addr,!1,Sd),Ve(e,n)}}function ny(i,t){let e=this.cache,n=t.elements;if(n===void 0){if(He(e,t))return;i.uniformMatrix3fv(this.addr,!1,t),Ve(e,t)}else{if(He(e,n))return;wd.set(n),i.uniformMatrix3fv(this.addr,!1,wd),Ve(e,n)}}function iy(i,t){let e=this.cache,n=t.elements;if(n===void 0){if(He(e,t))return;i.uniformMatrix4fv(this.addr,!1,t),Ve(e,t)}else{if(He(e,n))return;Md.set(n),i.uniformMatrix4fv(this.addr,!1,Md),Ve(e,n)}}function sy(i,t){let e=this.cache;e[0]!==t&&(i.uniform1i(this.addr,t),e[0]=t)}function ry(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(He(e,t))return;i.uniform2iv(this.addr,t),Ve(e,t)}}function oy(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(He(e,t))return;i.uniform3iv(this.addr,t),Ve(e,t)}}function ay(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(He(e,t))return;i.uniform4iv(this.addr,t),Ve(e,t)}}function ly(i,t){let e=this.cache;e[0]!==t&&(i.uniform1ui(this.addr,t),e[0]=t)}function cy(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(He(e,t))return;i.uniform2uiv(this.addr,t),Ve(e,t)}}function hy(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(He(e,t))return;i.uniform3uiv(this.addr,t),Ve(e,t)}}function uy(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(He(e,t))return;i.uniform4uiv(this.addr,t),Ve(e,t)}}function dy(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r;this.type===i.SAMPLER_2D_SHADOW?(vd.compareFunction=mf,r=vd):r=bf,e.setTexture2D(t||r,s)}function fy(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture3D(t||Mf,s)}function py(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTextureCube(t||wf,s)}function my(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture2DArray(t||_f,s)}function gy(i){switch(i){case 5126:return Jx;case 35664:return jx;case 35665:return Qx;case 35666:return ty;case 35674:return ey;case 35675:return ny;case 35676:return iy;case 5124:case 35670:return sy;case 35667:case 35671:return ry;case 35668:case 35672:return oy;case 35669:case 35673:return ay;case 5125:return ly;case 36294:return cy;case 36295:return hy;case 36296:return uy;case 35678:case 36198:case 36298:case 36306:case 35682:return dy;case 35679:case 36299:case 36307:return fy;case 35680:case 36300:case 36308:case 36293:return py;case 36289:case 36303:case 36311:case 36292:return my}}function xy(i,t){i.uniform1fv(this.addr,t)}function yy(i,t){let e=gr(t,this.size,2);i.uniform2fv(this.addr,e)}function vy(i,t){let e=gr(t,this.size,3);i.uniform3fv(this.addr,e)}function by(i,t){let e=gr(t,this.size,4);i.uniform4fv(this.addr,e)}function _y(i,t){let e=gr(t,this.size,4);i.uniformMatrix2fv(this.addr,!1,e)}function My(i,t){let e=gr(t,this.size,9);i.uniformMatrix3fv(this.addr,!1,e)}function wy(i,t){let e=gr(t,this.size,16);i.uniformMatrix4fv(this.addr,!1,e)}function Sy(i,t){i.uniform1iv(this.addr,t)}function Ey(i,t){i.uniform2iv(this.addr,t)}function Ty(i,t){i.uniform3iv(this.addr,t)}function Ay(i,t){i.uniform4iv(this.addr,t)}function Ry(i,t){i.uniform1uiv(this.addr,t)}function Cy(i,t){i.uniform2uiv(this.addr,t)}function Py(i,t){i.uniform3uiv(this.addr,t)}function Iy(i,t){i.uniform4uiv(this.addr,t)}function Ly(i,t,e){let n=this.cache,s=t.length,r=Xa(e,s);He(n,r)||(i.uniform1iv(this.addr,r),Ve(n,r));for(let o=0;o!==s;++o)e.setTexture2D(t[o]||bf,r[o])}function Dy(i,t,e){let n=this.cache,s=t.length,r=Xa(e,s);He(n,r)||(i.uniform1iv(this.addr,r),Ve(n,r));for(let o=0;o!==s;++o)e.setTexture3D(t[o]||Mf,r[o])}function ky(i,t,e){let n=this.cache,s=t.length,r=Xa(e,s);He(n,r)||(i.uniform1iv(this.addr,r),Ve(n,r));for(let o=0;o!==s;++o)e.setTextureCube(t[o]||wf,r[o])}function Uy(i,t,e){let n=this.cache,s=t.length,r=Xa(e,s);He(n,r)||(i.uniform1iv(this.addr,r),Ve(n,r));for(let o=0;o!==s;++o)e.setTexture2DArray(t[o]||_f,r[o])}function Ny(i){switch(i){case 5126:return xy;case 35664:return yy;case 35665:return vy;case 35666:return by;case 35674:return _y;case 35675:return My;case 35676:return wy;case 5124:case 35670:return Sy;case 35667:case 35671:return Ey;case 35668:case 35672:return Ty;case 35669:case 35673:return Ay;case 5125:return Ry;case 36294:return Cy;case 36295:return Py;case 36296:return Iy;case 35678:case 36198:case 36298:case 36306:case 35682:return Ly;case 35679:case 36299:case 36307:return Dy;case 35680:case 36300:case 36308:case 36293:return ky;case 36289:case 36303:case 36311:case 36292:return Uy}}var Kc=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=gy(e.type)}},Jc=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=Ny(e.type)}},jc=class{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){let s=this.seq;for(let r=0,o=s.length;r!==o;++r){let a=s[r];a.setValue(t,e[a.id],n)}}},jl=/(\w+)(\])?(\[|\.)?/g;function Ed(i,t){i.seq.push(t),i.map[t.id]=t}function zy(i,t,e){let n=i.name,s=n.length;for(jl.lastIndex=0;;){let r=jl.exec(n),o=jl.lastIndex,a=r[1],l=r[2]==="]",c=r[3];if(l&&(a=a|0),c===void 0||c==="["&&o+2===s){Ed(e,c===void 0?new Kc(a,i,t):new Jc(a,i,t));break}else{let u=e.map[a];u===void 0&&(u=new jc(a),Ed(e,u)),e=u}}}var nr=class{constructor(t,e){this.seq=[],this.map={};let n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let s=0;s<n;++s){let r=t.getActiveUniform(e,s),o=t.getUniformLocation(e,r.name);zy(r,o,this)}}setValue(t,e,n,s){let r=this.map[e];r!==void 0&&r.setValue(t,n,s)}setOptional(t,e,n){let s=e[n];s!==void 0&&this.setValue(t,n,s)}static upload(t,e,n,s){for(let r=0,o=e.length;r!==o;++r){let a=e[r],l=n[a.id];l.needsUpdate!==!1&&a.setValue(t,l.value,s)}}static seqWithValue(t,e){let n=[];for(let s=0,r=t.length;s!==r;++s){let o=t[s];o.id in e&&n.push(o)}return n}};function Td(i,t,e){let n=i.createShader(t);return i.shaderSource(n,e),i.compileShader(n),n}var Fy=37297,By=0;function Oy(i,t){let e=i.split(`
`),n=[],s=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let o=s;o<r;o++){let a=o+1;n.push(`${a===t?">":" "} ${a}: ${e[o]}`)}return n.join(`
`)}var Ad=new Gt;function Hy(i){ie._getMatrix(Ad,ie.workingColorSpace,i);let t=`mat3( ${Ad.elements.map(e=>e.toFixed(4))} )`;switch(ie.getTransfer(i)){case qa:return[t,"LinearTransferOETF"];case pe:return[t,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",i),[t,"LinearTransferOETF"]}}function Rd(i,t,e){let n=i.getShaderParameter(t,i.COMPILE_STATUS),s=i.getShaderInfoLog(t).trim();if(n&&s==="")return"";let r=/ERROR: 0:(\d+)/.exec(s);if(r){let o=parseInt(r[1]);return e.toUpperCase()+`

`+s+`

`+Oy(i.getShaderSource(t),o)}else return s}function Vy(i,t){let e=Hy(t);return[`vec4 ${i}( vec4 value ) {`,`	return ${e[1]}( vec4( value.rgb * ${e[0]}, value.a ) );`,"}"].join(`
`)}function Gy(i,t){let e;switch(t){case em:e="Linear";break;case nm:e="Reinhard";break;case im:e="Cineon";break;case Ih:e="ACESFilmic";break;case rm:e="AgX";break;case om:e="Neutral";break;case sm:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+i+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}var jo=new C;function Wy(){ie.getLuminanceCoefficients(jo);let i=jo.x.toFixed(4),t=jo.y.toFixed(4),e=jo.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${t}, ${e} );`,"	return dot( weights, rgb );","}"].join(`
`)}function $y(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Hr).join(`
`)}function qy(i){let t=[];for(let e in i){let n=i[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function Xy(i,t){let e={},n=i.getProgramParameter(t,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){let r=i.getActiveAttrib(t,s),o=r.name,a=1;r.type===i.FLOAT_MAT2&&(a=2),r.type===i.FLOAT_MAT3&&(a=3),r.type===i.FLOAT_MAT4&&(a=4),e[o]={type:r.type,location:i.getAttribLocation(t,o),locationSize:a}}return e}function Hr(i){return i!==""}function Cd(i,t){let e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function Pd(i,t){return i.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var Yy=/^[ \t]*#include +<([\w\d./]+)>/gm;function Qc(i){return i.replace(Yy,Ky)}var Zy=new Map;function Ky(i,t){let e=Yt[t];if(e===void 0){let n=Zy.get(t);if(n!==void 0)e=Yt[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("Can not resolve #include <"+t+">")}return Qc(e)}var Jy=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Id(i){return i.replace(Jy,jy)}function jy(i,t,e,n){let s="";for(let r=parseInt(t);r<parseInt(e);r++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function Ld(i){let t=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?t+=`
#define HIGH_PRECISION`:i.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function Qy(i){let t="SHADOWMAP_TYPE_BASIC";return i.shadowMapType===ef?t="SHADOWMAP_TYPE_PCF":i.shadowMapType===Ph?t="SHADOWMAP_TYPE_PCF_SOFT":i.shadowMapType===fi&&(t="SHADOWMAP_TYPE_VSM"),t}function tv(i){let t="ENVMAP_TYPE_CUBE";if(i.envMap)switch(i.envMapMode){case sr:case rr:t="ENVMAP_TYPE_CUBE";break;case $a:t="ENVMAP_TYPE_CUBE_UV";break}return t}function ev(i){let t="ENVMAP_MODE_REFLECTION";if(i.envMap)switch(i.envMapMode){case rr:t="ENVMAP_MODE_REFRACTION";break}return t}function nv(i){let t="ENVMAP_BLENDING_NONE";if(i.envMap)switch(i.combine){case nf:t="ENVMAP_BLENDING_MULTIPLY";break;case Qp:t="ENVMAP_BLENDING_MIX";break;case tm:t="ENVMAP_BLENDING_ADD";break}return t}function iv(i){let t=i.envMapCubeUVHeight;if(t===null)return null;let e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),7*16)),texelHeight:n,maxMip:e}}function sv(i,t,e,n){let s=i.getContext(),r=e.defines,o=e.vertexShader,a=e.fragmentShader,l=Qy(e),c=tv(e),h=ev(e),u=nv(e),d=iv(e),f=$y(e),g=qy(r),x=s.createProgram(),m,p,M=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(m=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g].filter(Hr).join(`
`),m.length>0&&(m+=`
`),p=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g].filter(Hr).join(`
`),p.length>0&&(p+=`
`)):(m=[Ld(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.batchingColor?"#define USE_BATCHING_COLOR":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.instancingMorph?"#define USE_INSTANCING_MORPH":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Hr).join(`
`),p=[Ld(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+c:"",e.envMap?"#define "+h:"",e.envMap?"#define "+u:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.dispersion?"#define USE_DISPERSION":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor||e.batchingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==Hi?"#define TONE_MAPPING":"",e.toneMapping!==Hi?Yt.tonemapping_pars_fragment:"",e.toneMapping!==Hi?Gy("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",Yt.colorspace_pars_fragment,Vy("linearToOutputTexel",e.outputColorSpace),Wy(),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(Hr).join(`
`)),o=Qc(o),o=Cd(o,e),o=Pd(o,e),a=Qc(a),a=Cd(a,e),a=Pd(a,e),o=Id(o),a=Id(a),e.isRawShaderMaterial!==!0&&(M=`#version 300 es
`,m=[f,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,p=["#define varying in",e.glslVersion===$u?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===$u?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+p);let v=M+m+o,y=M+p+a,w=Td(s,s.VERTEX_SHADER,v),S=Td(s,s.FRAGMENT_SHADER,y);s.attachShader(x,w),s.attachShader(x,S),e.index0AttributeName!==void 0?s.bindAttribLocation(x,0,e.index0AttributeName):e.morphTargets===!0&&s.bindAttribLocation(x,0,"position"),s.linkProgram(x);function A(R){if(i.debug.checkShaderErrors){let L=s.getProgramInfoLog(x).trim(),D=s.getShaderInfoLog(w).trim(),N=s.getShaderInfoLog(S).trim(),W=!0,k=!0;if(s.getProgramParameter(x,s.LINK_STATUS)===!1)if(W=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,x,w,S);else{let q=Rd(s,w,"vertex"),H=Rd(s,S,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(x,s.VALIDATE_STATUS)+`

Material Name: `+R.name+`
Material Type: `+R.type+`

Program Info Log: `+L+`
`+q+`
`+H)}else L!==""?console.warn("THREE.WebGLProgram: Program Info Log:",L):(D===""||N==="")&&(k=!1);k&&(R.diagnostics={runnable:W,programLog:L,vertexShader:{log:D,prefix:m},fragmentShader:{log:N,prefix:p}})}s.deleteShader(w),s.deleteShader(S),P=new nr(s,x),_=Xy(s,x)}let P;this.getUniforms=function(){return P===void 0&&A(this),P};let _;this.getAttributes=function(){return _===void 0&&A(this),_};let b=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return b===!1&&(b=s.getProgramParameter(x,Fy)),b},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(x),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=By++,this.cacheKey=t,this.usedTimes=1,this.program=x,this.vertexShader=w,this.fragmentShader=S,this}var rv=0,th=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){let e=t.vertexShader,n=t.fragmentShader,s=this._getShaderStage(e),r=this._getShaderStage(n),o=this._getShaderCacheForMaterial(t);return o.has(s)===!1&&(o.add(s),s.usedTimes++),o.has(r)===!1&&(o.add(r),r.usedTimes++),this}remove(t){let e=this.materialCache.get(t);for(let n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){let e=this.materialCache,n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){let e=this.shaderCache,n=e.get(t);return n===void 0&&(n=new eh(t),e.set(t,n)),n}},eh=class{constructor(t){this.id=rv++,this.code=t,this.usedTimes=0}};function ov(i,t,e,n,s,r,o){let a=new Jr,l=new th,c=new Set,h=[],u=s.logarithmicDepthBuffer,d=s.vertexTextures,f=s.precision,g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function x(_){return c.add(_),_===0?"uv":`uv${_}`}function m(_,b,R,L,D){let N=L.fog,W=D.geometry,k=_.isMeshStandardMaterial?L.environment:null,q=(_.isMeshStandardMaterial?e:t).get(_.envMap||k),H=q&&q.mapping===$a?q.image.height:null,K=g[_.type];_.precision!==null&&(f=s.getMaxPrecision(_.precision),f!==_.precision&&console.warn("THREE.WebGLProgram.getParameters:",_.precision,"not supported, using",f,"instead."));let Q=W.morphAttributes.position||W.morphAttributes.normal||W.morphAttributes.color,at=Q!==void 0?Q.length:0,Ct=0;W.morphAttributes.position!==void 0&&(Ct=1),W.morphAttributes.normal!==void 0&&(Ct=2),W.morphAttributes.color!==void 0&&(Ct=3);let qt,Y,et,vt;if(K){let ue=Zn[K];qt=ue.vertexShader,Y=ue.fragmentShader}else qt=_.vertexShader,Y=_.fragmentShader,l.update(_),et=l.getVertexShaderID(_),vt=l.getFragmentShaderID(_);let ct=i.getRenderTarget(),kt=i.state.buffers.depth.getReversed(),Bt=D.isInstancedMesh===!0,Zt=D.isBatchedMesh===!0,Ee=!!_.map,ee=!!_.matcap,ke=!!q,O=!!_.aoMap,Rn=!!_.lightMap,jt=!!_.bumpMap,Qt=!!_.normalMap,It=!!_.displacementMap,ve=!!_.emissiveMap,Pt=!!_.metalnessMap,I=!!_.roughnessMap,E=_.anisotropy>0,V=_.clearcoat>0,J=_.dispersion>0,tt=_.iridescence>0,Z=_.sheen>0,St=_.transmission>0,ht=E&&!!_.anisotropyMap,mt=V&&!!_.clearcoatMap,ne=V&&!!_.clearcoatNormalMap,it=V&&!!_.clearcoatRoughnessMap,gt=tt&&!!_.iridescenceMap,Dt=tt&&!!_.iridescenceThicknessMap,Nt=Z&&!!_.sheenColorMap,xt=Z&&!!_.sheenRoughnessMap,te=!!_.specularMap,Xt=!!_.specularColorMap,ge=!!_.specularIntensityMap,z=St&&!!_.transmissionMap,lt=St&&!!_.thicknessMap,X=!!_.gradientMap,j=!!_.alphaMap,pt=_.alphaTest>0,ut=!!_.alphaHash,Ht=!!_.extensions,Ie=Hi;_.toneMapped&&(ct===null||ct.isXRRenderTarget===!0)&&(Ie=i.toneMapping);let Xe={shaderID:K,shaderType:_.type,shaderName:_.name,vertexShader:qt,fragmentShader:Y,defines:_.defines,customVertexShaderID:et,customFragmentShaderID:vt,isRawShaderMaterial:_.isRawShaderMaterial===!0,glslVersion:_.glslVersion,precision:f,batching:Zt,batchingColor:Zt&&D._colorsTexture!==null,instancing:Bt,instancingColor:Bt&&D.instanceColor!==null,instancingMorph:Bt&&D.morphTexture!==null,supportsVertexTextures:d,outputColorSpace:ct===null?i.outputColorSpace:ct.isXRRenderTarget===!0?ct.texture.colorSpace:fr,alphaToCoverage:!!_.alphaToCoverage,map:Ee,matcap:ee,envMap:ke,envMapMode:ke&&q.mapping,envMapCubeUVHeight:H,aoMap:O,lightMap:Rn,bumpMap:jt,normalMap:Qt,displacementMap:d&&It,emissiveMap:ve,normalMapObjectSpace:Qt&&_.normalMapType===hm,normalMapTangentSpace:Qt&&_.normalMapType===pf,metalnessMap:Pt,roughnessMap:I,anisotropy:E,anisotropyMap:ht,clearcoat:V,clearcoatMap:mt,clearcoatNormalMap:ne,clearcoatRoughnessMap:it,dispersion:J,iridescence:tt,iridescenceMap:gt,iridescenceThicknessMap:Dt,sheen:Z,sheenColorMap:Nt,sheenRoughnessMap:xt,specularMap:te,specularColorMap:Xt,specularIntensityMap:ge,transmission:St,transmissionMap:z,thicknessMap:lt,gradientMap:X,opaque:_.transparent===!1&&_.blending===Qs&&_.alphaToCoverage===!1,alphaMap:j,alphaTest:pt,alphaHash:ut,combine:_.combine,mapUv:Ee&&x(_.map.channel),aoMapUv:O&&x(_.aoMap.channel),lightMapUv:Rn&&x(_.lightMap.channel),bumpMapUv:jt&&x(_.bumpMap.channel),normalMapUv:Qt&&x(_.normalMap.channel),displacementMapUv:It&&x(_.displacementMap.channel),emissiveMapUv:ve&&x(_.emissiveMap.channel),metalnessMapUv:Pt&&x(_.metalnessMap.channel),roughnessMapUv:I&&x(_.roughnessMap.channel),anisotropyMapUv:ht&&x(_.anisotropyMap.channel),clearcoatMapUv:mt&&x(_.clearcoatMap.channel),clearcoatNormalMapUv:ne&&x(_.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:it&&x(_.clearcoatRoughnessMap.channel),iridescenceMapUv:gt&&x(_.iridescenceMap.channel),iridescenceThicknessMapUv:Dt&&x(_.iridescenceThicknessMap.channel),sheenColorMapUv:Nt&&x(_.sheenColorMap.channel),sheenRoughnessMapUv:xt&&x(_.sheenRoughnessMap.channel),specularMapUv:te&&x(_.specularMap.channel),specularColorMapUv:Xt&&x(_.specularColorMap.channel),specularIntensityMapUv:ge&&x(_.specularIntensityMap.channel),transmissionMapUv:z&&x(_.transmissionMap.channel),thicknessMapUv:lt&&x(_.thicknessMap.channel),alphaMapUv:j&&x(_.alphaMap.channel),vertexTangents:!!W.attributes.tangent&&(Qt||E),vertexColors:_.vertexColors,vertexAlphas:_.vertexColors===!0&&!!W.attributes.color&&W.attributes.color.itemSize===4,pointsUvs:D.isPoints===!0&&!!W.attributes.uv&&(Ee||j),fog:!!N,useFog:_.fog===!0,fogExp2:!!N&&N.isFogExp2,flatShading:_.flatShading===!0,sizeAttenuation:_.sizeAttenuation===!0,logarithmicDepthBuffer:u,reverseDepthBuffer:kt,skinning:D.isSkinnedMesh===!0,morphTargets:W.morphAttributes.position!==void 0,morphNormals:W.morphAttributes.normal!==void 0,morphColors:W.morphAttributes.color!==void 0,morphTargetsCount:at,morphTextureStride:Ct,numDirLights:b.directional.length,numPointLights:b.point.length,numSpotLights:b.spot.length,numSpotLightMaps:b.spotLightMap.length,numRectAreaLights:b.rectArea.length,numHemiLights:b.hemi.length,numDirLightShadows:b.directionalShadowMap.length,numPointLightShadows:b.pointShadowMap.length,numSpotLightShadows:b.spotShadowMap.length,numSpotLightShadowsWithMaps:b.numSpotLightShadowsWithMaps,numLightProbes:b.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:_.dithering,shadowMapEnabled:i.shadowMap.enabled&&R.length>0,shadowMapType:i.shadowMap.type,toneMapping:Ie,decodeVideoTexture:Ee&&_.map.isVideoTexture===!0&&ie.getTransfer(_.map.colorSpace)===pe,decodeVideoTextureEmissive:ve&&_.emissiveMap.isVideoTexture===!0&&ie.getTransfer(_.emissiveMap.colorSpace)===pe,premultipliedAlpha:_.premultipliedAlpha,doubleSided:_.side===Te,flipSided:_.side===Ke,useDepthPacking:_.depthPacking>=0,depthPacking:_.depthPacking||0,index0AttributeName:_.index0AttributeName,extensionClipCullDistance:Ht&&_.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Ht&&_.extensions.multiDraw===!0||Zt)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:_.customProgramCacheKey()};return Xe.vertexUv1s=c.has(1),Xe.vertexUv2s=c.has(2),Xe.vertexUv3s=c.has(3),c.clear(),Xe}function p(_){let b=[];if(_.shaderID?b.push(_.shaderID):(b.push(_.customVertexShaderID),b.push(_.customFragmentShaderID)),_.defines!==void 0)for(let R in _.defines)b.push(R),b.push(_.defines[R]);return _.isRawShaderMaterial===!1&&(M(b,_),v(b,_),b.push(i.outputColorSpace)),b.push(_.customProgramCacheKey),b.join()}function M(_,b){_.push(b.precision),_.push(b.outputColorSpace),_.push(b.envMapMode),_.push(b.envMapCubeUVHeight),_.push(b.mapUv),_.push(b.alphaMapUv),_.push(b.lightMapUv),_.push(b.aoMapUv),_.push(b.bumpMapUv),_.push(b.normalMapUv),_.push(b.displacementMapUv),_.push(b.emissiveMapUv),_.push(b.metalnessMapUv),_.push(b.roughnessMapUv),_.push(b.anisotropyMapUv),_.push(b.clearcoatMapUv),_.push(b.clearcoatNormalMapUv),_.push(b.clearcoatRoughnessMapUv),_.push(b.iridescenceMapUv),_.push(b.iridescenceThicknessMapUv),_.push(b.sheenColorMapUv),_.push(b.sheenRoughnessMapUv),_.push(b.specularMapUv),_.push(b.specularColorMapUv),_.push(b.specularIntensityMapUv),_.push(b.transmissionMapUv),_.push(b.thicknessMapUv),_.push(b.combine),_.push(b.fogExp2),_.push(b.sizeAttenuation),_.push(b.morphTargetsCount),_.push(b.morphAttributeCount),_.push(b.numDirLights),_.push(b.numPointLights),_.push(b.numSpotLights),_.push(b.numSpotLightMaps),_.push(b.numHemiLights),_.push(b.numRectAreaLights),_.push(b.numDirLightShadows),_.push(b.numPointLightShadows),_.push(b.numSpotLightShadows),_.push(b.numSpotLightShadowsWithMaps),_.push(b.numLightProbes),_.push(b.shadowMapType),_.push(b.toneMapping),_.push(b.numClippingPlanes),_.push(b.numClipIntersection),_.push(b.depthPacking)}function v(_,b){a.disableAll(),b.supportsVertexTextures&&a.enable(0),b.instancing&&a.enable(1),b.instancingColor&&a.enable(2),b.instancingMorph&&a.enable(3),b.matcap&&a.enable(4),b.envMap&&a.enable(5),b.normalMapObjectSpace&&a.enable(6),b.normalMapTangentSpace&&a.enable(7),b.clearcoat&&a.enable(8),b.iridescence&&a.enable(9),b.alphaTest&&a.enable(10),b.vertexColors&&a.enable(11),b.vertexAlphas&&a.enable(12),b.vertexUv1s&&a.enable(13),b.vertexUv2s&&a.enable(14),b.vertexUv3s&&a.enable(15),b.vertexTangents&&a.enable(16),b.anisotropy&&a.enable(17),b.alphaHash&&a.enable(18),b.batching&&a.enable(19),b.dispersion&&a.enable(20),b.batchingColor&&a.enable(21),_.push(a.mask),a.disableAll(),b.fog&&a.enable(0),b.useFog&&a.enable(1),b.flatShading&&a.enable(2),b.logarithmicDepthBuffer&&a.enable(3),b.reverseDepthBuffer&&a.enable(4),b.skinning&&a.enable(5),b.morphTargets&&a.enable(6),b.morphNormals&&a.enable(7),b.morphColors&&a.enable(8),b.premultipliedAlpha&&a.enable(9),b.shadowMapEnabled&&a.enable(10),b.doubleSided&&a.enable(11),b.flipSided&&a.enable(12),b.useDepthPacking&&a.enable(13),b.dithering&&a.enable(14),b.transmission&&a.enable(15),b.sheen&&a.enable(16),b.opaque&&a.enable(17),b.pointsUvs&&a.enable(18),b.decodeVideoTexture&&a.enable(19),b.decodeVideoTextureEmissive&&a.enable(20),b.alphaToCoverage&&a.enable(21),_.push(a.mask)}function y(_){let b=g[_.type],R;if(b){let L=Zn[b];R=mr.clone(L.uniforms)}else R=_.uniforms;return R}function w(_,b){let R;for(let L=0,D=h.length;L<D;L++){let N=h[L];if(N.cacheKey===b){R=N,++R.usedTimes;break}}return R===void 0&&(R=new sv(i,b,_,r),h.push(R)),R}function S(_){if(--_.usedTimes===0){let b=h.indexOf(_);h[b]=h[h.length-1],h.pop(),_.destroy()}}function A(_){l.remove(_)}function P(){l.dispose()}return{getParameters:m,getProgramCacheKey:p,getUniforms:y,acquireProgram:w,releaseProgram:S,releaseShaderCache:A,programs:h,dispose:P}}function av(){let i=new WeakMap;function t(o){return i.has(o)}function e(o){let a=i.get(o);return a===void 0&&(a={},i.set(o,a)),a}function n(o){i.delete(o)}function s(o,a,l){i.get(o)[a]=l}function r(){i=new WeakMap}return{has:t,get:e,remove:n,update:s,dispose:r}}function lv(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.material.id!==t.material.id?i.material.id-t.material.id:i.z!==t.z?i.z-t.z:i.id-t.id}function Dd(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.z!==t.z?t.z-i.z:i.id-t.id}function kd(){let i=[],t=0,e=[],n=[],s=[];function r(){t=0,e.length=0,n.length=0,s.length=0}function o(u,d,f,g,x,m){let p=i[t];return p===void 0?(p={id:u.id,object:u,geometry:d,material:f,groupOrder:g,renderOrder:u.renderOrder,z:x,group:m},i[t]=p):(p.id=u.id,p.object=u,p.geometry=d,p.material=f,p.groupOrder=g,p.renderOrder=u.renderOrder,p.z=x,p.group=m),t++,p}function a(u,d,f,g,x,m){let p=o(u,d,f,g,x,m);f.transmission>0?n.push(p):f.transparent===!0?s.push(p):e.push(p)}function l(u,d,f,g,x,m){let p=o(u,d,f,g,x,m);f.transmission>0?n.unshift(p):f.transparent===!0?s.unshift(p):e.unshift(p)}function c(u,d){e.length>1&&e.sort(u||lv),n.length>1&&n.sort(d||Dd),s.length>1&&s.sort(d||Dd)}function h(){for(let u=t,d=i.length;u<d;u++){let f=i[u];if(f.id===null)break;f.id=null,f.object=null,f.geometry=null,f.material=null,f.group=null}}return{opaque:e,transmissive:n,transparent:s,init:r,push:a,unshift:l,finish:h,sort:c}}function cv(){let i=new WeakMap;function t(n,s){let r=i.get(n),o;return r===void 0?(o=new kd,i.set(n,[o])):s>=r.length?(o=new kd,r.push(o)):o=r[s],o}function e(){i=new WeakMap}return{get:t,dispose:e}}function hv(){let i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new C,color:new bt};break;case"SpotLight":e={position:new C,direction:new C,color:new bt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new C,color:new bt,distance:0,decay:0};break;case"HemisphereLight":e={direction:new C,skyColor:new bt,groundColor:new bt};break;case"RectAreaLight":e={color:new bt,position:new C,halfWidth:new C,halfHeight:new C};break}return i[t.id]=e,e}}}function uv(){let i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new rt};break;case"SpotLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new rt};break;case"PointLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new rt,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[t.id]=e,e}}}var dv=0;function fv(i,t){return(t.castShadow?2:0)-(i.castShadow?2:0)+(t.map?1:0)-(i.map?1:0)}function pv(i){let t=new hv,e=uv(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new C);let s=new C,r=new Wt,o=new Wt;function a(c){let h=0,u=0,d=0;for(let _=0;_<9;_++)n.probe[_].set(0,0,0);let f=0,g=0,x=0,m=0,p=0,M=0,v=0,y=0,w=0,S=0,A=0;c.sort(fv);for(let _=0,b=c.length;_<b;_++){let R=c[_],L=R.color,D=R.intensity,N=R.distance,W=R.shadow&&R.shadow.map?R.shadow.map.texture:null;if(R.isAmbientLight)h+=L.r*D,u+=L.g*D,d+=L.b*D;else if(R.isLightProbe){for(let k=0;k<9;k++)n.probe[k].addScaledVector(R.sh.coefficients[k],D);A++}else if(R.isDirectionalLight){let k=t.get(R);if(k.color.copy(R.color).multiplyScalar(R.intensity),R.castShadow){let q=R.shadow,H=e.get(R);H.shadowIntensity=q.intensity,H.shadowBias=q.bias,H.shadowNormalBias=q.normalBias,H.shadowRadius=q.radius,H.shadowMapSize=q.mapSize,n.directionalShadow[f]=H,n.directionalShadowMap[f]=W,n.directionalShadowMatrix[f]=R.shadow.matrix,M++}n.directional[f]=k,f++}else if(R.isSpotLight){let k=t.get(R);k.position.setFromMatrixPosition(R.matrixWorld),k.color.copy(L).multiplyScalar(D),k.distance=N,k.coneCos=Math.cos(R.angle),k.penumbraCos=Math.cos(R.angle*(1-R.penumbra)),k.decay=R.decay,n.spot[x]=k;let q=R.shadow;if(R.map&&(n.spotLightMap[w]=R.map,w++,q.updateMatrices(R),R.castShadow&&S++),n.spotLightMatrix[x]=q.matrix,R.castShadow){let H=e.get(R);H.shadowIntensity=q.intensity,H.shadowBias=q.bias,H.shadowNormalBias=q.normalBias,H.shadowRadius=q.radius,H.shadowMapSize=q.mapSize,n.spotShadow[x]=H,n.spotShadowMap[x]=W,y++}x++}else if(R.isRectAreaLight){let k=t.get(R);k.color.copy(L).multiplyScalar(D),k.halfWidth.set(R.width*.5,0,0),k.halfHeight.set(0,R.height*.5,0),n.rectArea[m]=k,m++}else if(R.isPointLight){let k=t.get(R);if(k.color.copy(R.color).multiplyScalar(R.intensity),k.distance=R.distance,k.decay=R.decay,R.castShadow){let q=R.shadow,H=e.get(R);H.shadowIntensity=q.intensity,H.shadowBias=q.bias,H.shadowNormalBias=q.normalBias,H.shadowRadius=q.radius,H.shadowMapSize=q.mapSize,H.shadowCameraNear=q.camera.near,H.shadowCameraFar=q.camera.far,n.pointShadow[g]=H,n.pointShadowMap[g]=W,n.pointShadowMatrix[g]=R.shadow.matrix,v++}n.point[g]=k,g++}else if(R.isHemisphereLight){let k=t.get(R);k.skyColor.copy(R.color).multiplyScalar(D),k.groundColor.copy(R.groundColor).multiplyScalar(D),n.hemi[p]=k,p++}}m>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=ot.LTC_FLOAT_1,n.rectAreaLTC2=ot.LTC_FLOAT_2):(n.rectAreaLTC1=ot.LTC_HALF_1,n.rectAreaLTC2=ot.LTC_HALF_2)),n.ambient[0]=h,n.ambient[1]=u,n.ambient[2]=d;let P=n.hash;(P.directionalLength!==f||P.pointLength!==g||P.spotLength!==x||P.rectAreaLength!==m||P.hemiLength!==p||P.numDirectionalShadows!==M||P.numPointShadows!==v||P.numSpotShadows!==y||P.numSpotMaps!==w||P.numLightProbes!==A)&&(n.directional.length=f,n.spot.length=x,n.rectArea.length=m,n.point.length=g,n.hemi.length=p,n.directionalShadow.length=M,n.directionalShadowMap.length=M,n.pointShadow.length=v,n.pointShadowMap.length=v,n.spotShadow.length=y,n.spotShadowMap.length=y,n.directionalShadowMatrix.length=M,n.pointShadowMatrix.length=v,n.spotLightMatrix.length=y+w-S,n.spotLightMap.length=w,n.numSpotLightShadowsWithMaps=S,n.numLightProbes=A,P.directionalLength=f,P.pointLength=g,P.spotLength=x,P.rectAreaLength=m,P.hemiLength=p,P.numDirectionalShadows=M,P.numPointShadows=v,P.numSpotShadows=y,P.numSpotMaps=w,P.numLightProbes=A,n.version=dv++)}function l(c,h){let u=0,d=0,f=0,g=0,x=0,m=h.matrixWorldInverse;for(let p=0,M=c.length;p<M;p++){let v=c[p];if(v.isDirectionalLight){let y=n.directional[u];y.direction.setFromMatrixPosition(v.matrixWorld),s.setFromMatrixPosition(v.target.matrixWorld),y.direction.sub(s),y.direction.transformDirection(m),u++}else if(v.isSpotLight){let y=n.spot[f];y.position.setFromMatrixPosition(v.matrixWorld),y.position.applyMatrix4(m),y.direction.setFromMatrixPosition(v.matrixWorld),s.setFromMatrixPosition(v.target.matrixWorld),y.direction.sub(s),y.direction.transformDirection(m),f++}else if(v.isRectAreaLight){let y=n.rectArea[g];y.position.setFromMatrixPosition(v.matrixWorld),y.position.applyMatrix4(m),o.identity(),r.copy(v.matrixWorld),r.premultiply(m),o.extractRotation(r),y.halfWidth.set(v.width*.5,0,0),y.halfHeight.set(0,v.height*.5,0),y.halfWidth.applyMatrix4(o),y.halfHeight.applyMatrix4(o),g++}else if(v.isPointLight){let y=n.point[d];y.position.setFromMatrixPosition(v.matrixWorld),y.position.applyMatrix4(m),d++}else if(v.isHemisphereLight){let y=n.hemi[x];y.direction.setFromMatrixPosition(v.matrixWorld),y.direction.transformDirection(m),x++}}}return{setup:a,setupView:l,state:n}}function Ud(i){let t=new pv(i),e=[],n=[];function s(h){c.camera=h,e.length=0,n.length=0}function r(h){e.push(h)}function o(h){n.push(h)}function a(){t.setup(e)}function l(h){t.setupView(e,h)}let c={lightsArray:e,shadowsArray:n,camera:null,lights:t,transmissionRenderTarget:{}};return{init:s,state:c,setupLights:a,setupLightsView:l,pushLight:r,pushShadow:o}}function mv(i){let t=new WeakMap;function e(s,r=0){let o=t.get(s),a;return o===void 0?(a=new Ud(i),t.set(s,[a])):r>=o.length?(a=new Ud(i),o.push(a)):a=o[r],a}function n(){t=new WeakMap}return{get:e,dispose:n}}var nh=class extends vi{static get type(){return"MeshDepthMaterial"}constructor(t){super(),this.isMeshDepthMaterial=!0,this.depthPacking=lm,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}},ih=class extends vi{static get type(){return"MeshDistanceMaterial"}constructor(t){super(),this.isMeshDistanceMaterial=!0,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}},gv=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,xv=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function yv(i,t,e){let n=new jr,s=new rt,r=new rt,o=new Me,a=new nh({depthPacking:cm}),l=new ih,c={},h=e.maxTextureSize,u={[jn]:Ke,[Ke]:jn,[Te]:Te},d=new dn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new rt},radius:{value:4}},vertexShader:gv,fragmentShader:xv}),f=d.clone();f.defines.HORIZONTAL_PASS=1;let g=new ae;g.setAttribute("position",new Ne(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let x=new nt(g,d),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=ef;let p=this.type;this.render=function(S,A,P){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||S.length===0)return;let _=i.getRenderTarget(),b=i.getActiveCubeFace(),R=i.getActiveMipmapLevel(),L=i.state;L.setBlending(Oi),L.buffers.color.setClear(1,1,1,1),L.buffers.depth.setTest(!0),L.setScissorTest(!1);let D=p!==fi&&this.type===fi,N=p===fi&&this.type!==fi;for(let W=0,k=S.length;W<k;W++){let q=S[W],H=q.shadow;if(H===void 0){console.warn("THREE.WebGLShadowMap:",q,"has no shadow.");continue}if(H.autoUpdate===!1&&H.needsUpdate===!1)continue;s.copy(H.mapSize);let K=H.getFrameExtents();if(s.multiply(K),r.copy(H.mapSize),(s.x>h||s.y>h)&&(s.x>h&&(r.x=Math.floor(h/K.x),s.x=r.x*K.x,H.mapSize.x=r.x),s.y>h&&(r.y=Math.floor(h/K.y),s.y=r.y*K.y,H.mapSize.y=r.y)),H.map===null||D===!0||N===!0){let at=this.type!==fi?{minFilter:_n,magFilter:_n}:{};H.map!==null&&H.map.dispose(),H.map=new Vn(s.x,s.y,at),H.map.texture.name=q.name+".shadowMap",H.camera.updateProjectionMatrix()}i.setRenderTarget(H.map),i.clear();let Q=H.getViewportCount();for(let at=0;at<Q;at++){let Ct=H.getViewport(at);o.set(r.x*Ct.x,r.y*Ct.y,r.x*Ct.z,r.y*Ct.w),L.viewport(o),H.updateMatrices(q,at),n=H.getFrustum(),y(A,P,H.camera,q,this.type)}H.isPointLightShadow!==!0&&this.type===fi&&M(H,P),H.needsUpdate=!1}p=this.type,m.needsUpdate=!1,i.setRenderTarget(_,b,R)};function M(S,A){let P=t.update(x);d.defines.VSM_SAMPLES!==S.blurSamples&&(d.defines.VSM_SAMPLES=S.blurSamples,f.defines.VSM_SAMPLES=S.blurSamples,d.needsUpdate=!0,f.needsUpdate=!0),S.mapPass===null&&(S.mapPass=new Vn(s.x,s.y)),d.uniforms.shadow_pass.value=S.map.texture,d.uniforms.resolution.value=S.mapSize,d.uniforms.radius.value=S.radius,i.setRenderTarget(S.mapPass),i.clear(),i.renderBufferDirect(A,null,P,d,x,null),f.uniforms.shadow_pass.value=S.mapPass.texture,f.uniforms.resolution.value=S.mapSize,f.uniforms.radius.value=S.radius,i.setRenderTarget(S.map),i.clear(),i.renderBufferDirect(A,null,P,f,x,null)}function v(S,A,P,_){let b=null,R=P.isPointLight===!0?S.customDistanceMaterial:S.customDepthMaterial;if(R!==void 0)b=R;else if(b=P.isPointLight===!0?l:a,i.localClippingEnabled&&A.clipShadows===!0&&Array.isArray(A.clippingPlanes)&&A.clippingPlanes.length!==0||A.displacementMap&&A.displacementScale!==0||A.alphaMap&&A.alphaTest>0||A.map&&A.alphaTest>0){let L=b.uuid,D=A.uuid,N=c[L];N===void 0&&(N={},c[L]=N);let W=N[D];W===void 0&&(W=b.clone(),N[D]=W,A.addEventListener("dispose",w)),b=W}if(b.visible=A.visible,b.wireframe=A.wireframe,_===fi?b.side=A.shadowSide!==null?A.shadowSide:A.side:b.side=A.shadowSide!==null?A.shadowSide:u[A.side],b.alphaMap=A.alphaMap,b.alphaTest=A.alphaTest,b.map=A.map,b.clipShadows=A.clipShadows,b.clippingPlanes=A.clippingPlanes,b.clipIntersection=A.clipIntersection,b.displacementMap=A.displacementMap,b.displacementScale=A.displacementScale,b.displacementBias=A.displacementBias,b.wireframeLinewidth=A.wireframeLinewidth,b.linewidth=A.linewidth,P.isPointLight===!0&&b.isMeshDistanceMaterial===!0){let L=i.properties.get(b);L.light=P}return b}function y(S,A,P,_,b){if(S.visible===!1)return;if(S.layers.test(A.layers)&&(S.isMesh||S.isLine||S.isPoints)&&(S.castShadow||S.receiveShadow&&b===fi)&&(!S.frustumCulled||n.intersectsObject(S))){S.modelViewMatrix.multiplyMatrices(P.matrixWorldInverse,S.matrixWorld);let D=t.update(S),N=S.material;if(Array.isArray(N)){let W=D.groups;for(let k=0,q=W.length;k<q;k++){let H=W[k],K=N[H.materialIndex];if(K&&K.visible){let Q=v(S,K,_,b);S.onBeforeShadow(i,S,A,P,D,Q,H),i.renderBufferDirect(P,null,D,Q,S,H),S.onAfterShadow(i,S,A,P,D,Q,H)}}}else if(N.visible){let W=v(S,N,_,b);S.onBeforeShadow(i,S,A,P,D,W,null),i.renderBufferDirect(P,null,D,W,S,null),S.onAfterShadow(i,S,A,P,D,W,null)}}let L=S.children;for(let D=0,N=L.length;D<N;D++)y(L[D],A,P,_,b)}function w(S){S.target.removeEventListener("dispose",w);for(let P in c){let _=c[P],b=S.target.uuid;b in _&&(_[b].dispose(),delete _[b])}}}var vv={[ac]:lc,[cc]:dc,[hc]:fc,[ir]:uc,[lc]:ac,[dc]:cc,[fc]:hc,[uc]:ir};function bv(i,t){function e(){let z=!1,lt=new Me,X=null,j=new Me(0,0,0,0);return{setMask:function(pt){X!==pt&&!z&&(i.colorMask(pt,pt,pt,pt),X=pt)},setLocked:function(pt){z=pt},setClear:function(pt,ut,Ht,Ie,Xe){Xe===!0&&(pt*=Ie,ut*=Ie,Ht*=Ie),lt.set(pt,ut,Ht,Ie),j.equals(lt)===!1&&(i.clearColor(pt,ut,Ht,Ie),j.copy(lt))},reset:function(){z=!1,X=null,j.set(-1,0,0,0)}}}function n(){let z=!1,lt=!1,X=null,j=null,pt=null;return{setReversed:function(ut){if(lt!==ut){let Ht=t.get("EXT_clip_control");lt?Ht.clipControlEXT(Ht.LOWER_LEFT_EXT,Ht.ZERO_TO_ONE_EXT):Ht.clipControlEXT(Ht.LOWER_LEFT_EXT,Ht.NEGATIVE_ONE_TO_ONE_EXT);let Ie=pt;pt=null,this.setClear(Ie)}lt=ut},getReversed:function(){return lt},setTest:function(ut){ut?ct(i.DEPTH_TEST):kt(i.DEPTH_TEST)},setMask:function(ut){X!==ut&&!z&&(i.depthMask(ut),X=ut)},setFunc:function(ut){if(lt&&(ut=vv[ut]),j!==ut){switch(ut){case ac:i.depthFunc(i.NEVER);break;case lc:i.depthFunc(i.ALWAYS);break;case cc:i.depthFunc(i.LESS);break;case ir:i.depthFunc(i.LEQUAL);break;case hc:i.depthFunc(i.EQUAL);break;case uc:i.depthFunc(i.GEQUAL);break;case dc:i.depthFunc(i.GREATER);break;case fc:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}j=ut}},setLocked:function(ut){z=ut},setClear:function(ut){pt!==ut&&(lt&&(ut=1-ut),i.clearDepth(ut),pt=ut)},reset:function(){z=!1,X=null,j=null,pt=null,lt=!1}}}function s(){let z=!1,lt=null,X=null,j=null,pt=null,ut=null,Ht=null,Ie=null,Xe=null;return{setTest:function(ue){z||(ue?ct(i.STENCIL_TEST):kt(i.STENCIL_TEST))},setMask:function(ue){lt!==ue&&!z&&(i.stencilMask(ue),lt=ue)},setFunc:function(ue,Un,oi){(X!==ue||j!==Un||pt!==oi)&&(i.stencilFunc(ue,Un,oi),X=ue,j=Un,pt=oi)},setOp:function(ue,Un,oi){(ut!==ue||Ht!==Un||Ie!==oi)&&(i.stencilOp(ue,Un,oi),ut=ue,Ht=Un,Ie=oi)},setLocked:function(ue){z=ue},setClear:function(ue){Xe!==ue&&(i.clearStencil(ue),Xe=ue)},reset:function(){z=!1,lt=null,X=null,j=null,pt=null,ut=null,Ht=null,Ie=null,Xe=null}}}let r=new e,o=new n,a=new s,l=new WeakMap,c=new WeakMap,h={},u={},d=new WeakMap,f=[],g=null,x=!1,m=null,p=null,M=null,v=null,y=null,w=null,S=null,A=new bt(0,0,0),P=0,_=!1,b=null,R=null,L=null,D=null,N=null,W=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS),k=!1,q=0,H=i.getParameter(i.VERSION);H.indexOf("WebGL")!==-1?(q=parseFloat(/^WebGL (\d)/.exec(H)[1]),k=q>=1):H.indexOf("OpenGL ES")!==-1&&(q=parseFloat(/^OpenGL ES (\d)/.exec(H)[1]),k=q>=2);let K=null,Q={},at=i.getParameter(i.SCISSOR_BOX),Ct=i.getParameter(i.VIEWPORT),qt=new Me().fromArray(at),Y=new Me().fromArray(Ct);function et(z,lt,X,j){let pt=new Uint8Array(4),ut=i.createTexture();i.bindTexture(z,ut),i.texParameteri(z,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(z,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let Ht=0;Ht<X;Ht++)z===i.TEXTURE_3D||z===i.TEXTURE_2D_ARRAY?i.texImage3D(lt,0,i.RGBA,1,1,j,0,i.RGBA,i.UNSIGNED_BYTE,pt):i.texImage2D(lt+Ht,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,pt);return ut}let vt={};vt[i.TEXTURE_2D]=et(i.TEXTURE_2D,i.TEXTURE_2D,1),vt[i.TEXTURE_CUBE_MAP]=et(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),vt[i.TEXTURE_2D_ARRAY]=et(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),vt[i.TEXTURE_3D]=et(i.TEXTURE_3D,i.TEXTURE_3D,1,1),r.setClear(0,0,0,1),o.setClear(1),a.setClear(0),ct(i.DEPTH_TEST),o.setFunc(ir),jt(!1),Qt(zu),ct(i.CULL_FACE),O(Oi);function ct(z){h[z]!==!0&&(i.enable(z),h[z]=!0)}function kt(z){h[z]!==!1&&(i.disable(z),h[z]=!1)}function Bt(z,lt){return u[z]!==lt?(i.bindFramebuffer(z,lt),u[z]=lt,z===i.DRAW_FRAMEBUFFER&&(u[i.FRAMEBUFFER]=lt),z===i.FRAMEBUFFER&&(u[i.DRAW_FRAMEBUFFER]=lt),!0):!1}function Zt(z,lt){let X=f,j=!1;if(z){X=d.get(lt),X===void 0&&(X=[],d.set(lt,X));let pt=z.textures;if(X.length!==pt.length||X[0]!==i.COLOR_ATTACHMENT0){for(let ut=0,Ht=pt.length;ut<Ht;ut++)X[ut]=i.COLOR_ATTACHMENT0+ut;X.length=pt.length,j=!0}}else X[0]!==i.BACK&&(X[0]=i.BACK,j=!0);j&&i.drawBuffers(X)}function Ee(z){return g!==z?(i.useProgram(z),g=z,!0):!1}let ee={[cs]:i.FUNC_ADD,[Np]:i.FUNC_SUBTRACT,[zp]:i.FUNC_REVERSE_SUBTRACT};ee[Fp]=i.MIN,ee[Bp]=i.MAX;let ke={[Op]:i.ZERO,[Hp]:i.ONE,[Vp]:i.SRC_COLOR,[rc]:i.SRC_ALPHA,[Yp]:i.SRC_ALPHA_SATURATE,[qp]:i.DST_COLOR,[Wp]:i.DST_ALPHA,[Gp]:i.ONE_MINUS_SRC_COLOR,[oc]:i.ONE_MINUS_SRC_ALPHA,[Xp]:i.ONE_MINUS_DST_COLOR,[$p]:i.ONE_MINUS_DST_ALPHA,[Zp]:i.CONSTANT_COLOR,[Kp]:i.ONE_MINUS_CONSTANT_COLOR,[Jp]:i.CONSTANT_ALPHA,[jp]:i.ONE_MINUS_CONSTANT_ALPHA};function O(z,lt,X,j,pt,ut,Ht,Ie,Xe,ue){if(z===Oi){x===!0&&(kt(i.BLEND),x=!1);return}if(x===!1&&(ct(i.BLEND),x=!0),z!==Up){if(z!==m||ue!==_){if((p!==cs||y!==cs)&&(i.blendEquation(i.FUNC_ADD),p=cs,y=cs),ue)switch(z){case Qs:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Fu:i.blendFunc(i.ONE,i.ONE);break;case Bu:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case Ou:i.blendFuncSeparate(i.ZERO,i.SRC_COLOR,i.ZERO,i.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",z);break}else switch(z){case Qs:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Fu:i.blendFunc(i.SRC_ALPHA,i.ONE);break;case Bu:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case Ou:i.blendFunc(i.ZERO,i.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",z);break}M=null,v=null,w=null,S=null,A.set(0,0,0),P=0,m=z,_=ue}return}pt=pt||lt,ut=ut||X,Ht=Ht||j,(lt!==p||pt!==y)&&(i.blendEquationSeparate(ee[lt],ee[pt]),p=lt,y=pt),(X!==M||j!==v||ut!==w||Ht!==S)&&(i.blendFuncSeparate(ke[X],ke[j],ke[ut],ke[Ht]),M=X,v=j,w=ut,S=Ht),(Ie.equals(A)===!1||Xe!==P)&&(i.blendColor(Ie.r,Ie.g,Ie.b,Xe),A.copy(Ie),P=Xe),m=z,_=!1}function Rn(z,lt){z.side===Te?kt(i.CULL_FACE):ct(i.CULL_FACE);let X=z.side===Ke;lt&&(X=!X),jt(X),z.blending===Qs&&z.transparent===!1?O(Oi):O(z.blending,z.blendEquation,z.blendSrc,z.blendDst,z.blendEquationAlpha,z.blendSrcAlpha,z.blendDstAlpha,z.blendColor,z.blendAlpha,z.premultipliedAlpha),o.setFunc(z.depthFunc),o.setTest(z.depthTest),o.setMask(z.depthWrite),r.setMask(z.colorWrite);let j=z.stencilWrite;a.setTest(j),j&&(a.setMask(z.stencilWriteMask),a.setFunc(z.stencilFunc,z.stencilRef,z.stencilFuncMask),a.setOp(z.stencilFail,z.stencilZFail,z.stencilZPass)),ve(z.polygonOffset,z.polygonOffsetFactor,z.polygonOffsetUnits),z.alphaToCoverage===!0?ct(i.SAMPLE_ALPHA_TO_COVERAGE):kt(i.SAMPLE_ALPHA_TO_COVERAGE)}function jt(z){b!==z&&(z?i.frontFace(i.CW):i.frontFace(i.CCW),b=z)}function Qt(z){z!==Dp?(ct(i.CULL_FACE),z!==R&&(z===zu?i.cullFace(i.BACK):z===kp?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):kt(i.CULL_FACE),R=z}function It(z){z!==L&&(k&&i.lineWidth(z),L=z)}function ve(z,lt,X){z?(ct(i.POLYGON_OFFSET_FILL),(D!==lt||N!==X)&&(i.polygonOffset(lt,X),D=lt,N=X)):kt(i.POLYGON_OFFSET_FILL)}function Pt(z){z?ct(i.SCISSOR_TEST):kt(i.SCISSOR_TEST)}function I(z){z===void 0&&(z=i.TEXTURE0+W-1),K!==z&&(i.activeTexture(z),K=z)}function E(z,lt,X){X===void 0&&(K===null?X=i.TEXTURE0+W-1:X=K);let j=Q[X];j===void 0&&(j={type:void 0,texture:void 0},Q[X]=j),(j.type!==z||j.texture!==lt)&&(K!==X&&(i.activeTexture(X),K=X),i.bindTexture(z,lt||vt[z]),j.type=z,j.texture=lt)}function V(){let z=Q[K];z!==void 0&&z.type!==void 0&&(i.bindTexture(z.type,null),z.type=void 0,z.texture=void 0)}function J(){try{i.compressedTexImage2D.apply(i,arguments)}catch(z){console.error("THREE.WebGLState:",z)}}function tt(){try{i.compressedTexImage3D.apply(i,arguments)}catch(z){console.error("THREE.WebGLState:",z)}}function Z(){try{i.texSubImage2D.apply(i,arguments)}catch(z){console.error("THREE.WebGLState:",z)}}function St(){try{i.texSubImage3D.apply(i,arguments)}catch(z){console.error("THREE.WebGLState:",z)}}function ht(){try{i.compressedTexSubImage2D.apply(i,arguments)}catch(z){console.error("THREE.WebGLState:",z)}}function mt(){try{i.compressedTexSubImage3D.apply(i,arguments)}catch(z){console.error("THREE.WebGLState:",z)}}function ne(){try{i.texStorage2D.apply(i,arguments)}catch(z){console.error("THREE.WebGLState:",z)}}function it(){try{i.texStorage3D.apply(i,arguments)}catch(z){console.error("THREE.WebGLState:",z)}}function gt(){try{i.texImage2D.apply(i,arguments)}catch(z){console.error("THREE.WebGLState:",z)}}function Dt(){try{i.texImage3D.apply(i,arguments)}catch(z){console.error("THREE.WebGLState:",z)}}function Nt(z){qt.equals(z)===!1&&(i.scissor(z.x,z.y,z.z,z.w),qt.copy(z))}function xt(z){Y.equals(z)===!1&&(i.viewport(z.x,z.y,z.z,z.w),Y.copy(z))}function te(z,lt){let X=c.get(lt);X===void 0&&(X=new WeakMap,c.set(lt,X));let j=X.get(z);j===void 0&&(j=i.getUniformBlockIndex(lt,z.name),X.set(z,j))}function Xt(z,lt){let j=c.get(lt).get(z);l.get(lt)!==j&&(i.uniformBlockBinding(lt,j,z.__bindingPointIndex),l.set(lt,j))}function ge(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),o.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),h={},K=null,Q={},u={},d=new WeakMap,f=[],g=null,x=!1,m=null,p=null,M=null,v=null,y=null,w=null,S=null,A=new bt(0,0,0),P=0,_=!1,b=null,R=null,L=null,D=null,N=null,qt.set(0,0,i.canvas.width,i.canvas.height),Y.set(0,0,i.canvas.width,i.canvas.height),r.reset(),o.reset(),a.reset()}return{buffers:{color:r,depth:o,stencil:a},enable:ct,disable:kt,bindFramebuffer:Bt,drawBuffers:Zt,useProgram:Ee,setBlending:O,setMaterial:Rn,setFlipSided:jt,setCullFace:Qt,setLineWidth:It,setPolygonOffset:ve,setScissorTest:Pt,activeTexture:I,bindTexture:E,unbindTexture:V,compressedTexImage2D:J,compressedTexImage3D:tt,texImage2D:gt,texImage3D:Dt,updateUBOMapping:te,uniformBlockBinding:Xt,texStorage2D:ne,texStorage3D:it,texSubImage2D:Z,texSubImage3D:St,compressedTexSubImage2D:ht,compressedTexSubImage3D:mt,scissor:Nt,viewport:xt,reset:ge}}function Nd(i,t,e,n){let s=_v(n);switch(e){case lf:return i*t;case hf:return i*t;case uf:return i*t*2;case Uh:return i*t/s.components*s.byteLength;case Nh:return i*t/s.components*s.byteLength;case df:return i*t*2/s.components*s.byteLength;case zh:return i*t*2/s.components*s.byteLength;case cf:return i*t*3/s.components*s.byteLength;case Hn:return i*t*4/s.components*s.byteLength;case Fh:return i*t*4/s.components*s.byteLength;case ca:case ha:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*8;case ua:case da:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case yc:case bc:return Math.max(i,16)*Math.max(t,8)/4;case xc:case vc:return Math.max(i,8)*Math.max(t,8)/2;case _c:case Mc:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*8;case wc:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case Sc:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case Ec:return Math.floor((i+4)/5)*Math.floor((t+3)/4)*16;case Tc:return Math.floor((i+4)/5)*Math.floor((t+4)/5)*16;case Ac:return Math.floor((i+5)/6)*Math.floor((t+4)/5)*16;case Rc:return Math.floor((i+5)/6)*Math.floor((t+5)/6)*16;case Cc:return Math.floor((i+7)/8)*Math.floor((t+4)/5)*16;case Pc:return Math.floor((i+7)/8)*Math.floor((t+5)/6)*16;case Ic:return Math.floor((i+7)/8)*Math.floor((t+7)/8)*16;case Lc:return Math.floor((i+9)/10)*Math.floor((t+4)/5)*16;case Dc:return Math.floor((i+9)/10)*Math.floor((t+5)/6)*16;case kc:return Math.floor((i+9)/10)*Math.floor((t+7)/8)*16;case Uc:return Math.floor((i+9)/10)*Math.floor((t+9)/10)*16;case Nc:return Math.floor((i+11)/12)*Math.floor((t+9)/10)*16;case zc:return Math.floor((i+11)/12)*Math.floor((t+11)/12)*16;case fa:case Fc:case Bc:return Math.ceil(i/4)*Math.ceil(t/4)*16;case ff:case Oc:return Math.ceil(i/4)*Math.ceil(t/4)*8;case Hc:case Vc:return Math.ceil(i/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${e} format.`)}function _v(i){switch(i){case xi:case rf:return{byteLength:1,components:1};case Yr:case of:case ho:return{byteLength:2,components:1};case Dh:case kh:return{byteLength:2,components:4};case fs:case Lh:case Kn:return{byteLength:4,components:1};case af:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${i}.`)}function Mv(i,t,e,n,s,r,o){let a=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new rt,h=new WeakMap,u,d=new WeakMap,f=!1;try{f=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(I,E){return f?new OffscreenCanvas(I,E):ga("canvas")}function x(I,E,V){let J=1,tt=Pt(I);if((tt.width>V||tt.height>V)&&(J=V/Math.max(tt.width,tt.height)),J<1)if(typeof HTMLImageElement<"u"&&I instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&I instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&I instanceof ImageBitmap||typeof VideoFrame<"u"&&I instanceof VideoFrame){let Z=Math.floor(J*tt.width),St=Math.floor(J*tt.height);u===void 0&&(u=g(Z,St));let ht=E?g(Z,St):u;return ht.width=Z,ht.height=St,ht.getContext("2d").drawImage(I,0,0,Z,St),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+tt.width+"x"+tt.height+") to ("+Z+"x"+St+")."),ht}else return"data"in I&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+tt.width+"x"+tt.height+")."),I;return I}function m(I){return I.generateMipmaps}function p(I){i.generateMipmap(I)}function M(I){return I.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:I.isWebGL3DRenderTarget?i.TEXTURE_3D:I.isWebGLArrayRenderTarget||I.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function v(I,E,V,J,tt=!1){if(I!==null){if(i[I]!==void 0)return i[I];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+I+"'")}let Z=E;if(E===i.RED&&(V===i.FLOAT&&(Z=i.R32F),V===i.HALF_FLOAT&&(Z=i.R16F),V===i.UNSIGNED_BYTE&&(Z=i.R8)),E===i.RED_INTEGER&&(V===i.UNSIGNED_BYTE&&(Z=i.R8UI),V===i.UNSIGNED_SHORT&&(Z=i.R16UI),V===i.UNSIGNED_INT&&(Z=i.R32UI),V===i.BYTE&&(Z=i.R8I),V===i.SHORT&&(Z=i.R16I),V===i.INT&&(Z=i.R32I)),E===i.RG&&(V===i.FLOAT&&(Z=i.RG32F),V===i.HALF_FLOAT&&(Z=i.RG16F),V===i.UNSIGNED_BYTE&&(Z=i.RG8)),E===i.RG_INTEGER&&(V===i.UNSIGNED_BYTE&&(Z=i.RG8UI),V===i.UNSIGNED_SHORT&&(Z=i.RG16UI),V===i.UNSIGNED_INT&&(Z=i.RG32UI),V===i.BYTE&&(Z=i.RG8I),V===i.SHORT&&(Z=i.RG16I),V===i.INT&&(Z=i.RG32I)),E===i.RGB_INTEGER&&(V===i.UNSIGNED_BYTE&&(Z=i.RGB8UI),V===i.UNSIGNED_SHORT&&(Z=i.RGB16UI),V===i.UNSIGNED_INT&&(Z=i.RGB32UI),V===i.BYTE&&(Z=i.RGB8I),V===i.SHORT&&(Z=i.RGB16I),V===i.INT&&(Z=i.RGB32I)),E===i.RGBA_INTEGER&&(V===i.UNSIGNED_BYTE&&(Z=i.RGBA8UI),V===i.UNSIGNED_SHORT&&(Z=i.RGBA16UI),V===i.UNSIGNED_INT&&(Z=i.RGBA32UI),V===i.BYTE&&(Z=i.RGBA8I),V===i.SHORT&&(Z=i.RGBA16I),V===i.INT&&(Z=i.RGBA32I)),E===i.RGB&&V===i.UNSIGNED_INT_5_9_9_9_REV&&(Z=i.RGB9_E5),E===i.RGBA){let St=tt?qa:ie.getTransfer(J);V===i.FLOAT&&(Z=i.RGBA32F),V===i.HALF_FLOAT&&(Z=i.RGBA16F),V===i.UNSIGNED_BYTE&&(Z=St===pe?i.SRGB8_ALPHA8:i.RGBA8),V===i.UNSIGNED_SHORT_4_4_4_4&&(Z=i.RGBA4),V===i.UNSIGNED_SHORT_5_5_5_1&&(Z=i.RGB5_A1)}return(Z===i.R16F||Z===i.R32F||Z===i.RG16F||Z===i.RG32F||Z===i.RGBA16F||Z===i.RGBA32F)&&t.get("EXT_color_buffer_float"),Z}function y(I,E){let V;return I?E===null||E===fs||E===or?V=i.DEPTH24_STENCIL8:E===Kn?V=i.DEPTH32F_STENCIL8:E===Yr&&(V=i.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):E===null||E===fs||E===or?V=i.DEPTH_COMPONENT24:E===Kn?V=i.DEPTH_COMPONENT32F:E===Yr&&(V=i.DEPTH_COMPONENT16),V}function w(I,E){return m(I)===!0||I.isFramebufferTexture&&I.minFilter!==_n&&I.minFilter!==In?Math.log2(Math.max(E.width,E.height))+1:I.mipmaps!==void 0&&I.mipmaps.length>0?I.mipmaps.length:I.isCompressedTexture&&Array.isArray(I.image)?E.mipmaps.length:1}function S(I){let E=I.target;E.removeEventListener("dispose",S),P(E),E.isVideoTexture&&h.delete(E)}function A(I){let E=I.target;E.removeEventListener("dispose",A),b(E)}function P(I){let E=n.get(I);if(E.__webglInit===void 0)return;let V=I.source,J=d.get(V);if(J){let tt=J[E.__cacheKey];tt.usedTimes--,tt.usedTimes===0&&_(I),Object.keys(J).length===0&&d.delete(V)}n.remove(I)}function _(I){let E=n.get(I);i.deleteTexture(E.__webglTexture);let V=I.source,J=d.get(V);delete J[E.__cacheKey],o.memory.textures--}function b(I){let E=n.get(I);if(I.depthTexture&&(I.depthTexture.dispose(),n.remove(I.depthTexture)),I.isWebGLCubeRenderTarget)for(let J=0;J<6;J++){if(Array.isArray(E.__webglFramebuffer[J]))for(let tt=0;tt<E.__webglFramebuffer[J].length;tt++)i.deleteFramebuffer(E.__webglFramebuffer[J][tt]);else i.deleteFramebuffer(E.__webglFramebuffer[J]);E.__webglDepthbuffer&&i.deleteRenderbuffer(E.__webglDepthbuffer[J])}else{if(Array.isArray(E.__webglFramebuffer))for(let J=0;J<E.__webglFramebuffer.length;J++)i.deleteFramebuffer(E.__webglFramebuffer[J]);else i.deleteFramebuffer(E.__webglFramebuffer);if(E.__webglDepthbuffer&&i.deleteRenderbuffer(E.__webglDepthbuffer),E.__webglMultisampledFramebuffer&&i.deleteFramebuffer(E.__webglMultisampledFramebuffer),E.__webglColorRenderbuffer)for(let J=0;J<E.__webglColorRenderbuffer.length;J++)E.__webglColorRenderbuffer[J]&&i.deleteRenderbuffer(E.__webglColorRenderbuffer[J]);E.__webglDepthRenderbuffer&&i.deleteRenderbuffer(E.__webglDepthRenderbuffer)}let V=I.textures;for(let J=0,tt=V.length;J<tt;J++){let Z=n.get(V[J]);Z.__webglTexture&&(i.deleteTexture(Z.__webglTexture),o.memory.textures--),n.remove(V[J])}n.remove(I)}let R=0;function L(){R=0}function D(){let I=R;return I>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+I+" texture units while this GPU supports only "+s.maxTextures),R+=1,I}function N(I){let E=[];return E.push(I.wrapS),E.push(I.wrapT),E.push(I.wrapR||0),E.push(I.magFilter),E.push(I.minFilter),E.push(I.anisotropy),E.push(I.internalFormat),E.push(I.format),E.push(I.type),E.push(I.generateMipmaps),E.push(I.premultiplyAlpha),E.push(I.flipY),E.push(I.unpackAlignment),E.push(I.colorSpace),E.join()}function W(I,E){let V=n.get(I);if(I.isVideoTexture&&It(I),I.isRenderTargetTexture===!1&&I.version>0&&V.__version!==I.version){let J=I.image;if(J===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(J.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{Y(V,I,E);return}}e.bindTexture(i.TEXTURE_2D,V.__webglTexture,i.TEXTURE0+E)}function k(I,E){let V=n.get(I);if(I.version>0&&V.__version!==I.version){Y(V,I,E);return}e.bindTexture(i.TEXTURE_2D_ARRAY,V.__webglTexture,i.TEXTURE0+E)}function q(I,E){let V=n.get(I);if(I.version>0&&V.__version!==I.version){Y(V,I,E);return}e.bindTexture(i.TEXTURE_3D,V.__webglTexture,i.TEXTURE0+E)}function H(I,E){let V=n.get(I);if(I.version>0&&V.__version!==I.version){et(V,I,E);return}e.bindTexture(i.TEXTURE_CUBE_MAP,V.__webglTexture,i.TEXTURE0+E)}let K={[ds]:i.REPEAT,[us]:i.CLAMP_TO_EDGE,[gc]:i.MIRRORED_REPEAT},Q={[_n]:i.NEAREST,[am]:i.NEAREST_MIPMAP_NEAREST,[Lo]:i.NEAREST_MIPMAP_LINEAR,[In]:i.LINEAR,[El]:i.LINEAR_MIPMAP_NEAREST,[pi]:i.LINEAR_MIPMAP_LINEAR},at={[um]:i.NEVER,[xm]:i.ALWAYS,[dm]:i.LESS,[mf]:i.LEQUAL,[fm]:i.EQUAL,[gm]:i.GEQUAL,[pm]:i.GREATER,[mm]:i.NOTEQUAL};function Ct(I,E){if(E.type===Kn&&t.has("OES_texture_float_linear")===!1&&(E.magFilter===In||E.magFilter===El||E.magFilter===Lo||E.magFilter===pi||E.minFilter===In||E.minFilter===El||E.minFilter===Lo||E.minFilter===pi)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(I,i.TEXTURE_WRAP_S,K[E.wrapS]),i.texParameteri(I,i.TEXTURE_WRAP_T,K[E.wrapT]),(I===i.TEXTURE_3D||I===i.TEXTURE_2D_ARRAY)&&i.texParameteri(I,i.TEXTURE_WRAP_R,K[E.wrapR]),i.texParameteri(I,i.TEXTURE_MAG_FILTER,Q[E.magFilter]),i.texParameteri(I,i.TEXTURE_MIN_FILTER,Q[E.minFilter]),E.compareFunction&&(i.texParameteri(I,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(I,i.TEXTURE_COMPARE_FUNC,at[E.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(E.magFilter===_n||E.minFilter!==Lo&&E.minFilter!==pi||E.type===Kn&&t.has("OES_texture_float_linear")===!1)return;if(E.anisotropy>1||n.get(E).__currentAnisotropy){let V=t.get("EXT_texture_filter_anisotropic");i.texParameterf(I,V.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(E.anisotropy,s.getMaxAnisotropy())),n.get(E).__currentAnisotropy=E.anisotropy}}}function qt(I,E){let V=!1;I.__webglInit===void 0&&(I.__webglInit=!0,E.addEventListener("dispose",S));let J=E.source,tt=d.get(J);tt===void 0&&(tt={},d.set(J,tt));let Z=N(E);if(Z!==I.__cacheKey){tt[Z]===void 0&&(tt[Z]={texture:i.createTexture(),usedTimes:0},o.memory.textures++,V=!0),tt[Z].usedTimes++;let St=tt[I.__cacheKey];St!==void 0&&(tt[I.__cacheKey].usedTimes--,St.usedTimes===0&&_(E)),I.__cacheKey=Z,I.__webglTexture=tt[Z].texture}return V}function Y(I,E,V){let J=i.TEXTURE_2D;(E.isDataArrayTexture||E.isCompressedArrayTexture)&&(J=i.TEXTURE_2D_ARRAY),E.isData3DTexture&&(J=i.TEXTURE_3D);let tt=qt(I,E),Z=E.source;e.bindTexture(J,I.__webglTexture,i.TEXTURE0+V);let St=n.get(Z);if(Z.version!==St.__version||tt===!0){e.activeTexture(i.TEXTURE0+V);let ht=ie.getPrimaries(ie.workingColorSpace),mt=E.colorSpace===Fi?null:ie.getPrimaries(E.colorSpace),ne=E.colorSpace===Fi||ht===mt?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,E.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,E.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,ne);let it=x(E.image,!1,s.maxTextureSize);it=ve(E,it);let gt=r.convert(E.format,E.colorSpace),Dt=r.convert(E.type),Nt=v(E.internalFormat,gt,Dt,E.colorSpace,E.isVideoTexture);Ct(J,E);let xt,te=E.mipmaps,Xt=E.isVideoTexture!==!0,ge=St.__version===void 0||tt===!0,z=Z.dataReady,lt=w(E,it);if(E.isDepthTexture)Nt=y(E.format===ar,E.type),ge&&(Xt?e.texStorage2D(i.TEXTURE_2D,1,Nt,it.width,it.height):e.texImage2D(i.TEXTURE_2D,0,Nt,it.width,it.height,0,gt,Dt,null));else if(E.isDataTexture)if(te.length>0){Xt&&ge&&e.texStorage2D(i.TEXTURE_2D,lt,Nt,te[0].width,te[0].height);for(let X=0,j=te.length;X<j;X++)xt=te[X],Xt?z&&e.texSubImage2D(i.TEXTURE_2D,X,0,0,xt.width,xt.height,gt,Dt,xt.data):e.texImage2D(i.TEXTURE_2D,X,Nt,xt.width,xt.height,0,gt,Dt,xt.data);E.generateMipmaps=!1}else Xt?(ge&&e.texStorage2D(i.TEXTURE_2D,lt,Nt,it.width,it.height),z&&e.texSubImage2D(i.TEXTURE_2D,0,0,0,it.width,it.height,gt,Dt,it.data)):e.texImage2D(i.TEXTURE_2D,0,Nt,it.width,it.height,0,gt,Dt,it.data);else if(E.isCompressedTexture)if(E.isCompressedArrayTexture){Xt&&ge&&e.texStorage3D(i.TEXTURE_2D_ARRAY,lt,Nt,te[0].width,te[0].height,it.depth);for(let X=0,j=te.length;X<j;X++)if(xt=te[X],E.format!==Hn)if(gt!==null)if(Xt){if(z)if(E.layerUpdates.size>0){let pt=Nd(xt.width,xt.height,E.format,E.type);for(let ut of E.layerUpdates){let Ht=xt.data.subarray(ut*pt/xt.data.BYTES_PER_ELEMENT,(ut+1)*pt/xt.data.BYTES_PER_ELEMENT);e.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,X,0,0,ut,xt.width,xt.height,1,gt,Ht)}E.clearLayerUpdates()}else e.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,X,0,0,0,xt.width,xt.height,it.depth,gt,xt.data)}else e.compressedTexImage3D(i.TEXTURE_2D_ARRAY,X,Nt,xt.width,xt.height,it.depth,0,xt.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else Xt?z&&e.texSubImage3D(i.TEXTURE_2D_ARRAY,X,0,0,0,xt.width,xt.height,it.depth,gt,Dt,xt.data):e.texImage3D(i.TEXTURE_2D_ARRAY,X,Nt,xt.width,xt.height,it.depth,0,gt,Dt,xt.data)}else{Xt&&ge&&e.texStorage2D(i.TEXTURE_2D,lt,Nt,te[0].width,te[0].height);for(let X=0,j=te.length;X<j;X++)xt=te[X],E.format!==Hn?gt!==null?Xt?z&&e.compressedTexSubImage2D(i.TEXTURE_2D,X,0,0,xt.width,xt.height,gt,xt.data):e.compressedTexImage2D(i.TEXTURE_2D,X,Nt,xt.width,xt.height,0,xt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Xt?z&&e.texSubImage2D(i.TEXTURE_2D,X,0,0,xt.width,xt.height,gt,Dt,xt.data):e.texImage2D(i.TEXTURE_2D,X,Nt,xt.width,xt.height,0,gt,Dt,xt.data)}else if(E.isDataArrayTexture)if(Xt){if(ge&&e.texStorage3D(i.TEXTURE_2D_ARRAY,lt,Nt,it.width,it.height,it.depth),z)if(E.layerUpdates.size>0){let X=Nd(it.width,it.height,E.format,E.type);for(let j of E.layerUpdates){let pt=it.data.subarray(j*X/it.data.BYTES_PER_ELEMENT,(j+1)*X/it.data.BYTES_PER_ELEMENT);e.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,j,it.width,it.height,1,gt,Dt,pt)}E.clearLayerUpdates()}else e.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,it.width,it.height,it.depth,gt,Dt,it.data)}else e.texImage3D(i.TEXTURE_2D_ARRAY,0,Nt,it.width,it.height,it.depth,0,gt,Dt,it.data);else if(E.isData3DTexture)Xt?(ge&&e.texStorage3D(i.TEXTURE_3D,lt,Nt,it.width,it.height,it.depth),z&&e.texSubImage3D(i.TEXTURE_3D,0,0,0,0,it.width,it.height,it.depth,gt,Dt,it.data)):e.texImage3D(i.TEXTURE_3D,0,Nt,it.width,it.height,it.depth,0,gt,Dt,it.data);else if(E.isFramebufferTexture){if(ge)if(Xt)e.texStorage2D(i.TEXTURE_2D,lt,Nt,it.width,it.height);else{let X=it.width,j=it.height;for(let pt=0;pt<lt;pt++)e.texImage2D(i.TEXTURE_2D,pt,Nt,X,j,0,gt,Dt,null),X>>=1,j>>=1}}else if(te.length>0){if(Xt&&ge){let X=Pt(te[0]);e.texStorage2D(i.TEXTURE_2D,lt,Nt,X.width,X.height)}for(let X=0,j=te.length;X<j;X++)xt=te[X],Xt?z&&e.texSubImage2D(i.TEXTURE_2D,X,0,0,gt,Dt,xt):e.texImage2D(i.TEXTURE_2D,X,Nt,gt,Dt,xt);E.generateMipmaps=!1}else if(Xt){if(ge){let X=Pt(it);e.texStorage2D(i.TEXTURE_2D,lt,Nt,X.width,X.height)}z&&e.texSubImage2D(i.TEXTURE_2D,0,0,0,gt,Dt,it)}else e.texImage2D(i.TEXTURE_2D,0,Nt,gt,Dt,it);m(E)&&p(J),St.__version=Z.version,E.onUpdate&&E.onUpdate(E)}I.__version=E.version}function et(I,E,V){if(E.image.length!==6)return;let J=qt(I,E),tt=E.source;e.bindTexture(i.TEXTURE_CUBE_MAP,I.__webglTexture,i.TEXTURE0+V);let Z=n.get(tt);if(tt.version!==Z.__version||J===!0){e.activeTexture(i.TEXTURE0+V);let St=ie.getPrimaries(ie.workingColorSpace),ht=E.colorSpace===Fi?null:ie.getPrimaries(E.colorSpace),mt=E.colorSpace===Fi||St===ht?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,E.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,E.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,mt);let ne=E.isCompressedTexture||E.image[0].isCompressedTexture,it=E.image[0]&&E.image[0].isDataTexture,gt=[];for(let j=0;j<6;j++)!ne&&!it?gt[j]=x(E.image[j],!0,s.maxCubemapSize):gt[j]=it?E.image[j].image:E.image[j],gt[j]=ve(E,gt[j]);let Dt=gt[0],Nt=r.convert(E.format,E.colorSpace),xt=r.convert(E.type),te=v(E.internalFormat,Nt,xt,E.colorSpace),Xt=E.isVideoTexture!==!0,ge=Z.__version===void 0||J===!0,z=tt.dataReady,lt=w(E,Dt);Ct(i.TEXTURE_CUBE_MAP,E);let X;if(ne){Xt&&ge&&e.texStorage2D(i.TEXTURE_CUBE_MAP,lt,te,Dt.width,Dt.height);for(let j=0;j<6;j++){X=gt[j].mipmaps;for(let pt=0;pt<X.length;pt++){let ut=X[pt];E.format!==Hn?Nt!==null?Xt?z&&e.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,pt,0,0,ut.width,ut.height,Nt,ut.data):e.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,pt,te,ut.width,ut.height,0,ut.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Xt?z&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,pt,0,0,ut.width,ut.height,Nt,xt,ut.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,pt,te,ut.width,ut.height,0,Nt,xt,ut.data)}}}else{if(X=E.mipmaps,Xt&&ge){X.length>0&&lt++;let j=Pt(gt[0]);e.texStorage2D(i.TEXTURE_CUBE_MAP,lt,te,j.width,j.height)}for(let j=0;j<6;j++)if(it){Xt?z&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,0,0,0,gt[j].width,gt[j].height,Nt,xt,gt[j].data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,0,te,gt[j].width,gt[j].height,0,Nt,xt,gt[j].data);for(let pt=0;pt<X.length;pt++){let Ht=X[pt].image[j].image;Xt?z&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,pt+1,0,0,Ht.width,Ht.height,Nt,xt,Ht.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,pt+1,te,Ht.width,Ht.height,0,Nt,xt,Ht.data)}}else{Xt?z&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,0,0,0,Nt,xt,gt[j]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,0,te,Nt,xt,gt[j]);for(let pt=0;pt<X.length;pt++){let ut=X[pt];Xt?z&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,pt+1,0,0,Nt,xt,ut.image[j]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+j,pt+1,te,Nt,xt,ut.image[j])}}}m(E)&&p(i.TEXTURE_CUBE_MAP),Z.__version=tt.version,E.onUpdate&&E.onUpdate(E)}I.__version=E.version}function vt(I,E,V,J,tt,Z){let St=r.convert(V.format,V.colorSpace),ht=r.convert(V.type),mt=v(V.internalFormat,St,ht,V.colorSpace),ne=n.get(E),it=n.get(V);if(it.__renderTarget=E,!ne.__hasExternalTextures){let gt=Math.max(1,E.width>>Z),Dt=Math.max(1,E.height>>Z);tt===i.TEXTURE_3D||tt===i.TEXTURE_2D_ARRAY?e.texImage3D(tt,Z,mt,gt,Dt,E.depth,0,St,ht,null):e.texImage2D(tt,Z,mt,gt,Dt,0,St,ht,null)}e.bindFramebuffer(i.FRAMEBUFFER,I),Qt(E)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,J,tt,it.__webglTexture,0,jt(E)):(tt===i.TEXTURE_2D||tt>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&tt<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,J,tt,it.__webglTexture,Z),e.bindFramebuffer(i.FRAMEBUFFER,null)}function ct(I,E,V){if(i.bindRenderbuffer(i.RENDERBUFFER,I),E.depthBuffer){let J=E.depthTexture,tt=J&&J.isDepthTexture?J.type:null,Z=y(E.stencilBuffer,tt),St=E.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,ht=jt(E);Qt(E)?a.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,ht,Z,E.width,E.height):V?i.renderbufferStorageMultisample(i.RENDERBUFFER,ht,Z,E.width,E.height):i.renderbufferStorage(i.RENDERBUFFER,Z,E.width,E.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,St,i.RENDERBUFFER,I)}else{let J=E.textures;for(let tt=0;tt<J.length;tt++){let Z=J[tt],St=r.convert(Z.format,Z.colorSpace),ht=r.convert(Z.type),mt=v(Z.internalFormat,St,ht,Z.colorSpace),ne=jt(E);V&&Qt(E)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,ne,mt,E.width,E.height):Qt(E)?a.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,ne,mt,E.width,E.height):i.renderbufferStorage(i.RENDERBUFFER,mt,E.width,E.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function kt(I,E){if(E&&E.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(i.FRAMEBUFFER,I),!(E.depthTexture&&E.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");let J=n.get(E.depthTexture);J.__renderTarget=E,(!J.__webglTexture||E.depthTexture.image.width!==E.width||E.depthTexture.image.height!==E.height)&&(E.depthTexture.image.width=E.width,E.depthTexture.image.height=E.height,E.depthTexture.needsUpdate=!0),W(E.depthTexture,0);let tt=J.__webglTexture,Z=jt(E);if(E.depthTexture.format===tr)Qt(E)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,tt,0,Z):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,tt,0);else if(E.depthTexture.format===ar)Qt(E)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,tt,0,Z):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,tt,0);else throw new Error("Unknown depthTexture format")}function Bt(I){let E=n.get(I),V=I.isWebGLCubeRenderTarget===!0;if(E.__boundDepthTexture!==I.depthTexture){let J=I.depthTexture;if(E.__depthDisposeCallback&&E.__depthDisposeCallback(),J){let tt=()=>{delete E.__boundDepthTexture,delete E.__depthDisposeCallback,J.removeEventListener("dispose",tt)};J.addEventListener("dispose",tt),E.__depthDisposeCallback=tt}E.__boundDepthTexture=J}if(I.depthTexture&&!E.__autoAllocateDepthBuffer){if(V)throw new Error("target.depthTexture not supported in Cube render targets");kt(E.__webglFramebuffer,I)}else if(V){E.__webglDepthbuffer=[];for(let J=0;J<6;J++)if(e.bindFramebuffer(i.FRAMEBUFFER,E.__webglFramebuffer[J]),E.__webglDepthbuffer[J]===void 0)E.__webglDepthbuffer[J]=i.createRenderbuffer(),ct(E.__webglDepthbuffer[J],I,!1);else{let tt=I.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,Z=E.__webglDepthbuffer[J];i.bindRenderbuffer(i.RENDERBUFFER,Z),i.framebufferRenderbuffer(i.FRAMEBUFFER,tt,i.RENDERBUFFER,Z)}}else if(e.bindFramebuffer(i.FRAMEBUFFER,E.__webglFramebuffer),E.__webglDepthbuffer===void 0)E.__webglDepthbuffer=i.createRenderbuffer(),ct(E.__webglDepthbuffer,I,!1);else{let J=I.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,tt=E.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,tt),i.framebufferRenderbuffer(i.FRAMEBUFFER,J,i.RENDERBUFFER,tt)}e.bindFramebuffer(i.FRAMEBUFFER,null)}function Zt(I,E,V){let J=n.get(I);E!==void 0&&vt(J.__webglFramebuffer,I,I.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),V!==void 0&&Bt(I)}function Ee(I){let E=I.texture,V=n.get(I),J=n.get(E);I.addEventListener("dispose",A);let tt=I.textures,Z=I.isWebGLCubeRenderTarget===!0,St=tt.length>1;if(St||(J.__webglTexture===void 0&&(J.__webglTexture=i.createTexture()),J.__version=E.version,o.memory.textures++),Z){V.__webglFramebuffer=[];for(let ht=0;ht<6;ht++)if(E.mipmaps&&E.mipmaps.length>0){V.__webglFramebuffer[ht]=[];for(let mt=0;mt<E.mipmaps.length;mt++)V.__webglFramebuffer[ht][mt]=i.createFramebuffer()}else V.__webglFramebuffer[ht]=i.createFramebuffer()}else{if(E.mipmaps&&E.mipmaps.length>0){V.__webglFramebuffer=[];for(let ht=0;ht<E.mipmaps.length;ht++)V.__webglFramebuffer[ht]=i.createFramebuffer()}else V.__webglFramebuffer=i.createFramebuffer();if(St)for(let ht=0,mt=tt.length;ht<mt;ht++){let ne=n.get(tt[ht]);ne.__webglTexture===void 0&&(ne.__webglTexture=i.createTexture(),o.memory.textures++)}if(I.samples>0&&Qt(I)===!1){V.__webglMultisampledFramebuffer=i.createFramebuffer(),V.__webglColorRenderbuffer=[],e.bindFramebuffer(i.FRAMEBUFFER,V.__webglMultisampledFramebuffer);for(let ht=0;ht<tt.length;ht++){let mt=tt[ht];V.__webglColorRenderbuffer[ht]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,V.__webglColorRenderbuffer[ht]);let ne=r.convert(mt.format,mt.colorSpace),it=r.convert(mt.type),gt=v(mt.internalFormat,ne,it,mt.colorSpace,I.isXRRenderTarget===!0),Dt=jt(I);i.renderbufferStorageMultisample(i.RENDERBUFFER,Dt,gt,I.width,I.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+ht,i.RENDERBUFFER,V.__webglColorRenderbuffer[ht])}i.bindRenderbuffer(i.RENDERBUFFER,null),I.depthBuffer&&(V.__webglDepthRenderbuffer=i.createRenderbuffer(),ct(V.__webglDepthRenderbuffer,I,!0)),e.bindFramebuffer(i.FRAMEBUFFER,null)}}if(Z){e.bindTexture(i.TEXTURE_CUBE_MAP,J.__webglTexture),Ct(i.TEXTURE_CUBE_MAP,E);for(let ht=0;ht<6;ht++)if(E.mipmaps&&E.mipmaps.length>0)for(let mt=0;mt<E.mipmaps.length;mt++)vt(V.__webglFramebuffer[ht][mt],I,E,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+ht,mt);else vt(V.__webglFramebuffer[ht],I,E,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+ht,0);m(E)&&p(i.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(St){for(let ht=0,mt=tt.length;ht<mt;ht++){let ne=tt[ht],it=n.get(ne);e.bindTexture(i.TEXTURE_2D,it.__webglTexture),Ct(i.TEXTURE_2D,ne),vt(V.__webglFramebuffer,I,ne,i.COLOR_ATTACHMENT0+ht,i.TEXTURE_2D,0),m(ne)&&p(i.TEXTURE_2D)}e.unbindTexture()}else{let ht=i.TEXTURE_2D;if((I.isWebGL3DRenderTarget||I.isWebGLArrayRenderTarget)&&(ht=I.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),e.bindTexture(ht,J.__webglTexture),Ct(ht,E),E.mipmaps&&E.mipmaps.length>0)for(let mt=0;mt<E.mipmaps.length;mt++)vt(V.__webglFramebuffer[mt],I,E,i.COLOR_ATTACHMENT0,ht,mt);else vt(V.__webglFramebuffer,I,E,i.COLOR_ATTACHMENT0,ht,0);m(E)&&p(ht),e.unbindTexture()}I.depthBuffer&&Bt(I)}function ee(I){let E=I.textures;for(let V=0,J=E.length;V<J;V++){let tt=E[V];if(m(tt)){let Z=M(I),St=n.get(tt).__webglTexture;e.bindTexture(Z,St),p(Z),e.unbindTexture()}}}let ke=[],O=[];function Rn(I){if(I.samples>0){if(Qt(I)===!1){let E=I.textures,V=I.width,J=I.height,tt=i.COLOR_BUFFER_BIT,Z=I.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,St=n.get(I),ht=E.length>1;if(ht)for(let mt=0;mt<E.length;mt++)e.bindFramebuffer(i.FRAMEBUFFER,St.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+mt,i.RENDERBUFFER,null),e.bindFramebuffer(i.FRAMEBUFFER,St.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+mt,i.TEXTURE_2D,null,0);e.bindFramebuffer(i.READ_FRAMEBUFFER,St.__webglMultisampledFramebuffer),e.bindFramebuffer(i.DRAW_FRAMEBUFFER,St.__webglFramebuffer);for(let mt=0;mt<E.length;mt++){if(I.resolveDepthBuffer&&(I.depthBuffer&&(tt|=i.DEPTH_BUFFER_BIT),I.stencilBuffer&&I.resolveStencilBuffer&&(tt|=i.STENCIL_BUFFER_BIT)),ht){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,St.__webglColorRenderbuffer[mt]);let ne=n.get(E[mt]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,ne,0)}i.blitFramebuffer(0,0,V,J,0,0,V,J,tt,i.NEAREST),l===!0&&(ke.length=0,O.length=0,ke.push(i.COLOR_ATTACHMENT0+mt),I.depthBuffer&&I.resolveDepthBuffer===!1&&(ke.push(Z),O.push(Z),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,O)),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,ke))}if(e.bindFramebuffer(i.READ_FRAMEBUFFER,null),e.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),ht)for(let mt=0;mt<E.length;mt++){e.bindFramebuffer(i.FRAMEBUFFER,St.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+mt,i.RENDERBUFFER,St.__webglColorRenderbuffer[mt]);let ne=n.get(E[mt]).__webglTexture;e.bindFramebuffer(i.FRAMEBUFFER,St.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+mt,i.TEXTURE_2D,ne,0)}e.bindFramebuffer(i.DRAW_FRAMEBUFFER,St.__webglMultisampledFramebuffer)}else if(I.depthBuffer&&I.resolveDepthBuffer===!1&&l){let E=I.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[E])}}}function jt(I){return Math.min(s.maxSamples,I.samples)}function Qt(I){let E=n.get(I);return I.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&E.__useRenderToTexture!==!1}function It(I){let E=o.render.frame;h.get(I)!==E&&(h.set(I,E),I.update())}function ve(I,E){let V=I.colorSpace,J=I.format,tt=I.type;return I.isCompressedTexture===!0||I.isVideoTexture===!0||V!==fr&&V!==Fi&&(ie.getTransfer(V)===pe?(J!==Hn||tt!==xi)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",V)),E}function Pt(I){return typeof HTMLImageElement<"u"&&I instanceof HTMLImageElement?(c.width=I.naturalWidth||I.width,c.height=I.naturalHeight||I.height):typeof VideoFrame<"u"&&I instanceof VideoFrame?(c.width=I.displayWidth,c.height=I.displayHeight):(c.width=I.width,c.height=I.height),c}this.allocateTextureUnit=D,this.resetTextureUnits=L,this.setTexture2D=W,this.setTexture2DArray=k,this.setTexture3D=q,this.setTextureCube=H,this.rebindTextures=Zt,this.setupRenderTarget=Ee,this.updateRenderTargetMipmap=ee,this.updateMultisampleRenderTarget=Rn,this.setupDepthRenderbuffer=Bt,this.setupFrameBufferTexture=vt,this.useMultisampledRTT=Qt}function wv(i,t){function e(n,s=Fi){let r,o=ie.getTransfer(s);if(n===xi)return i.UNSIGNED_BYTE;if(n===Dh)return i.UNSIGNED_SHORT_4_4_4_4;if(n===kh)return i.UNSIGNED_SHORT_5_5_5_1;if(n===af)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===rf)return i.BYTE;if(n===of)return i.SHORT;if(n===Yr)return i.UNSIGNED_SHORT;if(n===Lh)return i.INT;if(n===fs)return i.UNSIGNED_INT;if(n===Kn)return i.FLOAT;if(n===ho)return i.HALF_FLOAT;if(n===lf)return i.ALPHA;if(n===cf)return i.RGB;if(n===Hn)return i.RGBA;if(n===hf)return i.LUMINANCE;if(n===uf)return i.LUMINANCE_ALPHA;if(n===tr)return i.DEPTH_COMPONENT;if(n===ar)return i.DEPTH_STENCIL;if(n===Uh)return i.RED;if(n===Nh)return i.RED_INTEGER;if(n===df)return i.RG;if(n===zh)return i.RG_INTEGER;if(n===Fh)return i.RGBA_INTEGER;if(n===ca||n===ha||n===ua||n===da)if(o===pe)if(r=t.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===ca)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===ha)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===ua)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===da)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=t.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===ca)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===ha)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===ua)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===da)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===xc||n===yc||n===vc||n===bc)if(r=t.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===xc)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===yc)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===vc)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===bc)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===_c||n===Mc||n===wc)if(r=t.get("WEBGL_compressed_texture_etc"),r!==null){if(n===_c||n===Mc)return o===pe?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===wc)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===Sc||n===Ec||n===Tc||n===Ac||n===Rc||n===Cc||n===Pc||n===Ic||n===Lc||n===Dc||n===kc||n===Uc||n===Nc||n===zc)if(r=t.get("WEBGL_compressed_texture_astc"),r!==null){if(n===Sc)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===Ec)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Tc)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===Ac)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===Rc)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===Cc)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Pc)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===Ic)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===Lc)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===Dc)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===kc)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===Uc)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Nc)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===zc)return o===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===fa||n===Fc||n===Bc)if(r=t.get("EXT_texture_compression_bptc"),r!==null){if(n===fa)return o===pe?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===Fc)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===Bc)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===ff||n===Oc||n===Hc||n===Vc)if(r=t.get("EXT_texture_compression_rgtc"),r!==null){if(n===fa)return r.COMPRESSED_RED_RGTC1_EXT;if(n===Oc)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===Hc)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===Vc)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===or?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:e}}var sh=class extends Be{constructor(t=[]){super(),this.isArrayCamera=!0,this.cameras=t}},Jt=class extends Oe{constructor(){super(),this.isGroup=!0,this.type="Group"}},Sv={type:"move"},Wr=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Jt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Jt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new C,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new C),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Jt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new C,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new C),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){let e=this._hand;if(e)for(let n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let s=null,r=null,o=null,a=this._targetRay,l=this._grip,c=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(c&&t.hand){o=!0;for(let x of t.hand.values()){let m=e.getJointPose(x,n),p=this._getHandJoint(c,x);m!==null&&(p.matrix.fromArray(m.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=m.radius),p.visible=m!==null}let h=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],d=h.position.distanceTo(u.position),f=.02,g=.005;c.inputState.pinching&&d>f+g?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!c.inputState.pinching&&d<=f-g&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else l!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,n),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1));a!==null&&(s=e.getPose(t.targetRaySpace,n),s===null&&r!==null&&(s=r),s!==null&&(a.matrix.fromArray(s.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,s.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(s.linearVelocity)):a.hasLinearVelocity=!1,s.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(s.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(Sv)))}return a!==null&&(a.visible=s!==null),l!==null&&(l.visible=r!==null),c!==null&&(c.visible=o!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){let n=new Jt;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}},Ev=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,Tv=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`,rh=class{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,e,n){if(this.texture===null){let s=new hn,r=t.properties.get(s);r.__webglTexture=e.texture,(e.depthNear!=n.depthNear||e.depthFar!=n.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=s}}getMesh(t){if(this.texture!==null&&this.mesh===null){let e=t.cameras[0].viewport,n=new dn({vertexShader:Ev,fragmentShader:Tv,uniforms:{depthColor:{value:this.texture},depthWidth:{value:e.z},depthHeight:{value:e.w}}});this.mesh=new nt(new Mn(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}},oh=class extends Vi{constructor(t,e){super();let n=this,s=null,r=1,o=null,a="local-floor",l=1,c=null,h=null,u=null,d=null,f=null,g=null,x=new rh,m=e.getContextAttributes(),p=null,M=null,v=[],y=[],w=new rt,S=null,A=new Be;A.viewport=new Me;let P=new Be;P.viewport=new Me;let _=[A,P],b=new sh,R=null,L=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(Y){let et=v[Y];return et===void 0&&(et=new Wr,v[Y]=et),et.getTargetRaySpace()},this.getControllerGrip=function(Y){let et=v[Y];return et===void 0&&(et=new Wr,v[Y]=et),et.getGripSpace()},this.getHand=function(Y){let et=v[Y];return et===void 0&&(et=new Wr,v[Y]=et),et.getHandSpace()};function D(Y){let et=y.indexOf(Y.inputSource);if(et===-1)return;let vt=v[et];vt!==void 0&&(vt.update(Y.inputSource,Y.frame,c||o),vt.dispatchEvent({type:Y.type,data:Y.inputSource}))}function N(){s.removeEventListener("select",D),s.removeEventListener("selectstart",D),s.removeEventListener("selectend",D),s.removeEventListener("squeeze",D),s.removeEventListener("squeezestart",D),s.removeEventListener("squeezeend",D),s.removeEventListener("end",N),s.removeEventListener("inputsourceschange",W);for(let Y=0;Y<v.length;Y++){let et=y[Y];et!==null&&(y[Y]=null,v[Y].disconnect(et))}R=null,L=null,x.reset(),t.setRenderTarget(p),f=null,d=null,u=null,s=null,M=null,qt.stop(),n.isPresenting=!1,t.setPixelRatio(S),t.setSize(w.width,w.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(Y){r=Y,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(Y){a=Y,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||o},this.setReferenceSpace=function(Y){c=Y},this.getBaseLayer=function(){return d!==null?d:f},this.getBinding=function(){return u},this.getFrame=function(){return g},this.getSession=function(){return s},this.setSession=async function(Y){if(s=Y,s!==null){if(p=t.getRenderTarget(),s.addEventListener("select",D),s.addEventListener("selectstart",D),s.addEventListener("selectend",D),s.addEventListener("squeeze",D),s.addEventListener("squeezestart",D),s.addEventListener("squeezeend",D),s.addEventListener("end",N),s.addEventListener("inputsourceschange",W),m.xrCompatible!==!0&&await e.makeXRCompatible(),S=t.getPixelRatio(),t.getSize(w),s.renderState.layers===void 0){let et={antialias:m.antialias,alpha:!0,depth:m.depth,stencil:m.stencil,framebufferScaleFactor:r};f=new XRWebGLLayer(s,e,et),s.updateRenderState({baseLayer:f}),t.setPixelRatio(1),t.setSize(f.framebufferWidth,f.framebufferHeight,!1),M=new Vn(f.framebufferWidth,f.framebufferHeight,{format:Hn,type:xi,colorSpace:t.outputColorSpace,stencilBuffer:m.stencil})}else{let et=null,vt=null,ct=null;m.depth&&(ct=m.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,et=m.stencil?ar:tr,vt=m.stencil?or:fs);let kt={colorFormat:e.RGBA8,depthFormat:ct,scaleFactor:r};u=new XRWebGLBinding(s,e),d=u.createProjectionLayer(kt),s.updateRenderState({layers:[d]}),t.setPixelRatio(1),t.setSize(d.textureWidth,d.textureHeight,!1),M=new Vn(d.textureWidth,d.textureHeight,{format:Hn,type:xi,depthTexture:new Sa(d.textureWidth,d.textureHeight,vt,void 0,void 0,void 0,void 0,void 0,void 0,et),stencilBuffer:m.stencil,colorSpace:t.outputColorSpace,samples:m.antialias?4:0,resolveDepthBuffer:d.ignoreDepthValues===!1})}M.isXRRenderTarget=!0,this.setFoveation(l),c=null,o=await s.requestReferenceSpace(a),qt.setContext(s),qt.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return x.getDepthTexture()};function W(Y){for(let et=0;et<Y.removed.length;et++){let vt=Y.removed[et],ct=y.indexOf(vt);ct>=0&&(y[ct]=null,v[ct].disconnect(vt))}for(let et=0;et<Y.added.length;et++){let vt=Y.added[et],ct=y.indexOf(vt);if(ct===-1){for(let Bt=0;Bt<v.length;Bt++)if(Bt>=y.length){y.push(vt),ct=Bt;break}else if(y[Bt]===null){y[Bt]=vt,ct=Bt;break}if(ct===-1)break}let kt=v[ct];kt&&kt.connect(vt)}}let k=new C,q=new C;function H(Y,et,vt){k.setFromMatrixPosition(et.matrixWorld),q.setFromMatrixPosition(vt.matrixWorld);let ct=k.distanceTo(q),kt=et.projectionMatrix.elements,Bt=vt.projectionMatrix.elements,Zt=kt[14]/(kt[10]-1),Ee=kt[14]/(kt[10]+1),ee=(kt[9]+1)/kt[5],ke=(kt[9]-1)/kt[5],O=(kt[8]-1)/kt[0],Rn=(Bt[8]+1)/Bt[0],jt=Zt*O,Qt=Zt*Rn,It=ct/(-O+Rn),ve=It*-O;if(et.matrixWorld.decompose(Y.position,Y.quaternion,Y.scale),Y.translateX(ve),Y.translateZ(It),Y.matrixWorld.compose(Y.position,Y.quaternion,Y.scale),Y.matrixWorldInverse.copy(Y.matrixWorld).invert(),kt[10]===-1)Y.projectionMatrix.copy(et.projectionMatrix),Y.projectionMatrixInverse.copy(et.projectionMatrixInverse);else{let Pt=Zt+It,I=Ee+It,E=jt-ve,V=Qt+(ct-ve),J=ee*Ee/I*Pt,tt=ke*Ee/I*Pt;Y.projectionMatrix.makePerspective(E,V,J,tt,Pt,I),Y.projectionMatrixInverse.copy(Y.projectionMatrix).invert()}}function K(Y,et){et===null?Y.matrixWorld.copy(Y.matrix):Y.matrixWorld.multiplyMatrices(et.matrixWorld,Y.matrix),Y.matrixWorldInverse.copy(Y.matrixWorld).invert()}this.updateCamera=function(Y){if(s===null)return;let et=Y.near,vt=Y.far;x.texture!==null&&(x.depthNear>0&&(et=x.depthNear),x.depthFar>0&&(vt=x.depthFar)),b.near=P.near=A.near=et,b.far=P.far=A.far=vt,(R!==b.near||L!==b.far)&&(s.updateRenderState({depthNear:b.near,depthFar:b.far}),R=b.near,L=b.far),A.layers.mask=Y.layers.mask|2,P.layers.mask=Y.layers.mask|4,b.layers.mask=A.layers.mask|P.layers.mask;let ct=Y.parent,kt=b.cameras;K(b,ct);for(let Bt=0;Bt<kt.length;Bt++)K(kt[Bt],ct);kt.length===2?H(b,A,P):b.projectionMatrix.copy(A.projectionMatrix),Q(Y,b,ct)};function Q(Y,et,vt){vt===null?Y.matrix.copy(et.matrixWorld):(Y.matrix.copy(vt.matrixWorld),Y.matrix.invert(),Y.matrix.multiply(et.matrixWorld)),Y.matrix.decompose(Y.position,Y.quaternion,Y.scale),Y.updateMatrixWorld(!0),Y.projectionMatrix.copy(et.projectionMatrix),Y.projectionMatrixInverse.copy(et.projectionMatrixInverse),Y.isPerspectiveCamera&&(Y.fov=Zr*2*Math.atan(1/Y.projectionMatrix.elements[5]),Y.zoom=1)}this.getCamera=function(){return b},this.getFoveation=function(){if(!(d===null&&f===null))return l},this.setFoveation=function(Y){l=Y,d!==null&&(d.fixedFoveation=Y),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=Y)},this.hasDepthSensing=function(){return x.texture!==null},this.getDepthSensingMesh=function(){return x.getMesh(b)};let at=null;function Ct(Y,et){if(h=et.getViewerPose(c||o),g=et,h!==null){let vt=h.views;f!==null&&(t.setRenderTargetFramebuffer(M,f.framebuffer),t.setRenderTarget(M));let ct=!1;vt.length!==b.cameras.length&&(b.cameras.length=0,ct=!0);for(let Bt=0;Bt<vt.length;Bt++){let Zt=vt[Bt],Ee=null;if(f!==null)Ee=f.getViewport(Zt);else{let ke=u.getViewSubImage(d,Zt);Ee=ke.viewport,Bt===0&&(t.setRenderTargetTextures(M,ke.colorTexture,d.ignoreDepthValues?void 0:ke.depthStencilTexture),t.setRenderTarget(M))}let ee=_[Bt];ee===void 0&&(ee=new Be,ee.layers.enable(Bt),ee.viewport=new Me,_[Bt]=ee),ee.matrix.fromArray(Zt.transform.matrix),ee.matrix.decompose(ee.position,ee.quaternion,ee.scale),ee.projectionMatrix.fromArray(Zt.projectionMatrix),ee.projectionMatrixInverse.copy(ee.projectionMatrix).invert(),ee.viewport.set(Ee.x,Ee.y,Ee.width,Ee.height),Bt===0&&(b.matrix.copy(ee.matrix),b.matrix.decompose(b.position,b.quaternion,b.scale)),ct===!0&&b.cameras.push(ee)}let kt=s.enabledFeatures;if(kt&&kt.includes("depth-sensing")){let Bt=u.getDepthInformation(vt[0]);Bt&&Bt.isValid&&Bt.texture&&x.init(t,Bt,s.renderState)}}for(let vt=0;vt<v.length;vt++){let ct=y[vt],kt=v[vt];ct!==null&&kt!==void 0&&kt.update(ct,et,c||o)}at&&at(Y,et),et.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:et}),g=null}let qt=new vf;qt.setAnimationLoop(Ct),this.setAnimationLoop=function(Y){at=Y},this.dispose=function(){}}},as=new un,Av=new Wt;function Rv(i,t){function e(m,p){m.matrixAutoUpdate===!0&&m.updateMatrix(),p.value.copy(m.matrix)}function n(m,p){p.color.getRGB(m.fogColor.value,yf(i)),p.isFog?(m.fogNear.value=p.near,m.fogFar.value=p.far):p.isFogExp2&&(m.fogDensity.value=p.density)}function s(m,p,M,v,y){p.isMeshBasicMaterial||p.isMeshLambertMaterial?r(m,p):p.isMeshToonMaterial?(r(m,p),u(m,p)):p.isMeshPhongMaterial?(r(m,p),h(m,p)):p.isMeshStandardMaterial?(r(m,p),d(m,p),p.isMeshPhysicalMaterial&&f(m,p,y)):p.isMeshMatcapMaterial?(r(m,p),g(m,p)):p.isMeshDepthMaterial?r(m,p):p.isMeshDistanceMaterial?(r(m,p),x(m,p)):p.isMeshNormalMaterial?r(m,p):p.isLineBasicMaterial?(o(m,p),p.isLineDashedMaterial&&a(m,p)):p.isPointsMaterial?l(m,p,M,v):p.isSpriteMaterial?c(m,p):p.isShadowMaterial?(m.color.value.copy(p.color),m.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function r(m,p){m.opacity.value=p.opacity,p.color&&m.diffuse.value.copy(p.color),p.emissive&&m.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(m.map.value=p.map,e(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.bumpMap&&(m.bumpMap.value=p.bumpMap,e(p.bumpMap,m.bumpMapTransform),m.bumpScale.value=p.bumpScale,p.side===Ke&&(m.bumpScale.value*=-1)),p.normalMap&&(m.normalMap.value=p.normalMap,e(p.normalMap,m.normalMapTransform),m.normalScale.value.copy(p.normalScale),p.side===Ke&&m.normalScale.value.negate()),p.displacementMap&&(m.displacementMap.value=p.displacementMap,e(p.displacementMap,m.displacementMapTransform),m.displacementScale.value=p.displacementScale,m.displacementBias.value=p.displacementBias),p.emissiveMap&&(m.emissiveMap.value=p.emissiveMap,e(p.emissiveMap,m.emissiveMapTransform)),p.specularMap&&(m.specularMap.value=p.specularMap,e(p.specularMap,m.specularMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest);let M=t.get(p),v=M.envMap,y=M.envMapRotation;v&&(m.envMap.value=v,as.copy(y),as.x*=-1,as.y*=-1,as.z*=-1,v.isCubeTexture&&v.isRenderTargetTexture===!1&&(as.y*=-1,as.z*=-1),m.envMapRotation.value.setFromMatrix4(Av.makeRotationFromEuler(as)),m.flipEnvMap.value=v.isCubeTexture&&v.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=p.reflectivity,m.ior.value=p.ior,m.refractionRatio.value=p.refractionRatio),p.lightMap&&(m.lightMap.value=p.lightMap,m.lightMapIntensity.value=p.lightMapIntensity,e(p.lightMap,m.lightMapTransform)),p.aoMap&&(m.aoMap.value=p.aoMap,m.aoMapIntensity.value=p.aoMapIntensity,e(p.aoMap,m.aoMapTransform))}function o(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,p.map&&(m.map.value=p.map,e(p.map,m.mapTransform))}function a(m,p){m.dashSize.value=p.dashSize,m.totalSize.value=p.dashSize+p.gapSize,m.scale.value=p.scale}function l(m,p,M,v){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.size.value=p.size*M,m.scale.value=v*.5,p.map&&(m.map.value=p.map,e(p.map,m.uvTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function c(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.rotation.value=p.rotation,p.map&&(m.map.value=p.map,e(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function h(m,p){m.specular.value.copy(p.specular),m.shininess.value=Math.max(p.shininess,1e-4)}function u(m,p){p.gradientMap&&(m.gradientMap.value=p.gradientMap)}function d(m,p){m.metalness.value=p.metalness,p.metalnessMap&&(m.metalnessMap.value=p.metalnessMap,e(p.metalnessMap,m.metalnessMapTransform)),m.roughness.value=p.roughness,p.roughnessMap&&(m.roughnessMap.value=p.roughnessMap,e(p.roughnessMap,m.roughnessMapTransform)),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)}function f(m,p,M){m.ior.value=p.ior,p.sheen>0&&(m.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),m.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(m.sheenColorMap.value=p.sheenColorMap,e(p.sheenColorMap,m.sheenColorMapTransform)),p.sheenRoughnessMap&&(m.sheenRoughnessMap.value=p.sheenRoughnessMap,e(p.sheenRoughnessMap,m.sheenRoughnessMapTransform))),p.clearcoat>0&&(m.clearcoat.value=p.clearcoat,m.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(m.clearcoatMap.value=p.clearcoatMap,e(p.clearcoatMap,m.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,e(p.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(m.clearcoatNormalMap.value=p.clearcoatNormalMap,e(p.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===Ke&&m.clearcoatNormalScale.value.negate())),p.dispersion>0&&(m.dispersion.value=p.dispersion),p.iridescence>0&&(m.iridescence.value=p.iridescence,m.iridescenceIOR.value=p.iridescenceIOR,m.iridescenceThicknessMinimum.value=p.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=p.iridescenceThicknessRange[1],p.iridescenceMap&&(m.iridescenceMap.value=p.iridescenceMap,e(p.iridescenceMap,m.iridescenceMapTransform)),p.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=p.iridescenceThicknessMap,e(p.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),p.transmission>0&&(m.transmission.value=p.transmission,m.transmissionSamplerMap.value=M.texture,m.transmissionSamplerSize.value.set(M.width,M.height),p.transmissionMap&&(m.transmissionMap.value=p.transmissionMap,e(p.transmissionMap,m.transmissionMapTransform)),m.thickness.value=p.thickness,p.thicknessMap&&(m.thicknessMap.value=p.thicknessMap,e(p.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=p.attenuationDistance,m.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(m.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(m.anisotropyMap.value=p.anisotropyMap,e(p.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=p.specularIntensity,m.specularColor.value.copy(p.specularColor),p.specularColorMap&&(m.specularColorMap.value=p.specularColorMap,e(p.specularColorMap,m.specularColorMapTransform)),p.specularIntensityMap&&(m.specularIntensityMap.value=p.specularIntensityMap,e(p.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,p){p.matcap&&(m.matcap.value=p.matcap)}function x(m,p){let M=t.get(p).light;m.referencePosition.value.setFromMatrixPosition(M.matrixWorld),m.nearDistance.value=M.shadow.camera.near,m.farDistance.value=M.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function Cv(i,t,e,n){let s={},r={},o=[],a=i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS);function l(M,v){let y=v.program;n.uniformBlockBinding(M,y)}function c(M,v){let y=s[M.id];y===void 0&&(g(M),y=h(M),s[M.id]=y,M.addEventListener("dispose",m));let w=v.program;n.updateUBOMapping(M,w);let S=t.render.frame;r[M.id]!==S&&(d(M),r[M.id]=S)}function h(M){let v=u();M.__bindingPointIndex=v;let y=i.createBuffer(),w=M.__size,S=M.usage;return i.bindBuffer(i.UNIFORM_BUFFER,y),i.bufferData(i.UNIFORM_BUFFER,w,S),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,v,y),y}function u(){for(let M=0;M<a;M++)if(o.indexOf(M)===-1)return o.push(M),M;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function d(M){let v=s[M.id],y=M.uniforms,w=M.__cache;i.bindBuffer(i.UNIFORM_BUFFER,v);for(let S=0,A=y.length;S<A;S++){let P=Array.isArray(y[S])?y[S]:[y[S]];for(let _=0,b=P.length;_<b;_++){let R=P[_];if(f(R,S,_,w)===!0){let L=R.__offset,D=Array.isArray(R.value)?R.value:[R.value],N=0;for(let W=0;W<D.length;W++){let k=D[W],q=x(k);typeof k=="number"||typeof k=="boolean"?(R.__data[0]=k,i.bufferSubData(i.UNIFORM_BUFFER,L+N,R.__data)):k.isMatrix3?(R.__data[0]=k.elements[0],R.__data[1]=k.elements[1],R.__data[2]=k.elements[2],R.__data[3]=0,R.__data[4]=k.elements[3],R.__data[5]=k.elements[4],R.__data[6]=k.elements[5],R.__data[7]=0,R.__data[8]=k.elements[6],R.__data[9]=k.elements[7],R.__data[10]=k.elements[8],R.__data[11]=0):(k.toArray(R.__data,N),N+=q.storage/Float32Array.BYTES_PER_ELEMENT)}i.bufferSubData(i.UNIFORM_BUFFER,L,R.__data)}}}i.bindBuffer(i.UNIFORM_BUFFER,null)}function f(M,v,y,w){let S=M.value,A=v+"_"+y;if(w[A]===void 0)return typeof S=="number"||typeof S=="boolean"?w[A]=S:w[A]=S.clone(),!0;{let P=w[A];if(typeof S=="number"||typeof S=="boolean"){if(P!==S)return w[A]=S,!0}else if(P.equals(S)===!1)return P.copy(S),!0}return!1}function g(M){let v=M.uniforms,y=0,w=16;for(let A=0,P=v.length;A<P;A++){let _=Array.isArray(v[A])?v[A]:[v[A]];for(let b=0,R=_.length;b<R;b++){let L=_[b],D=Array.isArray(L.value)?L.value:[L.value];for(let N=0,W=D.length;N<W;N++){let k=D[N],q=x(k),H=y%w,K=H%q.boundary,Q=H+K;y+=K,Q!==0&&w-Q<q.storage&&(y+=w-Q),L.__data=new Float32Array(q.storage/Float32Array.BYTES_PER_ELEMENT),L.__offset=y,y+=q.storage}}}let S=y%w;return S>0&&(y+=w-S),M.__size=y,M.__cache={},this}function x(M){let v={boundary:0,storage:0};return typeof M=="number"||typeof M=="boolean"?(v.boundary=4,v.storage=4):M.isVector2?(v.boundary=8,v.storage=8):M.isVector3||M.isColor?(v.boundary=16,v.storage=12):M.isVector4?(v.boundary=16,v.storage=16):M.isMatrix3?(v.boundary=48,v.storage=48):M.isMatrix4?(v.boundary=64,v.storage=64):M.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",M),v}function m(M){let v=M.target;v.removeEventListener("dispose",m);let y=o.indexOf(v.__bindingPointIndex);o.splice(y,1),i.deleteBuffer(s[v.id]),delete s[v.id],delete r[v.id]}function p(){for(let M in s)i.deleteBuffer(s[M]);o=[],s={},r={}}return{bind:l,update:c,dispose:p}}var Ea=class{constructor(t={}){let{canvas:e=km(),context:n=null,depth:s=!0,stencil:r=!1,alpha:o=!1,antialias:a=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1,reverseDepthBuffer:d=!1}=t;this.isWebGLRenderer=!0;let f;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");f=n.getContextAttributes().alpha}else f=o;let g=new Uint32Array(4),x=new Int32Array(4),m=null,p=null,M=[],v=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=me,this.toneMapping=Hi,this.toneMappingExposure=1;let y=this,w=!1,S=0,A=0,P=null,_=-1,b=null,R=new Me,L=new Me,D=null,N=new bt(0),W=0,k=e.width,q=e.height,H=1,K=null,Q=null,at=new Me(0,0,k,q),Ct=new Me(0,0,k,q),qt=!1,Y=new jr,et=!1,vt=!1,ct=new Wt,kt=new Wt,Bt=new C,Zt=new Me,Ee={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0},ee=!1;function ke(){return P===null?H:1}let O=n;function Rn(T,F){return e.getContext(T,F)}try{let T={alpha:!0,depth:s,stencil:r,antialias:a,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${Ch}`),e.addEventListener("webglcontextlost",j,!1),e.addEventListener("webglcontextrestored",pt,!1),e.addEventListener("webglcontextcreationerror",ut,!1),O===null){let F="webgl2";if(O=Rn(F,T),O===null)throw Rn(F)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(T){throw console.error("THREE.WebGLRenderer: "+T.message),T}let jt,Qt,It,ve,Pt,I,E,V,J,tt,Z,St,ht,mt,ne,it,gt,Dt,Nt,xt,te,Xt,ge,z;function lt(){jt=new $x(O),jt.init(),Xt=new wv(O,jt),Qt=new Bx(O,jt,t,Xt),It=new bv(O,jt),Qt.reverseDepthBuffer&&d&&It.buffers.depth.setReversed(!0),ve=new Yx(O),Pt=new av,I=new Mv(O,jt,It,Pt,Qt,Xt,ve),E=new Hx(y),V=new Wx(y),J=new e0(O),ge=new zx(O,J),tt=new qx(O,J,ve,ge),Z=new Kx(O,tt,J,ve),Nt=new Zx(O,Qt,I),it=new Ox(Pt),St=new ov(y,E,V,jt,Qt,ge,it),ht=new Rv(y,Pt),mt=new cv,ne=new mv(jt),Dt=new Nx(y,E,V,It,Z,f,l),gt=new yv(y,Z,Qt),z=new Cv(O,ve,Qt,It),xt=new Fx(O,jt,ve),te=new Xx(O,jt,ve),ve.programs=St.programs,y.capabilities=Qt,y.extensions=jt,y.properties=Pt,y.renderLists=mt,y.shadowMap=gt,y.state=It,y.info=ve}lt();let X=new oh(y,O);this.xr=X,this.getContext=function(){return O},this.getContextAttributes=function(){return O.getContextAttributes()},this.forceContextLoss=function(){let T=jt.get("WEBGL_lose_context");T&&T.loseContext()},this.forceContextRestore=function(){let T=jt.get("WEBGL_lose_context");T&&T.restoreContext()},this.getPixelRatio=function(){return H},this.setPixelRatio=function(T){T!==void 0&&(H=T,this.setSize(k,q,!1))},this.getSize=function(T){return T.set(k,q)},this.setSize=function(T,F,G=!0){if(X.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}k=T,q=F,e.width=Math.floor(T*H),e.height=Math.floor(F*H),G===!0&&(e.style.width=T+"px",e.style.height=F+"px"),this.setViewport(0,0,T,F)},this.getDrawingBufferSize=function(T){return T.set(k*H,q*H).floor()},this.setDrawingBufferSize=function(T,F,G){k=T,q=F,H=G,e.width=Math.floor(T*G),e.height=Math.floor(F*G),this.setViewport(0,0,T,F)},this.getCurrentViewport=function(T){return T.copy(R)},this.getViewport=function(T){return T.copy(at)},this.setViewport=function(T,F,G,$){T.isVector4?at.set(T.x,T.y,T.z,T.w):at.set(T,F,G,$),It.viewport(R.copy(at).multiplyScalar(H).round())},this.getScissor=function(T){return T.copy(Ct)},this.setScissor=function(T,F,G,$){T.isVector4?Ct.set(T.x,T.y,T.z,T.w):Ct.set(T,F,G,$),It.scissor(L.copy(Ct).multiplyScalar(H).round())},this.getScissorTest=function(){return qt},this.setScissorTest=function(T){It.setScissorTest(qt=T)},this.setOpaqueSort=function(T){K=T},this.setTransparentSort=function(T){Q=T},this.getClearColor=function(T){return T.copy(Dt.getClearColor())},this.setClearColor=function(){Dt.setClearColor.apply(Dt,arguments)},this.getClearAlpha=function(){return Dt.getClearAlpha()},this.setClearAlpha=function(){Dt.setClearAlpha.apply(Dt,arguments)},this.clear=function(T=!0,F=!0,G=!0){let $=0;if(T){let B=!1;if(P!==null){let st=P.texture.format;B=st===Fh||st===zh||st===Nh}if(B){let st=P.texture.type,dt=st===xi||st===fs||st===Yr||st===or||st===Dh||st===kh,_t=Dt.getClearColor(),Mt=Dt.getClearAlpha(),zt=_t.r,Vt=_t.g,wt=_t.b;dt?(g[0]=zt,g[1]=Vt,g[2]=wt,g[3]=Mt,O.clearBufferuiv(O.COLOR,0,g)):(x[0]=zt,x[1]=Vt,x[2]=wt,x[3]=Mt,O.clearBufferiv(O.COLOR,0,x))}else $|=O.COLOR_BUFFER_BIT}F&&($|=O.DEPTH_BUFFER_BIT),G&&($|=O.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),O.clear($)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",j,!1),e.removeEventListener("webglcontextrestored",pt,!1),e.removeEventListener("webglcontextcreationerror",ut,!1),mt.dispose(),ne.dispose(),Pt.dispose(),E.dispose(),V.dispose(),Z.dispose(),ge.dispose(),z.dispose(),St.dispose(),X.dispose(),X.removeEventListener("sessionstart",Cu),X.removeEventListener("sessionend",Pu),es.stop()};function j(T){T.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),w=!0}function pt(){console.log("THREE.WebGLRenderer: Context Restored."),w=!1;let T=ve.autoReset,F=gt.enabled,G=gt.autoUpdate,$=gt.needsUpdate,B=gt.type;lt(),ve.autoReset=T,gt.enabled=F,gt.autoUpdate=G,gt.needsUpdate=$,gt.type=B}function ut(T){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",T.statusMessage)}function Ht(T){let F=T.target;F.removeEventListener("dispose",Ht),Ie(F)}function Ie(T){Xe(T),Pt.remove(T)}function Xe(T){let F=Pt.get(T).programs;F!==void 0&&(F.forEach(function(G){St.releaseProgram(G)}),T.isShaderMaterial&&St.releaseShaderCache(T))}this.renderBufferDirect=function(T,F,G,$,B,st){F===null&&(F=Ee);let dt=B.isMesh&&B.matrixWorld.determinant()<0,_t=Pp(T,F,G,$,B);It.setMaterial($,dt);let Mt=G.index,zt=1;if($.wireframe===!0){if(Mt=tt.getWireframeAttribute(G),Mt===void 0)return;zt=2}let Vt=G.drawRange,wt=G.attributes.position,oe=Vt.start*zt,xe=(Vt.start+Vt.count)*zt;st!==null&&(oe=Math.max(oe,st.start*zt),xe=Math.min(xe,(st.start+st.count)*zt)),Mt!==null?(oe=Math.max(oe,0),xe=Math.min(xe,Mt.count)):wt!=null&&(oe=Math.max(oe,0),xe=Math.min(xe,wt.count));let be=xe-oe;if(be<0||be===1/0)return;ge.setup(B,$,_t,G,Mt);let cn,ce=xt;if(Mt!==null&&(cn=J.get(Mt),ce=te,ce.setIndex(cn)),B.isMesh)$.wireframe===!0?(It.setLineWidth($.wireframeLinewidth*ke()),ce.setMode(O.LINES)):ce.setMode(O.TRIANGLES);else if(B.isLine){let Et=$.linewidth;Et===void 0&&(Et=1),It.setLineWidth(Et*ke()),B.isLineSegments?ce.setMode(O.LINES):B.isLineLoop?ce.setMode(O.LINE_LOOP):ce.setMode(O.LINE_STRIP)}else B.isPoints?ce.setMode(O.POINTS):B.isSprite&&ce.setMode(O.TRIANGLES);if(B.isBatchedMesh)if(B._multiDrawInstances!==null)ce.renderMultiDrawInstances(B._multiDrawStarts,B._multiDrawCounts,B._multiDrawCount,B._multiDrawInstances);else if(jt.get("WEBGL_multi_draw"))ce.renderMultiDraw(B._multiDrawStarts,B._multiDrawCounts,B._multiDrawCount);else{let Et=B._multiDrawStarts,ai=B._multiDrawCounts,he=B._multiDrawCount,Nn=Mt?J.get(Mt).bytesPerElement:1,Is=Pt.get($).currentProgram.getUniforms();for(let xn=0;xn<he;xn++)Is.setValue(O,"_gl_DrawID",xn),ce.render(Et[xn]/Nn,ai[xn])}else if(B.isInstancedMesh)ce.renderInstances(oe,be,B.count);else if(G.isInstancedBufferGeometry){let Et=G._maxInstanceCount!==void 0?G._maxInstanceCount:1/0,ai=Math.min(G.instanceCount,Et);ce.renderInstances(oe,be,ai)}else ce.render(oe,be)};function ue(T,F,G){T.transparent===!0&&T.side===Te&&T.forceSinglePass===!1?(T.side=Ke,T.needsUpdate=!0,Io(T,F,G),T.side=jn,T.needsUpdate=!0,Io(T,F,G),T.side=Te):Io(T,F,G)}this.compile=function(T,F,G=null){G===null&&(G=T),p=ne.get(G),p.init(F),v.push(p),G.traverseVisible(function(B){B.isLight&&B.layers.test(F.layers)&&(p.pushLight(B),B.castShadow&&p.pushShadow(B))}),T!==G&&T.traverseVisible(function(B){B.isLight&&B.layers.test(F.layers)&&(p.pushLight(B),B.castShadow&&p.pushShadow(B))}),p.setupLights();let $=new Set;return T.traverse(function(B){if(!(B.isMesh||B.isPoints||B.isLine||B.isSprite))return;let st=B.material;if(st)if(Array.isArray(st))for(let dt=0;dt<st.length;dt++){let _t=st[dt];ue(_t,G,B),$.add(_t)}else ue(st,G,B),$.add(st)}),v.pop(),p=null,$},this.compileAsync=function(T,F,G=null){let $=this.compile(T,F,G);return new Promise(B=>{function st(){if($.forEach(function(dt){Pt.get(dt).currentProgram.isReady()&&$.delete(dt)}),$.size===0){B(T);return}setTimeout(st,10)}jt.get("KHR_parallel_shader_compile")!==null?st():setTimeout(st,10)})};let Un=null;function oi(T){Un&&Un(T)}function Cu(){es.stop()}function Pu(){es.start()}let es=new vf;es.setAnimationLoop(oi),typeof self<"u"&&es.setContext(self),this.setAnimationLoop=function(T){Un=T,X.setAnimationLoop(T),T===null?es.stop():es.start()},X.addEventListener("sessionstart",Cu),X.addEventListener("sessionend",Pu),this.render=function(T,F){if(F!==void 0&&F.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(w===!0)return;if(T.matrixWorldAutoUpdate===!0&&T.updateMatrixWorld(),F.parent===null&&F.matrixWorldAutoUpdate===!0&&F.updateMatrixWorld(),X.enabled===!0&&X.isPresenting===!0&&(X.cameraAutoUpdate===!0&&X.updateCamera(F),F=X.getCamera()),T.isScene===!0&&T.onBeforeRender(y,T,F,P),p=ne.get(T,v.length),p.init(F),v.push(p),kt.multiplyMatrices(F.projectionMatrix,F.matrixWorldInverse),Y.setFromProjectionMatrix(kt),vt=this.localClippingEnabled,et=it.init(this.clippingPlanes,vt),m=mt.get(T,M.length),m.init(),M.push(m),X.enabled===!0&&X.isPresenting===!0){let st=y.xr.getDepthSensingMesh();st!==null&&Sl(st,F,-1/0,y.sortObjects)}Sl(T,F,0,y.sortObjects),m.finish(),y.sortObjects===!0&&m.sort(K,Q),ee=X.enabled===!1||X.isPresenting===!1||X.hasDepthSensing()===!1,ee&&Dt.addToRenderList(m,T),this.info.render.frame++,et===!0&&it.beginShadows();let G=p.state.shadowsArray;gt.render(G,T,F),et===!0&&it.endShadows(),this.info.autoReset===!0&&this.info.reset();let $=m.opaque,B=m.transmissive;if(p.setupLights(),F.isArrayCamera){let st=F.cameras;if(B.length>0)for(let dt=0,_t=st.length;dt<_t;dt++){let Mt=st[dt];Lu($,B,T,Mt)}ee&&Dt.render(T);for(let dt=0,_t=st.length;dt<_t;dt++){let Mt=st[dt];Iu(m,T,Mt,Mt.viewport)}}else B.length>0&&Lu($,B,T,F),ee&&Dt.render(T),Iu(m,T,F);P!==null&&(I.updateMultisampleRenderTarget(P),I.updateRenderTargetMipmap(P)),T.isScene===!0&&T.onAfterRender(y,T,F),ge.resetDefaultState(),_=-1,b=null,v.pop(),v.length>0?(p=v[v.length-1],et===!0&&it.setGlobalState(y.clippingPlanes,p.state.camera)):p=null,M.pop(),M.length>0?m=M[M.length-1]:m=null};function Sl(T,F,G,$){if(T.visible===!1)return;if(T.layers.test(F.layers)){if(T.isGroup)G=T.renderOrder;else if(T.isLOD)T.autoUpdate===!0&&T.update(F);else if(T.isLight)p.pushLight(T),T.castShadow&&p.pushShadow(T);else if(T.isSprite){if(!T.frustumCulled||Y.intersectsSprite(T)){$&&Zt.setFromMatrixPosition(T.matrixWorld).applyMatrix4(kt);let dt=Z.update(T),_t=T.material;_t.visible&&m.push(T,dt,_t,G,Zt.z,null)}}else if((T.isMesh||T.isLine||T.isPoints)&&(!T.frustumCulled||Y.intersectsObject(T))){let dt=Z.update(T),_t=T.material;if($&&(T.boundingSphere!==void 0?(T.boundingSphere===null&&T.computeBoundingSphere(),Zt.copy(T.boundingSphere.center)):(dt.boundingSphere===null&&dt.computeBoundingSphere(),Zt.copy(dt.boundingSphere.center)),Zt.applyMatrix4(T.matrixWorld).applyMatrix4(kt)),Array.isArray(_t)){let Mt=dt.groups;for(let zt=0,Vt=Mt.length;zt<Vt;zt++){let wt=Mt[zt],oe=_t[wt.materialIndex];oe&&oe.visible&&m.push(T,dt,oe,G,Zt.z,wt)}}else _t.visible&&m.push(T,dt,_t,G,Zt.z,null)}}let st=T.children;for(let dt=0,_t=st.length;dt<_t;dt++)Sl(st[dt],F,G,$)}function Iu(T,F,G,$){let B=T.opaque,st=T.transmissive,dt=T.transparent;p.setupLightsView(G),et===!0&&it.setGlobalState(y.clippingPlanes,G),$&&It.viewport(R.copy($)),B.length>0&&Po(B,F,G),st.length>0&&Po(st,F,G),dt.length>0&&Po(dt,F,G),It.buffers.depth.setTest(!0),It.buffers.depth.setMask(!0),It.buffers.color.setMask(!0),It.setPolygonOffset(!1)}function Lu(T,F,G,$){if((G.isScene===!0?G.overrideMaterial:null)!==null)return;p.state.transmissionRenderTarget[$.id]===void 0&&(p.state.transmissionRenderTarget[$.id]=new Vn(1,1,{generateMipmaps:!0,type:jt.has("EXT_color_buffer_half_float")||jt.has("EXT_color_buffer_float")?ho:xi,minFilter:pi,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:ie.workingColorSpace}));let st=p.state.transmissionRenderTarget[$.id],dt=$.viewport||R;st.setSize(dt.z,dt.w);let _t=y.getRenderTarget();y.setRenderTarget(st),y.getClearColor(N),W=y.getClearAlpha(),W<1&&y.setClearColor(16777215,.5),y.clear(),ee&&Dt.render(G);let Mt=y.toneMapping;y.toneMapping=Hi;let zt=$.viewport;if($.viewport!==void 0&&($.viewport=void 0),p.setupLightsView($),et===!0&&it.setGlobalState(y.clippingPlanes,$),Po(T,G,$),I.updateMultisampleRenderTarget(st),I.updateRenderTargetMipmap(st),jt.has("WEBGL_multisampled_render_to_texture")===!1){let Vt=!1;for(let wt=0,oe=F.length;wt<oe;wt++){let xe=F[wt],be=xe.object,cn=xe.geometry,ce=xe.material,Et=xe.group;if(ce.side===Te&&be.layers.test($.layers)){let ai=ce.side;ce.side=Ke,ce.needsUpdate=!0,Du(be,G,$,cn,ce,Et),ce.side=ai,ce.needsUpdate=!0,Vt=!0}}Vt===!0&&(I.updateMultisampleRenderTarget(st),I.updateRenderTargetMipmap(st))}y.setRenderTarget(_t),y.setClearColor(N,W),zt!==void 0&&($.viewport=zt),y.toneMapping=Mt}function Po(T,F,G){let $=F.isScene===!0?F.overrideMaterial:null;for(let B=0,st=T.length;B<st;B++){let dt=T[B],_t=dt.object,Mt=dt.geometry,zt=$===null?dt.material:$,Vt=dt.group;_t.layers.test(G.layers)&&Du(_t,F,G,Mt,zt,Vt)}}function Du(T,F,G,$,B,st){T.onBeforeRender(y,F,G,$,B,st),T.modelViewMatrix.multiplyMatrices(G.matrixWorldInverse,T.matrixWorld),T.normalMatrix.getNormalMatrix(T.modelViewMatrix),B.onBeforeRender(y,F,G,$,T,st),B.transparent===!0&&B.side===Te&&B.forceSinglePass===!1?(B.side=Ke,B.needsUpdate=!0,y.renderBufferDirect(G,F,$,B,T,st),B.side=jn,B.needsUpdate=!0,y.renderBufferDirect(G,F,$,B,T,st),B.side=Te):y.renderBufferDirect(G,F,$,B,T,st),T.onAfterRender(y,F,G,$,B,st)}function Io(T,F,G){F.isScene!==!0&&(F=Ee);let $=Pt.get(T),B=p.state.lights,st=p.state.shadowsArray,dt=B.state.version,_t=St.getParameters(T,B.state,st,F,G),Mt=St.getProgramCacheKey(_t),zt=$.programs;$.environment=T.isMeshStandardMaterial?F.environment:null,$.fog=F.fog,$.envMap=(T.isMeshStandardMaterial?V:E).get(T.envMap||$.environment),$.envMapRotation=$.environment!==null&&T.envMap===null?F.environmentRotation:T.envMapRotation,zt===void 0&&(T.addEventListener("dispose",Ht),zt=new Map,$.programs=zt);let Vt=zt.get(Mt);if(Vt!==void 0){if($.currentProgram===Vt&&$.lightsStateVersion===dt)return Uu(T,_t),Vt}else _t.uniforms=St.getUniforms(T),T.onBeforeCompile(_t,y),Vt=St.acquireProgram(_t,Mt),zt.set(Mt,Vt),$.uniforms=_t.uniforms;let wt=$.uniforms;return(!T.isShaderMaterial&&!T.isRawShaderMaterial||T.clipping===!0)&&(wt.clippingPlanes=it.uniform),Uu(T,_t),$.needsLights=Lp(T),$.lightsStateVersion=dt,$.needsLights&&(wt.ambientLightColor.value=B.state.ambient,wt.lightProbe.value=B.state.probe,wt.directionalLights.value=B.state.directional,wt.directionalLightShadows.value=B.state.directionalShadow,wt.spotLights.value=B.state.spot,wt.spotLightShadows.value=B.state.spotShadow,wt.rectAreaLights.value=B.state.rectArea,wt.ltc_1.value=B.state.rectAreaLTC1,wt.ltc_2.value=B.state.rectAreaLTC2,wt.pointLights.value=B.state.point,wt.pointLightShadows.value=B.state.pointShadow,wt.hemisphereLights.value=B.state.hemi,wt.directionalShadowMap.value=B.state.directionalShadowMap,wt.directionalShadowMatrix.value=B.state.directionalShadowMatrix,wt.spotShadowMap.value=B.state.spotShadowMap,wt.spotLightMatrix.value=B.state.spotLightMatrix,wt.spotLightMap.value=B.state.spotLightMap,wt.pointShadowMap.value=B.state.pointShadowMap,wt.pointShadowMatrix.value=B.state.pointShadowMatrix),$.currentProgram=Vt,$.uniformsList=null,Vt}function ku(T){if(T.uniformsList===null){let F=T.currentProgram.getUniforms();T.uniformsList=nr.seqWithValue(F.seq,T.uniforms)}return T.uniformsList}function Uu(T,F){let G=Pt.get(T);G.outputColorSpace=F.outputColorSpace,G.batching=F.batching,G.batchingColor=F.batchingColor,G.instancing=F.instancing,G.instancingColor=F.instancingColor,G.instancingMorph=F.instancingMorph,G.skinning=F.skinning,G.morphTargets=F.morphTargets,G.morphNormals=F.morphNormals,G.morphColors=F.morphColors,G.morphTargetsCount=F.morphTargetsCount,G.numClippingPlanes=F.numClippingPlanes,G.numIntersection=F.numClipIntersection,G.vertexAlphas=F.vertexAlphas,G.vertexTangents=F.vertexTangents,G.toneMapping=F.toneMapping}function Pp(T,F,G,$,B){F.isScene!==!0&&(F=Ee),I.resetTextureUnits();let st=F.fog,dt=$.isMeshStandardMaterial?F.environment:null,_t=P===null?y.outputColorSpace:P.isXRRenderTarget===!0?P.texture.colorSpace:fr,Mt=($.isMeshStandardMaterial?V:E).get($.envMap||dt),zt=$.vertexColors===!0&&!!G.attributes.color&&G.attributes.color.itemSize===4,Vt=!!G.attributes.tangent&&(!!$.normalMap||$.anisotropy>0),wt=!!G.morphAttributes.position,oe=!!G.morphAttributes.normal,xe=!!G.morphAttributes.color,be=Hi;$.toneMapped&&(P===null||P.isXRRenderTarget===!0)&&(be=y.toneMapping);let cn=G.morphAttributes.position||G.morphAttributes.normal||G.morphAttributes.color,ce=cn!==void 0?cn.length:0,Et=Pt.get($),ai=p.state.lights;if(et===!0&&(vt===!0||T!==b)){let Cn=T===b&&$.id===_;it.setState($,T,Cn)}let he=!1;$.version===Et.__version?(Et.needsLights&&Et.lightsStateVersion!==ai.state.version||Et.outputColorSpace!==_t||B.isBatchedMesh&&Et.batching===!1||!B.isBatchedMesh&&Et.batching===!0||B.isBatchedMesh&&Et.batchingColor===!0&&B.colorTexture===null||B.isBatchedMesh&&Et.batchingColor===!1&&B.colorTexture!==null||B.isInstancedMesh&&Et.instancing===!1||!B.isInstancedMesh&&Et.instancing===!0||B.isSkinnedMesh&&Et.skinning===!1||!B.isSkinnedMesh&&Et.skinning===!0||B.isInstancedMesh&&Et.instancingColor===!0&&B.instanceColor===null||B.isInstancedMesh&&Et.instancingColor===!1&&B.instanceColor!==null||B.isInstancedMesh&&Et.instancingMorph===!0&&B.morphTexture===null||B.isInstancedMesh&&Et.instancingMorph===!1&&B.morphTexture!==null||Et.envMap!==Mt||$.fog===!0&&Et.fog!==st||Et.numClippingPlanes!==void 0&&(Et.numClippingPlanes!==it.numPlanes||Et.numIntersection!==it.numIntersection)||Et.vertexAlphas!==zt||Et.vertexTangents!==Vt||Et.morphTargets!==wt||Et.morphNormals!==oe||Et.morphColors!==xe||Et.toneMapping!==be||Et.morphTargetsCount!==ce)&&(he=!0):(he=!0,Et.__version=$.version);let Nn=Et.currentProgram;he===!0&&(Nn=Io($,F,B));let Is=!1,xn=!1,Rr=!1,_e=Nn.getUniforms(),Yn=Et.uniforms;if(It.useProgram(Nn.program)&&(Is=!0,xn=!0,Rr=!0),$.id!==_&&(_=$.id,xn=!0),Is||b!==T){It.buffers.depth.getReversed()?(ct.copy(T.projectionMatrix),Nm(ct),zm(ct),_e.setValue(O,"projectionMatrix",ct)):_e.setValue(O,"projectionMatrix",T.projectionMatrix),_e.setValue(O,"viewMatrix",T.matrixWorldInverse);let Pi=_e.map.cameraPosition;Pi!==void 0&&Pi.setValue(O,Bt.setFromMatrixPosition(T.matrixWorld)),Qt.logarithmicDepthBuffer&&_e.setValue(O,"logDepthBufFC",2/(Math.log(T.far+1)/Math.LN2)),($.isMeshPhongMaterial||$.isMeshToonMaterial||$.isMeshLambertMaterial||$.isMeshBasicMaterial||$.isMeshStandardMaterial||$.isShaderMaterial)&&_e.setValue(O,"isOrthographic",T.isOrthographicCamera===!0),b!==T&&(b=T,xn=!0,Rr=!0)}if(B.isSkinnedMesh){_e.setOptional(O,B,"bindMatrix"),_e.setOptional(O,B,"bindMatrixInverse");let Cn=B.skeleton;Cn&&(Cn.boneTexture===null&&Cn.computeBoneTexture(),_e.setValue(O,"boneTexture",Cn.boneTexture,I))}B.isBatchedMesh&&(_e.setOptional(O,B,"batchingTexture"),_e.setValue(O,"batchingTexture",B._matricesTexture,I),_e.setOptional(O,B,"batchingIdTexture"),_e.setValue(O,"batchingIdTexture",B._indirectTexture,I),_e.setOptional(O,B,"batchingColorTexture"),B._colorsTexture!==null&&_e.setValue(O,"batchingColorTexture",B._colorsTexture,I));let Cr=G.morphAttributes;if((Cr.position!==void 0||Cr.normal!==void 0||Cr.color!==void 0)&&Nt.update(B,G,Nn),(xn||Et.receiveShadow!==B.receiveShadow)&&(Et.receiveShadow=B.receiveShadow,_e.setValue(O,"receiveShadow",B.receiveShadow)),$.isMeshGouraudMaterial&&$.envMap!==null&&(Yn.envMap.value=Mt,Yn.flipEnvMap.value=Mt.isCubeTexture&&Mt.isRenderTargetTexture===!1?-1:1),$.isMeshStandardMaterial&&$.envMap===null&&F.environment!==null&&(Yn.envMapIntensity.value=F.environmentIntensity),xn&&(_e.setValue(O,"toneMappingExposure",y.toneMappingExposure),Et.needsLights&&Ip(Yn,Rr),st&&$.fog===!0&&ht.refreshFogUniforms(Yn,st),ht.refreshMaterialUniforms(Yn,$,H,q,p.state.transmissionRenderTarget[T.id]),nr.upload(O,ku(Et),Yn,I)),$.isShaderMaterial&&$.uniformsNeedUpdate===!0&&(nr.upload(O,ku(Et),Yn,I),$.uniformsNeedUpdate=!1),$.isSpriteMaterial&&_e.setValue(O,"center",B.center),_e.setValue(O,"modelViewMatrix",B.modelViewMatrix),_e.setValue(O,"normalMatrix",B.normalMatrix),_e.setValue(O,"modelMatrix",B.matrixWorld),$.isShaderMaterial||$.isRawShaderMaterial){let Cn=$.uniformsGroups;for(let Pi=0,Ii=Cn.length;Pi<Ii;Pi++){let Nu=Cn[Pi];z.update(Nu,Nn),z.bind(Nu,Nn)}}return Nn}function Ip(T,F){T.ambientLightColor.needsUpdate=F,T.lightProbe.needsUpdate=F,T.directionalLights.needsUpdate=F,T.directionalLightShadows.needsUpdate=F,T.pointLights.needsUpdate=F,T.pointLightShadows.needsUpdate=F,T.spotLights.needsUpdate=F,T.spotLightShadows.needsUpdate=F,T.rectAreaLights.needsUpdate=F,T.hemisphereLights.needsUpdate=F}function Lp(T){return T.isMeshLambertMaterial||T.isMeshToonMaterial||T.isMeshPhongMaterial||T.isMeshStandardMaterial||T.isShadowMaterial||T.isShaderMaterial&&T.lights===!0}this.getActiveCubeFace=function(){return S},this.getActiveMipmapLevel=function(){return A},this.getRenderTarget=function(){return P},this.setRenderTargetTextures=function(T,F,G){Pt.get(T.texture).__webglTexture=F,Pt.get(T.depthTexture).__webglTexture=G;let $=Pt.get(T);$.__hasExternalTextures=!0,$.__autoAllocateDepthBuffer=G===void 0,$.__autoAllocateDepthBuffer||jt.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),$.__useRenderToTexture=!1)},this.setRenderTargetFramebuffer=function(T,F){let G=Pt.get(T);G.__webglFramebuffer=F,G.__useDefaultFramebuffer=F===void 0},this.setRenderTarget=function(T,F=0,G=0){P=T,S=F,A=G;let $=!0,B=null,st=!1,dt=!1;if(T){let Mt=Pt.get(T);if(Mt.__useDefaultFramebuffer!==void 0)It.bindFramebuffer(O.FRAMEBUFFER,null),$=!1;else if(Mt.__webglFramebuffer===void 0)I.setupRenderTarget(T);else if(Mt.__hasExternalTextures)I.rebindTextures(T,Pt.get(T.texture).__webglTexture,Pt.get(T.depthTexture).__webglTexture);else if(T.depthBuffer){let wt=T.depthTexture;if(Mt.__boundDepthTexture!==wt){if(wt!==null&&Pt.has(wt)&&(T.width!==wt.image.width||T.height!==wt.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");I.setupDepthRenderbuffer(T)}}let zt=T.texture;(zt.isData3DTexture||zt.isDataArrayTexture||zt.isCompressedArrayTexture)&&(dt=!0);let Vt=Pt.get(T).__webglFramebuffer;T.isWebGLCubeRenderTarget?(Array.isArray(Vt[F])?B=Vt[F][G]:B=Vt[F],st=!0):T.samples>0&&I.useMultisampledRTT(T)===!1?B=Pt.get(T).__webglMultisampledFramebuffer:Array.isArray(Vt)?B=Vt[G]:B=Vt,R.copy(T.viewport),L.copy(T.scissor),D=T.scissorTest}else R.copy(at).multiplyScalar(H).floor(),L.copy(Ct).multiplyScalar(H).floor(),D=qt;if(It.bindFramebuffer(O.FRAMEBUFFER,B)&&$&&It.drawBuffers(T,B),It.viewport(R),It.scissor(L),It.setScissorTest(D),st){let Mt=Pt.get(T.texture);O.framebufferTexture2D(O.FRAMEBUFFER,O.COLOR_ATTACHMENT0,O.TEXTURE_CUBE_MAP_POSITIVE_X+F,Mt.__webglTexture,G)}else if(dt){let Mt=Pt.get(T.texture),zt=F||0;O.framebufferTextureLayer(O.FRAMEBUFFER,O.COLOR_ATTACHMENT0,Mt.__webglTexture,G||0,zt)}_=-1},this.readRenderTargetPixels=function(T,F,G,$,B,st,dt){if(!(T&&T.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let _t=Pt.get(T).__webglFramebuffer;if(T.isWebGLCubeRenderTarget&&dt!==void 0&&(_t=_t[dt]),_t){It.bindFramebuffer(O.FRAMEBUFFER,_t);try{let Mt=T.texture,zt=Mt.format,Vt=Mt.type;if(!Qt.textureFormatReadable(zt)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!Qt.textureTypeReadable(Vt)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}F>=0&&F<=T.width-$&&G>=0&&G<=T.height-B&&O.readPixels(F,G,$,B,Xt.convert(zt),Xt.convert(Vt),st)}finally{let Mt=P!==null?Pt.get(P).__webglFramebuffer:null;It.bindFramebuffer(O.FRAMEBUFFER,Mt)}}},this.readRenderTargetPixelsAsync=async function(T,F,G,$,B,st,dt){if(!(T&&T.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let _t=Pt.get(T).__webglFramebuffer;if(T.isWebGLCubeRenderTarget&&dt!==void 0&&(_t=_t[dt]),_t){let Mt=T.texture,zt=Mt.format,Vt=Mt.type;if(!Qt.textureFormatReadable(zt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!Qt.textureTypeReadable(Vt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");if(F>=0&&F<=T.width-$&&G>=0&&G<=T.height-B){It.bindFramebuffer(O.FRAMEBUFFER,_t);let wt=O.createBuffer();O.bindBuffer(O.PIXEL_PACK_BUFFER,wt),O.bufferData(O.PIXEL_PACK_BUFFER,st.byteLength,O.STREAM_READ),O.readPixels(F,G,$,B,Xt.convert(zt),Xt.convert(Vt),0);let oe=P!==null?Pt.get(P).__webglFramebuffer:null;It.bindFramebuffer(O.FRAMEBUFFER,oe);let xe=O.fenceSync(O.SYNC_GPU_COMMANDS_COMPLETE,0);return O.flush(),await Um(O,xe,4),O.bindBuffer(O.PIXEL_PACK_BUFFER,wt),O.getBufferSubData(O.PIXEL_PACK_BUFFER,0,st),O.deleteBuffer(wt),O.deleteSync(xe),st}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")}},this.copyFramebufferToTexture=function(T,F=null,G=0){T.isTexture!==!0&&(Or("WebGLRenderer: copyFramebufferToTexture function signature has changed."),F=arguments[0]||null,T=arguments[1]);let $=Math.pow(2,-G),B=Math.floor(T.image.width*$),st=Math.floor(T.image.height*$),dt=F!==null?F.x:0,_t=F!==null?F.y:0;I.setTexture2D(T,0),O.copyTexSubImage2D(O.TEXTURE_2D,G,0,0,dt,_t,B,st),It.unbindTexture()},this.copyTextureToTexture=function(T,F,G=null,$=null,B=0){T.isTexture!==!0&&(Or("WebGLRenderer: copyTextureToTexture function signature has changed."),$=arguments[0]||null,T=arguments[1],F=arguments[2],B=arguments[3]||0,G=null);let st,dt,_t,Mt,zt,Vt,wt,oe,xe,be=T.isCompressedTexture?T.mipmaps[B]:T.image;G!==null?(st=G.max.x-G.min.x,dt=G.max.y-G.min.y,_t=G.isBox3?G.max.z-G.min.z:1,Mt=G.min.x,zt=G.min.y,Vt=G.isBox3?G.min.z:0):(st=be.width,dt=be.height,_t=be.depth||1,Mt=0,zt=0,Vt=0),$!==null?(wt=$.x,oe=$.y,xe=$.z):(wt=0,oe=0,xe=0);let cn=Xt.convert(F.format),ce=Xt.convert(F.type),Et;F.isData3DTexture?(I.setTexture3D(F,0),Et=O.TEXTURE_3D):F.isDataArrayTexture||F.isCompressedArrayTexture?(I.setTexture2DArray(F,0),Et=O.TEXTURE_2D_ARRAY):(I.setTexture2D(F,0),Et=O.TEXTURE_2D),O.pixelStorei(O.UNPACK_FLIP_Y_WEBGL,F.flipY),O.pixelStorei(O.UNPACK_PREMULTIPLY_ALPHA_WEBGL,F.premultiplyAlpha),O.pixelStorei(O.UNPACK_ALIGNMENT,F.unpackAlignment);let ai=O.getParameter(O.UNPACK_ROW_LENGTH),he=O.getParameter(O.UNPACK_IMAGE_HEIGHT),Nn=O.getParameter(O.UNPACK_SKIP_PIXELS),Is=O.getParameter(O.UNPACK_SKIP_ROWS),xn=O.getParameter(O.UNPACK_SKIP_IMAGES);O.pixelStorei(O.UNPACK_ROW_LENGTH,be.width),O.pixelStorei(O.UNPACK_IMAGE_HEIGHT,be.height),O.pixelStorei(O.UNPACK_SKIP_PIXELS,Mt),O.pixelStorei(O.UNPACK_SKIP_ROWS,zt),O.pixelStorei(O.UNPACK_SKIP_IMAGES,Vt);let Rr=T.isDataArrayTexture||T.isData3DTexture,_e=F.isDataArrayTexture||F.isData3DTexture;if(T.isRenderTargetTexture||T.isDepthTexture){let Yn=Pt.get(T),Cr=Pt.get(F),Cn=Pt.get(Yn.__renderTarget),Pi=Pt.get(Cr.__renderTarget);It.bindFramebuffer(O.READ_FRAMEBUFFER,Cn.__webglFramebuffer),It.bindFramebuffer(O.DRAW_FRAMEBUFFER,Pi.__webglFramebuffer);for(let Ii=0;Ii<_t;Ii++)Rr&&O.framebufferTextureLayer(O.READ_FRAMEBUFFER,O.COLOR_ATTACHMENT0,Pt.get(T).__webglTexture,B,Vt+Ii),T.isDepthTexture?(_e&&O.framebufferTextureLayer(O.DRAW_FRAMEBUFFER,O.COLOR_ATTACHMENT0,Pt.get(F).__webglTexture,B,xe+Ii),O.blitFramebuffer(Mt,zt,st,dt,wt,oe,st,dt,O.DEPTH_BUFFER_BIT,O.NEAREST)):_e?O.copyTexSubImage3D(Et,B,wt,oe,xe+Ii,Mt,zt,st,dt):O.copyTexSubImage2D(Et,B,wt,oe,xe+Ii,Mt,zt,st,dt);It.bindFramebuffer(O.READ_FRAMEBUFFER,null),It.bindFramebuffer(O.DRAW_FRAMEBUFFER,null)}else _e?T.isDataTexture||T.isData3DTexture?O.texSubImage3D(Et,B,wt,oe,xe,st,dt,_t,cn,ce,be.data):F.isCompressedArrayTexture?O.compressedTexSubImage3D(Et,B,wt,oe,xe,st,dt,_t,cn,be.data):O.texSubImage3D(Et,B,wt,oe,xe,st,dt,_t,cn,ce,be):T.isDataTexture?O.texSubImage2D(O.TEXTURE_2D,B,wt,oe,st,dt,cn,ce,be.data):T.isCompressedTexture?O.compressedTexSubImage2D(O.TEXTURE_2D,B,wt,oe,be.width,be.height,cn,be.data):O.texSubImage2D(O.TEXTURE_2D,B,wt,oe,st,dt,cn,ce,be);O.pixelStorei(O.UNPACK_ROW_LENGTH,ai),O.pixelStorei(O.UNPACK_IMAGE_HEIGHT,he),O.pixelStorei(O.UNPACK_SKIP_PIXELS,Nn),O.pixelStorei(O.UNPACK_SKIP_ROWS,Is),O.pixelStorei(O.UNPACK_SKIP_IMAGES,xn),B===0&&F.generateMipmaps&&O.generateMipmap(Et),It.unbindTexture()},this.copyTextureToTexture3D=function(T,F,G=null,$=null,B=0){return T.isTexture!==!0&&(Or("WebGLRenderer: copyTextureToTexture3D function signature has changed."),G=arguments[0]||null,$=arguments[1]||null,T=arguments[2],F=arguments[3],B=arguments[4]||0),Or('WebGLRenderer: copyTextureToTexture3D function has been deprecated. Use "copyTextureToTexture" instead.'),this.copyTextureToTexture(T,F,G,$,B)},this.initRenderTarget=function(T){Pt.get(T).__webglFramebuffer===void 0&&I.setupRenderTarget(T)},this.initTexture=function(T){T.isCubeTexture?I.setTextureCube(T,0):T.isData3DTexture?I.setTexture3D(T,0):T.isDataArrayTexture||T.isCompressedArrayTexture?I.setTexture2DArray(T,0):I.setTexture2D(T,0),It.unbindTexture()},this.resetState=function(){S=0,A=0,P=null,It.reset(),ge.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return mi}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;let e=this.getContext();e.drawingBufferColorspace=ie._getDrawingBufferColorSpace(t),e.unpackColorSpace=ie._getUnpackColorSpace()}};var Ta=class i{constructor(t,e=1,n=1e3){this.isFog=!0,this.name="",this.color=new bt(t),this.near=e,this.far=n}clone(){return new i(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}},hr=class extends Oe{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new un,this.environmentIntensity=1,this.environmentRotation=new un,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){let e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(e.object.environmentIntensity=this.environmentIntensity),e.object.environmentRotation=this.environmentRotation.toArray(),e}},Aa=class{constructor(t,e){this.isInterleavedBuffer=!0,this.array=t,this.stride=e,this.count=t!==void 0?t.length/e:0,this.usage=Wc,this.updateRanges=[],this.version=0,this.uuid=Jn()}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.array=new t.array.constructor(t.array),this.count=t.count,this.stride=t.stride,this.usage=t.usage,this}copyAt(t,e,n){t*=this.stride,n*=e.stride;for(let s=0,r=this.stride;s<r;s++)this.array[t+s]=e.array[n+s];return this}set(t,e=0){return this.array.set(t,e),this}clone(t){t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Jn()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let e=new this.array.constructor(t.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(e,this.stride);return n.setUsage(this.usage),n}onUpload(t){return this.onUploadCallback=t,this}toJSON(t){return t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Jn()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}},en=new C,Qr=class i{constructor(t,e,n,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=t,this.itemSize=e,this.offset=n,this.normalized=s}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(t){this.data.needsUpdate=t}applyMatrix4(t){for(let e=0,n=this.data.count;e<n;e++)en.fromBufferAttribute(this,e),en.applyMatrix4(t),this.setXYZ(e,en.x,en.y,en.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)en.fromBufferAttribute(this,e),en.applyNormalMatrix(t),this.setXYZ(e,en.x,en.y,en.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)en.fromBufferAttribute(this,e),en.transformDirection(t),this.setXYZ(e,en.x,en.y,en.z);return this}getComponent(t,e){let n=this.array[t*this.data.stride+this.offset+e];return this.normalized&&(n=On(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=de(n,this.array)),this.data.array[t*this.data.stride+this.offset+e]=n,this}setX(t,e){return this.normalized&&(e=de(e,this.array)),this.data.array[t*this.data.stride+this.offset]=e,this}setY(t,e){return this.normalized&&(e=de(e,this.array)),this.data.array[t*this.data.stride+this.offset+1]=e,this}setZ(t,e){return this.normalized&&(e=de(e,this.array)),this.data.array[t*this.data.stride+this.offset+2]=e,this}setW(t,e){return this.normalized&&(e=de(e,this.array)),this.data.array[t*this.data.stride+this.offset+3]=e,this}getX(t){let e=this.data.array[t*this.data.stride+this.offset];return this.normalized&&(e=On(e,this.array)),e}getY(t){let e=this.data.array[t*this.data.stride+this.offset+1];return this.normalized&&(e=On(e,this.array)),e}getZ(t){let e=this.data.array[t*this.data.stride+this.offset+2];return this.normalized&&(e=On(e,this.array)),e}getW(t){let e=this.data.array[t*this.data.stride+this.offset+3];return this.normalized&&(e=On(e,this.array)),e}setXY(t,e,n){return t=t*this.data.stride+this.offset,this.normalized&&(e=de(e,this.array),n=de(n,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this}setXYZ(t,e,n,s){return t=t*this.data.stride+this.offset,this.normalized&&(e=de(e,this.array),n=de(n,this.array),s=de(s,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=s,this}setXYZW(t,e,n,s,r){return t=t*this.data.stride+this.offset,this.normalized&&(e=de(e,this.array),n=de(n,this.array),s=de(s,this.array),r=de(r,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=s,this.data.array[t+3]=r,this}clone(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let n=0;n<this.count;n++){let s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return new Ne(new this.array.constructor(e),this.itemSize,this.normalized)}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new i(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let n=0;n<this.count;n++){let s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.toJSON(t)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},to=class extends vi{static get type(){return"SpriteMaterial"}constructor(t){super(),this.isSpriteMaterial=!0,this.color=new bt(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.rotation=t.rotation,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},qs,kr=new C,Xs=new C,Ys=new C,Zs=new rt,Ur=new rt,Sf=new Wt,Qo=new C,Nr=new C,ta=new C,zd=new rt,Ql=new rt,Fd=new rt,Ra=class extends Oe{constructor(t=new to){if(super(),this.isSprite=!0,this.type="Sprite",qs===void 0){qs=new ae;let e=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new Aa(e,5);qs.setIndex([0,1,2,0,2,3]),qs.setAttribute("position",new Qr(n,3,0,!1)),qs.setAttribute("uv",new Qr(n,2,3,!1))}this.geometry=qs,this.material=t,this.center=new rt(.5,.5)}raycast(t,e){t.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),Xs.setFromMatrixScale(this.matrixWorld),Sf.copy(t.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse,this.matrixWorld),Ys.setFromMatrixPosition(this.modelViewMatrix),t.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Xs.multiplyScalar(-Ys.z);let n=this.material.rotation,s,r;n!==0&&(r=Math.cos(n),s=Math.sin(n));let o=this.center;ea(Qo.set(-.5,-.5,0),Ys,o,Xs,s,r),ea(Nr.set(.5,-.5,0),Ys,o,Xs,s,r),ea(ta.set(.5,.5,0),Ys,o,Xs,s,r),zd.set(0,0),Ql.set(1,0),Fd.set(1,1);let a=t.ray.intersectTriangle(Qo,Nr,ta,!1,kr);if(a===null&&(ea(Nr.set(-.5,.5,0),Ys,o,Xs,s,r),Ql.set(0,1),a=t.ray.intersectTriangle(Qo,ta,Nr,!1,kr),a===null))return;let l=t.ray.origin.distanceTo(kr);l<t.near||l>t.far||e.push({distance:l,point:kr.clone(),uv:Bi.getInterpolation(kr,Qo,Nr,ta,zd,Ql,Fd,new rt),face:null,object:this})}copy(t,e){return super.copy(t,e),t.center!==void 0&&this.center.copy(t.center),this.material=t.material,this}};function ea(i,t,e,n,s,r){Zs.subVectors(i,e).addScalar(.5).multiply(n),s!==void 0?(Ur.x=r*Zs.x-s*Zs.y,Ur.y=s*Zs.x+r*Zs.y):Ur.copy(Zs),i.copy(t),i.x+=Ur.x,i.y+=Ur.y,i.applyMatrix4(Sf)}var ah=class extends hn{constructor(t=null,e=1,n=1,s,r,o,a,l,c=_n,h=_n,u,d){super(null,o,a,l,c,h,s,r,u,d),this.isDataTexture=!0,this.image={data:t,width:e,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var eo=class extends Ne{constructor(t,e,n,s=1){super(t,e,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){let t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}},Ks=new Wt,Bd=new Wt,na=[],Od=new yi,Pv=new Wt,zr=new nt,Fr=new Gi,sn=class extends nt{constructor(t,e,n){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new eo(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<n;s++)this.setMatrixAt(s,Pv)}computeBoundingBox(){let t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new yi),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,Ks),Od.copy(t.boundingBox).applyMatrix4(Ks),this.boundingBox.union(Od)}computeBoundingSphere(){let t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new Gi),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,Ks),Fr.copy(t.boundingSphere).applyMatrix4(Ks),this.boundingSphere.union(Fr)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),t.morphTexture!==null&&(this.morphTexture=t.morphTexture.clone()),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,e){e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){e.fromArray(this.instanceMatrix.array,t*16)}getMorphAt(t,e){let n=e.morphTargetInfluences,s=this.morphTexture.source.data.data,r=n.length+1,o=t*r+1;for(let a=0;a<n.length;a++)n[a]=s[o+a]}raycast(t,e){let n=this.matrixWorld,s=this.count;if(zr.geometry=this.geometry,zr.material=this.material,zr.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Fr.copy(this.boundingSphere),Fr.applyMatrix4(n),t.ray.intersectsSphere(Fr)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,Ks),Bd.multiplyMatrices(n,Ks),zr.matrixWorld=Bd,zr.raycast(t,na);for(let o=0,a=na.length;o<a;o++){let l=na[o];l.instanceId=r,l.object=this,e.push(l)}na.length=0}}setColorAt(t,e){this.instanceColor===null&&(this.instanceColor=new eo(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),e.toArray(this.instanceColor.array,t*3)}setMatrixAt(t,e){e.toArray(this.instanceMatrix.array,t*16)}setMorphAt(t,e){let n=e.morphTargetInfluences,s=n.length+1;this.morphTexture===null&&(this.morphTexture=new ah(new Float32Array(s*this.count),s,this.count,Uh,Kn));let r=this.morphTexture.source.data.data,o=0;for(let c=0;c<n.length;c++)o+=n[c];let a=this.geometry.morphTargetsRelative?1:1-o,l=s*t;r[l]=a,r.set(n,l+1)}updateMorphTargets(){}dispose(){return this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null),this}};var bi=class extends vi{static get type(){return"LineBasicMaterial"}constructor(t){super(),this.isLineBasicMaterial=!0,this.color=new bt(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.linewidth=t.linewidth,this.linecap=t.linecap,this.linejoin=t.linejoin,this.fog=t.fog,this}},Ca=new C,Pa=new C,Hd=new Wt,Br=new Kr,ia=new Gi,tc=new C,Vd=new C,Ln=class extends Oe{constructor(t=new ae,e=new bi){super(),this.isLine=!0,this.type="Line",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}computeLineDistances(){let t=this.geometry;if(t.index===null){let e=t.attributes.position,n=[0];for(let s=1,r=e.count;s<r;s++)Ca.fromBufferAttribute(e,s-1),Pa.fromBufferAttribute(e,s),n[s]=n[s-1],n[s]+=Ca.distanceTo(Pa);t.setAttribute("lineDistance",new Ot(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(t,e){let n=this.geometry,s=this.matrixWorld,r=t.params.Line.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),ia.copy(n.boundingSphere),ia.applyMatrix4(s),ia.radius+=r,t.ray.intersectsSphere(ia)===!1)return;Hd.copy(s).invert(),Br.copy(t.ray).applyMatrix4(Hd);let a=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,c=this.isLineSegments?2:1,h=n.index,d=n.attributes.position;if(h!==null){let f=Math.max(0,o.start),g=Math.min(h.count,o.start+o.count);for(let x=f,m=g-1;x<m;x+=c){let p=h.getX(x),M=h.getX(x+1),v=sa(this,t,Br,l,p,M);v&&e.push(v)}if(this.isLineLoop){let x=h.getX(g-1),m=h.getX(f),p=sa(this,t,Br,l,x,m);p&&e.push(p)}}else{let f=Math.max(0,o.start),g=Math.min(d.count,o.start+o.count);for(let x=f,m=g-1;x<m;x+=c){let p=sa(this,t,Br,l,x,x+1);p&&e.push(p)}if(this.isLineLoop){let x=sa(this,t,Br,l,g-1,f);x&&e.push(x)}}}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}};function sa(i,t,e,n,s,r){let o=i.geometry.attributes.position;if(Ca.fromBufferAttribute(o,s),Pa.fromBufferAttribute(o,r),e.distanceSqToSegment(Ca,Pa,tc,Vd)>n)return;tc.applyMatrix4(i.matrixWorld);let l=t.ray.origin.distanceTo(tc);if(!(l<t.near||l>t.far))return{distance:l,point:Vd.clone().applyMatrix4(i.matrixWorld),index:s,face:null,faceIndex:null,barycoord:null,object:i}}var Gd=new C,Wd=new C,Ia=class extends Ln{constructor(t,e){super(t,e),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){let t=this.geometry;if(t.index===null){let e=t.attributes.position,n=[];for(let s=0,r=e.count;s<r;s+=2)Gd.fromBufferAttribute(e,s),Wd.fromBufferAttribute(e,s+1),n[s]=s===0?0:n[s-1],n[s+1]=n[s]+Gd.distanceTo(Wd);t.setAttribute("lineDistance",new Ot(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}};var Je=class extends hn{constructor(t,e,n,s,r,o,a,l,c){super(t,e,n,s,r,o,a,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}},Dn=class{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(t,e){let n=this.getUtoTmapping(t);return this.getPoint(n,e)}getPoints(t=5){let e=[];for(let n=0;n<=t;n++)e.push(this.getPoint(n/t));return e}getSpacedPoints(t=5){let e=[];for(let n=0;n<=t;n++)e.push(this.getPointAt(n/t));return e}getLength(){let t=this.getLengths();return t[t.length-1]}getLengths(t=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===t+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;let e=[],n,s=this.getPoint(0),r=0;e.push(0);for(let o=1;o<=t;o++)n=this.getPoint(o/t),r+=n.distanceTo(s),e.push(r),s=n;return this.cacheArcLengths=e,e}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(t,e){let n=this.getLengths(),s=0,r=n.length,o;e?o=e:o=t*n[r-1];let a=0,l=r-1,c;for(;a<=l;)if(s=Math.floor(a+(l-a)/2),c=n[s]-o,c<0)a=s+1;else if(c>0)l=s-1;else{l=s;break}if(s=l,n[s]===o)return s/(r-1);let h=n[s],d=n[s+1]-h,f=(o-h)/d;return(s+f)/(r-1)}getTangent(t,e){let s=t-1e-4,r=t+1e-4;s<0&&(s=0),r>1&&(r=1);let o=this.getPoint(s),a=this.getPoint(r),l=e||(o.isVector2?new rt:new C);return l.copy(a).sub(o).normalize(),l}getTangentAt(t,e){let n=this.getUtoTmapping(t);return this.getTangent(n,e)}computeFrenetFrames(t,e){let n=new C,s=[],r=[],o=[],a=new C,l=new Wt;for(let f=0;f<=t;f++){let g=f/t;s[f]=this.getTangentAt(g,new C)}r[0]=new C,o[0]=new C;let c=Number.MAX_VALUE,h=Math.abs(s[0].x),u=Math.abs(s[0].y),d=Math.abs(s[0].z);h<=c&&(c=h,n.set(1,0,0)),u<=c&&(c=u,n.set(0,1,0)),d<=c&&n.set(0,0,1),a.crossVectors(s[0],n).normalize(),r[0].crossVectors(s[0],a),o[0].crossVectors(s[0],r[0]);for(let f=1;f<=t;f++){if(r[f]=r[f-1].clone(),o[f]=o[f-1].clone(),a.crossVectors(s[f-1],s[f]),a.length()>Number.EPSILON){a.normalize();let g=Math.acos(Fe(s[f-1].dot(s[f]),-1,1));r[f].applyMatrix4(l.makeRotationAxis(a,g))}o[f].crossVectors(s[f],r[f])}if(e===!0){let f=Math.acos(Fe(r[0].dot(r[t]),-1,1));f/=t,s[0].dot(a.crossVectors(r[0],r[t]))>0&&(f=-f);for(let g=1;g<=t;g++)r[g].applyMatrix4(l.makeRotationAxis(s[g],f*g)),o[g].crossVectors(s[g],r[g])}return{tangents:s,normals:r,binormals:o}}clone(){return new this.constructor().copy(this)}copy(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}toJSON(){let t={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return t.arcLengthDivisions=this.arcLengthDivisions,t.type=this.type,t}fromJSON(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}},no=class extends Dn{constructor(t=0,e=0,n=1,s=1,r=0,o=Math.PI*2,a=!1,l=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=t,this.aY=e,this.xRadius=n,this.yRadius=s,this.aStartAngle=r,this.aEndAngle=o,this.aClockwise=a,this.aRotation=l}getPoint(t,e=new rt){let n=e,s=Math.PI*2,r=this.aEndAngle-this.aStartAngle,o=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=s;for(;r>s;)r-=s;r<Number.EPSILON&&(o?r=0:r=s),this.aClockwise===!0&&!o&&(r===s?r=-s:r=r-s);let a=this.aStartAngle+t*r,l=this.aX+this.xRadius*Math.cos(a),c=this.aY+this.yRadius*Math.sin(a);if(this.aRotation!==0){let h=Math.cos(this.aRotation),u=Math.sin(this.aRotation),d=l-this.aX,f=c-this.aY;l=d*h-f*u+this.aX,c=d*u+f*h+this.aY}return n.set(l,c)}copy(t){return super.copy(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}toJSON(){let t=super.toJSON();return t.aX=this.aX,t.aY=this.aY,t.xRadius=this.xRadius,t.yRadius=this.yRadius,t.aStartAngle=this.aStartAngle,t.aEndAngle=this.aEndAngle,t.aClockwise=this.aClockwise,t.aRotation=this.aRotation,t}fromJSON(t){return super.fromJSON(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}},lh=class extends no{constructor(t,e,n,s,r,o){super(t,e,n,n,s,r,o),this.isArcCurve=!0,this.type="ArcCurve"}};function Hh(){let i=0,t=0,e=0,n=0;function s(r,o,a,l){i=r,t=a,e=-3*r+3*o-2*a-l,n=2*r-2*o+a+l}return{initCatmullRom:function(r,o,a,l,c){s(o,a,c*(a-r),c*(l-o))},initNonuniformCatmullRom:function(r,o,a,l,c,h,u){let d=(o-r)/c-(a-r)/(c+h)+(a-o)/h,f=(a-o)/h-(l-o)/(h+u)+(l-a)/u;d*=h,f*=h,s(o,a,d,f)},calc:function(r){let o=r*r,a=o*r;return i+t*r+e*o+n*a}}}var ra=new C,ec=new Hh,nc=new Hh,ic=new Hh,ch=class extends Dn{constructor(t=[],e=!1,n="centripetal",s=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=t,this.closed=e,this.curveType=n,this.tension=s}getPoint(t,e=new C){let n=e,s=this.points,r=s.length,o=(r-(this.closed?0:1))*t,a=Math.floor(o),l=o-a;this.closed?a+=a>0?0:(Math.floor(Math.abs(a)/r)+1)*r:l===0&&a===r-1&&(a=r-2,l=1);let c,h;this.closed||a>0?c=s[(a-1)%r]:(ra.subVectors(s[0],s[1]).add(s[0]),c=ra);let u=s[a%r],d=s[(a+1)%r];if(this.closed||a+2<r?h=s[(a+2)%r]:(ra.subVectors(s[r-1],s[r-2]).add(s[r-1]),h=ra),this.curveType==="centripetal"||this.curveType==="chordal"){let f=this.curveType==="chordal"?.5:.25,g=Math.pow(c.distanceToSquared(u),f),x=Math.pow(u.distanceToSquared(d),f),m=Math.pow(d.distanceToSquared(h),f);x<1e-4&&(x=1),g<1e-4&&(g=x),m<1e-4&&(m=x),ec.initNonuniformCatmullRom(c.x,u.x,d.x,h.x,g,x,m),nc.initNonuniformCatmullRom(c.y,u.y,d.y,h.y,g,x,m),ic.initNonuniformCatmullRom(c.z,u.z,d.z,h.z,g,x,m)}else this.curveType==="catmullrom"&&(ec.initCatmullRom(c.x,u.x,d.x,h.x,this.tension),nc.initCatmullRom(c.y,u.y,d.y,h.y,this.tension),ic.initCatmullRom(c.z,u.z,d.z,h.z,this.tension));return n.set(ec.calc(l),nc.calc(l),ic.calc(l)),n}copy(t){super.copy(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let s=t.points[e];this.points.push(s.clone())}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}toJSON(){let t=super.toJSON();t.points=[];for(let e=0,n=this.points.length;e<n;e++){let s=this.points[e];t.points.push(s.toArray())}return t.closed=this.closed,t.curveType=this.curveType,t.tension=this.tension,t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let s=t.points[e];this.points.push(new C().fromArray(s))}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}};function $d(i,t,e,n,s){let r=(n-t)*.5,o=(s-e)*.5,a=i*i,l=i*a;return(2*e-2*n+r+o)*l+(-3*e+3*n-2*r-o)*a+r*i+e}function Iv(i,t){let e=1-i;return e*e*t}function Lv(i,t){return 2*(1-i)*i*t}function Dv(i,t){return i*i*t}function $r(i,t,e,n){return Iv(i,t)+Lv(i,e)+Dv(i,n)}function kv(i,t){let e=1-i;return e*e*e*t}function Uv(i,t){let e=1-i;return 3*e*e*i*t}function Nv(i,t){return 3*(1-i)*i*i*t}function zv(i,t){return i*i*i*t}function qr(i,t,e,n,s){return kv(i,t)+Uv(i,e)+Nv(i,n)+zv(i,s)}var La=class extends Dn{constructor(t=new rt,e=new rt,n=new rt,s=new rt){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=t,this.v1=e,this.v2=n,this.v3=s}getPoint(t,e=new rt){let n=e,s=this.v0,r=this.v1,o=this.v2,a=this.v3;return n.set(qr(t,s.x,r.x,o.x,a.x),qr(t,s.y,r.y,o.y,a.y)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}},hh=class extends Dn{constructor(t=new C,e=new C,n=new C,s=new C){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=t,this.v1=e,this.v2=n,this.v3=s}getPoint(t,e=new C){let n=e,s=this.v0,r=this.v1,o=this.v2,a=this.v3;return n.set(qr(t,s.x,r.x,o.x,a.x),qr(t,s.y,r.y,o.y,a.y),qr(t,s.z,r.z,o.z,a.z)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}},Da=class extends Dn{constructor(t=new rt,e=new rt){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=t,this.v2=e}getPoint(t,e=new rt){let n=e;return t===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(t).add(this.v1)),n}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new rt){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},uh=class extends Dn{constructor(t=new C,e=new C){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=t,this.v2=e}getPoint(t,e=new C){let n=e;return t===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(t).add(this.v1)),n}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new C){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},ka=class extends Dn{constructor(t=new rt,e=new rt,n=new rt){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=t,this.v1=e,this.v2=n}getPoint(t,e=new rt){let n=e,s=this.v0,r=this.v1,o=this.v2;return n.set($r(t,s.x,r.x,o.x),$r(t,s.y,r.y,o.y)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},io=class extends Dn{constructor(t=new C,e=new C,n=new C){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=t,this.v1=e,this.v2=n}getPoint(t,e=new C){let n=e,s=this.v0,r=this.v1,o=this.v2;return n.set($r(t,s.x,r.x,o.x),$r(t,s.y,r.y,o.y),$r(t,s.z,r.z,o.z)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Ua=class extends Dn{constructor(t=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=t}getPoint(t,e=new rt){let n=e,s=this.points,r=(s.length-1)*t,o=Math.floor(r),a=r-o,l=s[o===0?o:o-1],c=s[o],h=s[o>s.length-2?s.length-1:o+1],u=s[o>s.length-3?s.length-1:o+2];return n.set($d(a,l.x,c.x,h.x,u.x),$d(a,l.y,c.y,h.y,u.y)),n}copy(t){super.copy(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let s=t.points[e];this.points.push(s.clone())}return this}toJSON(){let t=super.toJSON();t.points=[];for(let e=0,n=this.points.length;e<n;e++){let s=this.points[e];t.points.push(s.toArray())}return t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let s=t.points[e];this.points.push(new rt().fromArray(s))}return this}},qd=Object.freeze({__proto__:null,ArcCurve:lh,CatmullRomCurve3:ch,CubicBezierCurve:La,CubicBezierCurve3:hh,EllipseCurve:no,LineCurve:Da,LineCurve3:uh,QuadraticBezierCurve:ka,QuadraticBezierCurve3:io,SplineCurve:Ua}),dh=class extends Dn{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(t){this.curves.push(t)}closePath(){let t=this.curves[0].getPoint(0),e=this.curves[this.curves.length-1].getPoint(1);if(!t.equals(e)){let n=t.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new qd[n](e,t))}return this}getPoint(t,e){let n=t*this.getLength(),s=this.getCurveLengths(),r=0;for(;r<s.length;){if(s[r]>=n){let o=s[r]-n,a=this.curves[r],l=a.getLength(),c=l===0?0:1-o/l;return a.getPointAt(c,e)}r++}return null}getLength(){let t=this.getCurveLengths();return t[t.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;let t=[],e=0;for(let n=0,s=this.curves.length;n<s;n++)e+=this.curves[n].getLength(),t.push(e);return this.cacheLengths=t,t}getSpacedPoints(t=40){let e=[];for(let n=0;n<=t;n++)e.push(this.getPoint(n/t));return this.autoClose&&e.push(e[0]),e}getPoints(t=12){let e=[],n;for(let s=0,r=this.curves;s<r.length;s++){let o=r[s],a=o.isEllipseCurve?t*2:o.isLineCurve||o.isLineCurve3?1:o.isSplineCurve?t*o.points.length:t,l=o.getPoints(a);for(let c=0;c<l.length;c++){let h=l[c];n&&n.equals(h)||(e.push(h),n=h)}}return this.autoClose&&e.length>1&&!e[e.length-1].equals(e[0])&&e.push(e[0]),e}copy(t){super.copy(t),this.curves=[];for(let e=0,n=t.curves.length;e<n;e++){let s=t.curves[e];this.curves.push(s.clone())}return this.autoClose=t.autoClose,this}toJSON(){let t=super.toJSON();t.autoClose=this.autoClose,t.curves=[];for(let e=0,n=this.curves.length;e<n;e++){let s=this.curves[e];t.curves.push(s.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.autoClose=t.autoClose,this.curves=[];for(let e=0,n=t.curves.length;e<n;e++){let s=t.curves[e];this.curves.push(new qd[s.type]().fromJSON(s))}return this}},so=class extends dh{constructor(t){super(),this.type="Path",this.currentPoint=new rt,t&&this.setFromPoints(t)}setFromPoints(t){this.moveTo(t[0].x,t[0].y);for(let e=1,n=t.length;e<n;e++)this.lineTo(t[e].x,t[e].y);return this}moveTo(t,e){return this.currentPoint.set(t,e),this}lineTo(t,e){let n=new Da(this.currentPoint.clone(),new rt(t,e));return this.curves.push(n),this.currentPoint.set(t,e),this}quadraticCurveTo(t,e,n,s){let r=new ka(this.currentPoint.clone(),new rt(t,e),new rt(n,s));return this.curves.push(r),this.currentPoint.set(n,s),this}bezierCurveTo(t,e,n,s,r,o){let a=new La(this.currentPoint.clone(),new rt(t,e),new rt(n,s),new rt(r,o));return this.curves.push(a),this.currentPoint.set(r,o),this}splineThru(t){let e=[this.currentPoint.clone()].concat(t),n=new Ua(e);return this.curves.push(n),this.currentPoint.copy(t[t.length-1]),this}arc(t,e,n,s,r,o){let a=this.currentPoint.x,l=this.currentPoint.y;return this.absarc(t+a,e+l,n,s,r,o),this}absarc(t,e,n,s,r,o){return this.absellipse(t,e,n,n,s,r,o),this}ellipse(t,e,n,s,r,o,a,l){let c=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(t+c,e+h,n,s,r,o,a,l),this}absellipse(t,e,n,s,r,o,a,l){let c=new no(t,e,n,s,r,o,a,l);if(this.curves.length>0){let u=c.getPoint(0);u.equals(this.currentPoint)||this.lineTo(u.x,u.y)}this.curves.push(c);let h=c.getPoint(1);return this.currentPoint.copy(h),this}copy(t){return super.copy(t),this.currentPoint.copy(t.currentPoint),this}toJSON(){let t=super.toJSON();return t.currentPoint=this.currentPoint.toArray(),t}fromJSON(t){return super.fromJSON(t),this.currentPoint.fromArray(t.currentPoint),this}},fh=class i extends ae{constructor(t=[new rt(0,-.5),new rt(.5,0),new rt(0,.5)],e=12,n=0,s=Math.PI*2){super(),this.type="LatheGeometry",this.parameters={points:t,segments:e,phiStart:n,phiLength:s},e=Math.floor(e),s=Fe(s,0,Math.PI*2);let r=[],o=[],a=[],l=[],c=[],h=1/e,u=new C,d=new rt,f=new C,g=new C,x=new C,m=0,p=0;for(let M=0;M<=t.length-1;M++)switch(M){case 0:m=t[M+1].x-t[M].x,p=t[M+1].y-t[M].y,f.x=p*1,f.y=-m,f.z=p*0,x.copy(f),f.normalize(),l.push(f.x,f.y,f.z);break;case t.length-1:l.push(x.x,x.y,x.z);break;default:m=t[M+1].x-t[M].x,p=t[M+1].y-t[M].y,f.x=p*1,f.y=-m,f.z=p*0,g.copy(f),f.x+=x.x,f.y+=x.y,f.z+=x.z,f.normalize(),l.push(f.x,f.y,f.z),x.copy(g)}for(let M=0;M<=e;M++){let v=n+M*h*s,y=Math.sin(v),w=Math.cos(v);for(let S=0;S<=t.length-1;S++){u.x=t[S].x*y,u.y=t[S].y,u.z=t[S].x*w,o.push(u.x,u.y,u.z),d.x=M/e,d.y=S/(t.length-1),a.push(d.x,d.y);let A=l[3*S+0]*y,P=l[3*S+1],_=l[3*S+0]*w;c.push(A,P,_)}}for(let M=0;M<e;M++)for(let v=0;v<t.length-1;v++){let y=v+M*t.length,w=y,S=y+t.length,A=y+t.length+1,P=y+1;r.push(w,S,P),r.push(A,P,S)}this.setIndex(r),this.setAttribute("position",new Ot(o,3)),this.setAttribute("uv",new Ot(a,2)),this.setAttribute("normal",new Ot(c,3))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.points,t.segments,t.phiStart,t.phiLength)}},Gn=class i extends fh{constructor(t=1,e=1,n=4,s=8){let r=new so;r.absarc(0,-e/2,t,Math.PI*1.5,0),r.absarc(0,e/2,t,0,Math.PI*.5),super(r.getPoints(n),s),this.type="CapsuleGeometry",this.parameters={radius:t,length:e,capSegments:n,radialSegments:s}}static fromJSON(t){return new i(t.radius,t.length,t.capSegments,t.radialSegments)}},je=class i extends ae{constructor(t=1,e=32,n=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:n,thetaLength:s},e=Math.max(3,e);let r=[],o=[],a=[],l=[],c=new C,h=new rt;o.push(0,0,0),a.push(0,0,1),l.push(.5,.5);for(let u=0,d=3;u<=e;u++,d+=3){let f=n+u/e*s;c.x=t*Math.cos(f),c.y=t*Math.sin(f),o.push(c.x,c.y,c.z),a.push(0,0,1),h.x=(o[d]/t+1)/2,h.y=(o[d+1]/t+1)/2,l.push(h.x,h.y)}for(let u=1;u<=e;u++)r.push(u,u+1,0);this.setIndex(r),this.setAttribute("position",new Ot(o,3)),this.setAttribute("normal",new Ot(a,3)),this.setAttribute("uv",new Ot(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.radius,t.segments,t.thetaStart,t.thetaLength)}},Ut=class i extends ae{constructor(t=1,e=1,n=1,s=32,r=1,o=!1,a=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:n,radialSegments:s,heightSegments:r,openEnded:o,thetaStart:a,thetaLength:l};let c=this;s=Math.floor(s),r=Math.floor(r);let h=[],u=[],d=[],f=[],g=0,x=[],m=n/2,p=0;M(),o===!1&&(t>0&&v(!0),e>0&&v(!1)),this.setIndex(h),this.setAttribute("position",new Ot(u,3)),this.setAttribute("normal",new Ot(d,3)),this.setAttribute("uv",new Ot(f,2));function M(){let y=new C,w=new C,S=0,A=(e-t)/n;for(let P=0;P<=r;P++){let _=[],b=P/r,R=b*(e-t)+t;for(let L=0;L<=s;L++){let D=L/s,N=D*l+a,W=Math.sin(N),k=Math.cos(N);w.x=R*W,w.y=-b*n+m,w.z=R*k,u.push(w.x,w.y,w.z),y.set(W,A,k).normalize(),d.push(y.x,y.y,y.z),f.push(D,1-b),_.push(g++)}x.push(_)}for(let P=0;P<s;P++)for(let _=0;_<r;_++){let b=x[_][P],R=x[_+1][P],L=x[_+1][P+1],D=x[_][P+1];(t>0||_!==0)&&(h.push(b,R,D),S+=3),(e>0||_!==r-1)&&(h.push(R,L,D),S+=3)}c.addGroup(p,S,0),p+=S}function v(y){let w=g,S=new rt,A=new C,P=0,_=y===!0?t:e,b=y===!0?1:-1;for(let L=1;L<=s;L++)u.push(0,m*b,0),d.push(0,b,0),f.push(.5,.5),g++;let R=g;for(let L=0;L<=s;L++){let N=L/s*l+a,W=Math.cos(N),k=Math.sin(N);A.x=_*k,A.y=m*b,A.z=_*W,u.push(A.x,A.y,A.z),d.push(0,b,0),S.x=W*.5+.5,S.y=k*.5*b+.5,f.push(S.x,S.y),g++}for(let L=0;L<s;L++){let D=w+L,N=R+L;y===!0?h.push(N,N+1,D):h.push(N+1,N,D),P+=3}c.addGroup(p,P,y===!0?1:2),p+=P}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},Qn=class i extends Ut{constructor(t=1,e=1,n=32,s=1,r=!1,o=0,a=Math.PI*2){super(0,t,e,n,s,r,o,a),this.type="ConeGeometry",this.parameters={radius:t,height:e,radialSegments:n,heightSegments:s,openEnded:r,thetaStart:o,thetaLength:a}}static fromJSON(t){return new i(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},Na=class i extends ae{constructor(t=[],e=[],n=1,s=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:e,radius:n,detail:s};let r=[],o=[];a(s),c(n),h(),this.setAttribute("position",new Ot(r,3)),this.setAttribute("normal",new Ot(r.slice(),3)),this.setAttribute("uv",new Ot(o,2)),s===0?this.computeVertexNormals():this.normalizeNormals();function a(M){let v=new C,y=new C,w=new C;for(let S=0;S<e.length;S+=3)f(e[S+0],v),f(e[S+1],y),f(e[S+2],w),l(v,y,w,M)}function l(M,v,y,w){let S=w+1,A=[];for(let P=0;P<=S;P++){A[P]=[];let _=M.clone().lerp(y,P/S),b=v.clone().lerp(y,P/S),R=S-P;for(let L=0;L<=R;L++)L===0&&P===S?A[P][L]=_:A[P][L]=_.clone().lerp(b,L/R)}for(let P=0;P<S;P++)for(let _=0;_<2*(S-P)-1;_++){let b=Math.floor(_/2);_%2===0?(d(A[P][b+1]),d(A[P+1][b]),d(A[P][b])):(d(A[P][b+1]),d(A[P+1][b+1]),d(A[P+1][b]))}}function c(M){let v=new C;for(let y=0;y<r.length;y+=3)v.x=r[y+0],v.y=r[y+1],v.z=r[y+2],v.normalize().multiplyScalar(M),r[y+0]=v.x,r[y+1]=v.y,r[y+2]=v.z}function h(){let M=new C;for(let v=0;v<r.length;v+=3){M.x=r[v+0],M.y=r[v+1],M.z=r[v+2];let y=m(M)/2/Math.PI+.5,w=p(M)/Math.PI+.5;o.push(y,1-w)}g(),u()}function u(){for(let M=0;M<o.length;M+=6){let v=o[M+0],y=o[M+2],w=o[M+4],S=Math.max(v,y,w),A=Math.min(v,y,w);S>.9&&A<.1&&(v<.2&&(o[M+0]+=1),y<.2&&(o[M+2]+=1),w<.2&&(o[M+4]+=1))}}function d(M){r.push(M.x,M.y,M.z)}function f(M,v){let y=M*3;v.x=t[y+0],v.y=t[y+1],v.z=t[y+2]}function g(){let M=new C,v=new C,y=new C,w=new C,S=new rt,A=new rt,P=new rt;for(let _=0,b=0;_<r.length;_+=9,b+=6){M.set(r[_+0],r[_+1],r[_+2]),v.set(r[_+3],r[_+4],r[_+5]),y.set(r[_+6],r[_+7],r[_+8]),S.set(o[b+0],o[b+1]),A.set(o[b+2],o[b+3]),P.set(o[b+4],o[b+5]),w.copy(M).add(v).add(y).divideScalar(3);let R=m(w);x(S,b+0,M,R),x(A,b+2,v,R),x(P,b+4,y,R)}}function x(M,v,y,w){w<0&&M.x===1&&(o[v]=M.x-1),y.x===0&&y.z===0&&(o[v]=w/2/Math.PI+.5)}function m(M){return Math.atan2(M.z,-M.x)}function p(M){return Math.atan2(-M.y,Math.sqrt(M.x*M.x+M.z*M.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.vertices,t.indices,t.radius,t.details)}},ro=class i extends Na{constructor(t=1,e=0){let n=(1+Math.sqrt(5))/2,s=1/n,r=[-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-s,-n,0,-s,n,0,s,-n,0,s,n,-s,-n,0,-s,n,0,s,-n,0,s,n,0,-n,0,-s,n,0,-s,-n,0,s,n,0,s],o=[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9];super(r,o,t,e),this.type="DodecahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new i(t.radius,t.detail)}};var oo=class extends so{constructor(t){super(t),this.uuid=Jn(),this.type="Shape",this.holes=[]}getPointsHoles(t){let e=[];for(let n=0,s=this.holes.length;n<s;n++)e[n]=this.holes[n].getPoints(t);return e}extractPoints(t){return{shape:this.getPoints(t),holes:this.getPointsHoles(t)}}copy(t){super.copy(t),this.holes=[];for(let e=0,n=t.holes.length;e<n;e++){let s=t.holes[e];this.holes.push(s.clone())}return this}toJSON(){let t=super.toJSON();t.uuid=this.uuid,t.holes=[];for(let e=0,n=this.holes.length;e<n;e++){let s=this.holes[e];t.holes.push(s.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.uuid=t.uuid,this.holes=[];for(let e=0,n=t.holes.length;e<n;e++){let s=t.holes[e];this.holes.push(new so().fromJSON(s))}return this}},Fv={triangulate:function(i,t,e=2){let n=t&&t.length,s=n?t[0]*e:i.length,r=Ef(i,0,s,e,!0),o=[];if(!r||r.next===r.prev)return o;let a,l,c,h,u,d,f;if(n&&(r=Gv(i,t,r,e)),i.length>80*e){a=c=i[0],l=h=i[1];for(let g=e;g<s;g+=e)u=i[g],d=i[g+1],u<a&&(a=u),d<l&&(l=d),u>c&&(c=u),d>h&&(h=d);f=Math.max(c-a,h-l),f=f!==0?32767/f:0}return ao(r,o,e,a,l,f,0),o}};function Ef(i,t,e,n,s){let r,o;if(s===tb(i,t,e,n)>0)for(r=t;r<e;r+=n)o=Xd(r,i[r],i[r+1],o);else for(r=e-n;r>=t;r-=n)o=Xd(r,i[r],i[r+1],o);return o&&Ya(o,o.next)&&(co(o),o=o.next),o}function ps(i,t){if(!i)return i;t||(t=i);let e=i,n;do if(n=!1,!e.steiner&&(Ya(e,e.next)||Ae(e.prev,e,e.next)===0)){if(co(e),e=t=e.prev,e===e.next)break;n=!0}else e=e.next;while(n||e!==t);return t}function ao(i,t,e,n,s,r,o){if(!i)return;!o&&r&&Yv(i,n,s,r);let a=i,l,c;for(;i.prev!==i.next;){if(l=i.prev,c=i.next,r?Ov(i,n,s,r):Bv(i)){t.push(l.i/e|0),t.push(i.i/e|0),t.push(c.i/e|0),co(i),i=c.next,a=c.next;continue}if(i=c,i===a){o?o===1?(i=Hv(ps(i),t,e),ao(i,t,e,n,s,r,2)):o===2&&Vv(i,t,e,n,s,r):ao(ps(i),t,e,n,s,r,1);break}}}function Bv(i){let t=i.prev,e=i,n=i.next;if(Ae(t,e,n)>=0)return!1;let s=t.x,r=e.x,o=n.x,a=t.y,l=e.y,c=n.y,h=s<r?s<o?s:o:r<o?r:o,u=a<l?a<c?a:c:l<c?l:c,d=s>r?s>o?s:o:r>o?r:o,f=a>l?a>c?a:c:l>c?l:c,g=n.next;for(;g!==t;){if(g.x>=h&&g.x<=d&&g.y>=u&&g.y<=f&&js(s,a,r,l,o,c,g.x,g.y)&&Ae(g.prev,g,g.next)>=0)return!1;g=g.next}return!0}function Ov(i,t,e,n){let s=i.prev,r=i,o=i.next;if(Ae(s,r,o)>=0)return!1;let a=s.x,l=r.x,c=o.x,h=s.y,u=r.y,d=o.y,f=a<l?a<c?a:c:l<c?l:c,g=h<u?h<d?h:d:u<d?u:d,x=a>l?a>c?a:c:l>c?l:c,m=h>u?h>d?h:d:u>d?u:d,p=ph(f,g,t,e,n),M=ph(x,m,t,e,n),v=i.prevZ,y=i.nextZ;for(;v&&v.z>=p&&y&&y.z<=M;){if(v.x>=f&&v.x<=x&&v.y>=g&&v.y<=m&&v!==s&&v!==o&&js(a,h,l,u,c,d,v.x,v.y)&&Ae(v.prev,v,v.next)>=0||(v=v.prevZ,y.x>=f&&y.x<=x&&y.y>=g&&y.y<=m&&y!==s&&y!==o&&js(a,h,l,u,c,d,y.x,y.y)&&Ae(y.prev,y,y.next)>=0))return!1;y=y.nextZ}for(;v&&v.z>=p;){if(v.x>=f&&v.x<=x&&v.y>=g&&v.y<=m&&v!==s&&v!==o&&js(a,h,l,u,c,d,v.x,v.y)&&Ae(v.prev,v,v.next)>=0)return!1;v=v.prevZ}for(;y&&y.z<=M;){if(y.x>=f&&y.x<=x&&y.y>=g&&y.y<=m&&y!==s&&y!==o&&js(a,h,l,u,c,d,y.x,y.y)&&Ae(y.prev,y,y.next)>=0)return!1;y=y.nextZ}return!0}function Hv(i,t,e){let n=i;do{let s=n.prev,r=n.next.next;!Ya(s,r)&&Tf(s,n,n.next,r)&&lo(s,r)&&lo(r,s)&&(t.push(s.i/e|0),t.push(n.i/e|0),t.push(r.i/e|0),co(n),co(n.next),n=i=r),n=n.next}while(n!==i);return ps(n)}function Vv(i,t,e,n,s,r){let o=i;do{let a=o.next.next;for(;a!==o.prev;){if(o.i!==a.i&&Jv(o,a)){let l=Af(o,a);o=ps(o,o.next),l=ps(l,l.next),ao(o,t,e,n,s,r,0),ao(l,t,e,n,s,r,0);return}a=a.next}o=o.next}while(o!==i)}function Gv(i,t,e,n){let s=[],r,o,a,l,c;for(r=0,o=t.length;r<o;r++)a=t[r]*n,l=r<o-1?t[r+1]*n:i.length,c=Ef(i,a,l,n,!1),c===c.next&&(c.steiner=!0),s.push(Kv(c));for(s.sort(Wv),r=0;r<s.length;r++)e=$v(s[r],e);return e}function Wv(i,t){return i.x-t.x}function $v(i,t){let e=qv(i,t);if(!e)return t;let n=Af(e,i);return ps(n,n.next),ps(e,e.next)}function qv(i,t){let e=t,n=-1/0,s,r=i.x,o=i.y;do{if(o<=e.y&&o>=e.next.y&&e.next.y!==e.y){let d=e.x+(o-e.y)*(e.next.x-e.x)/(e.next.y-e.y);if(d<=r&&d>n&&(n=d,s=e.x<e.next.x?e:e.next,d===r))return s}e=e.next}while(e!==t);if(!s)return null;let a=s,l=s.x,c=s.y,h=1/0,u;e=s;do r>=e.x&&e.x>=l&&r!==e.x&&js(o<c?r:n,o,l,c,o<c?n:r,o,e.x,e.y)&&(u=Math.abs(o-e.y)/(r-e.x),lo(e,i)&&(u<h||u===h&&(e.x>s.x||e.x===s.x&&Xv(s,e)))&&(s=e,h=u)),e=e.next;while(e!==a);return s}function Xv(i,t){return Ae(i.prev,i,t.prev)<0&&Ae(t.next,i,i.next)<0}function Yv(i,t,e,n){let s=i;do s.z===0&&(s.z=ph(s.x,s.y,t,e,n)),s.prevZ=s.prev,s.nextZ=s.next,s=s.next;while(s!==i);s.prevZ.nextZ=null,s.prevZ=null,Zv(s)}function Zv(i){let t,e,n,s,r,o,a,l,c=1;do{for(e=i,i=null,r=null,o=0;e;){for(o++,n=e,a=0,t=0;t<c&&(a++,n=n.nextZ,!!n);t++);for(l=c;a>0||l>0&&n;)a!==0&&(l===0||!n||e.z<=n.z)?(s=e,e=e.nextZ,a--):(s=n,n=n.nextZ,l--),r?r.nextZ=s:i=s,s.prevZ=r,r=s;e=n}r.nextZ=null,c*=2}while(o>1);return i}function ph(i,t,e,n,s){return i=(i-e)*s|0,t=(t-n)*s|0,i=(i|i<<8)&16711935,i=(i|i<<4)&252645135,i=(i|i<<2)&858993459,i=(i|i<<1)&1431655765,t=(t|t<<8)&16711935,t=(t|t<<4)&252645135,t=(t|t<<2)&858993459,t=(t|t<<1)&1431655765,i|t<<1}function Kv(i){let t=i,e=i;do(t.x<e.x||t.x===e.x&&t.y<e.y)&&(e=t),t=t.next;while(t!==i);return e}function js(i,t,e,n,s,r,o,a){return(s-o)*(t-a)>=(i-o)*(r-a)&&(i-o)*(n-a)>=(e-o)*(t-a)&&(e-o)*(r-a)>=(s-o)*(n-a)}function Jv(i,t){return i.next.i!==t.i&&i.prev.i!==t.i&&!jv(i,t)&&(lo(i,t)&&lo(t,i)&&Qv(i,t)&&(Ae(i.prev,i,t.prev)||Ae(i,t.prev,t))||Ya(i,t)&&Ae(i.prev,i,i.next)>0&&Ae(t.prev,t,t.next)>0)}function Ae(i,t,e){return(t.y-i.y)*(e.x-t.x)-(t.x-i.x)*(e.y-t.y)}function Ya(i,t){return i.x===t.x&&i.y===t.y}function Tf(i,t,e,n){let s=aa(Ae(i,t,e)),r=aa(Ae(i,t,n)),o=aa(Ae(e,n,i)),a=aa(Ae(e,n,t));return!!(s!==r&&o!==a||s===0&&oa(i,e,t)||r===0&&oa(i,n,t)||o===0&&oa(e,i,n)||a===0&&oa(e,t,n))}function oa(i,t,e){return t.x<=Math.max(i.x,e.x)&&t.x>=Math.min(i.x,e.x)&&t.y<=Math.max(i.y,e.y)&&t.y>=Math.min(i.y,e.y)}function aa(i){return i>0?1:i<0?-1:0}function jv(i,t){let e=i;do{if(e.i!==i.i&&e.next.i!==i.i&&e.i!==t.i&&e.next.i!==t.i&&Tf(e,e.next,i,t))return!0;e=e.next}while(e!==i);return!1}function lo(i,t){return Ae(i.prev,i,i.next)<0?Ae(i,t,i.next)>=0&&Ae(i,i.prev,t)>=0:Ae(i,t,i.prev)<0||Ae(i,i.next,t)<0}function Qv(i,t){let e=i,n=!1,s=(i.x+t.x)/2,r=(i.y+t.y)/2;do e.y>r!=e.next.y>r&&e.next.y!==e.y&&s<(e.next.x-e.x)*(r-e.y)/(e.next.y-e.y)+e.x&&(n=!n),e=e.next;while(e!==i);return n}function Af(i,t){let e=new mh(i.i,i.x,i.y),n=new mh(t.i,t.x,t.y),s=i.next,r=t.prev;return i.next=t,t.prev=i,e.next=s,s.prev=e,n.next=e,e.prev=n,r.next=n,n.prev=r,n}function Xd(i,t,e,n){let s=new mh(i,t,e);return n?(s.next=n.next,s.prev=n,n.next.prev=s,n.next=s):(s.prev=s,s.next=s),s}function co(i){i.next.prev=i.prev,i.prev.next=i.next,i.prevZ&&(i.prevZ.nextZ=i.nextZ),i.nextZ&&(i.nextZ.prevZ=i.prevZ)}function mh(i,t,e){this.i=i,this.x=t,this.y=e,this.prev=null,this.next=null,this.z=0,this.prevZ=null,this.nextZ=null,this.steiner=!1}function tb(i,t,e,n){let s=0;for(let r=t,o=e-n;r<e;r+=n)s+=(i[o]-i[r])*(i[r+1]+i[o+1]),o=r;return s}var Xr=class i{static area(t){let e=t.length,n=0;for(let s=e-1,r=0;r<e;s=r++)n+=t[s].x*t[r].y-t[r].x*t[s].y;return n*.5}static isClockWise(t){return i.area(t)<0}static triangulateShape(t,e){let n=[],s=[],r=[];Yd(t),Zd(n,t);let o=t.length;e.forEach(Yd);for(let l=0;l<e.length;l++)s.push(o),o+=e[l].length,Zd(n,e[l]);let a=Fv.triangulate(n,s);for(let l=0;l<a.length;l+=3)r.push(a.slice(l,l+3));return r}};function Yd(i){let t=i.length;t>2&&i[t-1].equals(i[0])&&i.pop()}function Zd(i,t){for(let e=0;e<t.length;e++)i.push(t[e].x),i.push(t[e].y)}var ms=class i extends Na{constructor(t=1,e=0){let n=(1+Math.sqrt(5))/2,s=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],r=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(s,r,t,e),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new i(t.radius,t.detail)}};var fn=class i extends ae{constructor(t=.5,e=1,n=32,s=1,r=0,o=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:e,thetaSegments:n,phiSegments:s,thetaStart:r,thetaLength:o},n=Math.max(3,n),s=Math.max(1,s);let a=[],l=[],c=[],h=[],u=t,d=(e-t)/s,f=new C,g=new rt;for(let x=0;x<=s;x++){for(let m=0;m<=n;m++){let p=r+m/n*o;f.x=u*Math.cos(p),f.y=u*Math.sin(p),l.push(f.x,f.y,f.z),c.push(0,0,1),g.x=(f.x/e+1)/2,g.y=(f.y/e+1)/2,h.push(g.x,g.y)}u+=d}for(let x=0;x<s;x++){let m=x*(n+1);for(let p=0;p<n;p++){let M=p+m,v=M,y=M+n+1,w=M+n+2,S=M+1;a.push(v,y,S),a.push(y,w,S)}}this.setIndex(a),this.setAttribute("position",new Ot(l,3)),this.setAttribute("normal",new Ot(c,3)),this.setAttribute("uv",new Ot(h,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}},za=class i extends ae{constructor(t=new oo([new rt(0,.5),new rt(-.5,-.5),new rt(.5,-.5)]),e=12){super(),this.type="ShapeGeometry",this.parameters={shapes:t,curveSegments:e};let n=[],s=[],r=[],o=[],a=0,l=0;if(Array.isArray(t)===!1)c(t);else for(let h=0;h<t.length;h++)c(t[h]),this.addGroup(a,l,h),a+=l,l=0;this.setIndex(n),this.setAttribute("position",new Ot(s,3)),this.setAttribute("normal",new Ot(r,3)),this.setAttribute("uv",new Ot(o,2));function c(h){let u=s.length/3,d=h.extractPoints(e),f=d.shape,g=d.holes;Xr.isClockWise(f)===!1&&(f=f.reverse());for(let m=0,p=g.length;m<p;m++){let M=g[m];Xr.isClockWise(M)===!0&&(g[m]=M.reverse())}let x=Xr.triangulateShape(f,g);for(let m=0,p=g.length;m<p;m++){let M=g[m];f=f.concat(M)}for(let m=0,p=f.length;m<p;m++){let M=f[m];s.push(M.x,M.y,0),r.push(0,0,1),o.push(M.x,M.y)}for(let m=0,p=x.length;m<p;m++){let M=x[m],v=M[0]+u,y=M[1]+u,w=M[2]+u;n.push(v,y,w),l+=3}}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){let t=super.toJSON(),e=this.parameters.shapes;return eb(e,t)}static fromJSON(t,e){let n=[];for(let s=0,r=t.shapes.length;s<r;s++){let o=e[t.shapes[s]];n.push(o)}return new i(n,t.curveSegments)}};function eb(i,t){if(t.shapes=[],Array.isArray(i))for(let e=0,n=i.length;e<n;e++){let s=i[e];t.shapes.push(s.uuid)}else t.shapes.push(i.uuid);return t}var Ce=class i extends ae{constructor(t=1,e=32,n=16,s=0,r=Math.PI*2,o=0,a=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:n,phiStart:s,phiLength:r,thetaStart:o,thetaLength:a},e=Math.max(3,Math.floor(e)),n=Math.max(2,Math.floor(n));let l=Math.min(o+a,Math.PI),c=0,h=[],u=new C,d=new C,f=[],g=[],x=[],m=[];for(let p=0;p<=n;p++){let M=[],v=p/n,y=0;p===0&&o===0?y=.5/e:p===n&&l===Math.PI&&(y=-.5/e);for(let w=0;w<=e;w++){let S=w/e;u.x=-t*Math.cos(s+S*r)*Math.sin(o+v*a),u.y=t*Math.cos(o+v*a),u.z=t*Math.sin(s+S*r)*Math.sin(o+v*a),g.push(u.x,u.y,u.z),d.copy(u).normalize(),x.push(d.x,d.y,d.z),m.push(S+y,1-v),M.push(c++)}h.push(M)}for(let p=0;p<n;p++)for(let M=0;M<e;M++){let v=h[p][M+1],y=h[p][M],w=h[p+1][M],S=h[p+1][M+1];(p!==0||o>0)&&f.push(v,y,S),(p!==n-1||l<Math.PI)&&f.push(y,w,S)}this.setIndex(f),this.setAttribute("position",new Ot(g,3)),this.setAttribute("normal",new Ot(x,3)),this.setAttribute("uv",new Ot(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}};var gs=class i extends ae{constructor(t=1,e=.4,n=12,s=48,r=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:t,tube:e,radialSegments:n,tubularSegments:s,arc:r},n=Math.floor(n),s=Math.floor(s);let o=[],a=[],l=[],c=[],h=new C,u=new C,d=new C;for(let f=0;f<=n;f++)for(let g=0;g<=s;g++){let x=g/s*r,m=f/n*Math.PI*2;u.x=(t+e*Math.cos(m))*Math.cos(x),u.y=(t+e*Math.cos(m))*Math.sin(x),u.z=e*Math.sin(m),a.push(u.x,u.y,u.z),h.x=t*Math.cos(x),h.y=t*Math.sin(x),d.subVectors(u,h).normalize(),l.push(d.x,d.y,d.z),c.push(g/s),c.push(f/n)}for(let f=1;f<=n;f++)for(let g=1;g<=s;g++){let x=(s+1)*f+g-1,m=(s+1)*(f-1)+g-1,p=(s+1)*(f-1)+g,M=(s+1)*f+g;o.push(x,m,M),o.push(m,p,M)}this.setIndex(o),this.setAttribute("position",new Ot(a,3)),this.setAttribute("normal",new Ot(l,3)),this.setAttribute("uv",new Ot(c,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc)}};var ye=class extends vi{static get type(){return"MeshStandardMaterial"}constructor(t){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.color=new bt(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new bt(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=pf,this.normalScale=new rt(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new un,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}},Fa=class extends ye{static get type(){return"MeshPhysicalMaterial"}constructor(t){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new rt(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return Fe(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(e){this.ior=(1+.4*e)/(1-.4*e)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new bt(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new bt(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new bt(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._dispersion=0,this._iridescence=0,this._sheen=0,this._transmission=0,this.setValues(t)}get anisotropy(){return this._anisotropy}set anisotropy(t){this._anisotropy>0!=t>0&&this.version++,this._anisotropy=t}get clearcoat(){return this._clearcoat}set clearcoat(t){this._clearcoat>0!=t>0&&this.version++,this._clearcoat=t}get iridescence(){return this._iridescence}set iridescence(t){this._iridescence>0!=t>0&&this.version++,this._iridescence=t}get dispersion(){return this._dispersion}set dispersion(t){this._dispersion>0!=t>0&&this.version++,this._dispersion=t}get sheen(){return this._sheen}set sheen(t){this._sheen>0!=t>0&&this.version++,this._sheen=t}get transmission(){return this._transmission}set transmission(t){this._transmission>0!=t>0&&this.version++,this._transmission=t}copy(t){return super.copy(t),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=t.anisotropy,this.anisotropyRotation=t.anisotropyRotation,this.anisotropyMap=t.anisotropyMap,this.clearcoat=t.clearcoat,this.clearcoatMap=t.clearcoatMap,this.clearcoatRoughness=t.clearcoatRoughness,this.clearcoatRoughnessMap=t.clearcoatRoughnessMap,this.clearcoatNormalMap=t.clearcoatNormalMap,this.clearcoatNormalScale.copy(t.clearcoatNormalScale),this.dispersion=t.dispersion,this.ior=t.ior,this.iridescence=t.iridescence,this.iridescenceMap=t.iridescenceMap,this.iridescenceIOR=t.iridescenceIOR,this.iridescenceThicknessRange=[...t.iridescenceThicknessRange],this.iridescenceThicknessMap=t.iridescenceThicknessMap,this.sheen=t.sheen,this.sheenColor.copy(t.sheenColor),this.sheenColorMap=t.sheenColorMap,this.sheenRoughness=t.sheenRoughness,this.sheenRoughnessMap=t.sheenRoughnessMap,this.transmission=t.transmission,this.transmissionMap=t.transmissionMap,this.thickness=t.thickness,this.thicknessMap=t.thicknessMap,this.attenuationDistance=t.attenuationDistance,this.attenuationColor.copy(t.attenuationColor),this.specularIntensity=t.specularIntensity,this.specularIntensityMap=t.specularIntensityMap,this.specularColor.copy(t.specularColor),this.specularColorMap=t.specularColorMap,this}};var ur=class extends bi{static get type(){return"LineDashedMaterial"}constructor(t){super(),this.isLineDashedMaterial=!0,this.scale=1,this.dashSize=3,this.gapSize=1,this.setValues(t)}copy(t){return super.copy(t),this.scale=t.scale,this.dashSize=t.dashSize,this.gapSize=t.gapSize,this}};function la(i,t,e){return!i||!e&&i.constructor===t?i:typeof t.BYTES_PER_ELEMENT=="number"?new t(i):Array.prototype.slice.call(i)}function nb(i){return ArrayBuffer.isView(i)&&!(i instanceof DataView)}var dr=class{constructor(t,e,n,s){this.parameterPositions=t,this._cachedIndex=0,this.resultBuffer=s!==void 0?s:new e.constructor(n),this.sampleValues=e,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(t){let e=this.parameterPositions,n=this._cachedIndex,s=e[n],r=e[n-1];n:{t:{let o;e:{i:if(!(t<s)){for(let a=n+2;;){if(s===void 0){if(t<r)break i;return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===a)break;if(r=s,s=e[++n],t<s)break t}o=e.length;break e}if(!(t>=r)){let a=e[1];t<a&&(n=2,r=a);for(let l=n-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===l)break;if(s=r,r=e[--n-1],t>=r)break t}o=n,n=0;break e}break n}for(;n<o;){let a=n+o>>>1;t<e[a]?o=a:n=a+1}if(s=e[n],r=e[n-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(s===void 0)return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,r,s)}return this.interpolate_(n,r,t,s)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(t){let e=this.resultBuffer,n=this.sampleValues,s=this.valueSize,r=t*s;for(let o=0;o!==s;++o)e[o]=n[r+o];return e}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},gh=class extends dr{constructor(t,e,n,s){super(t,e,n,s),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Hu,endingEnd:Hu}}intervalChanged_(t,e,n){let s=this.parameterPositions,r=t-2,o=t+1,a=s[r],l=s[o];if(a===void 0)switch(this.getSettings_().endingStart){case Vu:r=t,a=2*e-n;break;case Gu:r=s.length-2,a=e+s[r]-s[r+1];break;default:r=t,a=n}if(l===void 0)switch(this.getSettings_().endingEnd){case Vu:o=t,l=2*n-e;break;case Gu:o=1,l=n+s[1]-s[0];break;default:o=t-1,l=e}let c=(n-e)*.5,h=this.valueSize;this._weightPrev=c/(e-a),this._weightNext=c/(l-n),this._offsetPrev=r*h,this._offsetNext=o*h}interpolate_(t,e,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=t*a,c=l-a,h=this._offsetPrev,u=this._offsetNext,d=this._weightPrev,f=this._weightNext,g=(n-e)/(s-e),x=g*g,m=x*g,p=-d*m+2*d*x-d*g,M=(1+d)*m+(-1.5-2*d)*x+(-.5+d)*g+1,v=(-1-f)*m+(1.5+f)*x+.5*g,y=f*m-f*x;for(let w=0;w!==a;++w)r[w]=p*o[h+w]+M*o[c+w]+v*o[l+w]+y*o[u+w];return r}},xh=class extends dr{constructor(t,e,n,s){super(t,e,n,s)}interpolate_(t,e,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=t*a,c=l-a,h=(n-e)/(s-e),u=1-h;for(let d=0;d!==a;++d)r[d]=o[c+d]*u+o[l+d]*h;return r}},yh=class extends dr{constructor(t,e,n,s){super(t,e,n,s)}interpolate_(t){return this.copySampleValue_(t-1)}},Wn=class{constructor(t,e,n,s){if(t===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(e===void 0||e.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+t);this.name=t,this.times=la(e,this.TimeBufferType),this.values=la(n,this.ValueBufferType),this.setInterpolation(s||this.DefaultInterpolation)}static toJSON(t){let e=t.constructor,n;if(e.toJSON!==this.toJSON)n=e.toJSON(t);else{n={name:t.name,times:la(t.times,Array),values:la(t.values,Array)};let s=t.getInterpolation();s!==t.DefaultInterpolation&&(n.interpolation=s)}return n.type=t.ValueTypeName,n}InterpolantFactoryMethodDiscrete(t){return new yh(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodLinear(t){return new xh(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodSmooth(t){return new gh(this.times,this.values,this.getValueSize(),t)}setInterpolation(t){let e;switch(t){case pa:e=this.InterpolantFactoryMethodDiscrete;break;case Gc:e=this.InterpolantFactoryMethodLinear;break;case Tl:e=this.InterpolantFactoryMethodSmooth;break}if(e===void 0){let n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(t!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return console.warn("THREE.KeyframeTrack:",n),this}return this.createInterpolant=e,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return pa;case this.InterpolantFactoryMethodLinear:return Gc;case this.InterpolantFactoryMethodSmooth:return Tl}}getValueSize(){return this.values.length/this.times.length}shift(t){if(t!==0){let e=this.times;for(let n=0,s=e.length;n!==s;++n)e[n]+=t}return this}scale(t){if(t!==1){let e=this.times;for(let n=0,s=e.length;n!==s;++n)e[n]*=t}return this}trim(t,e){let n=this.times,s=n.length,r=0,o=s-1;for(;r!==s&&n[r]<t;)++r;for(;o!==-1&&n[o]>e;)--o;if(++o,r!==0||o!==s){r>=o&&(o=Math.max(o,1),r=o-1);let a=this.getValueSize();this.times=n.slice(r,o),this.values=this.values.slice(r*a,o*a)}return this}validate(){let t=!0,e=this.getValueSize();e-Math.floor(e)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),t=!1);let n=this.times,s=this.values,r=n.length;r===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),t=!1);let o=null;for(let a=0;a!==r;a++){let l=n[a];if(typeof l=="number"&&isNaN(l)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,a,l),t=!1;break}if(o!==null&&o>l){console.error("THREE.KeyframeTrack: Out of order keys.",this,a,l,o),t=!1;break}o=l}if(s!==void 0&&nb(s))for(let a=0,l=s.length;a!==l;++a){let c=s[a];if(isNaN(c)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,a,c),t=!1;break}}return t}optimize(){let t=this.times.slice(),e=this.values.slice(),n=this.getValueSize(),s=this.getInterpolation()===Tl,r=t.length-1,o=1;for(let a=1;a<r;++a){let l=!1,c=t[a],h=t[a+1];if(c!==h&&(a!==1||c!==t[0]))if(s)l=!0;else{let u=a*n,d=u-n,f=u+n;for(let g=0;g!==n;++g){let x=e[u+g];if(x!==e[d+g]||x!==e[f+g]){l=!0;break}}}if(l){if(a!==o){t[o]=t[a];let u=a*n,d=o*n;for(let f=0;f!==n;++f)e[d+f]=e[u+f]}++o}}if(r>0){t[o]=t[r];for(let a=r*n,l=o*n,c=0;c!==n;++c)e[l+c]=e[a+c];++o}return o!==t.length?(this.times=t.slice(0,o),this.values=e.slice(0,o*n)):(this.times=t,this.values=e),this}clone(){let t=this.times.slice(),e=this.values.slice(),n=this.constructor,s=new n(this.name,t,e);return s.createInterpolant=this.createInterpolant,s}};Wn.prototype.TimeBufferType=Float32Array;Wn.prototype.ValueBufferType=Float32Array;Wn.prototype.DefaultInterpolation=Gc;var xs=class extends Wn{constructor(t,e,n){super(t,e,n)}};xs.prototype.ValueTypeName="bool";xs.prototype.ValueBufferType=Array;xs.prototype.DefaultInterpolation=pa;xs.prototype.InterpolantFactoryMethodLinear=void 0;xs.prototype.InterpolantFactoryMethodSmooth=void 0;var vh=class extends Wn{};vh.prototype.ValueTypeName="color";var bh=class extends Wn{};bh.prototype.ValueTypeName="number";var _h=class extends dr{constructor(t,e,n,s){super(t,e,n,s)}interpolate_(t,e,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=(n-e)/(s-e),c=t*a;for(let h=c+a;c!==h;c+=4)Re.slerpFlat(r,0,o,c-a,o,c,l);return r}},Ba=class extends Wn{InterpolantFactoryMethodLinear(t){return new _h(this.times,this.values,this.getValueSize(),t)}};Ba.prototype.ValueTypeName="quaternion";Ba.prototype.InterpolantFactoryMethodSmooth=void 0;var ys=class extends Wn{constructor(t,e,n){super(t,e,n)}};ys.prototype.ValueTypeName="string";ys.prototype.ValueBufferType=Array;ys.prototype.DefaultInterpolation=pa;ys.prototype.InterpolantFactoryMethodLinear=void 0;ys.prototype.InterpolantFactoryMethodSmooth=void 0;var Mh=class extends Wn{};Mh.prototype.ValueTypeName="vector";var wh=class{constructor(t,e,n){let s=this,r=!1,o=0,a=0,l,c=[];this.onStart=void 0,this.onLoad=t,this.onProgress=e,this.onError=n,this.itemStart=function(h){a++,r===!1&&s.onStart!==void 0&&s.onStart(h,o,a),r=!0},this.itemEnd=function(h){o++,s.onProgress!==void 0&&s.onProgress(h,o,a),o===a&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(h){s.onError!==void 0&&s.onError(h)},this.resolveURL=function(h){return l?l(h):h},this.setURLModifier=function(h){return l=h,this},this.addHandler=function(h,u){return c.push(h,u),this},this.removeHandler=function(h){let u=c.indexOf(h);return u!==-1&&c.splice(u,2),this},this.getHandler=function(h){for(let u=0,d=c.length;u<d;u+=2){let f=c[u],g=c[u+1];if(f.global&&(f.lastIndex=0),f.test(h))return g}return null}}},ib=new wh,Sh=class{constructor(t){this.manager=t!==void 0?t:ib,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(t,e){let n=this;return new Promise(function(s,r){n.load(t,s,e,r)})}parse(){}setCrossOrigin(t){return this.crossOrigin=t,this}setWithCredentials(t){return this.withCredentials=t,this}setPath(t){return this.path=t,this}setResourcePath(t){return this.resourcePath=t,this}setRequestHeader(t){return this.requestHeader=t,this}};Sh.DEFAULT_MATERIAL_NAME="__DEFAULT";var Oa=class extends Oe{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new bt(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){let e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(e.object.target=this.target.uuid),e}},Ha=class extends Oa{constructor(t,e,n){super(t,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Oe.DEFAULT_UP),this.updateMatrix(),this.groundColor=new bt(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}},sc=new Wt,Kd=new C,Jd=new C,Eh=class{constructor(t){this.camera=t,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new rt(512,512),this.map=null,this.mapPass=null,this.matrix=new Wt,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new jr,this._frameExtents=new rt(1,1),this._viewportCount=1,this._viewports=[new Me(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){let e=this.camera,n=this.matrix;Kd.setFromMatrixPosition(t.matrixWorld),e.position.copy(Kd),Jd.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(Jd),e.updateMatrixWorld(),sc.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(sc),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(sc)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.intensity=t.intensity,this.bias=t.bias,this.radius=t.radius,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let t={};return this.intensity!==1&&(t.intensity=this.intensity),this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}};var Th=class extends Eh{constructor(){super(new wa(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},Va=class extends Oa{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Oe.DEFAULT_UP),this.updateMatrix(),this.target=new Oe,this.shadow=new Th}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}};var Ga=class{constructor(t=!0){this.autoStart=t,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=jd(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let t=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){let e=jd();t=(e-this.oldTime)/1e3,this.oldTime=e,this.elapsedTime+=t}return t}};function jd(){return performance.now()}var Vh="\\[\\]\\.:\\/",sb=new RegExp("["+Vh+"]","g"),Gh="[^"+Vh+"]",rb="[^"+Vh.replace("\\.","")+"]",ob=/((?:WC+[\/:])*)/.source.replace("WC",Gh),ab=/(WCOD+)?/.source.replace("WCOD",rb),lb=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",Gh),cb=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",Gh),hb=new RegExp("^"+ob+ab+lb+cb+"$"),ub=["material","materials","bones","map"],Ah=class{constructor(t,e,n){let s=n||we.parseTrackName(e);this._targetGroup=t,this._bindings=t.subscribe_(e,s)}getValue(t,e){this.bind();let n=this._targetGroup.nCachedObjects_,s=this._bindings[n];s!==void 0&&s.getValue(t,e)}setValue(t,e){let n=this._bindings;for(let s=this._targetGroup.nCachedObjects_,r=n.length;s!==r;++s)n[s].setValue(t,e)}bind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].bind()}unbind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].unbind()}},we=class i{constructor(t,e,n){this.path=e,this.parsedPath=n||i.parseTrackName(e),this.node=i.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,e,n){return t&&t.isAnimationObjectGroup?new i.Composite(t,e,n):new i(t,e,n)}static sanitizeNodeName(t){return t.replace(/\s/g,"_").replace(sb,"")}static parseTrackName(t){let e=hb.exec(t);if(e===null)throw new Error("PropertyBinding: Cannot parse trackName: "+t);let n={nodeName:e[2],objectName:e[3],objectIndex:e[4],propertyName:e[5],propertyIndex:e[6]},s=n.nodeName&&n.nodeName.lastIndexOf(".");if(s!==void 0&&s!==-1){let r=n.nodeName.substring(s+1);ub.indexOf(r)!==-1&&(n.nodeName=n.nodeName.substring(0,s),n.objectName=r)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+t);return n}static findNode(t,e){if(e===void 0||e===""||e==="."||e===-1||e===t.name||e===t.uuid)return t;if(t.skeleton){let n=t.skeleton.getBoneByName(e);if(n!==void 0)return n}if(t.children){let n=function(r){for(let o=0;o<r.length;o++){let a=r[o];if(a.name===e||a.uuid===e)return a;let l=n(a.children);if(l)return l}return null},s=n(t.children);if(s)return s}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(t,e){t[e]=this.targetObject[this.propertyName]}_getValue_array(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)t[e++]=n[s]}_getValue_arrayElement(t,e){t[e]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(t,e){this.resolvedProperty.toArray(t,e)}_setValue_direct(t,e){this.targetObject[this.propertyName]=t[e]}_setValue_direct_setNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=t[e++]}_setValue_array_setNeedsUpdate(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=t[e++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=t[e++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(t,e){this.resolvedProperty[this.propertyIndex]=t[e]}_setValue_arrayElement_setNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(t,e){this.resolvedProperty.fromArray(t,e)}_setValue_fromArray_setNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(t,e){this.bind(),this.getValue(t,e)}_setValue_unbound(t,e){this.bind(),this.setValue(t,e)}bind(){let t=this.node,e=this.parsedPath,n=e.objectName,s=e.propertyName,r=e.propertyIndex;if(t||(t=i.findNode(this.rootNode,e.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let c=e.objectIndex;switch(n){case"materials":if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}t=t.material.materials;break;case"bones":if(!t.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}t=t.skeleton.bones;for(let h=0;h<t.length;h++)if(t[h].name===c){c=h;break}break;case"map":if("map"in t){t=t.map;break}if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}t=t.material.map;break;default:if(t[n]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}t=t[n]}if(c!==void 0){if(t[c]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,t);return}t=t[c]}}let o=t[s];if(o===void 0){let c=e.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+c+"."+s+" but it wasn't found.",t);return}let a=this.Versioning.None;this.targetObject=t,t.needsUpdate!==void 0?a=this.Versioning.NeedsUpdate:t.matrixWorldNeedsUpdate!==void 0&&(a=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(r!==void 0){if(s==="morphTargetInfluences"){if(!t.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!t.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}t.morphTargetDictionary[r]!==void 0&&(r=t.morphTargetDictionary[r])}l=this.BindingType.ArrayElement,this.resolvedProperty=o,this.propertyIndex=r}else o.fromArray!==void 0&&o.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=o):Array.isArray(o)?(l=this.BindingType.EntireArray,this.resolvedProperty=o):this.propertyName=s;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][a]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};we.Composite=Ah;we.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};we.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};we.prototype.GetterByBindingType=[we.prototype._getValue_direct,we.prototype._getValue_array,we.prototype._getValue_arrayElement,we.prototype._getValue_toArray];we.prototype.SetterByBindingTypeAndVersioning=[[we.prototype._setValue_direct,we.prototype._setValue_direct_setNeedsUpdate,we.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[we.prototype._setValue_array,we.prototype._setValue_array_setNeedsUpdate,we.prototype._setValue_array_setMatrixWorldNeedsUpdate],[we.prototype._setValue_arrayElement,we.prototype._setValue_arrayElement_setNeedsUpdate,we.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[we.prototype._setValue_fromArray,we.prototype._setValue_fromArray_setNeedsUpdate,we.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var x_=new Float32Array(1);var Qd=new Wt,Wa=class{constructor(t,e,n=0,s=1/0){this.ray=new Kr(t,e),this.near=n,this.far=s,this.camera=null,this.layers=new Jr,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(t,e){this.ray.set(t,e)}setFromCamera(t,e){e.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(t.x,t.y,.5).unproject(e).sub(this.ray.origin).normalize(),this.camera=e):e.isOrthographicCamera?(this.ray.origin.set(t.x,t.y,(e.near+e.far)/(e.near-e.far)).unproject(e),this.ray.direction.set(0,0,-1).transformDirection(e.matrixWorld),this.camera=e):console.error("THREE.Raycaster: Unsupported camera type: "+e.type)}setFromXRController(t){return Qd.identity().extractRotation(t.matrixWorld),this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(Qd),this}intersectObject(t,e=!0,n=[]){return Rh(t,this,n,e),n.sort(tf),n}intersectObjects(t,e=!0,n=[]){for(let s=0,r=t.length;s<r;s++)Rh(t[s],this,n,e);return n.sort(tf),n}};function tf(i,t){return i.distance-t.distance}function Rh(i,t,e,n){let s=!0;if(i.layers.test(t.layers)&&i.raycast(t,e)===!1&&(s=!1),s===!0&&n===!0){let r=i.children;for(let o=0,a=r.length;o<a;o++)Rh(r[o],t,e,!0)}}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Ch}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Ch);function vs(i){let t=i>>>0;return()=>{t=t+1831565813>>>0;let e=t;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}}function db(i,t){let e=vs(i),n=new Float32Array(t*t).map(()=>e()),s=(r,o)=>n[(o%t+t)%t*t+(r%t+t)%t];return(r,o)=>{let a=Math.floor(r),l=Math.floor(o),c=r-a,h=o-l,u=c*c*(3-2*c),d=h*h*(3-2*h),f=s(a,l),g=s(a+1,l),x=s(a,l+1),m=s(a+1,l+1);return f+(g-f)*u+(x-f)*d+(f-g-x+m)*u*d}}function Ge(i,t,e=5){let n=Array.from({length:e},(s,r)=>db(i+r*101,t<<r));return(s,r)=>{let o=0,a=.5,l=0;for(let c=0;c<e;c++)o+=n[c](s*(t<<c),r*(t<<c))*a,l+=a,a*=.5;return o/l}}var se=512;function pn(i,t=se){let e=new Float32Array(t*t),n=new Uint8ClampedArray(t*t*4);for(let s=0;s<t;s++)for(let r=0;r<t;r++){let o=s*t+r,[a,l,c,h]=i(r/t,s/t,r,s);n[o*4]=a,n[o*4+1]=l,n[o*4+2]=c,n[o*4+3]=255,e[o]=h}return{size:t,h:e,col:n}}function fb({size:i,h:t,col:e},n){let s=document.createElement("canvas");s.width=s.height=i,s.getContext("2d").putImageData(new ImageData(e,i,i),0,0);let r=new Je(s);r.colorSpace=me;let o=new Uint8ClampedArray(i*i*4),a=(h,u)=>t[(u+i)%i*i+(h+i)%i];for(let h=0;h<i;h++)for(let u=0;u<i;u++){let d=(a(u+1,h)-a(u-1,h))*n,f=(a(u,h+1)-a(u,h-1))*n,g=Math.hypot(d,f,1),x=(h*i+u)*4;o[x]=(-d/g*.5+.5)*255,o[x+1]=(f/g*.5+.5)*255,o[x+2]=(1/g*.5+.5)*255,o[x+3]=255}let l=document.createElement("canvas");l.width=l.height=i,l.getContext("2d").putImageData(new ImageData(o,i,i),0,0);let c=new Je(l);for(let h of[r,c])h.wrapS=h.wrapT=ds,h.anisotropy=4,h.generateMipmaps=!0,h.minFilter=pi;return{map:r,normal:c}}var $e=(i,t,e)=>i+(t-i)*e,uo=i=>Math.max(0,Math.min(1,i)),pb={grass(){let i=Ge(11,4),t=Ge(12,32,3),e=vs(5),n=new Float32Array(se*se);for(let s=0;s<26e3;s++){let r=e()*se,o=e()*se,a=4+e()*9,l=-Math.PI/2+(e()-.5)*.9,c=.4+e()*.6;for(let h=0;h<a;h++)n[(Math.floor(o)+se)%se*se+(Math.floor(r)+se)%se]=c,r+=Math.cos(l),o+=Math.sin(l)}return pn((s,r,o,a)=>{let l=i(s,r),c=t(s,r),h=n[a*se+o],u=uo(l*1.3-.15),d=uo((l-.62)*4),f=$e(58,92,u)+h*18,g=$e(92,128,u)+h*26,x=$e(34,46,u);f=$e(f,142,d*.5),g=$e(g,136,d*.4),x=$e(x,70,d*.4);let m=.78+c*.35;return[f*m,g*m,x*m,h*.8+c*.4]})},green(){let i=Ge(21,64,3),t=Ge(22,4,3);return pn((e,n)=>{let s=i(e,n),r=t(e,n),o=.88+s*.22+r*.08;return[78*o,140*o,52*o,s*.3]})},dirt(){let i=Ge(31,4),t=Ge(32,48,3),e=vs(33),n=new Float32Array(se*se);for(let s=0;s<900;s++){let r=e()*se,o=e()*se,a=1.5+e()*4,l=.5+e()*.5;for(let c=-a;c<=a;c++)for(let h=-a;h<=a;h++){let u=1-Math.hypot(h,c)/a;if(u>0){let d=(Math.floor(o+c)+se)%se*se+(Math.floor(r+h)+se)%se;n[d]=Math.max(n[d],Math.sqrt(u)*l)}}}return pn((s,r,o,a)=>{let l=i(s,r),c=t(s,r),h=n[a*se+o],u=.75+l*.35+c*.15;return[$e(150*u,175,h*.6),$e(122*u,165,h*.6),$e(86*u,150,h*.6),c*.5+h]})},paving(){let i=vs(41),t=Ge(42,32,3),e=Ge(43,4),n=Array.from({length:22},()=>[i(),i(),.75+i()*.3]);return pn((s,r)=>{let o=9,a=9,l=1;for(let[m,p,M]of n)for(let v=-1;v<=1;v++)for(let y=-1;y<=1;y++){let w=Math.hypot(s-m-y,r-p-v);w<o?(a=o,o=w,l=M):w<a&&(a=w)}let c=a-o,h=uo(1-c/.012),u=t(s,r),d=e(s,r),f=.8+u*.25+d*.1,g=[196*l*f,186*l*f,168*l*f],x=[110,104,96];return[$e(g[0],x[0],h),$e(g[1],x[1],h),$e(g[2],x[2],h),(1-h)*(.8+u*.2)-uo(1-c/.03)*.15]},256)},wood(){let i=Ge(51,8,4),t=vs(52),e=Array.from({length:8},()=>.8+t()*.35);return pn((n,s)=>{let r=Math.floor(s*8),o=s*8-r,a=Math.sin((n*6+i(n*.2+r*.13,s)*3)*Math.PI*6)*.5+.5,l=e[r]*(.85+a*.2+i(n,s)*.1),c=o<.03||o>.97?.45:1;return[150*l*c,102*l*c,64*l*c,c<1?0:.6+a*.2]})},bark(){let i=Ge(61,4,4);return pn((t,e)=>{let n=i(t*3,e*.4),s=Math.abs(Math.sin((t*10+n*2)*Math.PI)),r=.55+s*.4+i(t,e)*.2;return[96*r,74*r,56*r,s]})},leaves(){let i=vs(71),t=Ge(72,8,3),e=new Float32Array(se*se),n=new Float32Array(se*se);for(let s=0;s<2600;s++){let r=i()*se,o=i()*se,a=5+i()*7,l=i(),c=i()*Math.PI;for(let h=-a;h<=a;h++)for(let u=-a;u<=a;u++){let d=u*Math.cos(c)+h*Math.sin(c),f=-u*Math.sin(c)+h*Math.cos(c),g=1-d*d/(a*a)-f*f/(a*a*.25);if(g>0){let x=(Math.floor(o+h)+se)%se*se+(Math.floor(r+u)+se)%se,m=s/2600+g*.2;m>e[x]&&(e[x]=m,n[x]=l)}}}return pn((s,r,o,a)=>{let l=a*se+o,c=n[l],h=t(s,r),u=.55+e[l]*.5+h*.15;return[$e(48,92,c)*u,$e(88,128,c)*u,$e(34,40,c)*u,e[l]]})},sand(){let i=Ge(81,64,3),t=Ge(82,4);return pn((e,n)=>{let s=i(e,n),r=t(e,n),o=.85+s*.2+r*.1;return[222*o,202*o,160*o,s*.4+Math.sin((e+r*.3)*60)*.05]})},rock(){let i=Ge(91,4,6),t=Ge(92,16,3);return pn((e,n)=>{let s=i(e,n),r=t(e,n),o=.6+s*.5,a=uo((r-.65)*5);return[$e(132*o,120,a*.4),$e(128*o,132,a*.4),$e(120*o,90,a*.4),s]})},felt(){let i=Ge(101,128,2);return pn((t,e)=>{let n=i(t,e),s=.9+n*.12;return[200*s,200*s,200*s,n*.2]},256)},plaster(){let i=Ge(111,32,4);return pn((t,e)=>{let n=i(t,e),s=.9+n*.12;return[238*s,232*s,220*s,n*.5]},256)},roof(){let i=Ge(121,16,3),t=vs(122),e=Array.from({length:64},()=>.85+t()*.25);return pn((n,s)=>{let r=Math.floor(s*8),o=s*8-r,a=Math.floor(n*8+r%2*.5)%8,l=(n*8+r%2*.5)%1,c=Math.sin(l*Math.PI),h=e[r*8+a]*(.75+c*.3)*(.7+o*.3)*(.9+i(n,s)*.15);return[255*h,255*h,255*h,c*.5+o*.5]},256)},fabric(){return pn((i,t,e,n)=>{let s=((e>>1)+(n>>1))%2?1:.92;return[255*s,255*s,255*s,s]},128)},water(){let i=Ge(131,8,5);return pn((t,e)=>[128,128,255,i(t,e)],256)}},Wh={};function _i(i){if(!Wh[i]){let t={grass:6,dirt:10,paving:14,wood:5,bark:10,leaves:9,sand:4,rock:12,felt:2,plaster:5,roof:8,fabric:3,water:22,green:3}[i]||6;Wh[i]=fb(pb[i](),t)}return Wh[i]}var bs={value:new URLSearchParams(location.search).has("curve")?.0022:0},mb=`
  uniform float uBend;
  varying vec3 vTpPos;
  varying vec3 vTpNormal;
`,gb=`
  vec4 tpW = vec4(transformed, 1.0);
  vec3 tpN = objectNormal;
  #ifdef USE_INSTANCING
    tpW = instanceMatrix * tpW;
    tpN = mat3(instanceMatrix) * tpN;
  #endif
  tpW = modelMatrix * tpW;
  vTpPos = tpW.xyz;
  vTpNormal = normalize(mat3(modelMatrix) * tpN);
  vec2 dxz = tpW.xz - cameraPosition.xz;
  tpW.y -= dot(dxz, dxz) * uBend;
  vec4 mvPosition = viewMatrix * tpW;
  gl_Position = projectionMatrix * mvPosition;
`,xb=`
  uniform sampler2D uTpNormal;
  uniform float uTpScale;
  uniform float uTpNS;
  varying vec3 vTpPos;
  varying vec3 vTpNormal;
  vec3 tpW3() { vec3 b = pow(abs(normalize(vTpNormal)), vec3(4.0)); return b / (b.x + b.y + b.z); }
`,yb=`
  #ifdef USE_MAP
    vec3 tpB = tpW3();
    vec2 tpUX = vTpPos.zy * uTpScale, tpUY = vTpPos.xz * uTpScale, tpUZ = vTpPos.xy * uTpScale;
    vec4 tpC = texture2D(map, tpUX) * tpB.x + texture2D(map, tpUY) * tpB.y + texture2D(map, tpUZ) * tpB.z;
    diffuseColor *= tpC;
  #endif
`,vb=`
  #ifdef USE_MAP
  {
    vec3 tpB2 = tpW3();
    vec3 nX = texture2D(uTpNormal, vTpPos.zy * uTpScale).xyz * 2.0 - 1.0;
    vec3 nY = texture2D(uTpNormal, vTpPos.xz * uTpScale).xyz * 2.0 - 1.0;
    vec3 nZ = texture2D(uTpNormal, vTpPos.xy * uTpScale).xyz * 2.0 - 1.0;
    vec3 wn = normalize(vTpNormal);
    vec3 pert = vec3(0.0, nX.y, nX.x) * tpB2.x + vec3(nY.x, 0.0, nY.y) * tpB2.y + vec3(nZ.x, nZ.y, 0.0) * tpB2.z;
    vec3 vn = normalize((viewMatrix * vec4(normalize(wn + pert * uTpNS), 0.0)).xyz);
    normal = normalize(mix(normal, vn, 0.85));
  }
  #endif
`;function bb(i,t,e,n){return i.onBeforeCompile=s=>{s.uniforms.uBend=bs,s.uniforms.uTpNormal={value:t},s.uniforms.uTpScale={value:e},s.uniforms.uTpNS={value:n},s.vertexShader=mb+s.vertexShader.replace("#include <project_vertex>",gb),s.fragmentShader=xb+s.fragmentShader.replace("#include <map_fragment>",yb).replace("#include <normal_fragment_maps>",`#include <normal_fragment_maps>
`+vb)},i.customProgramCacheKey=()=>"tp",i}var _b=`
  vec4 cW = vec4(transformed, 1.0);
  #ifdef USE_INSTANCING
    cW = instanceMatrix * cW;
  #endif
  cW = modelMatrix * cW;
  vec2 cdxz = cW.xz - cameraPosition.xz;
  cW.y -= dot(cdxz, cdxz) * uBend;
  vec4 mvPosition = viewMatrix * cW;
  gl_Position = projectionMatrix * mvPosition;
`;function wn(i){return i.onBeforeCompile=t=>{t.uniforms.uBend=bs,t.vertexShader=`uniform float uBend;
`+t.vertexShader.replace("#include <project_vertex>",_b)},i.customProgramCacheKey=()=>"curve",i}var Mb={grass:["grass",3,.8,.95],green:["green",2,.5,.85],dirt:["dirt",2.5,1,.95],paving:["paving",3,1,.85],wood:["wood",1.6,.8,.7],bark:["bark",1.2,1,.95],leaves:["leaves",1.6,1,.8],sand:["sand",2,.6,.95],rock:["rock",2.5,1.2,.9],felt:["felt",.4,.4,.95],plaster:["plaster",2,.5,.9],roof:["roof",1.4,1,.75],fabric:["fabric",.08,.5,.9],concrete:["plaster",1.5,.9,.9]},xr=new Map;function Lt(i,t=16777215,e={}){let n=`${i}|${t}|${JSON.stringify(e)}`;if(xr.has(n))return xr.get(n);let[s,r,o,a,l=0]=Mb[i],{map:c,normal:h}=_i(s),u=bb(new ye({color:t,map:c,roughness:a,metalness:l,...e}),h,1/r,o);return xr.set(n,u),u}function Tt(i,t={}){let e=`plain|${i}|${JSON.stringify(t)}`;return xr.has(e)||xr.set(e,wn(new ye({color:i,roughness:.6,metalness:0,...t}))),xr.get(e)}var Rf={skin:[16769220,16107936,14263418,11039052,8015411],shirts:["#ff8fa3","#ffb86b","#ffe066","#8ce99a","#74c0fc","#b197fc","#f783ac","#63e6be"],wood:13011541,woodDark:9263668,stone:15129803,path:15785908,roof:14711391,white:16775920};var yr=class i extends nt{constructor(){let t=i.SkyShader,e=new dn({name:t.name,uniforms:mr.clone(t.uniforms),vertexShader:t.vertexShader,fragmentShader:t.fragmentShader,side:Ke,depthWrite:!1});super(new $t(1,1,1),e),this.isSky=!0}};yr.SkyShader={name:"SkyShader",uniforms:{turbidity:{value:2},rayleigh:{value:1},mieCoefficient:{value:.005},mieDirectionalG:{value:.8},sunPosition:{value:new C},up:{value:new C(0,1,0)}},vertexShader:`
		uniform vec3 sunPosition;
		uniform float rayleigh;
		uniform float turbidity;
		uniform float mieCoefficient;
		uniform vec3 up;

		varying vec3 vWorldPosition;
		varying vec3 vSunDirection;
		varying float vSunfade;
		varying vec3 vBetaR;
		varying vec3 vBetaM;
		varying float vSunE;

		// constants for atmospheric scattering
		const float e = 2.71828182845904523536028747135266249775724709369995957;
		const float pi = 3.141592653589793238462643383279502884197169;

		// wavelength of used primaries, according to preetham
		const vec3 lambda = vec3( 680E-9, 550E-9, 450E-9 );
		// this pre-calcuation replaces older TotalRayleigh(vec3 lambda) function:
		// (8.0 * pow(pi, 3.0) * pow(pow(n, 2.0) - 1.0, 2.0) * (6.0 + 3.0 * pn)) / (3.0 * N * pow(lambda, vec3(4.0)) * (6.0 - 7.0 * pn))
		const vec3 totalRayleigh = vec3( 5.804542996261093E-6, 1.3562911419845635E-5, 3.0265902468824876E-5 );

		// mie stuff
		// K coefficient for the primaries
		const float v = 4.0;
		const vec3 K = vec3( 0.686, 0.678, 0.666 );
		// MieConst = pi * pow( ( 2.0 * pi ) / lambda, vec3( v - 2.0 ) ) * K
		const vec3 MieConst = vec3( 1.8399918514433978E14, 2.7798023919660528E14, 4.0790479543861094E14 );

		// earth shadow hack
		// cutoffAngle = pi / 1.95;
		const float cutoffAngle = 1.6110731556870734;
		const float steepness = 1.5;
		const float EE = 1000.0;

		float sunIntensity( float zenithAngleCos ) {
			zenithAngleCos = clamp( zenithAngleCos, -1.0, 1.0 );
			return EE * max( 0.0, 1.0 - pow( e, -( ( cutoffAngle - acos( zenithAngleCos ) ) / steepness ) ) );
		}

		vec3 totalMie( float T ) {
			float c = ( 0.2 * T ) * 10E-18;
			return 0.434 * c * MieConst;
		}

		void main() {

			vec4 worldPosition = modelMatrix * vec4( position, 1.0 );
			vWorldPosition = worldPosition.xyz;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			gl_Position.z = gl_Position.w; // set z to camera.far

			vSunDirection = normalize( sunPosition );

			vSunE = sunIntensity( dot( vSunDirection, up ) );

			vSunfade = 1.0 - clamp( 1.0 - exp( ( sunPosition.y / 450000.0 ) ), 0.0, 1.0 );

			float rayleighCoefficient = rayleigh - ( 1.0 * ( 1.0 - vSunfade ) );

			// extinction (absorbtion + out scattering)
			// rayleigh coefficients
			vBetaR = totalRayleigh * rayleighCoefficient;

			// mie coefficients
			vBetaM = totalMie( turbidity ) * mieCoefficient;

		}`,fragmentShader:`
		varying vec3 vWorldPosition;
		varying vec3 vSunDirection;
		varying float vSunfade;
		varying vec3 vBetaR;
		varying vec3 vBetaM;
		varying float vSunE;

		uniform float mieDirectionalG;
		uniform vec3 up;

		// constants for atmospheric scattering
		const float pi = 3.141592653589793238462643383279502884197169;

		const float n = 1.0003; // refractive index of air
		const float N = 2.545E25; // number of molecules per unit volume for air at 288.15K and 1013mb (sea level -45 celsius)

		// optical length at zenith for molecules
		const float rayleighZenithLength = 8.4E3;
		const float mieZenithLength = 1.25E3;
		// 66 arc seconds -> degrees, and the cosine of that
		const float sunAngularDiameterCos = 0.999956676946448443553574619906976478926848692873900859324;

		// 3.0 / ( 16.0 * pi )
		const float THREE_OVER_SIXTEENPI = 0.05968310365946075;
		// 1.0 / ( 4.0 * pi )
		const float ONE_OVER_FOURPI = 0.07957747154594767;

		float rayleighPhase( float cosTheta ) {
			return THREE_OVER_SIXTEENPI * ( 1.0 + pow( cosTheta, 2.0 ) );
		}

		float hgPhase( float cosTheta, float g ) {
			float g2 = pow( g, 2.0 );
			float inverse = 1.0 / pow( 1.0 - 2.0 * g * cosTheta + g2, 1.5 );
			return ONE_OVER_FOURPI * ( ( 1.0 - g2 ) * inverse );
		}

		void main() {

			vec3 direction = normalize( vWorldPosition - cameraPosition );

			// optical length
			// cutoff angle at 90 to avoid singularity in next formula.
			float zenithAngle = acos( max( 0.0, dot( up, direction ) ) );
			float inverse = 1.0 / ( cos( zenithAngle ) + 0.15 * pow( 93.885 - ( ( zenithAngle * 180.0 ) / pi ), -1.253 ) );
			float sR = rayleighZenithLength * inverse;
			float sM = mieZenithLength * inverse;

			// combined extinction factor
			vec3 Fex = exp( -( vBetaR * sR + vBetaM * sM ) );

			// in scattering
			float cosTheta = dot( direction, vSunDirection );

			float rPhase = rayleighPhase( cosTheta * 0.5 + 0.5 );
			vec3 betaRTheta = vBetaR * rPhase;

			float mPhase = hgPhase( cosTheta, mieDirectionalG );
			vec3 betaMTheta = vBetaM * mPhase;

			vec3 Lin = pow( vSunE * ( ( betaRTheta + betaMTheta ) / ( vBetaR + vBetaM ) ) * ( 1.0 - Fex ), vec3( 1.5 ) );
			Lin *= mix( vec3( 1.0 ), pow( vSunE * ( ( betaRTheta + betaMTheta ) / ( vBetaR + vBetaM ) ) * Fex, vec3( 1.0 / 2.0 ) ), clamp( pow( 1.0 - dot( up, vSunDirection ), 5.0 ), 0.0, 1.0 ) );

			// nightsky
			float theta = acos( direction.y ); // elevation --> y-axis, [-pi/2, pi/2]
			float phi = atan( direction.z, direction.x ); // azimuth --> x-axis [-pi/2, pi/2]
			vec2 uv = vec2( phi, theta ) / vec2( 2.0 * pi, pi ) + vec2( 0.5, 0.0 );
			vec3 L0 = vec3( 0.1 ) * Fex;

			// composition + solar disc
			float sundisk = smoothstep( sunAngularDiameterCos, sunAngularDiameterCos + 0.00002, cosTheta );
			L0 += ( vSunE * 19000.0 * Fex ) * sundisk;

			vec3 texColor = ( Lin + L0 ) * 0.04 + vec3( 0.0, 0.0003, 0.00075 );

			vec3 retColor = pow( texColor, vec3( 1.0 / ( 1.2 + ( 1.2 * vSunfade ) ) ) );

			gl_FragColor = vec4( retColor, 1.0 );

			#include <tonemapping_fragment>
			#include <colorspace_fragment>

		}`};var Za=class extends nt{constructor(t,e={}){super(t),this.isWater=!0;let n=this,s=e.textureWidth!==void 0?e.textureWidth:512,r=e.textureHeight!==void 0?e.textureHeight:512,o=e.clipBias!==void 0?e.clipBias:0,a=e.alpha!==void 0?e.alpha:1,l=e.time!==void 0?e.time:0,c=e.waterNormals!==void 0?e.waterNormals:null,h=e.sunDirection!==void 0?e.sunDirection:new C(.70707,.70707,0),u=new bt(e.sunColor!==void 0?e.sunColor:16777215),d=new bt(e.waterColor!==void 0?e.waterColor:8355711),f=e.eye!==void 0?e.eye:new C(0,0,0),g=e.distortionScale!==void 0?e.distortionScale:20,x=e.side!==void 0?e.side:jn,m=e.fog!==void 0?e.fog:!1,p=new bn,M=new C,v=new C,y=new C,w=new Wt,S=new C(0,0,-1),A=new Me,P=new C,_=new C,b=new Me,R=new Wt,L=new Be,D=new Vn(s,r),N={name:"MirrorShader",uniforms:mr.merge([ot.fog,ot.lights,{normalSampler:{value:null},mirrorSampler:{value:null},alpha:{value:1},time:{value:0},size:{value:1},distortionScale:{value:20},textureMatrix:{value:new Wt},sunColor:{value:new bt(8355711)},sunDirection:{value:new C(.70707,.70707,0)},eye:{value:new C},waterColor:{value:new bt(5592405)}}]),vertexShader:`
				uniform mat4 textureMatrix;
				uniform float time;

				varying vec4 mirrorCoord;
				varying vec4 worldPosition;

				#include <common>
				#include <fog_pars_vertex>
				#include <shadowmap_pars_vertex>
				#include <logdepthbuf_pars_vertex>

				void main() {
					mirrorCoord = modelMatrix * vec4( position, 1.0 );
					worldPosition = mirrorCoord.xyzw;
					mirrorCoord = textureMatrix * mirrorCoord;
					vec4 mvPosition =  modelViewMatrix * vec4( position, 1.0 );
					gl_Position = projectionMatrix * mvPosition;

				#include <beginnormal_vertex>
				#include <defaultnormal_vertex>
				#include <logdepthbuf_vertex>
				#include <fog_vertex>
				#include <shadowmap_vertex>
			}`,fragmentShader:`
				uniform sampler2D mirrorSampler;
				uniform float alpha;
				uniform float time;
				uniform float size;
				uniform float distortionScale;
				uniform sampler2D normalSampler;
				uniform vec3 sunColor;
				uniform vec3 sunDirection;
				uniform vec3 eye;
				uniform vec3 waterColor;

				varying vec4 mirrorCoord;
				varying vec4 worldPosition;

				vec4 getNoise( vec2 uv ) {
					vec2 uv0 = ( uv / 103.0 ) + vec2(time / 17.0, time / 29.0);
					vec2 uv1 = uv / 107.0-vec2( time / -19.0, time / 31.0 );
					vec2 uv2 = uv / vec2( 8907.0, 9803.0 ) + vec2( time / 101.0, time / 97.0 );
					vec2 uv3 = uv / vec2( 1091.0, 1027.0 ) - vec2( time / 109.0, time / -113.0 );
					vec4 noise = texture2D( normalSampler, uv0 ) +
						texture2D( normalSampler, uv1 ) +
						texture2D( normalSampler, uv2 ) +
						texture2D( normalSampler, uv3 );
					return noise * 0.5 - 1.0;
				}

				void sunLight( const vec3 surfaceNormal, const vec3 eyeDirection, float shiny, float spec, float diffuse, inout vec3 diffuseColor, inout vec3 specularColor ) {
					vec3 reflection = normalize( reflect( -sunDirection, surfaceNormal ) );
					float direction = max( 0.0, dot( eyeDirection, reflection ) );
					specularColor += pow( direction, shiny ) * sunColor * spec;
					diffuseColor += max( dot( sunDirection, surfaceNormal ), 0.0 ) * sunColor * diffuse;
				}

				#include <common>
				#include <packing>
				#include <bsdfs>
				#include <fog_pars_fragment>
				#include <logdepthbuf_pars_fragment>
				#include <lights_pars_begin>
				#include <shadowmap_pars_fragment>
				#include <shadowmask_pars_fragment>

				void main() {

					#include <logdepthbuf_fragment>
					vec4 noise = getNoise( worldPosition.xz * size );
					vec3 surfaceNormal = normalize( noise.xzy * vec3( 1.5, 1.0, 1.5 ) );

					vec3 diffuseLight = vec3(0.0);
					vec3 specularLight = vec3(0.0);

					vec3 worldToEye = eye-worldPosition.xyz;
					vec3 eyeDirection = normalize( worldToEye );
					sunLight( surfaceNormal, eyeDirection, 100.0, 2.0, 0.5, diffuseLight, specularLight );

					float distance = length(worldToEye);

					vec2 distortion = surfaceNormal.xz * ( 0.001 + 1.0 / distance ) * distortionScale;
					vec3 reflectionSample = vec3( texture2D( mirrorSampler, mirrorCoord.xy / mirrorCoord.w + distortion ) );

					float theta = max( dot( eyeDirection, surfaceNormal ), 0.0 );
					float rf0 = 0.3;
					float reflectance = rf0 + ( 1.0 - rf0 ) * pow( ( 1.0 - theta ), 5.0 );
					vec3 scatter = max( 0.0, dot( surfaceNormal, eyeDirection ) ) * waterColor;
					vec3 albedo = mix( ( sunColor * diffuseLight * 0.3 + scatter ) * getShadowMask(), ( vec3( 0.1 ) + reflectionSample * 0.9 + reflectionSample * specularLight ), reflectance);
					vec3 outgoingLight = albedo;
					gl_FragColor = vec4( outgoingLight, alpha );

					#include <tonemapping_fragment>
					#include <colorspace_fragment>
					#include <fog_fragment>	
				}`},W=new dn({name:N.name,uniforms:mr.clone(N.uniforms),vertexShader:N.vertexShader,fragmentShader:N.fragmentShader,lights:!0,side:x,fog:m});W.uniforms.mirrorSampler.value=D.texture,W.uniforms.textureMatrix.value=R,W.uniforms.alpha.value=a,W.uniforms.time.value=l,W.uniforms.normalSampler.value=c,W.uniforms.sunColor.value=u,W.uniforms.waterColor.value=d,W.uniforms.sunDirection.value=h,W.uniforms.distortionScale.value=g,W.uniforms.eye.value=f,n.material=W,n.onBeforeRender=function(k,q,H){if(v.setFromMatrixPosition(n.matrixWorld),y.setFromMatrixPosition(H.matrixWorld),w.extractRotation(n.matrixWorld),M.set(0,0,1),M.applyMatrix4(w),P.subVectors(v,y),P.dot(M)>0)return;P.reflect(M).negate(),P.add(v),w.extractRotation(H.matrixWorld),S.set(0,0,-1),S.applyMatrix4(w),S.add(y),_.subVectors(v,S),_.reflect(M).negate(),_.add(v),L.position.copy(P),L.up.set(0,1,0),L.up.applyMatrix4(w),L.up.reflect(M),L.lookAt(_),L.far=H.far,L.updateMatrixWorld(),L.projectionMatrix.copy(H.projectionMatrix),R.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),R.multiply(L.projectionMatrix),R.multiply(L.matrixWorldInverse),p.setFromNormalAndCoplanarPoint(M,v),p.applyMatrix4(L.matrixWorldInverse),A.set(p.normal.x,p.normal.y,p.normal.z,p.constant);let K=L.projectionMatrix;b.x=(Math.sign(A.x)+K.elements[8])/K.elements[0],b.y=(Math.sign(A.y)+K.elements[9])/K.elements[5],b.z=-1,b.w=(1+K.elements[10])/K.elements[14],A.multiplyScalar(2/A.dot(b)),K.elements[2]=A.x,K.elements[6]=A.y,K.elements[10]=A.z+1-o,K.elements[14]=A.w,f.setFromMatrixPosition(H.matrixWorld);let Q=k.getRenderTarget(),at=k.xr.enabled,Ct=k.shadowMap.autoUpdate;n.visible=!1,k.xr.enabled=!1,k.shadowMap.autoUpdate=!1,k.setRenderTarget(D),k.state.buffers.depth.setMask(!0),k.autoClear===!1&&k.clear(),k.render(q,L),n.visible=!0,k.xr.enabled=at,k.shadowMap.autoUpdate=Ct,k.setRenderTarget(Q);let qt=H.viewport;qt!==void 0&&k.state.viewport(qt)}}};function $h(i,t=!1){let e=i[0].index!==null,n=new Set(Object.keys(i[0].attributes)),s=new Set(Object.keys(i[0].morphAttributes)),r={},o={},a=i[0].morphTargetsRelative,l=new ae,c=0;for(let h=0;h<i.length;++h){let u=i[h],d=0;if(e!==(u.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(let f in u.attributes){if(!n.has(f))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+'. All geometries must have compatible attributes; make sure "'+f+'" attribute exists among all geometries, or in none of them.'),null;r[f]===void 0&&(r[f]=[]),r[f].push(u.attributes[f]),d++}if(d!==n.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". Make sure all geometries have the same number of attributes."),null;if(a!==u.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(let f in u.morphAttributes){if(!s.has(f))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+".  .morphAttributes must be consistent throughout all geometries."),null;o[f]===void 0&&(o[f]=[]),o[f].push(u.morphAttributes[f])}if(t){let f;if(e)f=u.index.count;else if(u.attributes.position!==void 0)f=u.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". The geometry must have either an index or a position attribute"),null;l.addGroup(c,f,h),c+=f}}if(e){let h=0,u=[];for(let d=0;d<i.length;++d){let f=i[d].index;for(let g=0;g<f.count;++g)u.push(f.getX(g)+h);h+=i[d].attributes.position.count}l.setIndex(u)}for(let h in r){let u=Cf(r[h]);if(!u)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" attribute."),null;l.setAttribute(h,u)}for(let h in o){let u=o[h][0].length;if(u===0)break;l.morphAttributes=l.morphAttributes||{},l.morphAttributes[h]=[];for(let d=0;d<u;++d){let f=[];for(let x=0;x<o[h].length;++x)f.push(o[h][x][d]);let g=Cf(f);if(!g)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" morphAttribute."),null;l.morphAttributes[h].push(g)}}return l}function Cf(i){let t,e,n,s=-1,r=0;for(let c=0;c<i.length;++c){let h=i[c];if(t===void 0&&(t=h.array.constructor),t!==h.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(e===void 0&&(e=h.itemSize),e!==h.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(n===void 0&&(n=h.normalized),n!==h.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(s===-1&&(s=h.gpuType),s!==h.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;r+=h.count*e}let o=new t(r),a=new Ne(o,e,n),l=0;for(let c=0;c<i.length;++c){let h=i[c];if(h.isInterleavedBufferAttribute){let u=l/e;for(let d=0,f=h.count;d<f;d++)for(let g=0;g<e;g++){let x=h.getComponent(d,g);a.setComponent(d+u,g,x)}}else o.set(h.array,l);l+=h.count*e}return s!==void 0&&(a.gpuType=s),a}var Pf={id:"hub",type:"hub",name:"\uD0DC\uC77C\uACE8\uD504 \uB77C\uC6B4\uC9C0",biome:"temperate"},qh={temperate:{tint:16777215,patch:14208140,water:1920867,tree:"round",elev:38,turb:4,sun:1},links:{tint:14277806,patch:13219708,water:2113362,tree:"none",elev:24,turb:8,sun:.85},coastal:{tint:15925232,patch:14208140,water:1331306,tree:"pine",elev:42,turb:3,sun:1},dry:{tint:15128476,patch:13215850,water:2054768,tree:"round",elev:55,turb:6,sun:1.15},tropical:{tint:15138776,patch:12572538,water:1010296,tree:"palm",elev:62,turb:5,sun:1.15},savanna:{tint:15256708,patch:13213792,water:2776166,tree:"acacia",elev:48,turb:9,sun:1.2},cold:{tint:12175021,patch:16054266,water:1718860,tree:"pine",elev:14,turb:2,sun:.75,snow:!0}};function _s(i){let t=2166136261;for(let e of String(i))t=Math.imul(t^e.charCodeAt(0),16777619);return()=>{t+=1831565813;let e=t;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}}var Kt={islandR:135,lake:{x:-62,z:0,r:22},pier:{x0:-52,x1:-37,hw:1.5,y:.45},green:{x0:44,x1:76,z0:-8,z1:8,y:.12},pavilion:{x:0,z:-48,hw:6,hd:5,y:.15},table:{x:0,z:-48,L:2.24,W:1.12,h:.78}};Kt.table.y=Kt.pavilion.y+Kt.table.h;var fo=[{id:"golf",x:46.5,z:0,r:3.2},{id:"fishing",x:-50.5,z:0,r:2.6},{id:"billiards",x:0,z:-45.2,r:2.4}];function Ka(i){return new fn(.001,i,Math.max(24,Math.ceil(i*.7)),Math.max(2,Math.ceil(i/3)))}function Ms(i,t,e){return new $t(i,t,e,Math.max(1,Math.ceil(i/2)),1,Math.max(1,Math.ceil(e/2)))}function Rt(i,t,e=0,n=0,s=0,{cast:r=!0,receive:o=!0}={}){let a=new nt(i,t);return a.position.set(e,n,s),a.castShadow=r,a.receiveShadow=o,a}var Ja=class{constructor(t,e,n,s){this.scene=t,this.venue=e,this.biome=qh[e.biome]||qh.temperate,this.rand=_s(e.id),this.group=new Jt,this.colliders={circles:[],rects:[]},this.anim=[],this.quality=n,t.add(this.group),this.renderer=s,this.water=null,this.buildLights(),this.buildGround(),this.buildPlaza(),this.buildGolf(),this.buildLake(),this.buildPavilion(),this.buildNature(),this.buildEnvironment()}buildLights(){let t=this.biome,e=pr.degToRad(90-t.elev),n=pr.degToRad(215);this.sunDir=new C().setFromSphericalCoords(1,e,n);let s=new bt(16773596).lerp(new bt(16756848),pr.clamp((30-t.elev)/30,0,1)),r=new Ha(13624319,5919286,.35),o=new Va(s,3*t.sun);o.castShadow=this.quality.shadows;let a=this.quality.shadowMap;o.shadow.mapSize.set(a,a);let l=o.shadow.camera;l.left=l.bottom=-26,l.right=l.top=26,l.near=1,l.far=160,o.shadow.bias=-4e-4,o.shadow.normalBias=.04,this.sun=o,this.group.add(r,o,o.target)}buildEnvironment(){let t=this.biome,e=new yr;e.scale.setScalar(4e3);let n=e.material.uniforms;if(n.turbidity.value=t.turb*.55,n.rayleigh.value=t.elev<20?3:2.6,n.mieCoefficient.value=.003,n.mieDirectionalG.value=.8,n.sunPosition.value.copy(this.sunDir),this.scene.add(e),this.sky=e,this.renderer){let r=new cr(this.renderer),o=new hr,a=new yr;a.scale.setScalar(4e3);for(let l in n)a.material.uniforms[l].value=n[l].value;o.add(a),this.scene.environment=r.fromScene(o,0,1,5e3).texture,this.scene.environmentIntensity=.75,r.dispose()}let s=new bt(13228262).lerp(new bt(15259840),t.turb/12);this.scene.fog=new Ta(s,70,330)}follow(t){this.sun.position.set(t.x+this.sunDir.x*80,this.sunDir.y*80,t.z+this.sunDir.z*80),this.sun.target.position.set(t.x,0,t.z)}buildGround(){let{islandR:t}=Kt,e=this.biome,n=Rt(new fn(.001,t,96,40),Lt("grass",e.tint),0,0,0,{cast:!1});n.rotation.x=-Math.PI/2,this.group.add(n);let s=new je(1,20),r=Tt(e.patch,{roughness:.9});r.polygonOffset=!0,r.polygonOffsetFactor=-1;let o=new sn(s,r,e.snow?70:0),a=new Wt,l=new Re().setFromEuler(new un(-Math.PI/2,0,0));for(let g=0;g<70;g++){let x=this.rand()*Math.PI*2,m=15+this.rand()*110,p=3+this.rand()*9;a.compose(new C(Math.cos(x)*m,.01,Math.sin(x)*m),l,new C(p,p*(.6+this.rand()*.6),1)),o.setMatrixAt(g,a)}o.receiveShadow=!0,this.group.add(o);let c=Rt(new fn(t-1,t+9,96,3),Lt("sand"),0,-.02,0,{cast:!1});c.rotation.x=-Math.PI/2;let h=new ye({color:e.water,roughness:.12,metalness:.1,normalMap:_i("water").normal,normalScale:new rt(.4,.4)});h.normalMap.repeat.set(60,60);let u=Rt(new fn(.001,900,64,40),wn(h),0,-.3,0,{cast:!1});u.rotation.x=-Math.PI/2,this.anim.push(g=>{h.normalMap.offset.set(g*.004,g*.003)}),this.group.add(c,u);let d=Lt("dirt");d.polygonOffset=!0,d.polygonOffsetFactor=-2,this.paths=[];let f=(g,x,m,p,M=3)=>{let v=Math.hypot(m-g,p-x),y=Rt(new Mn(M,v,1,Math.ceil(v/2)),d,(g+m)/2,.02,(x+p)/2,{cast:!1});y.rotation.x=-Math.PI/2,y.rotation.z=Math.atan2(m-g,p-x),this.group.add(y),this.paths.push({x0:g,z0:x,x1:m,z1:p,w:M})};f(9,0,44,0),f(-9,0,-37,0),f(0,-9,0,-42.5),f(0,9,0,30,2.4)}buildPlaza(){let t=Lt("paving"),e=Rt(Ka(10),t,0,.05,0,{cast:!1});e.rotation.x=-Math.PI/2,this.group.add(e);let n=Rt(new gs(10,.22,8,64),Lt("concrete",11906722),0,.08,0);n.rotation.x=Math.PI/2,this.group.add(n);let s=Rt(new Ut(2.4,2.6,.6,40),Lt("concrete",14210252),0,.3,0),r=Rt(new Ut(2.1,2.1,.05,40),Tt(4029839,{roughness:.05,metalness:.2}),0,.58,0,{cast:!1}),o=Rt(new Ut(.3,.45,1.6,24),Lt("concrete",14210252),0,1.2,0),a=Rt(new Ut(.9,.4,.3,32),Lt("concrete",14210252),0,2,0),l=Rt(new Ce(.45,20,14),Tt(15136511,{transparent:!0,opacity:.45,roughness:.05}),0,2.4,0,{cast:!1});this.group.add(s,r,o,a,l),this.anim.push(f=>{l.scale.set(1,1+Math.sin(f*4)*.25,1),l.position.y=2.4+Math.sin(f*4)*.08}),this.colliders.circles.push({x:0,z:0,r:2.8});let c=Lt("wood",14267276),h=Tt(2829616,{metalness:.8,roughness:.45});for(let f=0;f<8;f++){let g=f/8*Math.PI*2+Math.PI/8,x=Math.cos(g)*7.5,m=Math.sin(g)*7.5,p=new Jt;p.add(Rt(new $t(1.8,.12,.5),c,0,.45,0)),p.add(Rt(new $t(1.8,.4,.1),c,0,.75,-.22)),p.add(Rt(new $t(.1,.45,.45),h,-.8,.22,0),Rt(new $t(.1,.45,.45),h,.8,.22,0)),p.position.set(x,0,m),p.rotation.y=-g-Math.PI/2,this.group.add(p),this.colliders.circles.push({x,z:m,r:.9});let M=g,v=Math.cos(M)*9.3,y=Math.sin(M)*9.3;this.group.add(Rt(new Ut(.06,.09,2.6,12),h,v,1.3,y)),this.group.add(Rt(new Ce(.22,16,12),Tt(16774877,{emissive:16769696,emissiveIntensity:.6,roughness:.2}),v,2.7,y,{cast:!1}))}let u=[12607551,7311226,11569754,6258586];[[-14,18],[14,18],[-22,6],[22,6]].forEach(([f,g],x)=>{let m=new Jt;m.add(Rt(new $t(4,2.6,3.6),Lt("plaster"),0,1.3,0));let p=Rt(new Qn(3.4,1.9,4),Lt("roof",u[x]),0,3.55,0);p.rotation.y=Math.PI/4,m.add(p),m.add(Rt(new $t(.9,1.5,.1),Lt("wood",8016438),0,.75,-1.82)),m.add(Rt(new $t(.7,.6,.1),Tt(1911347,{roughness:.05,metalness:.9}),1.2,1.5,-1.82),Rt(new $t(.7,.6,.1),Tt(1911347,{roughness:.05,metalness:.9}),-1.2,1.5,-1.82)),m.position.set(f,0,g),m.rotation.y=Math.atan2(f,g),this.group.add(m),this.colliders.circles.push({x:f,z:g,r:2.8})});let d=[["\u26F3",12,2.2,16769126],["\u{1F3A3}",-12,2.2,7651580],["\u{1F3B1}",2.2,-12,11638780]];for(let[f,g,x,m]of d){this.group.add(Rt(new Ut(.07,.08,2,10),Lt("wood",9068608),g,1,x));let p=this.emojiBoard(f,m);p.position.set(g,2.1,x),p.rotation.y=Math.atan2(-g,-x)+Math.PI,this.group.add(p)}}emojiBoard(t,e){let n=document.createElement("canvas");n.width=128,n.height=128;let s=n.getContext("2d");s.fillStyle="#"+e.toString(16).padStart(6,"0"),s.beginPath(),s.roundRect(4,4,120,120,24),s.fill(),s.font="80px serif",s.textAlign="center",s.textBaseline="middle",s.fillText(t,64,70);let r=new Je(n);return r.colorSpace=me,Rt(new Mn(1.1,1.1),wn(new Le({map:r,side:Te})),0,0,0,{cast:!1})}buildGolf(){let t=Kt.green,e=t.x1-t.x0,n=t.z1-t.z0,s=(t.x0+t.x1)/2,r=(t.z0+t.z1)/2;this.group.add(Rt(Ms(e+3,.08,n+3),Lt("grass",13164712),s,.04,r,{cast:!1}));let o=Lt("green",16777215),a=Lt("green",13821636),l=8;for(let y=0;y<l;y++)this.group.add(Rt(Ms(e/l,t.y,n),y%2?o:a,t.x0+(y+.5)*(e/l),t.y/2,r,{cast:!1}));let c=Lt("wood",13279866),h=.22,u=.25;this.group.add(Rt(Ms(e+u*2,h,u),c,s,t.y+h/2,t.z0-u/2)),this.group.add(Rt(Ms(e+u*2,h,u),c,s,t.y+h/2,t.z1+u/2)),this.group.add(Rt(Ms(u,h,n),c,t.x0-u/2,t.y+h/2,r)),this.group.add(Rt(Ms(u,h,n),c,t.x1+u/2,t.y+h/2,r));let d=this.rand;this.golf={holes:[],obstacles:[],tee:{x:t.x0+2.2,z:r}};for(let y=0;y<3;y++)this.golf.holes.push({x:t.x1-2.5-d()*6,z:t.z0+2+d()*(n-4)});let f=Lt("wood",10253394),g=Lt("rock"),x=3+Math.floor(d()*3);for(let y=0;y<x;y++){let w=t.x0+8+d()*(e-16),S=t.z0+1.5+d()*(n-3);if(d()<.5){let P=.6+d()*.6;this.golf.obstacles.push({kind:"circle",x:w,z:S,r:P});let _=Rt(new ro(P,0),g,w,t.y+P*.45,S);_.scale.y=.6,this.group.add(_)}else{let P=.3+d()*1.5,_=.3+d()*.3,b=d()<.5,R=b?_:P,L=b?P:_;this.golf.obstacles.push({kind:"rect",x0:w-R,x1:w+R,z0:S-L,z1:S+L}),this.group.add(Rt(new $t(R*2,.3,L*2),f,w,t.y+.15,S))}}this.cup=Rt(new je(.16,20),new Le({color:1710618}),0,t.y+.003,0,{cast:!1}),this.cup.rotation.x=-Math.PI/2,wn(this.cup.material);let m=new Jt;m.add(Rt(new Ut(.02,.02,1.8,8),Tt(15921906,{metalness:.6,roughness:.3}),0,.9,0));let p=Rt(new Mn(.6,.4,6,1),Lt("fabric",14100029,{side:Te}),.3,1.6,0);m.add(p),this.anim.push(y=>{p.rotation.y=Math.sin(y*3)*.25}),this.flag=m,this.group.add(this.cup,m),this.setHole(0);let M=Rt(new Ut(.06,.06,.04,10),Tt(16777215),this.golf.tee.x,t.y+.01,this.golf.tee.z,{cast:!1});this.group.add(M);let v=new Jt;v.add(Rt(new $t(1.4,.6,2.2),Tt(16053488,{roughness:.25,metalness:.1}),0,.6,0)),v.add(Rt(new $t(1.5,.08,1.6),Lt("fabric",3104070),0,1.9,.1));for(let[y,w]of[[-.6,-.8],[.6,-.8],[-.6,.8],[.6,.8]]){let S=Rt(new Ut(.28,.28,.2,20),Tt(1842204,{roughness:.9}),y,.28,w);S.rotation.z=Math.PI/2,v.add(S)}v.add(Rt(new Ut(.04,.04,1.3,6),Tt(13421772,{metalness:.9,roughness:.3}),-.65,1.25,.8),Rt(new Ut(.04,.04,1.3,6),Tt(13421772,{metalness:.9,roughness:.3}),.65,1.25,.8)),v.position.set(41,0,-5),v.rotation.y=.4,this.group.add(v),this.colliders.circles.push({x:41,z:-5,r:1.4})}setHole(t){let e=this.golf.holes[t%this.golf.holes.length];this.cup.position.set(e.x,Kt.green.y+.003,e.z),this.flag.position.set(e.x,Kt.green.y,e.z)}buildLake(){let t=Kt.lake,e=Kt.pier,n=Rt(Ka(t.r+2.5),Lt("sand",14272928),t.x,.015,t.z,{cast:!1});n.rotation.x=-Math.PI/2;let s;if(this.quality.reflect){s=new Za(Ka(t.r),{textureWidth:512,textureHeight:512,waterNormals:_i("water").normal,sunDirection:this.sunDir.clone(),sunColor:16774368,waterColor:new bt(this.biome.water).multiplyScalar(.6),distortionScale:3.2,alpha:.95,fog:!0}),s.material.uniforms.size.value=6,s.position.set(t.x,.05,t.z),this.noReflect=[];let f=s.onBeforeRender.bind(s);s.onBeforeRender=(...g)=>{for(let x of this.noReflect)x.visible=!1;f(...g);for(let x of this.noReflect)x.visible=!0},this.anim.push((g,x)=>{s.material.uniforms.time.value+=x*.6})}else{let f=new ye({color:this.biome.water,roughness:.06,metalness:.15,normalMap:_i("water").normal,normalScale:new rt(.35,.35)});f.normalMap=f.normalMap.clone(),f.normalMap.repeat.set(8,8),s=Rt(Ka(t.r),wn(f),t.x,.05,t.z,{cast:!1}),this.anim.push(g=>{f.normalMap.offset.set(g*.01,g*.007)})}s.rotation.x=-Math.PI/2,s.receiveShadow=!0,this.water=s,this.group.add(n,s);let r=new Wt,o=new je(.7,10,.3,Math.PI*1.8),a=new sn(o,Lt("leaves",9416816),14);for(let f=0;f<14;f++){let g=this.rand()*Math.PI*2,x=t.r-2-this.rand()*5;r.compose(new C(t.x+Math.cos(g)*x,.07,t.z+Math.sin(g)*x),new Re().setFromEuler(new un(-Math.PI/2,0,this.rand()*6)),new C(1,1,1)),a.setMatrixAt(f,r)}this.group.add(a);let l=Lt("wood",12096114),c=Lt("bark",7034436),h=e.x1-e.x0;for(let f=0;f<Math.floor(h/.6);f++)this.group.add(Rt(new $t(.52,.1,e.hw*2),f%2?l:Lt("wood",11042910),e.x0+.3+f*.6,e.y-.05,0));for(let f=e.x0+.3;f<e.x1;f+=3)for(let g of[-e.hw,e.hw])this.group.add(Rt(new Ut(.12,.12,1.2,8),c,f,e.y-.5,g));let u=new Jt,d=Rt(new Ut(.9,.6,.5,10,1,!1,0,Math.PI),Lt("wood",11880494),0,0,0);d.rotation.set(Math.PI/2,0,Math.PI/2),d.scale.set(1,2.2,1),u.add(d),u.position.set(t.x+8,.25,t.z+9),this.anim.push(f=>{u.position.y=.25+Math.sin(f*1.2)*.05,u.rotation.z=Math.sin(f)*.04}),this.group.add(u)}buildPavilion(){let t=Kt.pavilion,e=Kt.table,n=Lt("wood",4861468);this.group.add(Rt(Ms(t.hw*2,t.y,t.hd*2),Lt("wood",14729370),t.x,t.y/2,t.z,{cast:!1}));for(let[r,o]of[[-1,-1],[1,-1],[-1,1],[1,1]]){let a=t.x+r*(t.hw-.4),l=t.z+o*(t.hd-.4);this.group.add(Rt(new Ut(.2,.24,3.6,20),Lt("plaster"),a,t.y+1.8,l)),this.colliders.circles.push({x:a,z:l,r:.45})}let s=Rt(new Qn(Math.hypot(t.hw,t.hd)+.8,2.2,4),Lt("roof",6122365),t.x,t.y+4.7,t.z);s.rotation.y=Math.PI/4,s.scale.z=t.hd/t.hw,this.group.add(s),this.pavilionRoof=s,this.lamp=new Jt,this.lamp.add(Rt(new Ut(.01,.01,1.4,4),Tt(2236962,{metalness:.8}),e.x,t.y+3.1,e.z,{cast:!1})),this.lamp.add(Rt(new Qn(.6,.4,32,1,!0),Tt(2051374,{side:Te,metalness:.7,roughness:.35,emissive:3353104}),e.x,t.y+2.3,e.z,{cast:!1})),this.group.add(this.lamp),this.colliders.rects.push({x0:e.x-1.95,x1:e.x+1.95,z0:e.z-1.2,z1:e.z+1.2})}buildNature(){let t=this.biome.tree,e=(w,S)=>Math.hypot(w,S)<14||Math.hypot(w-Kt.lake.x,S-Kt.lake.z)<Kt.lake.r+5||w>38&&w<82&&Math.abs(S)<14||Math.abs(w)<10&&S<-38&&S>-58||Math.abs(S)<3.5||Math.abs(w)<3.5||Math.hypot(Math.abs(w)-18,S-12)<9,n=[],s=0,r=t==="none"?0:this.quality.trees;for(;n.length<r&&s++<r*20;){let w=this.rand()*Math.PI*2,S=14+Math.sqrt(this.rand())*115,A=Math.cos(w)*S,P=Math.sin(w)*S;e(A,P)||n.push([A,P,.8+this.rand()*.6])}let o=Lt("bark"),a={round:14217408,pine:10467482,palm:14742960,acacia:15262368},l=Lt("leaves",16777215),c,h,u,d,f=(w,S)=>{let A=w.attributes.position,P=new C;for(let _=0;_<A.count;_++){P.fromBufferAttribute(A,_);let b=Math.sin(P.x*3.1+P.y*1.7)*Math.cos(P.z*2.3-P.y)*S;P.multiplyScalar(1+b),A.setXYZ(_,P.x,P.y,P.z)}return w.computeVertexNormals(),w};if(t==="pine"?(d=1.4,c=new Ut(.13,.24,d,10),h=$h([0,1,2,3].map(w=>f(new Qn(1.6-w*.32,1.7,14,3).translate(0,w*.95,0),.08))),u=2):t==="palm"?(d=4,c=new Ut(.12,.2,d,6),h=new Qn(1.8,.7,7),u=4.1):t==="acacia"?(d=2.4,c=new Ut(.12,.18,d,6),h=new Ut(2,1.6,.6,10),u=2.6):(d=1.8,c=new Ut(.14,.26,d,10),h=$h([[0,0,0,1.3],[.8,-.3,.3,.9],[-.7,-.2,-.4,.95],[.1,.6,-.5,.85],[-.3,-.4,.8,.8]].map(([w,S,A,P])=>f(new ms(P,2),.1).translate(w,S,A))),u=2.7),c.translate(0,d/2,0),h.translate(0,u,0),n.length){let w=new sn(c,o,n.length),S=new sn(h,l,n.length),A=new Wt,P=new Re,_=new bt;n.forEach(([b,R,L],D)=>{P.setFromAxisAngle(new C(0,1,0),this.rand()*6.28),A.compose(new C(b,0,R),P,new C(L,L,L)),w.setMatrixAt(D,A),S.setMatrixAt(D,A),S.setColorAt(D,_.set(l.color).offsetHSL((this.rand()-.5)*.06,0,(this.rand()-.5)*.12)),this.colliders.circles.push({x:b,z:R,r:.45*L})});for(let b of[w,S])b.castShadow=!0,b.receiveShadow=!0,this.group.add(b)}let g=new ms(.16,0),x=new sn(g,Tt(16777215,{roughness:.7}),this.quality.flowers),m=[16748459,16765286,16777215,13481179,16739179,10221311],p=new Wt,M=new bt,v=0;for(;v<this.quality.flowers;){let w=this.rand()*Math.PI*2,S=11+this.rand()*110,A=Math.cos(w)*S,P=Math.sin(w)*S;if(e(A,P)&&Math.hypot(A,P)>11)continue;let _=m[Math.floor(this.rand()*m.length)];for(let b=0;b<8&&v<this.quality.flowers;b++,v++){let R=A+(this.rand()-.5)*3,L=P+(this.rand()-.5)*3;p.makeTranslation(R,.16,L),x.setMatrixAt(v,p),x.setColorAt(v,M.set(_))}}this.group.add(x);let y=new sn(new ro(.6,1),Lt("rock"),30);for(let w=0;w<30;w++){let S=this.rand()*Math.PI*2,A=20+this.rand()*110,P=.5+this.rand()*1.5;p.compose(new C(Math.cos(S)*A,.1,Math.sin(S)*A),new Re().setFromEuler(new un(this.rand(),this.rand()*6,0)),new C(P,P*.6,P)),y.setMatrixAt(w,p)}y.castShadow=!0,this.group.add(y)}isGrass(t,e){let n=Math.hypot(t,e);if(n<10.6||n>Kt.islandR-1.5)return!1;let s=Kt.lake;if(Math.hypot(t-s.x,e-s.z)<s.r+2.8)return!1;let r=Kt.green;if(t>r.x0-2&&t<r.x1+2&&e>r.z0-2&&e<r.z1+2)return!1;let o=Kt.pavilion;if(Math.abs(t-o.x)<o.hw+.3&&Math.abs(e-o.z)<o.hd+.3)return!1;for(let a of this.paths){let l=a.x1-a.x0,c=a.z1-a.z0,h=l*l+c*c,u=Math.max(0,Math.min(1,((t-a.x0)*l+(e-a.z0)*c)/h));if(Math.hypot(t-a.x0-l*u,e-a.z0-c*u)<a.w/2+.15)return!1}for(let a of this.colliders.circles)if(a.r>1&&Math.hypot(t-a.x,e-a.z)<a.r)return!1;return!0}groundHeight(t,e){let n=Kt.pier,s=Kt.green,r=Kt.pavilion;return t>=n.x0&&t<=n.x1+.5&&Math.abs(e)<=n.hw?n.y:t>=s.x0&&t<=s.x1&&e>=s.z0&&e<=s.z1?s.y:Math.abs(t-r.x)<=r.hw&&Math.abs(e-r.z)<=r.hd?r.y:0}resolve(t){let n=Kt.lake,s=Kt.pier;if(t.x>=s.x0&&t.x<=s.x1+.5&&Math.abs(t.z)<=s.hw-.2)t.z=Math.max(-s.hw+.3,Math.min(s.hw-.3,t.z)),t.x=Math.max(s.x0+.3,t.x);else{let l=t.x-n.x,c=t.z-n.z,h=Math.hypot(l,c);h<n.r+.35&&(t.x=n.x+l/h*(n.r+.35),t.z=n.z+c/h*(n.r+.35))}for(let l of this.colliders.circles){let c=t.x-l.x,h=t.z-l.z,u=l.r+.35,d=c*c+h*h;if(d<u*u&&d>1e-6){let f=Math.sqrt(d);t.x=l.x+c/f*u,t.z=l.z+h/f*u}}for(let l of this.colliders.rects)if(t.x>l.x0&&t.x<l.x1&&t.z>l.z0&&t.z<l.z1){let c=[[t.x-l.x0,"x",l.x0],[l.x1-t.x,"x",l.x1],[t.z-l.z0,"z",l.z0],[l.z1-t.z,"z",l.z1]];c.sort((h,u)=>h[0]-u[0]),t[c[0][1]]=c[0][2]}let o=Math.hypot(t.x,t.z),a=Kt.islandR-2;o>a&&(t.x*=a/o,t.z*=a/o)}update(t,e){for(let n of this.anim)n(t,e)}dispose(){this.scene.remove(this.group),this.group.traverse(t=>{t.geometry&&t.geometry.dispose()})}};var ei={body:new Gn(.26,.32,4,12),head:new Ce(.44,18,14),eye:new Gn(.045,.06,2,8),cheek:new je(.06,10),hair:new Ce(.46,18,10,0,Math.PI*2,0,Math.PI*.55),arm:new Gn(.075,.22,2,8).translate(0,-.15,0),leg:new Gn(.09,.16,2,8)},wb=new Le({color:2827296}),If=new Le({color:16751266,transparent:!0,opacity:.7}),Lf=[5978665,3023904,15254138,12605498,9072593,4026294];function Sb(i){return Lt("fabric",i)}function Xh(i,{bg:t="rgba(0,0,0,0.55)",fg:e="#fff",size:n=28,maxW:s=420}={}){let r=document.createElement("canvas"),o=r.getContext("2d"),a=`600 ${n}px system-ui, -apple-system, "Segoe UI", "Noto Sans KR", sans-serif`;o.font=a;let l=String(i).split(/(\s+)/),c=[],h="";for(let y of l){let w=h+y;o.measureText(w).width>s&&h?(c.push(h.trim()),h=y):h=w}h.trim()&&c.push(h.trim());let u=[];for(let y of c){let w="";for(let S of y)o.measureText(w+S).width>s?(u.push(w),w=S):w+=S;u.push(w)}let d=u.slice(0,3),f=Math.min(s,Math.max(...d.map(y=>o.measureText(y).width)))+28,g=n*1.25,x=d.length*g+16;r.width=Math.ceil(f),r.height=Math.ceil(x),o.font=a,o.fillStyle=t;let m=14;o.beginPath(),o.roundRect(0,0,r.width,r.height,m),o.fill(),o.fillStyle=e,o.textBaseline="middle",o.textAlign="center",d.forEach((y,w)=>o.fillText(y,r.width/2,8+g*(w+.5)));let p=new Je(r);p.colorSpace=me,p.minFilter=In,p.generateMipmaps=!1;let M=new Ra(new to({map:p,depthWrite:!1,transparent:!0})),v=.0085;return M.scale.set(r.width*v,r.height*v,1),M.renderOrder=10,M}function po(i){i.material.map.dispose(),i.material.dispose()}var mo=class{constructor({name:t,color:e,flag:n=""}){this.root=new Jt;let s=new Jt;this.body=s,this.root.add(s);let r=Sb(e),o=0;for(let p of String(t))o=o*31+p.charCodeAt(0)>>>0;let a=Tt([16769220,16107936,14263418,11039052,8015411][o%5],{roughness:.55}),l=Tt(Lf[(o>>>3)%Lf.length],{roughness:.45}),c=Lt("fabric",4016742),h=new nt(ei.body,r);h.position.y=.62,h.castShadow=!0;let u=new nt(ei.head,a);u.position.y=1.28,u.scale.set(1,.94,.96),u.castShadow=!0;let d=new nt(ei.hair,l);d.position.set(0,1.33,-.03),d.rotation.x=-.25;let f=new nt(ei.eye,wb);f.position.set(-.15,1.27,.4);let g=f.clone();g.position.x=.15;let x=new nt(ei.cheek,If);x.position.set(-.26,1.16,.36),x.rotation.y=-.5;let m=new nt(ei.cheek,If);m.position.set(.26,1.16,.36),m.rotation.y=.5,this.armL=new nt(ei.arm,r),this.armL.position.set(-.32,.83,0),this.armL.rotation.z=-.3,this.armR=new nt(ei.arm,r),this.armR.position.set(.32,.83,0),this.armR.rotation.z=.3,this.legL=new nt(ei.leg,c),this.legL.position.set(-.12,.2,0),this.legR=new nt(ei.leg,c),this.legR.position.set(.12,.2,0);for(let p of[this.legL,this.legR,this.armL,this.armR])p.castShadow=!0;s.add(h,u,d,f,g,x,m,this.armL,this.armR,this.legL,this.legR),this.blinkT=2+Math.random()*3,this.eyes=[f,g],this.tag=Xh(`${n?n+" ":""}${t}`,{size:26}),this.tag.position.y=2.05,this.root.add(this.tag),this.bubble=null,this.bubbleUntil=0,this.walk=0,this.prop=null}setName(t,e=""){this.root.remove(this.tag),po(this.tag),this.tag=Xh(`${e?e+" ":""}${t}`,{size:26}),this.tag.position.y=2.05,this.root.add(this.tag)}say(t,e){this.bubble&&(this.root.remove(this.bubble),po(this.bubble)),this.bubble=Xh(t,{bg:"rgba(255,255,255,0.95)",fg:"#1b1f2a",size:26,maxW:380}),this.bubble.position.y=2.4+this.bubble.scale.y/2,this.root.add(this.bubble),this.bubbleUntil=e+6e3}setProp(t){this.prop&&this.armR.remove(this.prop),this.prop=null,t&&(this.prop=new Jt,this.prop.position.y=-.15,this.prop.add(t),this.armR.add(this.prop))}animate(t,e,n){e>.2?this.walk+=t*(4+e*1.6):this.walk*=Math.pow(.001,t);let s=Math.sin(this.walk)*Math.min(1,e/3);this.legL.rotation.x=s*.7,this.legR.rotation.x=-s*.7,this.armL.rotation.x=-s*.6,this.prop||(this.armR.rotation.x=s*.6),this.blinkT-=t;let r=this.blinkT<.12?.15:1;if(this.blinkT<0&&(this.blinkT=2+Math.random()*4),this.eyes[0].scale.y=this.eyes[1].scale.y=r,this.body.position.y=Math.abs(Math.sin(this.walk))*.05*Math.min(1,e/3),this.armLOverride!=null&&(this.armL.rotation.x=this.armLOverride),this.swingPose!=null){let o=this.swingPose,a=Math.max(0,-o),l=Math.max(0,o);this.body.rotation.y=-a*1.15+l*1.45;let c=.45+a*2.4+l*2.2;this.armR.rotation.x=this.armL.rotation.x=-c,this.armR.rotation.z=-.32,this.armL.rotation.z=.32,this.legL.rotation.x=this.legR.rotation.x=0,this.legR.rotation.z=l*.18}else this.body.rotation.y&&(this.body.rotation.y=0,this.armR.rotation.z=.3,this.armL.rotation.z=-.3,this.legR.rotation.z=0);this.bubble&&n>this.bubbleUntil&&(this.root.remove(this.bubble),po(this.bubble),this.bubble=null)}curveFix(t,e){let n=this.root.position.x-t.x,s=this.root.position.z-t.z,r=(n*n+s*s)*e;this.tag.position.y=2.05-r,this.bubble&&(this.bubble.position.y=2.4+this.bubble.scale.y/2-r)}dispose(){po(this.tag),this.bubble&&po(this.bubble)}};var ft={keys:new Set,move:{x:0,y:0},lookDX:0,lookDY:0,orbitDX:0,orbitDY:0,zoomMul:1,power:!1,touch:matchMedia("(pointer: coarse)").matches,pointer:{x:0,y:0,down:!1,moved:!1,startX:0,startY:0,downAt:0}},Df={action:[],powerDown:[],powerUp:[],pointerDown:[],pointerUp:[]};function ws(i,t){Df[i].push(t)}var Mi=i=>Df[i].forEach(t=>t());function Eb(){let i=document.activeElement;return i&&(i.tagName==="INPUT"||i.tagName==="TEXTAREA"||i.tagName==="SELECT")}function Yh(i,t){let e=t.getBoundingClientRect();ft.pointer.x=(i.clientX-e.left)/e.width*2-1,ft.pointer.y=-((i.clientY-e.top)/e.height)*2+1}function kf(i){addEventListener("keydown",p=>{if(!Eb()){if(p.code==="Space"){p.preventDefault(),ft.power||(ft.power=!0,Mi("powerDown"));return}p.code==="KeyE"&&!p.repeat&&Mi("action"),ft.keys.add(p.code)}}),addEventListener("keyup",p=>{if(p.code==="Space"){ft.power&&(ft.power=!1,Mi("powerUp"));return}ft.keys.delete(p.code)}),addEventListener("blur",()=>{ft.keys.clear(),ft.power&&(ft.power=!1,Mi("powerUp"))}),i.addEventListener("contextmenu",p=>p.preventDefault());let t=null,e=new Map,n=()=>{let[p,M]=[...e.values()];return{x:(p.x+M.x)/2,y:(p.y+M.y)/2,d:Math.hypot(p.x-M.x,p.y-M.y)}},s=null,r=null;i.addEventListener("pointerdown",p=>{if(p.pointerType==="mouse"&&p.button===2){t={id:p.pointerId,x:p.clientX,y:p.clientY},i.setPointerCapture(p.pointerId);return}if(p.pointerType==="touch"){if(e.set(p.pointerId,{x:p.clientX,y:p.clientY}),e.size===2){s=n(),ft.pointer.down=!1;return}if(e.size>2)return}r||(r={id:p.pointerId,x:p.clientX,y:p.clientY},i.setPointerCapture(p.pointerId),Yh(p,i),Object.assign(ft.pointer,{down:!0,moved:!1,startX:ft.pointer.x,startY:ft.pointer.y,downAt:performance.now()}),Mi("pointerDown"))}),i.addEventListener("pointermove",p=>{if(t&&p.pointerId===t.id){ft.orbitDX+=p.clientX-t.x,ft.orbitDY+=p.clientY-t.y,t.x=p.clientX,t.y=p.clientY;return}if(e.has(p.pointerId)){if(e.set(p.pointerId,{x:p.clientX,y:p.clientY}),s&&e.size>=2){let M=n();ft.orbitDX+=M.x-s.x,ft.orbitDY+=M.y-s.y,s.d>20&&M.d>20&&(ft.zoomMul*=s.d/M.d),s=M,r&&(r.x=p.clientX,r.y=p.clientY);return}if(s)return}if(!r){Yh(p,i);return}p.pointerId===r.id&&(Yh(p,i),ft.pointer.moved=!0,ft.lookDX+=p.clientX-r.x,ft.lookDY+=p.clientY-r.y,r.x=p.clientX,r.y=p.clientY)});let o=p=>{if(t&&p.pointerId===t.id){t=null;return}e.delete(p.pointerId),e.size===0&&(s=null),r&&p.pointerId===r.id&&(r=null,ft.pointer.down=!1,Mi("pointerUp"))};i.addEventListener("pointerup",o),i.addEventListener("pointercancel",o);let a=document.getElementById("joy"),l=a.querySelector(".knob"),c=null,h=0,u=0,d=46;a.addEventListener("pointerdown",p=>{c=p.pointerId,a.setPointerCapture(c);let M=a.getBoundingClientRect();h=M.left+M.width/2,u=M.top+M.height/2,f(p)});let f=p=>{if(p.pointerId!==c)return;let M=p.clientX-h,v=p.clientY-u,y=Math.hypot(M,v);y>d&&(M*=d/y,v*=d/y),l.style.transform=`translate(${M}px, ${v}px)`,ft.move.x=M/d,ft.move.y=-v/d};a.addEventListener("pointermove",f);let g=p=>{p.pointerId===c&&(c=null,l.style.transform="",ft.move.x=ft.move.y=0)};a.addEventListener("pointerup",g),a.addEventListener("pointercancel",g);let x=document.getElementById("btnPower");x.addEventListener("pointerdown",p=>{p.preventDefault(),x.setPointerCapture(p.pointerId),ft.power=!0,Mi("powerDown")});let m=()=>{ft.power&&(ft.power=!1,Mi("powerUp"))};x.addEventListener("pointerup",m),x.addEventListener("pointercancel",m),document.getElementById("btnAction").addEventListener("click",()=>Mi("action"))}function Uf(){let i=ft.keys,t=ft.move.x,e=ft.move.y;(i.has("KeyW")||i.has("ArrowUp"))&&(e+=1),(i.has("KeyS")||i.has("ArrowDown"))&&(e-=1),(i.has("KeyA")||i.has("ArrowLeft"))&&(t-=1),(i.has("KeyD")||i.has("ArrowRight"))&&(t+=1);let n=Math.hypot(t,e);return n>1&&(t/=n,e/=n),{x:t,y:e,run:i.has("ShiftLeft")||n>.92}}function vr(i){let t=ft.keys,e=0;return(t.has("ArrowLeft")||t.has("KeyA"))&&(e+=1.4*i),(t.has("ArrowRight")||t.has("KeyD"))&&(e-=1.4*i),t.has("ShiftLeft")&&(e*=.25),e}function Nf(){let i={x:ft.orbitDX,y:ft.orbitDY,zoom:ft.zoomMul};return ft.orbitDX=ft.orbitDY=0,ft.zoomMul=1,i}function Wi(){let i={x:ft.lookDX,y:ft.lookDY};return ft.lookDX=ft.lookDY=0,i}var ja=class{constructor(t){this.h=t,this.id=null,this.offline=!1,this.ws=null,this.lastSent=0,this.lastState=""}connect(t,e,n,s){this.profile=t,this.venue=e;let r=`${n.replace(/^http/,"ws")}/ws?room=${encodeURIComponent(e.id)}&token=${encodeURIComponent(s||"")}`;try{this.ws=new WebSocket(r)}catch{return this.goOffline()}let o=setTimeout(()=>{this.id===null&&(this.ws.onclose=null,this.ws.close(),this.goOffline())},9e3);this.ws.onopen=()=>this.send({t:"hello",color:t.color}),this.ws.onmessage=a=>{if(this.offline)return;let l;try{l=JSON.parse(a.data)}catch{return}l.t==="welcome"&&(clearTimeout(o),this.id=l.id),this.h.message(l)},this.ws.onclose=a=>{var l,c;clearTimeout(o),this.id===null&&!this.offline?this.goOffline():this.offline||(c=(l=this.h).disconnected)==null||c.call(l,a.code)},this.ws.onerror=()=>{},this._ping=setInterval(()=>{var a;((a=this.ws)==null?void 0:a.readyState)===1&&this.ws.send('{"t":"ping"}')},3e4)}close(){this.ws&&(this.ws.onclose=null,this.ws.close()),clearInterval(this._ping),this.id=null,this.offline=!1}send(t){var e;if(this.offline)return this.offlineSend(t);((e=this.ws)==null?void 0:e.readyState)===1&&this.ws.send(JSON.stringify(t))}state(t,e){if(e-this.lastSent<100)return;let n=JSON.stringify(t);n===this.lastState&&e-this.lastSent<1e3||(this.lastSent=e,this.lastState=n,this.send({t:"state",s:t}))}chat(t){this.send({t:"chat",text:t})}event(t){this.send({t:"event",e:t})}goOffline(){this.offline=!0,this.id=0,this.parties={},this.h.message({t:"welcome",id:0,offline:!0,room:"offline",players:[],parties:[]})}offlineSend(t){if(t.t==="chat")this.h.message({t:"chat",id:Math.random(),from:0,name:this.profile.name,lang:this.profile.lang,text:t.text});else if(t.t==="event")this.h.message({t:"event",from:0,name:this.profile.name,e:t.e});else if(t.t.startsWith("party_")){let e=this.parties[t.game]||(this.parties[t.game]={slots:[],state:null});if(t.t==="party_join"){if(e.slots.length>=(t.game==="golf"?8:4))return this.h.message({t:"sys",key:"partyFull"});if(!t.guest&&e.slots.some(n=>!n.guest))return;e.slots.push({owner:0,name:t.guest||this.profile.name,guest:!!t.guest})}else if(t.t==="party_leave")e.slots=Number.isInteger(t.slot)?e.slots.filter((n,s)=>s!==t.slot):[],e.slots.length||(e.state=null);else if(t.t==="party_state")e.state=t.state;else return;this.h.message({t:"party",game:t.game,slots:e.slots,state:e.state})}}};var Zh={ko:{title:"\uD0DC\uC77C\uACE8\uD504 \uB77C\uC6B4\uC9C0",subtitle:"\uD68C\uC6D0\uB07C\uB9AC \uACE8\uD504\xB7\uB09A\uC2DC\xB7\uB2F9\uAD6C",name:"\uB2C9\uB124\uC784",lang:"\uC5B8\uC5B4",color:"\uCE90\uB9AD\uD130 \uC0C9\uC0C1",start:"\uC785\uC7A5\uD558\uAE30",online:"\uC628\uB77C\uC778",offline:"\uD63C\uC790 \uC5F0\uC2B5 \uBAA8\uB4DC",players:"\uBA85 \uC811\uC18D \uC911",chatPh:"\uBA54\uC2DC\uC9C0 \uC785\uB825",send:"\uC804\uC1A1",golf:"\uACE8\uD504",fishing:"\uB09A\uC2DC",billiards:"\uB2F9\uAD6C",play:"\uC2DC\uC791",exit:"\uB098\uAC00\uAE30",globe:"\uC9C0\uAD6C\uBCF8",golfHelp:"\uC88C\uC6B0 \uB4DC\uB798\uADF8/\u2190\u2192 \uC870\uC900 \xB7 \uAE38\uAC8C \uB20C\uB7EC \uD798 \uC870\uC808 \uD6C4 \uB193\uAE30",strokes:"\uD0C0\uC218",nStrokes:"{n}\uD0C0",sumTotal:"\uD569\uACC4",greenRead:"\uADF8\uB9B0 \uACBD\uC0AC",slopeUp:"\uC624\uB974\uB9C9",slopeDown:"\uB0B4\uB9AC\uB9C9",breakL:"\u2190 \uC67C\uCABD \uD728",breakR:"\uC624\uB978\uCABD \uD728 \u2192",flat:"\uD3C9\uC9C0",hole:"\uD640",sunk:"\uD640\uC778! {n}\uD0C0",fishHelp:"\uAE38\uAC8C \uB20C\uB7EC \uCE90\uC2A4\uD305 \xB7 \uC785\uC9C8 \uC624\uBA74 \uD0ED! \xB7 \uB20C\uB7EC\uC11C \uAC10\uACE0 \uD150\uC158 \uC720\uC9C0",cast:"\uCE90\uC2A4\uD305",waiting:"\uC785\uC9C8 \uAE30\uB2E4\uB9AC\uB294 \uC911\u2026",bite:"\uC785\uC9C8! \uC9C0\uAE08 \uD0ED!",reel:"\uAC10\uAE30",tension:"\uD150\uC158",distance:"\uAC70\uB9AC",snapped:"\uC904\uC774 \uB04A\uC5B4\uC84C\uC5B4\uC694",escaped:"\uBB3C\uACE0\uAE30\uAC00 \uB3C4\uB9DD\uAC14\uC5B4\uC694",missed:"\uB193\uCCE4\uC5B4\uC694",caught:"{fish} {kg}kg \uC7A1\uC558\uB2E4!",billHelp:"\uB4DC\uB798\uADF8/\u2190\u2192 \uC870\uC900 \xB7 \uAE38\uAC8C \uB20C\uB7EC \uD798 \uC870\uC808 \uD6C4 \uC0F7",yourTurn:"\uB0B4 \uCC28\uB840",waitTurn:"{name} \uCC28\uB840",potted:"\uD3EC\uCF13 {n}\uAC1C",rack:"\uB2E4\uC2DC \uBC30\uCE58",scratch:"\uC2A4\uD06C\uB798\uCE58!",power:"\uD798",evCatch:"{name}\uB2D8\uC774 {fish} {kg}kg\uC744 \uC7A1\uC558\uC5B4\uC694",evSink:"{name}\uB2D8\uC774 {hole}\uBC88 \uD640\uC744 {n}\uD0C0\uB85C \uB05D\uB0C8\uC5B4\uC694",evPot:"{name}\uB2D8\uC774 {n}\uBC88 \uACF5\uC744 \uB123\uC5C8\uC5B4\uC694",joined:"{name}\uB2D8\uC774 \uB4E4\uC5B4\uC654\uC5B4\uC694",left:"{name}\uB2D8\uC774 \uB098\uAC14\uC5B4\uC694",slowDown:"\uBA54\uC2DC\uC9C0\uB97C \uB108\uBB34 \uBE68\uB9AC \uBCF4\uB0B4\uACE0 \uC788\uC5B4\uC694",noTr:"\uBC88\uC5ED \uC11C\uBC84 \uBBF8\uC5F0\uACB0",translated:"\uBC88\uC5ED\uB428",showOrig:"\uC6D0\uBB38",venuePick:"\uD50C\uB808\uC774\uD560 \uC7A5\uC18C\uB97C \uACE0\uB974\uC138\uC694",venueGolf:"\uACE8\uD504\uC7A5",venueFish:"\uB09A\uC2DC\uD130",goVenue:"\uC774\uB3D9",backHub:"\uAD11\uC7A5\uC73C\uB85C",here:"\uD604\uC7AC \uC704\uCE58",quality:"\uD654\uC9C8",auto:"\uC790\uB3D9",party:"\uD30C\uD2F0",partyHint:"\uCD5C\uB300 {n}\uBA85 \xB7 \uAC19\uC740 \uAE30\uAE30\uC5D0\uC11C \uAC8C\uC2A4\uD2B8 \uCD94\uAC00 \uAC00\uB2A5",guest:"\uAC8C\uC2A4\uD2B8",me:"\uB098",emptySlot:"\uBE48 \uC790\uB9AC",joinParty:"\uCC38\uAC00",leaveParty:"\uD30C\uD2F0 \uB098\uAC00\uAE30",addGuest:"\uAC8C\uC2A4\uD2B8",startGame:"\uAC8C\uC784 \uC2DC\uC791",partyFull:"\uD30C\uD2F0\uAC00 \uAC00\uB4DD \uCC3C\uC5B4\uC694",screenGolf:"\uC2A4\uD06C\uB9B0 \uACE8\uD504",golf3:"3\uD640 \uB77C\uC6B4\uB4DC",golf1:"1\uBC88 \uD640",golf1b:"2\uBC88 \uD640 (\uD30C3)",scoreCard:"\uC2A4\uCF54\uC5B4\uCE74\uB4DC",player:"\uD50C\uB808\uC774\uC5B4",pinDist:"\uD540\uAE4C\uC9C0",wind:"\uBC14\uB78C",lie:"\uB77C\uC774",putter:"\uD37C\uD130",strokeN:"{n}\uBC88\uC9F8 \uC0F7",spectating:"\uAD00\uC804",lie_tee:"\uD2F0",lie_fairway:"\uD398\uC5B4\uC6E8\uC774",lie_rough:"\uB7EC\uD504",lie_bunker:"\uBC99\uCEE4",lie_green:"\uADF8\uB9B0",lie_fringe:"\uD504\uB9B0\uC9C0",lie_water:"\uC6CC\uD130 \uD574\uC800\uB4DC",lie_ob:"OB",shotData:"\uC0F7 \uB370\uC774\uD130",ballSpeed:"\uBCFC \uC2A4\uD53C\uB4DC",launchAngle:"\uBC1C\uC0AC\uAC01",backSpin:"\uBC31\uC2A4\uD540",sideSpin:"\uC0AC\uC774\uB4DC\uC2A4\uD540",apex:"\uCD5C\uACE0 \uB192\uC774",carry:"\uCE90\uB9AC",total:"\uCD1D\uAC70\uB9AC",penaltyWater:"\uD574\uC800\uB4DC! 1\uBC8C\uD0C0 \uD6C4 \uB4DC\uB86D",penaltyOB:"OB! 1\uBC8C\uD0C0, \uC6D0\uB798 \uC790\uB9AC\uC5D0\uC11C \uB2E4\uC2DC",pickup:"\uB354\uBE14\uD30C \xB7 \uD640\uC544\uC6C3",holeInOne:"\uD640\uC778\uC6D0!!",sc_m3:"\uC54C\uBC14\uD2B8\uB85C\uC2A4",sc_m2:"\uC774\uAE00",sc_m1:"\uBC84\uB514",sc_0:"\uD30C",sc_1:"\uBCF4\uAE30",sc_2:"\uB354\uBE14\uBCF4\uAE30",sc_3:"\uD2B8\uB9AC\uD50C+",fishHelp2:"\uC2A4\uD398\uC774\uC2A4 \uAE38\uAC8C \uB20C\uB7EC \uCE90\uC2A4\uD305 \xB7 \uCC0C\uAC00 \uC465 \uC7A0\uAE30\uBA74 \uD0ED(\uCC54\uC9C8) \xB7 \uD30C\uC774\uD305: \uB204\uB974\uACE0 \uAC10\uAE30 + \uBB3C\uACE0\uAE30 \uBC18\uB300 \uBC29\uD5A5(\u2190\u2192)\uC73C\uB85C \uBC84\uD2F0\uAE30",nibble:"\uD1A1\uD1A1\u2026 \uAC74\uB4DC\uB9AC\uB294 \uC911",biteNow:"\uCC0C\uAC00 \uC7A0\uACBC\uB2E4! \uC9C0\uAE08 \uCC54\uC9C8!",tooEarly:"\uB108\uBB34 \uBE68\uB9AC \uCC58\uC5B4\uC694, \uBB3C\uACE0\uAE30\uAC00 \uB3C4\uB9DD\uAC14\uC5B4\uC694",hooked:"\uAC78\uC5C8\uB2E4!",fishStamina:"\uBB3C\uACE0\uAE30 \uCCB4\uB825",lineLeft:"\uB0A8\uC740 \uC904",pullLeft:"\u2190 \uC67C\uCABD\uC73C\uB85C \uBC84\uD168!",pullRight:"\uC624\uB978\uCABD\uC73C\uB85C \uBC84\uD168! \u2192",running:"\uBB3C\uACE0\uAE30\uAC00 \uCC28\uACE0 \uB098\uAC00\uC694",keep:"\uC5B4\uB9DD\uC5D0 \uB123\uAE30",release:"\uB193\uC544\uC8FC\uAE30",keepNet:"\uC5B4\uB9DD",dex:"\uB3C4\uAC10",newSpecies:"\uC0C8\uB85C\uC6B4 \uC5B4\uC885!",newRecord:"\uCD5C\uB300\uC5B4 \uAC31\uC2E0!",netFull:"\uC5B4\uB9DD\uC774 \uAC00\uB4DD \uCC3C\uC5B4\uC694 (20\uB9C8\uB9AC)",released:"\uB193\uC544\uC92C\uC5B4\uC694",seaWater:"\uBC14\uB2E4",freshWater:"\uBBFC\uBB3C",length:"\uAE38\uC774",weight:"\uBB34\uAC8C",totalWeight:"\uCD1D \uBB34\uAC8C",best:"\uCD5C\uB300",unknown:"???",emptyNet:"\uC544\uC9C1 \uBE44\uC5B4 \uC788\uC5B4\uC694",sell:"\uBAA8\uB450 \uBC29\uB958",carom3:"3\uAD6C",carom3s:"3\uCFE0\uC158",carom4:"4\uAD6C",carom4s:"\uD55C\uAD6D\uC2DD 4\uAD6C",pool8:"\uD3EC\uCF13\uBCFC",pool8s:"8\uBCFC",tipOffset:"\uB2F9\uC810",chalk:"\uCD08\uD06C",pullBack:"\uB2F9\uACA8\uC11C \uC0F7",follow:"\uBC00\uC5B4\uCE58\uAE30",draw:"\uB04C\uC5B4\uCE58\uAE30",rightEng:"\uC6B0\uD68C\uC804",leftEng:"\uC88C\uD68C\uC804",centerBall:"\uC911\uC559 (\uBB34\uD68C\uC804)",miscue:"\uBBF8\uC2A4\uD050!",point:"\uB4DD\uC810",needCush:"\uCFE0\uC158 \uBD80\uC871 ({n}\uCFE0\uC158)",miss:"\uC2E4\uD328 \xB7 \uCC28\uB840 \uB118\uAE40",foulOpp:"\uC0C1\uB300 \uACF5 \uD130\uCE58",foulNone:"\uD5DB\uCE68",wins:"\uC2B9\uB9AC!",foulWrong:"\uBA3C\uC800 \uB9DE\uD78C \uACF5\uC774 \uD2C0\uB9BC",foulRail:"\uCFE0\uC158 \uC5C6\uC74C",eightWin:"8\uBC88 \uBCFC \uC131\uACF5! \uC2B9\uB9AC",eightLose:"8\uBC88 \uBCFC \uC2E4\uD328 \xB7 \uD328\uBC30",solid:"\uC194\uB9AC\uB4DC(1~7)",stripe:"\uC2A4\uD2B8\uB77C\uC774\uD504(9~15)",assigned:"\uBC30\uC815",foul:"\uD30C\uC6B8",ballInHand:"\uD504\uB9AC\uBCFC",viewTop:"\uD0D1\uBDF0",viewCue:"\uD050 \uC2DC\uC810",ballInHandHelp:"\uD504\uB9AC\uBCFC: \uD770 \uACF5\uC744 \uB04C\uC5B4\uC11C \uB193\uACE0 \u2192 \uC870\uC900 \u2192 \uAC8C\uC774\uC9C0\uB97C \uC544\uB798\uB85C \uB2F9\uACBC\uB2E4 \uB193\uAE30",billCueHelp:"1\uC778\uCE6D: \uB4DC\uB798\uADF8 \u2190\u2192 \uC870\uC900 \xB7 \u2191\u2193 \uC2DC\uC57C \uAC01\uB3C4 \xB7 \uD720 \uD655\uB300/\uCD95\uC18C \xB7 Shift \uBBF8\uC138 \uC870\uC900 \xB7 \uC2A4\uD398\uC774\uC2A4/\uAC8C\uC774\uC9C0\uB85C \uC0F7",billHelp2:"\uD14C\uC774\uBE14 \uD074\uB9AD/\uB4DC\uB798\uADF8 \uC870\uC900 \xB7 \u25C0\u25B6 \uBBF8\uC138\uC870\uC815 \xB7 \uB2F9\uC810(\u2191\u2193 Z X) \xB7 [ ] \uD050 \uAC01\uB3C4 \xB7 \uAC8C\uC774\uC9C0\uB97C \uB2F9\uACBC\uB2E4 \uB193\uAC70\uB098 \uC2A4\uD398\uC774\uC2A4 \uAE38\uAC8C \u2192 \uB193\uAE30 \xB7 C \uCD08\uD06C \xB7 V \uC2DC\uC810 \xB7 \uC6B0\uD074\uB9AD \uB4DC\uB798\uADF8 \uC790\uC720 \uC2DC\uC810",target:"\uBAA9\uD45C",group:"\uADF8\uB8F9",ball:"\uACF5",score:"\uC810\uC218",innings:"\uC774\uB2DD",highRun:"\uD558\uC774\uB7F0",open:"\uBBF8\uC815",roundDone:"\uB77C\uC6B4\uB4DC \uC885\uB8CC",playAgain:"\uB2E4\uC2DC \uD558\uAE30",backLobby:"\uD30C\uD2F0 \uD654\uBA74",swing:"\uC2A4\uC719",swingHelp:"\u2190\u2192 \uC870\uC900 \xB7 Q/E \uD074\uB7FD \xB7 \uC2A4\uD398\uC774\uC2A4 \uB204\uB974\uBA74 \uBC31\uC2A4\uC719 \u2192 \uB5BC\uBA74 \uD30C\uC6CC \u2192 \uB2E4\uC2DC \uB20C\uB7EC \uC784\uD329\uD2B8(\uD558\uC580 \uCE78)",puttHelp:"\u2190\u2192 \uC870\uC900(\uC815\uBC00) \xB7 \uC2A4\uD398\uC774\uC2A4 \uB204\uB974\uACE0 \uC788\uB2E4\uAC00 \uB5BC\uBA74 \uD37C\uD305 (\uAC70\uB9AC \uD45C\uC2DC \uCC38\uACE0)"},en:{title:"WorldPlay",subtitle:"Golf, fishing & billiards with the world",name:"Nickname",lang:"Language",color:"Avatar color",start:"Enter",online:"Online",offline:"Offline demo",players:"online",chatPh:"Type a message (auto-translated)",send:"Send",golf:"Golf",fishing:"Fishing",billiards:"Billiards",play:"Play",exit:"Exit",globe:"Globe",golfHelp:"Drag / \u2190\u2192 to aim \xB7 hold to charge, release to putt",strokes:"Strokes",nStrokes:"{n} strokes",sumTotal:"Total",greenRead:"Green read",slopeUp:"Uphill",slopeDown:"Downhill",breakL:"\u2190 breaks left",breakR:"breaks right \u2192",flat:"flat",hole:"Hole",sunk:"In the hole! {n} strokes",fishHelp:"Hold to cast \xB7 tap when it bites \xB7 hold to reel, keep tension",cast:"Cast",waiting:"Waiting for a bite\u2026",bite:"Bite! Tap now!",reel:"Reel",tension:"Tension",distance:"Distance",snapped:"The line snapped",escaped:"The fish got away",missed:"Missed it",caught:"Caught a {fish}, {kg} kg!",billHelp:"Drag / \u2190\u2192 to aim \xB7 hold to charge, release to shoot",yourTurn:"Your turn",waitTurn:"{name}'s turn",potted:"Potted {n}",rack:"Re-rack",scratch:"Scratch!",power:"Power",evCatch:"{name} caught a {fish}, {kg} kg",evSink:"{name} finished hole {hole} in {n}",evPot:"{name} potted ball {n}",joined:"{name} joined",left:"{name} left",slowDown:"You are sending messages too fast",noTr:"translator offline",translated:"translated",showOrig:"original",venuePick:"Pick a place to play",venueGolf:"Golf courses",venueFish:"Fishing spots",goVenue:"Go",backHub:"Back to plaza",here:"You are here",quality:"Quality",auto:"Auto",party:"Party",partyHint:"Up to {n} \xB7 add guests on this device",guest:"Guest",me:"me",emptySlot:"Empty",joinParty:"Join",leaveParty:"Leave",addGuest:"Guest",startGame:"Start",partyFull:"Party is full",screenGolf:"Screen Golf",golf3:"3-hole round",golf1:"Hole 1",golf1b:"Hole 2 (par 3)",scoreCard:"Scorecard",player:"Player",pinDist:"To pin",wind:"Wind",lie:"Lie",putter:"Putter",strokeN:"shot {n}",spectating:"watching",lie_tee:"Tee",lie_fairway:"Fairway",lie_rough:"Rough",lie_bunker:"Bunker",lie_green:"Green",lie_fringe:"Fringe",lie_water:"Water",lie_ob:"OB",shotData:"Shot data",ballSpeed:"Ball speed",launchAngle:"Launch",backSpin:"Back spin",sideSpin:"Side spin",apex:"Apex",carry:"Carry",total:"Total",penaltyWater:"Water! 1-stroke penalty, drop",penaltyOB:"OB! 1-stroke penalty, replay",pickup:"Double par \xB7 picked up",holeInOne:"HOLE IN ONE!!",sc_m3:"Albatross",sc_m2:"Eagle",sc_m1:"Birdie",sc_0:"Par",sc_1:"Bogey",sc_2:"Double bogey",sc_3:"Triple+",fishHelp2:"Hold Space to cast \xB7 tap when the float goes under \xB7 fight: hold to reel and lean against the fish (\u2190\u2192)",nibble:"Nibbling\u2026",biteNow:"Float is under! Strike now!",tooEarly:"Too early, the fish got spooked",hooked:"Fish on!",fishStamina:"Fish stamina",lineLeft:"Line out",pullLeft:"\u2190 Lean left!",pullRight:"Lean right! \u2192",running:"The fish is running",keep:"Keep in net",release:"Release",keepNet:"Keep net",dex:"Fish guide",newSpecies:"New species!",newRecord:"New personal best!",netFull:"Keep net is full (20)",released:"Released",seaWater:"Sea",freshWater:"Freshwater",length:"Length",weight:"Weight",totalWeight:"Total",best:"Best",unknown:"???",emptyNet:"Nothing yet",sell:"Release all",carom3:"3-ball",carom3s:"3-cushion",carom4:"4-ball",carom4s:"Korean 4-ball",pool8:"Pool",pool8s:"8-ball",tipOffset:"Tip",chalk:"Chalk",pullBack:"pull to shoot",follow:"Follow",draw:"Draw",rightEng:"Right",leftEng:"Left",centerBall:"Centre (no spin)",miscue:"Miscue!",point:"Point",needCush:"Not enough cushions ({n})",miss:"Miss \xB7 next player",foulOpp:"Touched opponent's ball",foulNone:"No contact",wins:"wins!",foulWrong:"Wrong ball first",foulRail:"No rail after contact",eightWin:"8-ball down! You win",eightLose:"8-ball foul \xB7 you lose",solid:"Solids (1\u20137)",stripe:"Stripes (9\u201315)",assigned:"assigned",foul:"Foul",ballInHand:"Ball in hand",viewTop:"Top",viewCue:"Cue view",ballInHandHelp:"Ball in hand: drag the white ball, aim, then pull the gauge down and release",billCueHelp:"First person: drag \u2190\u2192 to aim \xB7 \u2191\u2193 to tilt the view \xB7 wheel to zoom \xB7 Shift for fine aim \xB7 Space/gauge to shoot",billHelp2:"Click/drag the table to aim \xB7 \u25C0\u25B6 fine \xB7 tip (\u2191\u2193 Z X) \xB7 pull the gauge or hold Space \u2192 release \xB7 [ ] cue angle \xB7 C chalk \xB7 V view \xB7 right-drag free view",target:"Target",group:"Group",ball:"Ball",score:"Score",innings:"Inn.",highRun:"High run",open:"Open",roundDone:"Round complete",playAgain:"Play again",backLobby:"Party screen",swing:"Swing",swingHelp:"\u2190\u2192 aim \xB7 Q/E club \xB7 press Space to backswing \u2192 release for power \u2192 press again at the white zone",puttHelp:"\u2190\u2192 fine aim \xB7 hold Space, release to putt (see distance)"},ja:{title:"\u30EF\u30FC\u30EB\u30C9\u30D7\u30EC\u30A4",subtitle:"\u4E16\u754C\u4E2D\u306E\u53CB\u9054\u3068\u30B4\u30EB\u30D5\u30FB\u91E3\u308A\u30FB\u30D3\u30EA\u30E4\u30FC\u30C9",name:"\u30CB\u30C3\u30AF\u30CD\u30FC\u30E0",lang:"\u8A00\u8A9E",color:"\u30AD\u30E3\u30E9\u306E\u8272",start:"\u5165\u5834",online:"\u30AA\u30F3\u30E9\u30A4\u30F3",offline:"\u30AA\u30D5\u30E9\u30A4\u30F3\u30C7\u30E2",players:"\u4EBA\u304C\u30AA\u30F3\u30E9\u30A4\u30F3",chatPh:"\u30E1\u30C3\u30BB\u30FC\u30B8\uFF08\u81EA\u52D5\u7FFB\u8A33\uFF09",send:"\u9001\u4FE1",golf:"\u30B4\u30EB\u30D5",fishing:"\u91E3\u308A",billiards:"\u30D3\u30EA\u30E4\u30FC\u30C9",play:"\u30B9\u30BF\u30FC\u30C8",exit:"\u7D42\u4E86",globe:"\u5730\u7403\u5100",golfHelp:"\u30C9\u30E9\u30C3\u30B0/\u2190\u2192\u3067\u72D9\u3046\u30FB\u9577\u62BC\u3057\u3067\u529B\u3092\u305F\u3081\u3066\u96E2\u3059",strokes:"\u6253\u6570",hole:"\u30DB\u30FC\u30EB",sunk:"\u30AB\u30C3\u30D7\u30A4\u30F3\uFF01{n}\u6253",fishHelp:"\u9577\u62BC\u3057\u3067\u30AD\u30E3\u30B9\u30C8\u30FB\u30A2\u30BF\u30EA\u3067\u30BF\u30C3\u30D7\u30FB\u62BC\u3057\u3066\u5DFB\u304D\u30C6\u30F3\u30B7\u30E7\u30F3\u7DAD\u6301",cast:"\u30AD\u30E3\u30B9\u30C8",waiting:"\u30A2\u30BF\u30EA\u5F85\u3061\u2026",bite:"\u30A2\u30BF\u30EA\uFF01\u4ECA\u30BF\u30C3\u30D7\uFF01",reel:"\u5DFB\u304F",tension:"\u30C6\u30F3\u30B7\u30E7\u30F3",distance:"\u8DDD\u96E2",snapped:"\u7CF8\u304C\u5207\u308C\u305F",escaped:"\u9B5A\u306B\u9003\u3052\u3089\u308C\u305F",missed:"\u9003\u3057\u305F",caught:"{fish} {kg}kg \u91E3\u308C\u305F\uFF01",billHelp:"\u30C9\u30E9\u30C3\u30B0/\u2190\u2192\u3067\u72D9\u3046\u30FB\u9577\u62BC\u3057\u3067\u529B\u3092\u305F\u3081\u3066\u30B7\u30E7\u30C3\u30C8",yourTurn:"\u3042\u306A\u305F\u306E\u756A",waitTurn:"{name}\u306E\u756A",potted:"\u30DD\u30B1\u30C3\u30C8 {n}",rack:"\u518D\u914D\u7F6E",scratch:"\u30B9\u30AF\u30E9\u30C3\u30C1\uFF01",power:"\u30D1\u30EF\u30FC",evCatch:"{name}\u3055\u3093\u304C{fish} {kg}kg\u3092\u91E3\u308A\u307E\u3057\u305F",evSink:"{name}\u3055\u3093\u304C{hole}\u756A\u30DB\u30FC\u30EB\u3092{n}\u6253\u3067\u7D42\u4E86",evPot:"{name}\u3055\u3093\u304C{n}\u756A\u30DC\u30FC\u30EB\u3092\u30DD\u30B1\u30C3\u30C8",joined:"{name}\u3055\u3093\u304C\u53C2\u52A0",left:"{name}\u3055\u3093\u304C\u9000\u51FA",slowDown:"\u9001\u4FE1\u304C\u901F\u3059\u304E\u307E\u3059",noTr:"\u7FFB\u8A33\u30B5\u30FC\u30D0\u30FC\u672A\u63A5\u7D9A",translated:"\u7FFB\u8A33\u6E08\u307F",showOrig:"\u539F\u6587",venuePick:"\u30D7\u30EC\u30A4\u3059\u308B\u5834\u6240\u3092\u9078\u629E",venueGolf:"\u30B4\u30EB\u30D5\u5834",venueFish:"\u91E3\u308A\u5834",goVenue:"\u79FB\u52D5",backHub:"\u5E83\u5834\u3078",here:"\u73FE\u5728\u5730",quality:"\u753B\u8CEA",auto:"\u81EA\u52D5"},zh:{title:"\u4E16\u754C\u4E50\u56ED",subtitle:"\u548C\u5168\u4E16\u754C\u4E00\u8D77\u6253\u9AD8\u5C14\u592B\u3001\u9493\u9C7C\u3001\u53F0\u7403",name:"\u6635\u79F0",lang:"\u8BED\u8A00",color:"\u89D2\u8272\u989C\u8272",start:"\u8FDB\u5165",online:"\u5728\u7EBF",offline:"\u79BB\u7EBF\u6F14\u793A",players:"\u4EBA\u5728\u7EBF",chatPh:"\u8F93\u5165\u6D88\u606F\uFF08\u81EA\u52A8\u7FFB\u8BD1\uFF09",send:"\u53D1\u9001",golf:"\u9AD8\u5C14\u592B",fishing:"\u9493\u9C7C",billiards:"\u53F0\u7403",play:"\u5F00\u59CB",exit:"\u9000\u51FA",globe:"\u5730\u7403\u4EEA",golfHelp:"\u62D6\u52A8/\u2190\u2192\u7784\u51C6 \xB7 \u957F\u6309\u84C4\u529B\u677E\u5F00\u63A8\u6746",strokes:"\u6746\u6570",hole:"\u6D1E",sunk:"\u8FDB\u6D1E\uFF01{n}\u6746",fishHelp:"\u957F\u6309\u629B\u7AFF \xB7 \u54AC\u94A9\u65F6\u70B9\u51FB \xB7 \u6309\u4F4F\u6536\u7EBF\u4FDD\u6301\u5F20\u529B",cast:"\u629B\u7AFF",waiting:"\u7B49\u5F85\u54AC\u94A9\u2026",bite:"\u54AC\u94A9\u4E86\uFF01\u5FEB\u70B9\uFF01",reel:"\u6536\u7EBF",tension:"\u5F20\u529B",distance:"\u8DDD\u79BB",snapped:"\u7EBF\u65AD\u4E86",escaped:"\u9C7C\u8DD1\u4E86",missed:"\u9519\u8FC7\u4E86",caught:"\u9493\u5230 {fish} {kg}kg\uFF01",billHelp:"\u62D6\u52A8/\u2190\u2192\u7784\u51C6 \xB7 \u957F\u6309\u84C4\u529B\u677E\u5F00\u51FB\u7403",yourTurn:"\u8F6E\u5230\u4F60",waitTurn:"\u8F6E\u5230{name}",potted:"\u8FDB\u7403 {n}",rack:"\u91CD\u65B0\u6446\u7403",scratch:"\u6BCD\u7403\u843D\u888B\uFF01",power:"\u529B\u5EA6",evCatch:"{name} \u9493\u5230 {fish} {kg}kg",evSink:"{name} \u7528{n}\u6746\u5B8C\u6210\u7B2C{hole}\u6D1E",evPot:"{name} \u6253\u8FDB{n}\u53F7\u7403",joined:"{name} \u52A0\u5165\u4E86",left:"{name} \u79BB\u5F00\u4E86",slowDown:"\u53D1\u9001\u592A\u5FEB\u4E86",noTr:"\u7FFB\u8BD1\u670D\u52A1\u5668\u672A\u8FDE\u63A5",translated:"\u5DF2\u7FFB\u8BD1",showOrig:"\u539F\u6587",venuePick:"\u9009\u62E9\u6E38\u73A9\u5730\u70B9",venueGolf:"\u9AD8\u5C14\u592B\u7403\u573A",venueFish:"\u9493\u9C7C\u70B9",goVenue:"\u524D\u5F80",backHub:"\u56DE\u5E7F\u573A",here:"\u5F53\u524D\u4F4D\u7F6E",quality:"\u753B\u8D28",auto:"\u81EA\u52A8"},es:{title:"WorldPlay",subtitle:"Golf, pesca y billar con todo el mundo",name:"Apodo",lang:"Idioma",color:"Color del avatar",start:"Entrar",online:"En l\xEDnea",offline:"Demo sin conexi\xF3n",players:"en l\xEDnea",chatPh:"Escribe (traducci\xF3n autom\xE1tica)",send:"Enviar",golf:"Golf",fishing:"Pesca",billiards:"Billar",play:"Jugar",exit:"Salir",globe:"Globo",golfHelp:"Arrastra / \u2190\u2192 para apuntar \xB7 mant\xE9n para cargar y suelta",strokes:"Golpes",hole:"Hoyo",sunk:"\xA1Al hoyo! {n} golpes",fishHelp:"Mant\xE9n para lanzar \xB7 toca al picar \xB7 mant\xE9n para recoger",cast:"Lanzar",waiting:"Esperando que piquen\u2026",bite:"\xA1Pica! \xA1Toca ya!",reel:"Recoger",tension:"Tensi\xF3n",distance:"Distancia",snapped:"Se rompi\xF3 el sedal",escaped:"Se escap\xF3 el pez",missed:"Se fue",caught:"\xA1{fish} de {kg} kg!",billHelp:"Arrastra / \u2190\u2192 para apuntar \xB7 mant\xE9n y suelta para tirar",yourTurn:"Tu turno",waitTurn:"Turno de {name}",potted:"Metidas {n}",rack:"Reiniciar",scratch:"\xA1Falta!",power:"Fuerza",evCatch:"{name} pesc\xF3 un {fish} de {kg} kg",evSink:"{name} termin\xF3 el hoyo {hole} en {n}",evPot:"{name} meti\xF3 la bola {n}",joined:"{name} entr\xF3",left:"{name} sali\xF3",slowDown:"Env\xEDas mensajes muy r\xE1pido",noTr:"traductor sin conexi\xF3n",translated:"traducido",showOrig:"original",venuePick:"Elige d\xF3nde jugar",venueGolf:"Campos de golf",venueFish:"Zonas de pesca",goVenue:"Ir",backHub:"Volver a la plaza",here:"Est\xE1s aqu\xED",quality:"Calidad",auto:"Auto"}},zf={ko:{bluegill:"\uBE14\uB8E8\uAE38",crucian:"\uBD95\uC5B4",bass:"\uBC30\uC2A4",carp:"\uC789\uC5B4",trout:"\uC1A1\uC5B4",mandarin:"\uC3D8\uAC00\uB9AC",catfish:"\uBA54\uAE30",pike:"\uAC15\uAF2C\uCE58\uACE0\uAE30",eel:"\uBC40\uC7A5\uC5B4",golden:"\uD669\uAE08 \uC789\uC5B4",mackerel:"\uACE0\uB4F1\uC5B4",rockfish:"\uC6B0\uB7ED",flounder:"\uAD11\uC5B4",blackporgy:"\uAC10\uC131\uB3D4",seabream:"\uCC38\uB3D4",seabass:"\uB18D\uC5B4",yellowtail:"\uBC29\uC5B4",salmon:"\uC5F0\uC5B4",tuna:"\uCC38\uCE58"},en:{bluegill:"Bluegill",crucian:"Crucian Carp",bass:"Black Bass",carp:"Carp",trout:"Trout",mandarin:"Mandarin Fish",catfish:"Catfish",pike:"Pike",eel:"Eel",golden:"Golden Koi",mackerel:"Mackerel",rockfish:"Rockfish",flounder:"Flounder",blackporgy:"Black Porgy",seabream:"Red Sea Bream",seabass:"Sea Bass",yellowtail:"Yellowtail",salmon:"Salmon",tuna:"Bluefin Tuna"},ja:{bluegill:"\u30D6\u30EB\u30FC\u30AE\u30EB",crucian:"\u30D5\u30CA",bass:"\u30D6\u30E9\u30C3\u30AF\u30D0\u30B9",carp:"\u30B3\u30A4",trout:"\u30DE\u30B9",mandarin:"\u30B3\u30A6\u30E9\u30A4\u30B1\u30C4\u30AE\u30E7",catfish:"\u30CA\u30DE\u30BA",pike:"\u30D1\u30A4\u30AF",eel:"\u30A6\u30CA\u30AE",golden:"\u9EC4\u91D1\u306E\u9BC9",mackerel:"\u30B5\u30D0",rockfish:"\u30AF\u30ED\u30BD\u30A4",flounder:"\u30D2\u30E9\u30E1",blackporgy:"\u30AF\u30ED\u30C0\u30A4",seabream:"\u30DE\u30C0\u30A4",seabass:"\u30B9\u30BA\u30AD",yellowtail:"\u30D6\u30EA",salmon:"\u30B5\u30B1",tuna:"\u30AF\u30ED\u30DE\u30B0\u30ED"},zh:{bluegill:"\u84DD\u9CC3\u592A\u9633\u9C7C",crucian:"\u9CAB\u9C7C",bass:"\u9ED1\u9C88",carp:"\u9CA4\u9C7C",trout:"\u9CDF\u9C7C",mandarin:"\u9CDC\u9C7C",catfish:"\u9CB6\u9C7C",pike:"\u72D7\u9C7C",eel:"\u9CD7\u9C7C",golden:"\u91D1\u9526\u9CA4",mackerel:"\u9CAD\u9C7C",rockfish:"\u8BB8\u6C0F\u5E73\u9C89",flounder:"\u7259\u9C86",blackporgy:"\u9ED1\u9CB7",seabream:"\u771F\u9CB7",seabass:"\u9C88\u9C7C",yellowtail:"\u9C24\u9C7C",salmon:"\u4E09\u6587\u9C7C",tuna:"\u84DD\u9CCD\u91D1\u67AA\u9C7C"},es:{bluegill:"Mojarra",crucian:"Carp\xEDn",bass:"Lubina negra",carp:"Carpa",trout:"Trucha",mandarin:"Pez mandar\xEDn",catfish:"Bagre",pike:"Lucio",eel:"Anguila",golden:"Koi dorado",mackerel:"Caballa",rockfish:"Rocote",flounder:"Lenguado",blackporgy:"Sargo negro",seabream:"Pargo rojo",seabass:"Lubina",yellowtail:"Medregal",salmon:"Salm\xF3n",tuna:"At\xFAn rojo"}},br="en";function Ff(i){br=i}function rn(){return br}function U(i,t){let e=(Zh[br]&&Zh[br][i])??Zh.en[i]??i;if(t)for(let n in t)e=e.replace(`{${n}}`,t[n]);return e}var Qa={ko:{},en:{}};function Bf(i){for(let t in i)Object.assign(Qa[t]||(Qa[t]={}),i[t])}function wi(i,t=br){var e,n;return((e=zf[t])==null?void 0:e[i])||((n=Qa[t])==null?void 0:n[i])||Qa.en[i]||zf.en[i]||i}function Ss(i,t=br){return i[t]||(t==="ko"?i.ko:i.en)||i.id}var Es=new C(0,0,2500),Si=[{par:4,path:[[0,0],[150,0],[255,18],[352,26]],fw:32,green:{x:352,z:26,r:15,slope:[.018,-.012],crown:.012},pin:[356,22],bunkers:[[238,-6,10,5],[338,46,7,4.5],[369,9,6,4]],water:[],dog:"R"},{par:3,path:[[0,0],[70,-3],[168,-8]],fw:0,green:{x:168,z:-8,r:14,slope:[-.022,.008],crown:-.008},pin:[163,-12],bunkers:[[153,9,6,3.5],[182,-25,7,3.5],[186,4,4,5]],water:[[96,-5,34,20]]},{par:5,path:[[0,0],[210,-14],[335,12],[498,-10]],fw:34,green:{x:498,z:-10,r:16,slope:[.01,.024],crown:.015},pin:[503,-6],bunkers:[[205,6,9,5],[228,-36,8,5],[480,10,7,4],[485,-30,6,4]],water:[[300,-4,9,48]]}],Tb={ob:[58,88,36],rough:[74,112,45],fairway:[104,150,60],fringe:[98,156,64],green:[112,172,70],tee:[108,156,62],bunker:[222,205,160],water:[40,78,90]};function Ab(i,t,e){let n=1e9,s=0,r=0;for(let o=0;o<e.length-1;o++){let[a,l]=e[o],[c,h]=e[o+1],u=c-a,d=h-l,f=u*u+d*d,g=Math.sqrt(f),x=Math.max(0,Math.min(1,((i-a)*u+(t-l)*d)/f)),m=Math.hypot(i-a-u*x,t-l-d*x);m<n&&(n=m,s=r+x*g),r+=g}return[n,s]}var Of=(i,t,[e,n,s,r],o=0)=>((i-e)/(s+o))**2+((t-n)/(r+o))**2<=1;function Kh(i,t,e){for(let l of i.water)if(Of(t,e,l))return"water";for(let l of i.bunkers)if(Of(t,e,l))return"bunker";let n=i.green,s=Math.hypot(t-n.x,e-n.z),r=n.r*(1+.12*Math.sin(Math.atan2(e-n.z,t-n.x)*2+1));if(s<r)return"green";if(s<r+2.2)return"fringe";if(Math.abs(t)<5&&Math.abs(e)<4)return"tee";let[o,a]=Ab(t,e,i.path);return t<-25?"ob":i.fw&&a>28&&o<i.fw/2*(1+.1*Math.sin(a*.05))?"fairway":o>(i.fw||24)/2+42?"ob":"rough"}function Jh(i,t){let e=Math.imul(i|0,374761393)^Math.imul(t|0,668265263);return e=Math.imul(e^e>>>13,1274126177),((e^e>>>16)>>>0)/4294967296}var tl=class{constructor(t,e){this.scene=t,this.seed=e,this.group=new Jt,this.group.position.copy(Es),this.group.visible=!1,t.add(this.group);let n=new nt(new je(1600,48),Lt("grass",7311178));n.rotation.x=-Math.PI/2,n.position.y=-.05,n.receiveShadow=!0,this.group.add(n),this.buildHills(),this.holeGroup=null,this.index=-1}buildHills(){let t=_s(this.seed+"hills"),e=Lt("leaves",5599306);for(let n=0;n<22;n++){let s=n/22*Math.PI*2+t()*.2,r=750+t()*450,o=90+t()*160,a=new nt(new Ce(1,16,8,0,Math.PI*2,0,Math.PI/2),e);a.scale.set(o*(1.4+t()),o*(.25+t()*.25),o),a.position.set(250+Math.cos(s)*r,-2,Math.sin(s)*r),this.group.add(a)}}get visible(){return this.group.visible}set visible(t){this.group.visible=t}toWorld(t,e,n=new C){return n.set(t+Es.x,0,e+Es.z)}lie(t,e){return Kh(this.hole,t-Es.x,e-Es.z)}slopeAt(t,e){let n=this.hole,s=n==null?void 0:n.green;if(!(s!=null&&s.slope))return null;let r=t-Es.x,o=e-Es.z,a=r-s.x,l=o-s.z;if(Math.hypot(a,l)>s.r+3)return null;let h=(s.crown||0)/s.r;return[s.slope[0]-h*a,s.slope[1]-h*l]}build(t){if(this.index===t&&this.holeGroup)return;this.index=t,this.holeGroup&&(this.group.remove(this.holeGroup),this.holeGroup.traverse(L=>{var D,N,W;(D=L.geometry)==null||D.dispose(),(W=(N=L.material)==null?void 0:N.map)!=null&&W.isCanvasTexture&&L.material.map.dispose()}));let e=this.hole=Si[t%Si.length],n=this.holeGroup=new Jt;this.group.add(n),this.tee=this.toWorld(0,0),this.pin=this.toWorld(e.pin[0],e.pin[1]);let s=e.path.map(L=>L[0]),r=e.path.map(L=>L[1]),o=-40,a=Math.max(...s)+60,l=Math.min(...r)-80,c=Math.max(...r)+80,h=a-o,u=c-l,d=Math.min(2048,Math.ceil(h/.28)),f=Math.ceil(d*u/h),g=document.createElement("canvas");g.width=d,g.height=f;let x=g.getContext("2d"),m=x.createImageData(d,f),p=h/d,M=u/f;for(let L=0;L<f;L++)for(let D=0;D<d;D++){let N=o+(D+.5)*p,W=l+(L+.5)*M,k=Kh(e,N,W),[q,H,K]=Tb[k],Q=.92+Jh(D>>2,L>>2)*.08+Jh(D,L)*.06;(k==="fairway"||k==="tee")&&(Q*=Math.floor(N/9)&1?1.07:.95),k==="green"&&(Q*=Math.floor((N+W)/3)&1?1.05:.97),k==="bunker"&&(Q=.96+Jh(D,L)*.08);let at=(L*d+D)*4;m.data[at]=q*Q,m.data[at+1]=H*Q,m.data[at+2]=K*Q,m.data[at+3]=255}x.putImageData(m,0,0),this.mapCanvas=g,this.mapRect={x0:o,z0:l,W:h,H:u};let v=new Je(g);v.colorSpace=me,v.anisotropy=8;let y=new nt(new Mn(h,u),Rb(v));y.rotation.x=-Math.PI/2,y.position.set(o+h/2,0,l+u/2),y.receiveShadow=!0,n.add(y);let w=_i("water").normal.clone();w.wrapS=w.wrapT=ds,w.repeat.set(1/9,1/9),w.needsUpdate=!0;let S=new ye({color:2773600,roughness:.06,metalness:.1,normalMap:w,normalScale:new rt(.35,.35)});for(let[L,D,N,W]of e.water){let k=new oo;k.absellipse(0,0,N,W,0,Math.PI*2,!1,0);let q=new nt(new za(k,48),S);q.rotation.x=-Math.PI/2,q.position.set(L,.03,D),n.add(q)}for(let L of[-1,1]){let D=new nt(new Ce(.14,12,8),Tt(2976991,{roughness:.3}));D.position.set(0,.12,L*3),D.castShadow=!0,n.add(D)}let[A,P]=e.pin,_=new nt(new je(.075,20),new Le({color:1118481}));_.rotation.x=-Math.PI/2,_.position.set(A,.012,P),n.add(_);let b=new nt(new Ut(.018,.018,2.4,8),Tt(16119285,{roughness:.3,metalness:.4}));b.position.set(A,1.2,P),b.castShadow=!0;let R=new nt(new Mn(.7,.45,6,1),new ye({color:16726832,side:Te,roughness:.8}));R.position.set(A+.35,2.15,P),this.flag=R,n.add(b,R);for(let[L,D]of[[100,16777215],[150,16766474],[200,16726832]]){let N=this.pointFromGreen(L);if(!N)continue;let W=new nt(new Ut(.08,.08,1.1,8),Tt(D));W.position.set(N[0],.55,N[1]+(e.fw?e.fw/2+2:14)),n.add(W)}this.buildTrees(n,e)}pointFromGreen(t){let e=this.hole,[n,s]=e.pin,r=null,o=e.path;for(let a=o.length-1;a>0;a--){let[l,c]=o[a-1],[h,u]=o[a];for(let d=1;d>=0;d-=.02){let f=l+(h-l)*d,g=c+(u-c)*d,x=Math.hypot(f-n,g-s);if(x>=t)return r&&x-t>3?r:[f,g];r=[f,g]}}return null}buildTrees(t,e){let n=_s(this.seed+"trees"+this.index),s=[],r=e.path.reduce((v,y,w)=>w?v+Math.hypot(y[0]-e.path[w-1][0],y[1]-e.path[w-1][1]):0,0);for(let v=-10;v<r+40;v+=7){let y=0,w=0,S=0,A=0,P=1;for(let _=0;_<e.path.length-1;_++){let[b,R]=e.path[_],[L,D]=e.path[_+1],N=Math.hypot(L-b,D-R);if(v<=y+N||_===e.path.length-2){let W=Math.max(-.2,Math.min(1.3,(v-y)/N));w=b+(L-b)*W,S=R+(D-R)*W,A=-(D-R)/N,P=(L-b)/N;break}y+=N}for(let _ of[-1,1])for(let b=0;b<2;b++){let R=(e.fw||24)/2+20+n()*34+b*14,L=w+A*_*R+(n()-.5)*6,D=S+P*_*R+(n()-.5)*6,N=Kh(e,L,D);(N==="rough"||N==="ob")&&s.push([L,D,.8+n()*.7,n()])}}for(let v=0;v<26;v++){let y=(n()-.5)*2.4,w=e.green.r+28+n()*40;s.push([e.green.x+Math.cos(y)*w,e.green.z+Math.sin(y)*w,.9+n()*.8,n()])}let o=new Ut(.25,.4,4,6).translate(0,2,0),a=new ms(3.2,1).scale(1,1.25,1).translate(0,6.4,0),l=new Qn(2.6,8,8).translate(0,7,0),c=new sn(o,Lt("bark"),s.length),h=new sn(a,Lt("leaves",11061392),s.length),u=new sn(l,Lt("leaves",7311472),s.length),d=new Wt,f=new Re,g=new C,x=new C,m=new C(0,1,0),p=0,M=0;s.forEach(([v,y,w,S],A)=>{f.setFromAxisAngle(m,S*6.28),g.setScalar(w),x.set(v,0,y),d.compose(x,f,g),c.setMatrixAt(A,d),S<.6?h.setMatrixAt(p++,d):u.setMatrixAt(M++,d)}),h.count=p,u.count=M,this.trees=s.map(([v,y,w])=>[v,y,2.6*w,9*w]);for(let v of[c,h,u])v.castShadow=!0,v.receiveShadow=!0,t.add(v)}update(t){this.flag&&(this.flag.rotation.y=Math.sin(t*3.2)*.22)}};function Rb(i){let t=_i("grass"),e=new ye({map:i,roughness:.92});return e.onBeforeCompile=n=>{n.uniforms.uDet={value:t.map},n.uniforms.uDetN={value:t.normal},n.vertexShader=`varying vec3 vWp;
`+n.vertexShader.replace("#include <worldpos_vertex>",`#include <worldpos_vertex>
 vWp = (modelMatrix * vec4(transformed, 1.0)).xyz;`),n.fragmentShader=`uniform sampler2D uDet;
uniform sampler2D uDetN;
varying vec3 vWp;
`+n.fragmentShader.replace("#include <map_fragment>",`#include <map_fragment>
        vec3 dA = texture2D(uDet, vWp.xz / 2.2).rgb, dB = texture2D(uDet, vWp.xz / 13.0).rgb;
        float dl = dot(dA, vec3(0.3, 0.59, 0.11)) * 0.6 + dot(dB, vec3(0.3, 0.59, 0.11)) * 0.4;
        diffuseColor.rgb *= 0.55 + dl * 1.25;`).replace("#include <normal_fragment_maps>",`#include <normal_fragment_maps>
        { vec3 dn = texture2D(uDetN, vWp.xz / 2.2).xyz * 2.0 - 1.0;
          vec3 wn = normalize(vec3(dn.x * 0.6, 1.0, dn.y * 0.6));
          normal = normalize((viewMatrix * vec4(wn, 0.0)).xyz); }`)},e.customProgramCacheKey=()=>"course-ground",e}var Cb=.004166666666666667,Sn=[{id:"DR",carry:230,launch:11,spin:1,roll:1},{id:"3W",carry:210,launch:13.5,spin:1.12,roll:.9},{id:"5W",carry:195,launch:15,spin:1.2,roll:.82},{id:"4I",carry:180,launch:16.5,spin:1.28,roll:.72},{id:"5I",carry:170,launch:18,spin:1.34,roll:.66},{id:"6I",carry:160,launch:20,spin:1.4,roll:.6},{id:"7I",carry:150,launch:22,spin:1.46,roll:.54},{id:"8I",carry:140,launch:24.5,spin:1.52,roll:.48},{id:"9I",carry:128,launch:27,spin:1.58,roll:.42},{id:"PW",carry:115,launch:30,spin:1.64,roll:.36},{id:"AW",carry:100,launch:34,spin:1.7,roll:.3},{id:"SW",carry:82,launch:38,spin:1.76,roll:.24},{id:"LW",carry:62,launch:44,spin:1.82,roll:.18},{id:"PT",carry:0,launch:0,spin:0,roll:1,putter:!0,maxPutt:30}],Hf=2600,$i={tee:[.3,.6,2.3,1],fairway:[.3,.6,2.3,1],fringe:[.26,.6,1.4,.97],green:[.22,.55,.65,1],rough:[.16,.42,4.2,.82],bunker:[.02,.08,9,.7],water:[0,0,99,1],ob:[.16,.42,4.2,1]};function Qh({x:i,z:t,dir:e,speed:n,launchDeg:s,spin:r,side:o}){let a=s*Math.PI/180,l=Math.cos(a)*n;return{x:i,y:.02,z:t,vx:Math.cos(e)*l,vy:Math.sin(a)*n,vz:Math.sin(e)*l,spin:r,side:o,phase:n>0&&s>0?"air":"roll",sx:i,sz:t,carry:0,maxY:0,t:0}}function tu(i,t,e,n,s=1,r=null){let o=[],a=Math.ceil(t/Cb),l=t/a;for(;a-- >0&&i.phase!=="rest";)if(i.t+=l,i.phase==="air"){let c=i.vx-n.x,h=i.vz-n.z,u=i.vy,d=Math.hypot(c,u,h),f=Math.hypot(c,h)||1e-6,g=-.0034*d*c,x=-.0034*d*u-9.81,m=-.0034*d*h,p=.0023*i.spin*d;g+=p*(-u*c/f),m+=p*(-u*h/f),x+=p*f;let M=.0023*i.side*d*.5;if(g+=M*-h,m+=M*c,i.vx+=g*l,i.vy+=x*l,i.vz+=m*l,i.x+=i.vx*l,i.y+=i.vy*l,i.z+=i.vz*l,i.spin*=Math.exp(-l/7),i.maxY=Math.max(i.maxY,i.y),i.y<=0&&i.vy<0){i.y=0,i.carry||(i.carry=Math.hypot(i.x-i.sx,i.z-i.sz),o.push("land"));let v=e(i.x,i.z);if(v==="water"){i.phase="rest",o.push("water");break}let[y,w]=$i[v],S=w*(1.25-.32*i.spin)*s;i.vy=-i.vy*y,i.vx*=Math.max(.05,S),i.vz*=Math.max(.05,S),i.side*=.3,i.vy<1.2&&(i.vy=0,i.phase="roll")}}else if(i.phase==="roll"){let c=e(i.x,i.z);if(c==="water"){i.phase="rest",o.push("water");break}let h=r&&(c==="green"||c==="fringe")?r(i.x,i.z):null;h&&(i.vx-=9.81*.714*h[0]*l,i.vz-=9.81*.714*h[1]*l);let u=Math.hypot(i.vx,i.vz)||1e-6,d=$i[c][2],f=Math.max(0,u-d*l);if(f<=.02&&(!h||9.81*.714*Math.hypot(h[0],h[1])<d*.6)){i.vx=i.vz=0,i.phase="rest";break}if(i.vx*=f/u,i.vz*=f/u,i.x+=i.vx*l,i.z+=i.vz*l,i.onRoll&&i.onRoll(i,c))break}return i.phase==="rest"&&(o.push("rest"),e(i.x,i.z)==="ob"&&o.push("ob")),o}var jh=new Map;function Vf(i,t,e){let n=`${i.toFixed(1)}|${t}|${e}`;if(jh.has(n))return jh.get(n);let s=5,r=120,o={x:0,z:0},a=()=>"fairway";for(let c=0;c<26;c++){let h=(s+r)/2,u=Qh({x:0,z:0,dir:0,speed:h,launchDeg:t,spin:e,side:0});for(;u.phase==="air"&&u.t<20;)tu(u,1/30,a,o);u.carry<i?s=h:r=h}let l=(s+r)/2;return jh.set(n,l),l}var Gf=(i,t="green")=>Math.sqrt(2*$i[t][2]*Math.max(.05,i));var _r=class{constructor(t,e,{onChange:n,onMsg:s}={}){this.ctx=t,this.game=e,this.slots=[],this.state=null,this.onChange=n||(()=>{}),this.onMsg=s||(()=>{})}get net(){return this.ctx.net}get joined(){return this.slots.some(t=>t.owner===this.net.id)}mine(t){var e;return((e=this.slots[t])==null?void 0:e.owner)===this.net.id}name(t){var e;return((e=this.slots[t])==null?void 0:e.name)??"?"}onInfo(t){var e;this.slots=t.slots||[],this.state=t.state??null,(e=this.state)!=null&&e.seq&&(this.lastSeq=Math.max(this.lastSeq||0,this.state.seq)),this.onChange(this.state)}join(){this.net.send({t:"party_join",game:this.game})}addGuest(t){this.net.send({t:"party_join",game:this.game,guest:t})}removeGuest(t){this.net.send({t:"party_leave",game:this.game,slot:t})}leave(){this.net.send({t:"party_leave",game:this.game})}setState(t){var e;return this.lastSeq=Math.max(this.lastSeq||0,((e=this.state)==null?void 0:e.seq)||0)+1,t.seq=this.lastSeq,this.state=t,this.net.send({t:"party_state",game:this.game,state:t}),t}clear(){this.state=null,this.net.send({t:"party_state",game:this.game,state:null}),this.onChange(null)}msg(t){this.net.send({t:"party_msg",game:this.game,d:t})}};var Pb=`
.gp { position: fixed; z-index: 12; color: #f4f7fb; background: rgba(14, 20, 30, .74); border: 1px solid rgba(255,255,255,.14);
  border-radius: 14px; box-shadow: 0 8px 28px rgba(0,0,0,.35); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px);
  font-weight: 700; font-size: 13px; user-select: none; -webkit-user-select: none; }
.gp h3 { margin: 0 0 6px; font-size: 12px; letter-spacing: .08em; text-transform: uppercase; opacity: .65; }
.gp .big { font-size: 26px; font-weight: 900; line-height: 1; }
.gp .mid { font-size: 17px; font-weight: 900; }
.gp .dim { opacity: .6; }
.gp .kv { display: grid; grid-template-columns: auto auto; gap: 3px 14px; }
.gp .kv b { text-align: right; font-weight: 900; }
.gp button { font: inherit; color: inherit; cursor: pointer; border: 0; border-radius: 10px; padding: 8px 12px; background: rgba(255,255,255,.12); font-weight: 900; }
.gp button:hover { background: rgba(255,255,255,.2); }
.gp button.sm { padding: 2px 8px; border-radius: 7px; }
.gp-golf-btns button { background: rgba(14,20,30,.72); }
.gp button.on { background: #ffcc33; color: #1b1b1b; }
.gp button.go { background: #2fbf71; color: #fff; }
.gp button.warn { background: #ff6b5c; color: #fff; }
.gp button:disabled { opacity: .35; cursor: default; }
.gp .row { display: flex; gap: 6px; flex-wrap: wrap; align-items: center; }
.gp table { border-collapse: collapse; width: 100%; font-variant-numeric: tabular-nums; }
.gp td, .gp th { padding: 3px 6px; text-align: center; border-bottom: 1px solid rgba(255,255,255,.08); }
.gp th { font-size: 11px; opacity: .6; font-weight: 800; }
.gp td:first-child, .gp th:first-child { text-align: left; }
.gp tr.turn td { background: rgba(255, 204, 51, .18); }
.gp .slot { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 6px 8px; border-radius: 9px; background: rgba(255,255,255,.07); margin: 4px 0; }
.gp .slot .n { width: 22px; height: 22px; border-radius: 50%; display: grid; place-items: center; background: rgba(255,255,255,.18); font-size: 12px; flex-shrink: 0; }
.gp .slot .x { padding: 2px 8px; }
.gp-lobby { left: 50%; top: 50%; transform: translate(-50%, -50%); width: min(360px, calc(100vw - 24px)); padding: 16px; }
.gp-lobby h2 { margin: 0 0 4px; font-size: 20px; }
.gp-lobby .modes { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; margin: 10px 0; }
.gp-lobby .modes button { padding: 10px 4px; }
.gp-lobby .modes small { display: block; font-size: 10px; opacity: .7; font-weight: 700; margin-top: 2px; }
.gp-meter { position: relative; height: 18px; border-radius: 999px; background: rgba(255,255,255,.12); overflow: hidden; }
.gp-meter i { position: absolute; top: 0; bottom: 0; left: 0; background: linear-gradient(90deg, #6ee7b7, #fde047, #f87171); }
.gp-meter .mark { position: absolute; top: -2px; bottom: -2px; width: 3px; background: #fff; box-shadow: 0 0 6px #fff; }
.gp-meter .zone { position: absolute; top: 0; bottom: 0; background: rgba(255,255,255,.25); }
/* golf hole result banner */
.gp-golf-banner .who { font-size: 14px; opacity: .8; }
.gp-golf-banner .name { font-size: 54px; font-weight: 900; letter-spacing: .02em; text-shadow: 0 3px 14px rgba(0,0,0,.5); line-height: 1.1; }
.gp-golf-banner .sub { font-size: 16px; opacity: .85; margin-top: 4px; }
.gp-golf-banner.pop { animation: gbPop .5s cubic-bezier(.2,1.6,.4,1); }
@keyframes gbPop { from { transform: translate(-50%,-50%) scale(.4); opacity: 0; } to { transform: translate(-50%,-50%) scale(1); opacity: 1; } }
/* fishing float close-up */
.gp-fish-pip { border-radius: 14px !important; box-shadow: 0 6px 22px rgba(0,0,0,.4) !important; backdrop-filter: none !important; -webkit-backdrop-filter: none !important; }
.gp-fish-pip .pipLabel { position: absolute; left: 8px; top: 6px; font-size: 12px; text-shadow: 0 1px 3px #000; }
.gp-fish-pip .pipHint { position: absolute; right: 10px; top: 4px; font-size: 26px; animation: pipBlink .3s infinite alternate; }
@keyframes pipBlink { from { opacity: 1; } to { opacity: .3; } }
/* free-view pad (built in main.js), placed per game where nothing else lives */
#viewPad { position: fixed; z-index: 11; display: grid; grid-template-columns: repeat(3, 32px); gap: 3px; padding: 5px;
  background: rgba(14,20,30,.55); border-radius: 12px; backdrop-filter: blur(6px); -webkit-backdrop-filter: blur(6px); user-select: none; -webkit-user-select: none; touch-action: none; }
#viewPad[hidden] { display: none; }
.gp-lobby .slots.two { display: grid; grid-template-columns: 1fr 1fr; column-gap: 8px; }
#viewPad button { width: 32px; height: 30px; padding: 0; border: 0; border-radius: 8px; background: rgba(255,255,255,.14); color: #fff; font: 900 13px system-ui, sans-serif; cursor: pointer; touch-action: none; }
#viewPad button:hover { background: rgba(255,255,255,.26); }
#viewPad button[data-v=reset] { background: rgba(255,200,80,.3); }
body[data-mode=golf] #viewPad { right: 10px; bottom: max(14px, env(safe-area-inset-bottom)); }
body[data-mode=fishing] #viewPad { right: 10px; top: calc(max(10px, env(safe-area-inset-top)) + 268px); }
body[data-mode=billiards] #viewPad { right: 10px; top: calc(max(10px, env(safe-area-inset-top)) + 64px); }
@media (max-width: 720px) {
  #viewPad { grid-template-columns: repeat(3, 28px); gap: 2px; padding: 4px; }
  #viewPad button { width: 28px; height: 26px; font-size: 12px; }
  body[data-mode=golf] #viewPad { bottom: auto; top: calc(max(10px, env(safe-area-inset-top)) + 356px); }
  body[data-mode=fishing] #viewPad { right: auto; left: 8px; top: calc(max(10px, env(safe-area-inset-top)) + 216px); }
  body[data-mode=billiards] #viewPad { right: auto; left: 8px; top: calc(max(10px, env(safe-area-inset-top)) + 200px); }
}
@media (max-width: 720px) {
  .gp { font-size: 12px; } .gp .big { font-size: 20px; } .gp .mid { font-size: 15px; }
  .gp button { padding: 7px 9px; }
  /* golf */
  .gp-golf-bottom { left: 8px !important; right: 124px !important; width: auto !important; transform: none !important; padding: 8px !important; }
  .gp-golf-bottom #gClubs button { padding: 4px 5px !important; font-size: 11px; }
  .gp-golf-bottom #gHelp { display: none; }
  .gp-golf-btns { top: calc(max(10px, env(safe-area-inset-top)) + 150px) !important; bottom: auto !important; }
  .gp-golf-map canvas { width: 92px; height: auto; }
  .gp-golf-map { top: calc(max(10px, env(safe-area-inset-top)) + 186px) !important; }
  .gp-golf-shot { top: calc(max(10px, env(safe-area-inset-top)) + 196px) !important; }
  /* billiards */
  .gp-bill-help { display: none; }
  .gp-bill-board { top: calc(max(10px, env(safe-area-inset-top)) + 96px) !important; padding: 6px 8px !important; }
  .gp-bill-board th:nth-child(5), .gp-bill-board td:nth-child(5) { display: none; }
  .gp-bill-left { width: 124px !important; padding: 8px !important; }
  .gp-bill-left canvas { width: 84px; height: 84px; }
  .gp-bill-right { padding: 8px !important; }
  .gp-bill-right #bGauge { height: 140px !important; width: 46px !important; }
  .gp-bill-right .row button { padding: 6px 7px; }
  /* fishing */
  .gp-fish { width: calc(100vw - 140px) !important; left: 8px !important; transform: none !important; }
  .gp-fish #fHelp { display: none; }
  .gp-fish-pip { width: 150px !important; height: 112px !important; top: calc(max(10px, env(safe-area-inset-top)) + 96px) !important; }
  .gp-fish-card { top: 34% !important; }
}
/* in a game on a phone the chat folds up under the top bar */
@media (max-width: 720px) {
  body.ingame #chat { bottom: auto; left: auto; right: 10px; top: 55%; width: auto; align-items: flex-end; }
  body.ingame #btnGlobe { display: none; }
  body.ingame #chat:not(.open) #log, body.ingame #chat:not(.open) #chatForm { display: none; }
  body.ingame #chat.open { width: calc(100vw - 20px); z-index: 20; }
  body.ingame #chat.open #chatToggle { align-self: flex-end; }
}
`,Wf=!1;function De(i,t=""){if(!Wf){let n=document.createElement("style");n.textContent=Pb,document.head.append(n),Wf=!0}let e=document.createElement("div");e.className=`gp ${i}`,e.innerHTML=t,e.hidden=!0;for(let n of["pointerdown","touchstart"])e.addEventListener(n,s=>s.stopPropagation(),{passive:!0});return document.body.append(e),e}function Pe(i){return String(i).replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t])}var Mr=class{constructor({title:t,modes:e,onStart:n,onExit:s,max:r=4}){var o;this.max=r,this.el=De("gp-lobby"),this.title=t,this.modes=e,this.mode=(o=e==null?void 0:e[0])==null?void 0:o[0],this.onStart=n,this.onExit=s,this.guestN=1}show(t){this.party=t,this.el.hidden=!1,this.render()}hide(){this.el.hidden=!0}render(){if(this.el.hidden)return;let t=this.party,e=t.slots,n=t.ctx.net.id,s=t.joined,r=`<h2>${Pe(this.title)}</h2><div class="dim">${U("partyHint",{n:this.max})}</div>`;this.modes&&(r+='<div class="modes">'+this.modes.map(([o,a,l])=>`<button data-mode="${o}" class="${o===this.mode?"on":""}">${Pe(a)}<small>${Pe(l||"")}</small></button>`).join("")+"</div>"),r+=`<h3 style="margin-top:10px">${U("party")} ${e.length}/${this.max}</h3><div class="slots${this.max>4?" two":""}">`;for(let o=0;o<this.max;o++){let a=e[o];if(a){let l=a.owner===n&&a.guest?`<button class="x" data-rm="${o}">\u2715</button>`:"";r+=`<div class="slot"><span class="n">${o+1}</span><span style="flex:1">${Pe(a.name)}${a.guest?` <span class="dim">(${U("guest")})</span>`:""}${a.owner===n&&!a.guest?` <span class="dim">(${U("me")})</span>`:""}</span>${l}</div>`}else r+=`<div class="slot dim"><span class="n">${o+1}</span><span style="flex:1">${U("emptySlot")}</span></div>`}r+="</div>",r+='<div class="row" style="margin-top:10px">',r+=s?`<button data-a="leave">${U("leaveParty")}</button>`:`<button data-a="join" class="on">${U("joinParty")}</button>`,r+=`<button data-a="guest" ${!s||e.length>=this.max?"disabled":""}>\uFF0B ${U("addGuest")}</button>`,r+=`<span style="flex:1"></span><button data-a="exit">${U("exit")}</button>`,r+=`<button data-a="start" class="go" ${s?"":"disabled"}>${U("startGame")}</button></div>`,this.el.innerHTML=r,this.max>4&&(this.el.style.width="min(560px, calc(100vw - 24px))"),this.el.querySelectorAll("[data-mode]").forEach(o=>o.onclick=()=>{this.mode=o.dataset.mode,this.render()}),this.el.querySelectorAll("[data-rm]").forEach(o=>o.onclick=()=>t.removeGuest(+o.dataset.rm)),this.el.querySelectorAll("[data-a]").forEach(o=>o.onclick=()=>{let a=o.dataset.a;a==="join"&&t.join(),a==="leave"&&t.leave(),a==="guest"&&t.addGuest(`${U("guest")} ${++this.guestN-1}`),a==="exit"&&this.onExit(),a==="start"&&this.onStart(this.mode)})}};var el=.03,$f=.06,eu=8,nl=["#ffffff","#ffe14d","#ff8fa3","#74c0fc","#8ce99a","#ffa94d","#da77f2","#66d9e8"],Ib=nl.map(i=>parseInt(i.slice(1),16));function nu(i){let t=new Jt,e=i==="wood"?1:i==="iron"?.92:.82,n=new nt(new Ut(.008,.012,e,6),Tt(13685978,{metalness:.9,roughness:.25}));n.position.y=-e/2;let s=new nt(new Ut(.016,.014,.24,8),Tt(2236962,{roughness:.8}));s.position.y=-.1;let r;return i==="wood"?(r=new nt(new Ce(.06,16,10),Tt(1908516,{metalness:.6,roughness:.25})),r.scale.set(1,.6,1.25)):i==="iron"?(r=new nt(new $t(.02,.05,.085),Tt(13225686,{metalness:.95,roughness:.2})),r.rotation.x=.3):r=new nt(new $t(.06,.03,.12),Tt(5593696,{metalness:.9,roughness:.3})),r.position.y=-e,t.add(n,s,r),t}var Lb=i=>i.putter?"putter":/W|DR/.test(i.id)&&!/AW|SW|LW|PW/.test(i.id)?"wood":"iron",il=class{constructor(t){this.ctx=t,this.course=new tl(t.scene,t.venue.id),this.balls=Ib.map(o=>{let a=new nt(new Ce(el,18,12),Tt(16777215,{roughness:.25,emissive:o,emissiveIntensity:o===16777215?0:.25}));return a.castShadow=!0,a.visible=!1,t.scene.add(a),a}),this.tracerPts=new Float32Array(900*3);let e=new ae;e.setAttribute("position",new Ne(this.tracerPts,3)),e.setDrawRange(0,0),this.tracer=new Ln(e,new bi({color:16765503,transparent:!0,opacity:.9})),this.tracer.frustumCulled=!1,t.scene.add(this.tracer),this.aimLine=new Ln(new ae().setFromPoints([new C,new C(1,0,0)]),new ur({color:16777215,dashSize:1.2,gapSize:.8,transparent:!0,opacity:.75})),this.aimLine.frustumCulled=!1,this.ring=new nt(new fn(.85,1,40),new Le({color:16777215,transparent:!0,opacity:.8,side:Te})),this.ring.rotation.x=-Math.PI/2,this.aimLine.visible=this.ring.visible=!1,t.scene.add(this.aimLine,this.ring);let n=520,s=new ae;s.setAttribute("position",new Ne(new Float32Array(n*6),3));let r=new Float32Array(n*6);for(let o=0;o<n;o++)r.set([1,1,1],o*6),r.set([.42,.62,.3],o*6+3);s.setAttribute("color",new Ne(r,3)),this.flow=new Ia(s,new bi({vertexColors:!0,transparent:!0,opacity:.9,depthWrite:!1})),this.flow.frustumCulled=!1,this.flow.visible=!1,this.flowLife=new Float32Array(n),t.scene.add(this.flow),this.props={wood:nu("wood"),iron:nu("iron"),putter:nu("putter")},this.club=0,this.aim=0,this.swing={phase:"idle",v:0,power:0},this.flight=null,this.focus=new C,this.appliedSeq=-1,this.party=new _r(t,"golf",{onChange:o=>this.onParty(o),onMsg:o=>this.onPartyMsg(o)}),this.buildUI(),addEventListener("keydown",o=>{var a;!this.active||/INPUT|SELECT|TEXTAREA/.test((a=document.activeElement)==null?void 0:a.tagName)||(o.code==="KeyQ"&&this.pickClub(this.club-1),(o.code==="KeyE"||o.code==="KeyR")&&this.pickClub(this.club+1),o.code==="Tab"&&(o.preventDefault(),this.ui.card.hidden=!this.ui.card.hidden,this.renderCard()))}),addEventListener("wheel",o=>{this.active&&this.myTurn()&&this.pickClub(this.club+Math.sign(o.deltaY))},{passive:!0})}buildUI(){var e,n;if(this.uiLang=rn(),this.ui)for(let s of Object.values(this.ui))(e=s.classList)!=null&&e.contains("gp")&&s.remove();(n=this.lobby)==null||n.el.remove(),this.lobby=new Mr({title:`\u26F3 ${U("screenGolf")}`,modes:[["3",U("golf3"),"Par 12"],["1",U("golf1"),"Par 4"],["2",U("golf1b"),"Par 3"]],onStart:s=>this.start(s),onExit:()=>this.ctx.exit(),max:eu});let t=this.ui={};t.top=De("gp-golf-top",""),t.banner=De("gp-golf-banner",""),t.banner.style.cssText="left:50%;top:30%;transform:translate(-50%,-50%);padding:18px 36px;text-align:center;pointer-events:none;background:rgba(10,16,26,.82)",t.top.style.cssText="left:10px;top:calc(max(10px, env(safe-area-inset-top)) + 54px);padding:10px 14px;min-width:200px",t.info=De("gp-golf-info",""),t.info.style.cssText="right:10px;top:calc(max(10px, env(safe-area-inset-top)) + 54px);padding:10px 14px;text-align:right;min-width:150px",t.mapWrap=De("gp-golf-map",'<canvas width="150" height="230" style="display:block;border-radius:10px"></canvas>'),t.mapWrap.style.cssText="right:10px;top:calc(max(10px, env(safe-area-inset-top)) + 196px);padding:6px",t.map=t.mapWrap.querySelector("canvas"),t.bottom=De("gp-golf-bottom",""),t.bottom.style.cssText="left:50%;transform:translateX(-50%);bottom:max(14px, env(safe-area-inset-bottom));padding:10px 12px;width:min(640px, calc(100vw - 150px))",t.bottom.innerHTML=`<div class="row" id="gClubs" style="justify-content:center;gap:4px"></div>
      <div style="display:flex;align-items:center;gap:10px;margin-top:8px"><div class="gp-meter" style="flex:1" id="gMeter"><span class="zone"></span><i></i><span class="mark"></span></div>
      <div id="gMeterLbl" style="min-width:86px;text-align:right" class="mid"></div></div>
      <div class="dim" id="gHelp" style="margin-top:6px;text-align:center;font-size:11px"></div>`,t.clubs=t.bottom.querySelector("#gClubs"),t.meter=t.bottom.querySelector("#gMeter"),t.meterLbl=t.bottom.querySelector("#gMeterLbl"),t.help=t.bottom.querySelector("#gHelp");for(let s=0;s<Sn.length;s++){let r=document.createElement("button");r.textContent=Sn[s].id,r.style.padding="6px 7px",r.onclick=()=>this.pickClub(s),t.clubs.append(r)}t.shot=De("gp-golf-shot",""),t.shot.style.cssText="left:10px;top:calc(max(10px, env(safe-area-inset-top)) + 200px);padding:10px 14px;min-width:190px",t.card=De("gp-golf-card",""),t.card.style.cssText="left:50%;top:50%;transform:translate(-50%,-50%);padding:14px;width:min(520px, calc(100vw - 24px))",t.btns=De("gp-golf-btns",`<div class="row"><button data-a="card">\u{1F4CB} ${U("scoreCard")}</button><button data-a="exit">${U("exit")}</button></div>`),t.btns.style.cssText="left:10px;top:calc(max(10px, env(safe-area-inset-top)) + 150px);padding:6px;background:transparent;border:0;box-shadow:none;backdrop-filter:none",t.btns.querySelector("[data-a=card]").onclick=()=>{t.card.hidden=!t.card.hidden,this.renderCard()},t.btns.querySelector("[data-a=exit]").onclick=()=>this.ctx.exit()}showUI(t){for(let e of["top","info","mapWrap","bottom","btns"])this.ui[e].hidden=!t;t||(this.ui.shot.hidden=!0,this.ui.card.hidden=!0,this.ui.banner.hidden=!0)}pickClub(t){var r,o;let e=this.party.state,n=(r=e==null?void 0:e.balls)==null?void 0:r[e.turn],s=n&&this.course.lie(n.x,n.z)==="green";t=Math.max(0,Math.min(Sn.length-1,t)),s&&(t=Sn.length-1),this.swing.phase==="idle"&&(this.club=t,(o=this.ctx.avatar)==null||o.setProp(this.props[Lb(Sn[t])]),[...this.ui.clubs.children].forEach((a,l)=>a.classList.toggle("on",l===t)))}autoClub(t,e,n){var o;if(e==="green")return Sn.length-1;let s=((o=$i[e])==null?void 0:o[3])||1,r=0;for(let a=0;a<Sn.length-1;a++)Sn[a].carry*s>=t*.97&&(r=a);return r===0&&!n&&(r=1),r}enter(){this.active=!0;let t=this.ctx;t.hud.hide(),this.uiLang!==rn()&&(this.buildUI(),this.mapBg=null),this.course.visible=!0,this.savedFog=[t.scene.fog.near,t.scene.fog.far],t.scene.fog.near=160,t.scene.fog.far=1300,this.savedGrass=t.world.isGrass,t.world.isGrass=(e,n)=>{let s=this.course.lie(e,n);return s==="rough"||s==="ob"},this.course.build(0),t.player.pos.copy(this.course.tee).add(new C(-2,0,-2)),this.focus.copy(this.course.tee),!this.party.joined&&this.party.slots.length<eu&&!this.party.state&&this.party.join(),this.onParty(this.party.state)}exit(){var e;this.active=!1;let t=this.ctx;this.course.visible=!1,this.savedFog&&(t.scene.fog.near=this.savedFog[0],t.scene.fog.far=this.savedFog[1]),this.savedGrass&&(t.world.isGrass=this.savedGrass),this.party.leave(),this.lobby.hide(),this.showUI(!1),this.balls.forEach(n=>n.visible=!1),this.aimLine.visible=this.ring.visible=this.tracer.visible=!1,go("#btnPower").hidden=!0,(e=t.avatar)==null||e.setProp(null),t.avatar&&(t.avatar.swingPose=null),this.flight=null,this.swing.phase="idle"}holeIdx(t=this.party.state){return t?t.holes[t.h]:0}myTurn(){let t=this.party.state;return!!t&&t.phase==="play"&&!this.flight&&!t.holeDone&&this.party.mine(t.turn)}start(t){let e=this.party.slots.length;if(!e)return;let s={phase:"play",holes:t==="1"?[0]:t==="2"?[1]:[0,1,2],h:0,turn:0,balls:[],cards:Array.from({length:e},()=>[])};this.resetHole(s),this.party.setState(s),this.onParty(s)}resetHole(t){let e=this.course.toWorld(0,0),n=_s(`${this.ctx.venue.id}|wind|${t.holes[t.h]}|${t.seq||0}`),s=n()*6,r=n()*Math.PI*2;t.wind={x:+(Math.cos(r)*s).toFixed(2),z:+(Math.sin(r)*s).toFixed(2)},t.balls=this.party.slots.map((o,a)=>({x:e.x,z:e.z+(a-3.5)*.02,s:0,holed:!1,pen:0,prev:null})),t.turn=this.honorOrder(t)[0]??0,t.holeDone=!1}honorOrder(t){let e=t.balls.map((n,s)=>s);return t.h===0?e:e.sort((n,s)=>(t.cards[n][t.h-1]??99)-(t.cards[s][t.h-1]??99)||n-s)}onParty(t){if(!this.active)return;if(!t){this.showUI(!1),this.balls.forEach(n=>n.visible=!1),this.lobby.show(this.party),go("#btnPower").hidden=!0;return}if(this.lobby.hide(),this.showUI(!0),t.seq===this.appliedSeq)return;this.appliedSeq=t.seq,this.flight&&!this.flight.mine&&(this.flight=null);let e=this.holeIdx(t);this.course.index!==e&&(this.course.build(e),this.renderMapBg(),this.flyT=2.6),(t.phase==="done"||t.holeDone)&&(this.ui.card.hidden=!1),this.prepareTurn(),this.renderCard()}onPartyMsg(t){if(!this.active)return;let e=t.d;e.k==="shot"&&this.startFlight(e.slot,e.p,!1),e.k==="score"&&this.showScore(e)}showScore(t){var o;let e=this.ui.banner,n=t.n-t.par,s=t.n===1?"holeInOne":["sc_m3","sc_m2","sc_m1","sc_0","sc_1","sc_2","sc_3"][Math.max(0,Math.min(6,n+3))],r=t.pickup?"#cbd5e1":n<=-2||t.n===1?"#fde047":n===-1?"#7dd3fc":n===0?"#86efac":"#fca5a5";e.innerHTML=`<div class="who">${Pe(this.party.name(t.slot))}</div>
      <div class="name" style="color:${r}">${t.pickup?U("pickup"):U(s)}${n<0||t.n===1?"!":""}</div>
      <div class="sub">${U("nStrokes",{n:t.n})} \xB7 ${n===0?"E":(n>0?"+":"")+n}</div>`,e.hidden=!1,e.classList.remove("pop"),e.offsetWidth,e.classList.add("pop"),clearTimeout(this.bannerT),this.bannerT=setTimeout(()=>{e.hidden=!0},3200),n<0&&((o=this.ctx.audio)==null||o.chime())}prepareTurn(){var o,a;let t=this.party.state;if(!t||t.phase!=="play")return;let e=t.balls[t.turn];if(!e)return;let n=this.course.pin;this.aim=Math.atan2(n.z-e.z,n.x-e.x);let s=this.course.lie(e.x,e.z),r=Math.hypot(n.x-e.x,n.z-e.z);this.pickClub(this.autoClub(r,s,e.s===0)),this.swing={phase:"idle",v:0,power:0},(a=(o=this.ctx).snap)==null||a.call(o),go("#btnPower").hidden=!(ft.touch&&this.myTurn()),go("#btnPower").textContent=U("swing"),this.renderCard()}powerDown(){var n;if(!this.myTurn())return;let t=this.swing,e=Sn[this.club];t.phase==="idle"?(t.phase="back",t.v=0,(n=this.ctx.audio)==null||n.click(.3),this.ui.shot.hidden=!0,this.tracer.visible=!1):t.phase==="down"?this.impact(t.v):e.putter&&t.phase}powerUp(){let t=this.swing;if(t.phase==="back"){if(t.power=Math.max(.03,t.v),Sn[this.club].putter)return this.impact(0);t.phase="down"}}impact(t){var l,c;let e=this.party.state,n=this.swing,s=Sn[this.club],r=e.balls[e.turn],o=this.course.lie(r.x,r.z);n.phase="follow",n.t=0;let a;if(s.putter){let h=n.power*s.maxPutt;a={x:r.x,z:r.z,dir:this.aim,speed:Gf(h,o==="green"||o==="fringe"?o:"fairway"),launchDeg:0,spin:0,side:0,rollMul:1,putt:1}}else{let h=Math.max(-.25,Math.min(.25,t)),u=Math.min(.3,Math.max(0,Math.abs(h)-.025)*1.6),d=Math.min(1.06,n.power),f=s.carry*d*(1-u)*(((l=$i[o])==null?void 0:l[3])||1),g=Vf(f,s.launch,s.spin);a={x:r.x,z:r.z,dir:this.aim+h*.09,speed:g,launchDeg:s.launch*(o==="bunker"?1.15:1),spin:s.spin*(.85+d*.15),side:h*4.2,rollMul:s.roll,err:h}}(c=this.ctx.audio)==null||c.click(s.putter?.5:1),this.party.msg({k:"shot",slot:e.turn,p:a}),this.startFlight(e.turn,a,!0),go("#btnPower").hidden=!0}startFlight(t,e,n){let s=Qh(e),r=this.course.pin,o=this.party.state;s.onRoll=(a,l)=>{if(l!=="green"&&l!=="fringe")return!1;let c=Math.hypot(a.x-r.x,a.z-r.z),h=Math.hypot(a.vx,a.vz);if(c<$f&&h<1.6)return a.holed=!0,a.phase="rest",a.x=r.x,a.z=r.z,!0;if(c<$f*1.4&&h>=1.6){let u=(a.x-r.x)/c,d=(a.z-r.z)/c;a.vx+=u*.6,a.vz+=d*.6}return!1},this.flight={s,slot:t,p:e,mine:n,n:0,t:0,from:{x:e.x,z:e.z},dir:e.dir,lastDry:{x:e.x,z:e.z},restT:0},this.tracer.visible=!e.putt,this.tracer.geometry.setDrawRange(0,0),this.swing.phase=this.swing.phase==="follow"?"follow":"idle"}finishShot(t,e){var u;let n=structuredClone(this.party.state),s=n.balls[t.slot],r=t.s;s.prev={x:t.from.x,z:t.from.z},s.s+=1;let o="";if(e.includes("water")){s.s+=1,s.pen++;let d=this.dropPoint(t.lastDry,r);s.x=d.x,s.z=d.z,o=`\u{1F4A6} ${U("penaltyWater")}`}else e.includes("ob")?(s.s+=1,s.pen++,s.x=t.from.x,s.z=t.from.z,o=`\u{1F6A9} ${U("penaltyOB")}`):(s.x=+r.x.toFixed(3),s.z=+r.z.toFixed(3));let a=Si[this.holeIdx(n)].par;if(r.holed?(s.holed=!0,o=this.scoreName(s.s,a)):s.s>=a*2&&(s.holed=!0,s.pickup=!0,o=U("pickup")),r.holed||s.pickup){let d={k:"score",slot:t.slot,n:s.s,par:a,pickup:!!s.pickup};this.party.msg(d),this.showScore(d)}else o&&this.ctx.toast(o);r.holed&&((u=this.ctx.audio)==null||u.chime(),this.ctx.net.event({type:"sink",hole:n.h+1,n:s.s}));let l=n.balls.map((d,f)=>f).filter(d=>!n.balls[d].holed);if(!l.length){n.balls.forEach((f,g)=>{n.cards[g][n.h]=f.s}),n.holeDone=!0,this.party.setState(n),this.onParty(n);let d=n.seq;setTimeout(()=>this.nextHole(d),3800),this.ui.card.hidden=!1,this.renderCard();return}let c=this.course.pin,h=this.honorOrder(n).filter(d=>!n.balls[d].holed&&n.balls[d].s===0);n.turn=h.length?h[0]:l.sort((d,f)=>Math.hypot(n.balls[f].x-c.x,n.balls[f].z-c.z)-Math.hypot(n.balls[d].x-c.x,n.balls[d].z-c.z))[0],this.party.setState(n),this.onParty(n)}nextHole(t){let e=this.party.state;if(!e||e.seq!==t)return;let n=structuredClone(e);n.h+1>=n.holes.length?(n.phase="done",n.holeDone=!1):(n.h++,this.course.build(n.holes[n.h]),this.resetHole(n)),this.ui.card.hidden=n.phase!=="done",this.party.setState(n),this.onParty(n)}dropPoint(t,e){let n=this.course.pin,s=t.x,r=t.z;for(let o=0;o<80&&this.course.lie(s,r)==="water";o++){let a=Math.hypot(s-n.x,r-n.z);s+=(s-n.x)/a,r+=(r-n.z)/a}return{x:+s.toFixed(2),z:+r.toFixed(2)}}toPar(t,e){var o;let n=0,s=0;(o=t.cards[e])==null||o.forEach((a,l)=>{a&&(n+=a,s+=Si[t.holes[l]].par)});let r=n-s;return r===0?"E":(r>0?"+":"")+r}scoreName(t,e){if(t===1)return`\u{1F3C6} ${U("holeInOne")}`;let n=t-e;return`\u26F3 ${U(["sc_m3","sc_m2","sc_m1","sc_0","sc_1","sc_2","sc_3"][Math.max(0,Math.min(6,n+3))])} (${t})`}update(t){var m,p,M,v;let e=this.party.state;this.course.update(performance.now()/1e3);let n=Wi(),s=this.ctx.camTarget,r=this.ctx.player;if(r.speed=0,!e||e.phase!=="play"){let y=performance.now()/6e3,w=this.course.tee;s.pos.set(w.x-14+Math.cos(y)*4,6,w.z+Math.sin(y)*8),s.look.set(w.x+60,0,w.z),this.balls.forEach(S=>S.visible=!1),this.aimLine.visible=this.ring.visible=this.flow.visible=!1;return}e.balls.forEach((y,w)=>{var A;let S=this.balls[w];S.visible=!y.holed||((A=this.flight)==null?void 0:A.slot)===w,this.flight&&this.flight.slot===w||S.position.set(y.x,el,y.z)});for(let y=e.balls.length;y<eu;y++)this.balls[y].visible=!1;let o=e.balls[e.turn],a=Sn[this.club],l=this.course.pin;if(this.flight)this.updateFlight(t);else if(this.myTurn()){this.aim+=vr(t)*(a.putter?.25:.5)-n.x*(a.putter?.0012:.0025),this.camPitch=Math.max(-.25,Math.min(1,(this.camPitch||0)+n.y*.003));let y=this.swing;y.phase==="back"?(y.v=Math.min(1.1,y.v+t/(a.putter?1.6:1.05)),y.v>=1.1&&!a.putter&&(y.power=1.1,y.phase="down")):y.phase==="down"&&(y.v-=t*(y.power+.25)/.45,y.v<-.25&&this.impact(-.25))}let c=this.flight?this.flight.from:o,h=this.flight?this.flight.dir:this.aim,u=new C(Math.cos(h),0,Math.sin(h)),d=new C(-u.z,0,u.x);if(this.party.mine(this.flight?this.flight.slot:e.turn))r.pos.set(c.x-d.x*.62,0,c.z-d.z*.62),r.yaw=Math.atan2(d.x,d.z);else{let y=e.balls.findIndex((S,A)=>this.party.mine(A)),w=e.balls[y]||o;r.pos.set(w.x-2.5,0,w.z-2.5)}let f=this.swing,g=this.ctx.avatar;if(g){let y=a.putter?.22:1,w=0;f.phase==="back"?w=-Math.min(1,f.v)*y:f.phase==="down"?w=-Math.max(0,Math.min(1,f.v/Math.max(.05,f.power)))*Math.min(1,f.power)*y:f.phase==="follow"&&(f.t+=t,w=Math.min(1,f.t*5)*y,f.t>2.2&&(f.phase="idle"));let S=this.party.mine(this.flight?this.flight.slot:e.turn);g.swingPose=S||f.phase!=="idle"?w:null}let x=!this.flight&&this.myTurn();if(this.aimLine.visible=this.ring.visible=x,x){let y=this.course.lie(o.x,o.z),w=f.phase==="back"||f.phase==="down"?Math.min(1.06,f.power||f.v):1,S=a.putter?Math.max(.3,(f.phase==="idle"?Math.min(1,Math.hypot(l.x-o.x,l.z-o.z)/a.maxPutt):w)*a.maxPutt):a.carry*w*(((m=$i[y])==null?void 0:m[3])||1),A=new C(o.x,.04,o.z),P=A.clone().addScaledVector(u,S);this.aimLine.geometry.setFromPoints([A,P]),this.aimLine.computeLineDistances(),this.aimLine.material.dashSize=a.putter?.15:1.2,this.aimLine.material.gapSize=a.putter?.1:.8,this.ring.position.set(P.x,.05,P.z),this.ring.scale.setScalar(a.putter?.25:Math.max(1.5,S*.05)),this.expect=S}if(this.flyT>0){this.flyT-=t;let y=1-Math.max(0,this.flyT)/2.6,w=y*y*(3-2*y),S=this.course.tee;s.pos.set(l.x+(S.x-8-l.x)*w,60-56*w,l.z+(S.z-l.z)*w),s.look.set(l.x+(S.x+40-l.x)*w*.3,0,l.z+(S.z-l.z)*w*.3),w<.98&&((M=(p=this.ctx).snap)==null||M.call(p))}else if(this.flight)this.flightCamera(s);else{let y=a.putter,w=this.camPitch||0;s.pos.set(o.x,(y?1.25:1.9)+w*(y?3.2:9),o.z).addScaledVector(u,(y?-2.8:-4.6)-w*(y?1.2:4)).addScaledVector(d,y?.5:1.1),s.look.set(o.x,0,o.z).addScaledVector(u,(y?3.5:28)*(1+w*(y?.6:2.2)))}this.focus.set(this.flight?this.flight.s.x:o.x,0,this.flight?this.flight.s.z:o.z),this.updateHud(e,o,a,l);{let y=this.course.lie(o.x,o.z);this.updateFlow(t,(y==="green"||y==="fringe")&&(!this.flight||((v=this.flight.p)==null?void 0:v.putt)))}}updateFlight(t){let e=this.flight,n=e.s,s=this.party.state,r=tu(n,t,(a,l)=>this.course.lie(a,l),n.phase==="air"?s.wind:{x:0,z:0},e.p.rollMul,(a,l)=>this.course.slopeAt(a,l));if(n.phase==="air"&&this.course.trees){for(let[a,l,c,h]of this.course.trees)if(n.y<h&&n.y>1.5&&Math.hypot(n.x-a,n.z-l)<c*.7){n.vx*=.25,n.vz*=.25,n.vy=Math.min(n.vy,0);break}}e.t+=t,this.course.lie(n.x,n.z)!=="water"&&(e.lastDry.x=n.x,e.lastDry.z=n.z),this.balls[e.slot].position.set(n.x,el+n.y,n.z),this.tracer.visible&&e.n<900&&(e.n===0||n.phase==="air")&&(this.tracerPts.set([n.x,el+n.y,n.z],e.n*3),e.n++,this.tracer.geometry.setDrawRange(0,e.n),this.tracer.geometry.attributes.position.needsUpdate=!0),r.includes("land")&&!e.p.putt&&this.showShotData(e,!1),n.phase==="rest"&&(e.done||(e.done=!0,e.ev=r,this.showShotData(e,!0)),e.restT+=t,e.restT>1.4&&(this.flight=null,e.mine&&this.finishShot(e,e.ev)))}flightCamera(t){let e=this.flight,n=e.s,s=new C(n.x,n.y,n.z);Math.hypot(n.vx,n.vz)>.5&&(e.camDir=Math.atan2(n.vz,n.vx));let o=e.camDir??e.dir,a=new C(Math.cos(o),0,Math.sin(o));if(e.p.putt)t.pos.set(e.from.x,1.4,e.from.z).addScaledVector(a,-2.4).lerp(s.clone().setY(1.2),Math.min(.7,e.t*.25)),t.look.copy(s);else if(e.t<.9)t.pos.set(e.from.x,1.9,e.from.z).addScaledVector(a,-4.8).addScaledVector(new C(-a.z,0,a.x),1.1),t.look.copy(s);else{let l=n.phase==="air"?14:7;t.pos.copy(s).addScaledVector(a,-l),t.pos.y=Math.max(1.6,n.y*.75+3.2),t.look.copy(s)}}showShotData(t,e){let n=t.p,s=t.s,r=this.ui.shot;if(n.putt){if(!e)return;r.innerHTML=`<h3>${U("shotData")}</h3><div class="kv"><span>${U("total")}</span><b>${Math.hypot(s.x-t.from.x,s.z-t.from.z).toFixed(1)} m</b></div>`}else{let o=Math.hypot(s.x-t.from.x,s.z-t.from.z),a=Math.round(n.spin*Hf/50)*50,l=Math.round(n.side*380/10)*10;r.innerHTML=`<h3>${U("shotData")} \xB7 ${this.party.name(t.slot)}</h3><div class="kv">
        <span>${U("ballSpeed")}</span><b>${n.speed.toFixed(1)} m/s</b>
        <span>${U("launchAngle")}</span><b>${n.launchDeg.toFixed(1)}\xB0</b>
        <span>${U("backSpin")}</span><b>${a} rpm</b>
        <span>${U("sideSpin")}</span><b>${l>0?"R ":l<0?"L ":""}${Math.abs(l)} rpm</b>
        <span>${U("apex")}</span><b>${s.maxY.toFixed(1)} m</b>
        <span>${U("carry")}</span><b>${(s.carry||o).toFixed(1)} m</b>
        <span>${U("total")}</span><b>${e?o.toFixed(1)+" m":"\u2026"}</b></div>`}r.hidden=!1}viewPivot(){return this.focus}greenRead(t,e){let n=this.course.slopeAt(t.x,t.z),s=this.course.lie(t.x,t.z);if(!n||s!=="green"&&s!=="fringe")return"";let r=Math.hypot(e.x-t.x,e.z-t.z)||1,o=(e.x-t.x)/r,a=(e.z-t.z)/r,l=(n[0]*o+n[1]*a)*100,c=-(n[0]*-a+n[1]*o)*100,h=Math.abs(l)<.3?U("flat"):`${l>0?U("slopeUp"):U("slopeDown")} ${Math.abs(l).toFixed(1)}%`,u=Math.abs(c)<.3?"":` \xB7 ${c>0?U("breakR"):U("breakL")} ${Math.abs(c).toFixed(1)}%`;return`<div style="margin-top:6px;color:#9be7a5"><span class="dim">${U("greenRead")}</span><br><b>${h}${u}</b></div>`}updateFlow(t,e){let n=this.flow;if(n.visible=e,!e)return;let s=this.course.hole.green,r=this.course.toWorld(s.x,s.z),o=s.r+1,a=n.geometry.attributes.position,l=a.array,c=this.flowLife;for(let h=0;h<c.length;h++){let u=l[h*6],d=l[h*6+2],f=c[h]>0?this.course.slopeAt(u,d):null;if(!f||Math.hypot(u-r.x,d-r.z)>o){let p=o*Math.sqrt(Math.random()),M=Math.random()*Math.PI*2;u=r.x+Math.cos(M)*p,d=r.z+Math.sin(M)*p,c[h]=1.5+Math.random()*2.5}else u-=f[0]*22*t,d-=f[1]*22*t,c[h]-=t;let g=this.course.slopeAt(u,d)||[0,0],x=Math.hypot(g[0],g[1])||1e-6,m=.18+x*14;l[h*6]=u,l[h*6+1]=.03,l[h*6+2]=d,l[h*6+3]=u+g[0]/x*m,l[h*6+4]=.03,l[h*6+5]=d+g[1]/x*m}a.needsUpdate=!0}updateHud(t,e,n,s){var w;let r=this.holeIdx(t),o=Si[r],a=this.party.name(t.turn),l=this.course.lie(e.x,e.z),c=Math.hypot(s.x-e.x,s.z-e.z),h=this.party.mine(t.turn),u=Math.round(Math.hypot(o.pin[0],o.pin[1])),d=`${t.seq}|${this.club}|${Math.round(c*10)}|${!!this.flight}`;if(d!==this.hudKey){this.hudKey=d,this.ui.top.innerHTML=`<div class="row" style="gap:12px;align-items:baseline"><span class="big">${t.h+1}H</span><span class="mid">PAR ${o.par}</span><span class="dim">${u} m</span></div>
        <div style="margin-top:6px"><span style="color:${nl[t.turn]}">\u25CF</span> <b>${Pe(a)}</b> \xB7 ${U("strokeN",{n:e.s+1})} \xB7 <b>${this.toPar(t,t.turn)}</b>${h?"":` <span class="dim">(${U("spectating")})</span>`}</div>
        <div class="dim" style="margin-top:2px">${U("lie")}: ${U("lie_"+l)}</div>${this.greenRead(e,s)}`,this.ui.btns.style.setProperty("top",`${this.ui.top.offsetTop+this.ui.top.offsetHeight+6}px`,"important");let S=t.wind,A=Math.hypot(S.x,S.z);this.ui.info.innerHTML=`<h3>${U("pinDist")}</h3><div class="big">${c<20?c.toFixed(1):Math.round(c)}<span style="font-size:14px"> m</span></div>
        <div style="margin-top:8px" class="row" style="justify-content:flex-end"><span class="dim">${U("wind")}</span>
        <span id="gWind" style="display:inline-block;font-size:18px">\u2B06</span><b>${A.toFixed(1)} m/s</b></div>
        <div class="dim" style="margin-top:4px">${n.putter?U("putter"):`${n.id} \xB7 ${U("carry")} ${Math.round(n.carry*(((w=$i[l])==null?void 0:w[3])||1))} m`}</div>`}let f=t.wind,g=Math.atan2(f.z,f.x)-this.aim,x=this.ui.info.querySelector("#gWind");x&&(x.style.transform=`rotate(${g*180/Math.PI}deg)`);let m=this.swing,p=S=>(S+.25)/1.35*100;this.ui.meter.querySelector("i").style.left=`${p(0)}%`;let M=m.phase==="down"||m.phase==="follow"?m.power:m.phase==="back"?m.v:0;this.ui.meter.querySelector("i").style.width=`${p(Math.min(1.1,M))-p(0)}%`;let v=this.ui.meter.querySelector(".mark");v.style.left=`${p(m.phase==="idle"?0:m.v)}%`;let y=this.ui.meter.querySelector(".zone");y.style.left=`${p(-.025)}%`,y.style.width=`${p(.025)-p(-.025)}%`,y.hidden=n.putter,this.ui.meterLbl.textContent=n.putter?`${(Math.max(0,m.phase==="idle"?0:m.power||m.v)*n.maxPutt).toFixed(1)} m`:`${Math.round((m.phase==="idle"?1:Math.min(1.06,m.power||m.v))*100)}%`,this.ui.help.textContent=h?n.putter?U("puttHelp"):U("swingHelp"):U("waitTurn",{name:a}),this.ui.clubs.style.opacity=h?1:.4,performance.now()-(this.mapT||0)>100&&(this.mapT=performance.now(),this.drawMap(t))}renderMapBg(){let t=this.course,e=t.hole,n=this.ui.map,s=e.path.map(v=>v[0]),r=e.path.map(v=>v[1]),o=-20,a=Math.max(...s)+25,l=(Math.min(...r)+Math.max(...r))/2,c=Math.min((n.height-16)/(a-o),(n.width-10)/130);this.mapXf={xmin:o,zc:l,S:c};let h=document.createElement("canvas");h.width=n.width,h.height=n.height;let u=h.getContext("2d");u.fillStyle="#3a5a2a",u.fillRect(0,0,h.width,h.height);let{x0:d,z0:f,W:g,H:x}=t.mapRect,m=t.mapCanvas,p=g/m.width,M=x/m.height;u.setTransform(0,-p*c,M*c,0,h.width/2+(f-l)*c,h.height-8-(d-o)*c),u.drawImage(m,0,0),u.setTransform(1,0,0,1,0,0),this.mapBg=h}mapPt(t,e){let{xmin:n,zc:s,S:r}=this.mapXf,o=t-this.course.group.position.x,a=e-this.course.group.position.z;return[this.ui.map.width/2+(a-s)*r,this.ui.map.height-8-(o-n)*r]}drawMap(t){this.mapBg||this.renderMapBg();let e=this.ui.map.getContext("2d");e.drawImage(this.mapBg,0,0);let[n,s]=this.mapPt(this.course.pin.x,this.course.pin.z);e.fillStyle="#ff3b30",e.fillRect(n-1,s-9,2,9),e.beginPath(),e.moveTo(n+1,s-9),e.lineTo(n+7,s-6.5),e.lineTo(n+1,s-4),e.fill();let r=t.balls[t.turn];if(r&&!this.flight&&this.expect){let[o,a]=this.mapPt(r.x,r.z),[l,c]=this.mapPt(r.x+Math.cos(this.aim)*this.expect,r.z+Math.sin(this.aim)*this.expect);e.strokeStyle="rgba(255,255,255,.85)",e.setLineDash([3,3]),e.lineWidth=1.2,e.beginPath(),e.moveTo(o,a),e.lineTo(l,c),e.stroke(),e.setLineDash([])}t.balls.forEach((o,a)=>{var u;if(o.holed)return;let l=((u=this.flight)==null?void 0:u.slot)===a?this.flight.s:o,[c,h]=this.mapPt(l.x,l.z);e.fillStyle=nl[a],e.strokeStyle="#000",e.lineWidth=1,e.beginPath(),e.arc(c,h,a===t.turn?4:3,0,Math.PI*2),e.fill(),e.stroke()})}renderCard(){var o,a,l;let t=this.party.state,e=this.ui.card;if(!t||e.hidden)return;let n=t.holes,s=`<h3>${U("scoreCard")}${t.phase==="done"?" \xB7 "+U("roundDone"):""}</h3><table><tr><th>${U("player")}</th>`;n.forEach((c,h)=>{s+=`<th>${h+1}H<br>P${Si[c].par}</th>`}),s+=`<th>${U("sumTotal")}</th><th>\xB1</th></tr>`;let r=t.cards.map(c=>c.reduce((h,u)=>h+(u||0),0));if(t.cards.forEach((c,h)=>{let u=c.reduce((f,g,x)=>f+(g?Si[n[x]].par:0),0),d=r[h]-u;s+=`<tr class="${h===t.turn&&t.phase==="play"?"turn":""}"><td><span style="color:${nl[h]}">\u25CF</span> ${Pe(this.party.name(h))}</td>`,n.forEach((f,g)=>{var S;let x=c[g],m=Si[n[g]].par,p=g===t.h&&t.phase==="play"&&!x?((S=t.balls[h])==null?void 0:S.s)||"":x??"",M=x?x<m?"#7dd3fc":x>m?"#fca5a5":"":"",v=x?x-m:0,y=x?v<=-2?"border:3px double currentColor;border-radius:50%":v===-1?"border:2px solid currentColor;border-radius:50%":v===1?"border:2px solid currentColor;border-radius:3px":v>=2?"border:3px double currentColor;border-radius:3px":"":"",w=x?`<div style="font-size:9px;opacity:.75;margin-top:2px">${x===1?U("holeInOne"):U(["sc_m3","sc_m2","sc_m1","sc_0","sc_1","sc_2","sc_3"][Math.max(0,Math.min(6,v+3))])}</div>`:"";s+=`<td style="color:${M}"><span style="display:inline-block;min-width:22px;line-height:20px;${y}">${p}</span>${w}</td>`}),s+=`<td><b>${r[h]||""}</b></td><td>${u?(d>0?"+":"")+(d||"E"):""}</td></tr>`}),s+="</table>",t.phase==="done"){let c=Math.min(...r),h=r.map((u,d)=>u===c?this.party.name(d):null).filter(Boolean);s+=`<div class="mid" style="margin-top:10px;text-align:center">\u{1F3C6} ${Pe(h.join(", "))}</div>
        <div class="row" style="justify-content:center;margin-top:10px"><button class="go" data-a="again">${U("playAgain")}</button><button data-a="lobby">${U("backLobby")}</button></div>`}else s+='<div class="row" style="justify-content:flex-end;margin-top:8px"><button data-a="close">\u2715</button></div>';e.innerHTML=s,(o=e.querySelector("[data-a=again]"))==null||o.addEventListener("click",()=>this.start(t.holes.length===1?String(t.holes[0]+1):"3")),(a=e.querySelector("[data-a=lobby]"))==null||a.addEventListener("click",()=>{this.party.clear()}),(l=e.querySelector("[data-a=close]"))==null||l.addEventListener("click",()=>{e.hidden=!0})}netState(){return null}},go=i=>document.querySelector(i);var yo={carp:{h:.3,hx:.36,ped:.11,sn:.8,w:.45,belly:.06,dorsal:[.3,.62,.1],anal:[.66,.76,.08],barbel:1,scales:1},crucian:{h:.37,hx:.4,ped:.12,sn:.72,w:.38,belly:.04,dorsal:[.32,.64,.09],anal:[.66,.76,.08],scales:1},perch:{h:.31,hx:.34,ped:.1,sn:.95,w:.34,belly:.05,dorsal:[.26,.72,.11],spiny:1,anal:[.6,.75,.08],bigMouth:1,scales:1},disc:{h:.5,hx:.42,ped:.1,sn:.7,w:.22,belly:0,dorsal:[.26,.78,.09],spiny:1,anal:[.48,.78,.09],scales:1},torpedo:{h:.22,hx:.4,ped:.075,sn:.9,w:.55,belly:.03,dorsal:[.38,.52,.1],adipose:1,anal:[.66,.74,.06]},salmon:{h:.25,hx:.4,ped:.08,sn:1.05,w:.5,belly:.04,dorsal:[.38,.52,.1],adipose:1,anal:[.66,.74,.06],hookJaw:1},slim:{h:.21,hx:.4,ped:.085,sn:.85,w:.42,belly:.04,dorsal:[.42,.54,.1],anal:[.62,.74,.07],scales:1},tuna:{h:.28,hx:.42,ped:.035,sn:1,w:.75,belly:.02,dorsal:[.28,.42,.12],spiny:1,dorsal2:[.48,.56,.1],anal:[.56,.63,.08],finlets:1},jack:{h:.26,hx:.42,ped:.04,sn:.95,w:.5,belly:.02,dorsal:[.32,.74,.06],anal:[.54,.74,.05]},mackerel:{h:.2,hx:.42,ped:.04,sn:1.05,w:.6,belly:.02,dorsal:[.26,.38,.08],spiny:1,dorsal2:[.5,.58,.07],anal:[.54,.62,.06],finlets:1},pike:{h:.145,hx:.48,ped:.075,sn:1.5,w:.8,belly:.02,dorsal:[.62,.74,.09],anal:[.64,.76,.08],bigMouth:1},snakehead:{h:.16,hx:.35,ped:.1,sn:.8,w:.75,belly:.02,dorsal:[.22,.82,.07],anal:[.48,.82,.06],bigMouth:1},eel:{h:.075,hx:.3,ped:.07,sn:1,w:.9,belly:0,eel:1},ribbon:{h:.09,hx:.25,ped:.01,sn:1.4,w:.25,belly:0,eel:1,taper:1,bigMouth:1},needle:{h:.07,hx:.5,ped:.04,sn:2.4,w:.8,belly:0,dorsal:[.7,.8,.05],anal:[.68,.8,.05],beak:1},cat:{h:.18,hx:.24,ped:.08,sn:.55,w:.9,belly:.05,dorsal:[.28,.35,.11],anal:[.48,.86,.06],barbel:2,bigMouth:1},rock:{h:.31,hx:.32,ped:.1,sn:1,w:.45,belly:.04,dorsal:[.24,.74,.12],spiny:1,anal:[.6,.74,.09],bigMouth:1,scales:1},goby:{h:.18,hx:.22,ped:.09,sn:.55,w:.9,belly:.03,dorsal:[.3,.42,.09],spiny:1,dorsal2:[.48,.76,.07],anal:[.54,.76,.06]},flat:{h:.46,hx:.45,ped:.08,sn:.65,w:.12,belly:0,fringe:1},puffer:{h:.4,hx:.42,ped:.1,sn:.6,w:.85,belly:.08,dorsal:[.68,.76,.09],anal:[.68,.76,.08]},mullet:{h:.22,hx:.4,ped:.08,sn:.75,w:.6,belly:.03,dorsal:[.32,.4,.08],spiny:1,dorsal2:[.56,.64,.07],anal:[.58,.66,.06],scales:1},cod:{h:.23,hx:.35,ped:.06,sn:.85,w:.6,belly:.06,dorsal:[.26,.4,.09],dorsal2:[.44,.58,.08],anal:[.42,.58,.06],whisker:1},mahi:{h:.3,hx:.18,ped:.05,sn:.38,w:.35,belly:.02,dorsal:[.06,.84,.08],anal:[.46,.84,.06]},marlin:{h:.22,hx:.4,ped:.04,sn:1,w:.6,belly:.02,dorsal:[.2,.42,.22],sail:1,dorsal2:[.7,.74,.05],anal:[.58,.64,.07],bill:1},sturgeon:{h:.15,hx:.35,ped:.05,sn:1.6,w:.8,belly:.02,dorsal:[.66,.74,.08],anal:[.66,.74,.07],scutes:1,barbel:1},arapaima:{h:.18,hx:.35,ped:.12,sn:.9,w:.65,belly:.02,dorsal:[.62,.84,.08],anal:[.62,.84,.08],scales:1},arowana:{h:.22,hx:.4,ped:.1,sn:.8,w:.35,belly:-.02,dorsal:[.62,.84,.08],anal:[.52,.84,.08],scales:1,whisker:1}},Db=[["bluegill","\uBE14\uB8E8\uAE38","Bluegill","fresh","all",34,8,25,"disc","trunc","bars",3099196,8231542,15905882,1978202,.18,"mid",["worm","shrimp"],20],["crucian","\uBD95\uC5B4","Crucian Carp","fresh","all",30,10,45,"crucian","fork","plain",4868650,10916949,15260846,7035434,.28,"bot",["worm","paste","corn"],40],["carp","\uC789\uC5B4","Common Carp","fresh","all",16,30,110,"carp","fork","plain",4143650,10519878,15785120,9062954,.72,"bot",["corn","paste","worm"],30],["mirrorcarp","\uD5A5\uC5B4","Mirror Carp","fresh","all",9,35,90,"carp","fork","mirror",4867632,10127962,15655088,8018480,.68,"bot",["paste","corn"],35],["grasscarp","\uCD08\uC5B4","Grass Carp","fresh","all",6,50,140,"slim","fork","plain",4082226,9081438,15131332,5921328,.8,"mid",["corn","paste"],25],["koi","\uBE44\uB2E8\uC789\uC5B4","Koi","fresh","all",2,40,90,"carp","fork","koi",16052714,16052714,16448250,14829610,.6,"mid",["corn","paste"],260],["bass","\uBC30\uC2A4","Largemouth Bass","fresh","all",20,20,65,"perch","trunc","lateral",3099172,8228688,15657160,2306074,.58,"mid",["minnow","softworm","popper","worm"],45],["smallmouth","\uC2A4\uBAB0\uB9C8\uC6B0\uC2A4 \uBC30\uC2A4","Smallmouth Bass","fresh","all",9,20,55,"perch","trunc","bars",5917224,10126416,15129780,3811860,.65,"mid",["minnow","softworm","worm"],55],["mandarin","\uC3D8\uAC00\uB9AC","Mandarin Fish","fresh","warm",6,20,60,"rock","round","marble",6969898,12099680,15919296,2761748,.66,"bot",["minnow","softworm","shrimp"],140],["aucha","\uAEBD\uC9C0","Korean Aucha Perch","fresh","warm",10,10,30,"rock","round","bars",3815972,7236164,14209704,2001096,.4,"bot",["worm","softworm","minnow"],70],["rainbow","\uBB34\uC9C0\uAC1C\uC1A1\uC5B4","Rainbow Trout","fresh","cold",14,20,80,"torpedo","trunc","pinkband",4872762,11843752,15921898,14704762,.55,"mid",["worm","minnow","corn"],60],["masu","\uC0B0\uCC9C\uC5B4","Masu Trout","fresh","cold",8,15,45,"torpedo","trunc","parr",4872786,11056304,15790316,3820138,.45,"mid",["worm","minnow"],90],["lenok","\uC5F4\uBAA9\uC5B4","Lenok","fresh","cold",5,30,70,"torpedo","fork","spots",4864554,10780778,15391944,11550768,.6,"mid",["minnow","worm"],150],["char","\uACE4\uB4E4\uB9E4\uAE30","Arctic Char","fresh","cold",5,25,70,"torpedo","trunc","redspots",3030602,6979204,15231546,16052448,.6,"mid",["minnow","worm"],130],["sweetfish","\uC740\uC5B4","Sweetfish","fresh","all",10,12,30,"slim","fork","plain",4872778,12107952,16053482,15777856,.3,"mid",["minnow","worm"],120],["palechub","\uD53C\uB77C\uBBF8","Pale Chub","fresh","all",34,8,17,"slim","fork","barspink",4872810,12634320,16053492,14707338,.12,"top",["worm","paste"],15],["chub","\uB044\uB9AC","Korean Piscivorous Chub","fresh","warm",14,20,40,"slim","fork","plain",4084328,11845836,16053492,14721120,.45,"top",["minnow","worm"],25],["skygazer","\uAC15\uC900\uCE58","Skygazer","fresh","warm",10,40,100,"slim","fork","plain",5925490,13160660,16185078,9083556,.55,"top",["minnow","popper"],15],["barbel","\uB204\uCE58","Steed Barbel","fresh","warm",12,25,60,"slim","fork","spots",5921354,11184276,15658724,4868666,.5,"bot",["worm","paste"],20],["catfish","\uBA54\uAE30","Far Eastern Catfish","fresh","all",8,30,120,"cat","round","marble",3815980,6183492,14209720,2368026,.75,"bot",["worm","squid","shrimp"],45],["wels","\uC6F0\uC2A4 \uBA54\uAE30","Wels Catfish","fresh","cold",2,80,250,"cat","round","marble",3027496,5921352,13683892,1974296,1,"bot",["squid","worm"],40],["eel","\uBC40\uC7A5\uC5B4","Japanese Eel","fresh","warm",6,40,110,"eel","eel","plain",3029540,5922872,15394504,3817508,.6,"bot",["worm","squid"],220],["snakehead","\uAC00\uBB3C\uCE58","Snakehead","fresh","warm",6,40,100,"snakehead","round","blotch",3817002,8026708,14867648,1711122,.8,"top",["popper","softworm","minnow"],60],["pike","\uAC15\uAF2C\uCE58\uACE0\uAE30","Northern Pike","fresh","cold",6,40,130,"pike","fork","spots",4082218,8030800,15658188,14733424,.82,"mid",["minnow","popper"],50],["tilapia","\uD2F8\uB77C\uD53C\uC544","Tilapia","fresh","trop",18,15,50,"perch","trunc","bars",4869700,9344650,15132380,12599386,.4,"mid",["worm","corn","paste"],25],["peacock","\uD53C\uCF55 \uBC30\uC2A4","Peacock Bass","fresh","trop",8,30,80,"perch","round","bars",5138986,14204992,15788208,2767386,.85,"mid",["minnow","popper"],90],["arowana","\uC544\uB85C\uC640\uB098","Silver Arowana","fresh","trop",4,50,100,"arowana","round","plain",5925488,13161688,15791348,15245488,.7,"top",["popper","minnow"],300],["arapaima","\uD53C\uB77C\uB8E8\uCFE0","Arapaima","fresh","trop",2,100,300,"arapaima","round","redtail",3818552,7240294,13159604,13122090,1,"mid",["minnow","squid"],80],["sturgeon","\uCCA0\uAC11\uC0C1\uC5B4","Sturgeon","fresh","cold",1,80,250,"sturgeon","hetero","scutes",4869710,9080976,15000796,14211276,.95,"bot",["worm","squid"],500],["golden","\uD669\uAE08 \uC789\uC5B4","Golden Koi","fresh","all",1,50,100,"carp","fork","gold",15773728,15773728,16773824,16767072,.88,"mid",["corn","paste"],1500],["mackerel","\uACE0\uB4F1\uC5B4","Chub Mackerel","sea","all",30,20,50,"mackerel","fork","wavy",2775658,10138812,16053488,1714746,.4,"mid",["krill","jig","squid"],25],["horsemackerel","\uC804\uAC31\uC774","Horse Mackerel","sea","all",26,15,45,"jack","fork","scutes",4876906,11846848,16053486,14205024,.35,"mid",["krill","jig","lugworm"],30],["sardine","\uC815\uC5B4\uB9AC","Sardine","sea","all",26,12,25,"slim","fork","spots",2771562,11584720,16185078,1714762,.1,"top",["krill"],15],["rockfish","\uC6B0\uB7ED","Korean Rockfish","sea","all",24,15,60,"rock","trunc","marble",3815994,6972506,13157044,2762274,.42,"bot",["squid","softworm","lugworm","shrimp"],50],["blackrockfish","\uBCFC\uB77D","Dark-banded Rockfish","sea","all",20,12,35,"rock","trunc","bars",3814436,8022602,14208176,2761236,.32,"mid",["shrimp","krill","softworm"],70],["scorpion","\uC3E8\uBC45\uC774","Scorpionfish","sea","warm",12,12,35,"rock","round","marble",9058858,12608586,15780016,5905940,.35,"bot",["squid","lugworm"],80],["greenling","\uC950\uB178\uB798\uBBF8","Fat Greenling","sea","cold",18,20,60,"cod","trunc","marble",5917226,10126422,14997684,3812890,.45,"bot",["lugworm","squid"],45],["flounder","\uAD11\uC5B4","Olive Flounder","sea","all",14,30,100,"flat","round","spots",5917236,9074262,15920352,3812896,.55,"bot",["minnow","softworm","squid"],70],["stoneflounder","\uB3C4\uB2E4\uB9AC","Stone Flounder","sea","all",16,20,45,"flat","round","spots",6969920,10127458,15920352,3813408,.38,"bot",["lugworm"],60],["blackporgy","\uAC10\uC131\uB3D4","Black Porgy","sea","all",12,20,60,"perch","fork","plain",3817028,8291982,14212320,2369580,.62,"mid",["krill","shrimp","corn"],110],["seabream","\uCC38\uB3D4","Red Sea Bream","sea","warm",10,25,100,"perch","fork","bluedots",13126234,15239818,16310492,4235488,.62,"mid",["krill","shrimp","jig","squid"],120],["opaleye","\uBCB5\uC5D0\uB3D4","Largescale Blackfish","sea","warm",10,20,55,"perch","trunc","plain",1976878,4082256,8029834,1731210,.7,"top",["krill"],120],["rockbream","\uB3CC\uB3D4","Striped Beakfish","sea","warm",5,25,70,"disc","trunc","bars7",3815994,13157556,15262936,1710618,.9,"bot",["shrimp","squid"],260],["seabass","\uB18D\uC5B4","Japanese Sea Bass","sea","all",10,30,110,"perch","trunc","spots",4872804,10793144,15921906,2765888,.72,"mid",["minnow","softworm","popper","shrimp"],70],["mullet","\uC22D\uC5B4","Flathead Mullet","sea","all",16,30,80,"mullet","fork","lines",4083290,10793144,15658734,5925498,.55,"top",["paste","krill"],25],["goby","\uB9DD\uB465\uC5B4","Yellowfin Goby","sea","all",28,10,30,"goby","round","spots",6971460,11051136,15262412,3814436,.18,"bot",["lugworm","worm"],15],["filefish","\uC950\uCE58","Filefish","sea","warm",12,15,35,"disc","round","marble",9077862,11841168,14867652,5919808,.35,"mid",["krill","squid"],60],["butterfish","\uBCD1\uC5B4","Silver Pomfret","sea","warm",8,15,40,"disc","lunate","plain",9082532,13423836,16054008,6978186,.3,"mid",["krill"],90],["puffer","\uBCF5\uC5B4","Panther Puffer","sea","all",12,15,45,"puffer","trunc","spots",4868666,9079402,16184558,1710612,.3,"bot",["squid","lugworm","shrimp"],90],["hairtail","\uAC08\uCE58","Hairtail","sea","warm",10,60,150,"ribbon","eel","silver",12109004,14542058,16054008,9085104,.5,"mid",["squid","jig"],110],["needlefish","\uD559\uACF5\uCE58","Halfbeak","sea","all",12,20,40,"needle","fork","lines",3037802,11847888,16185078,15231546,.2,"top",["krill"],50],["croaker","\uBBFC\uC5B4","Brown Croaker","sea","warm",4,40,110,"cod","round","plain",6974042,11578518,15789280,9075290,.7,"bot",["shrimp","squid"],200],["yellowcroaker","\uCC38\uC870\uAE30","Yellow Croaker","sea","warm",10,15,40,"cod","round","plain",9079402,13944970,16048240,11571248,.3,"bot",["lugworm","shrimp"],160],["tilefish","\uC625\uB3D4","Red Tilefish","sea","warm",5,25,50,"cod","trunc","plain",13660266,15246490,16312544,15781968,.45,"bot",["squid","lugworm"],230],["grouper","\uB2A5\uC131\uC5B4","Convict Grouper","sea","warm",4,30,100,"rock","round","bars",5921354,9079412,13947068,2763296,.85,"bot",["squid","softworm","minnow"],220],["redgrouper","\uBD89\uBC14\uB9AC","Red Spotted Grouper","sea","warm",2,25,60,"rock","round","redspots",11037258,13672576,15916232,13647904,.8,"bot",["squid","shrimp"],450],["cod","\uB300\uAD6C","Pacific Cod","sea","cold",10,40,110,"cod","trunc","spots",6970948,11049082,15656660,3813408,.55,"bot",["squid","jig"],60],["pollock","\uBA85\uD0DC","Alaska Pollock","sea","cold",14,30,80,"cod","trunc","lines",5919812,10261628,15525590,3814436,.45,"mid",["jig","squid"],40],["salmon","\uC5F0\uC5B4","Chum Salmon","sea","cold",6,50,110,"salmon","fork","spots",4084322,10135728,15790318,10504794,.82,"mid",["jig","minnow","shrimp"],90],["yellowtail","\uBC29\uC5B4","Japanese Amberjack","sea","all",6,40,120,"jack","fork","yellowline",3824250,11583692,15921904,15781952,.88,"mid",["jig","minnow","squid"],80],["amberjack","\uBD80\uC2DC\uB9AC","Yellowtail Amberjack","sea","warm",4,50,150,"jack","fork","yellowline",4876910,12109508,16053486,15255616,.92,"mid",["jig","popper"],80],["gt","\uBB34\uBA85\uAC08\uC804\uAC31\uC774(GT)","Giant Trevally","sea","trop",3,50,150,"jack","fork","plain",3818568,9082008,14212316,2764852,.98,"top",["popper","jig"],40],["mahi","\uB9CC\uC0C8\uAE30","Mahi-mahi","sea","trop",5,50,150,"mahi","fork","mahi",2787946,10145866,15786058,2781376,.85,"top",["popper","jig","squid"],60],["tuna","\uCC38\uB2E4\uB791\uC5B4","Bluefin Tuna","sea","all",2,80,250,"tuna","lunate","tuna",1977934,8030876,15659250,15781952,1,"mid",["jig","squid"],200],["marlin","\uCCAD\uC0C8\uCE58","Blue Marlin","sea","trop",1,150,380,"marlin","lunate","marlin",1981034,6982320,15659252,4235488,1,"top",["popper","squid"],150],["goldenbream","\uD669\uAE08 \uCC38\uB3D4","Golden Sea Bream","sea","all",1,40,90,"perch","fork","gold",15773728,15773728,16773824,16767072,.9,"mid",["krill","shrimp"],1500]],on={fresh:[],sea:[]},qn={},iu={ko:{},en:{}};for(let i of Db){let[t,e,n,s,r,o,a,l,c,h,u,d,f,g,x,m,p,M,v]=i,y={id:t,water:s,zone:r,w:o,min:a,max:l,body:c,tail:h,pat:u,back:d,side:f,belly:g,acc:x,fight:m,depth:p,baits:M,price:v};on[s].push(y),qn[t]=y,iu.ko[t]=e,iu.en[t]=n}qn.seabreamgold=qn.goldenbream;Bf(iu);var sl={rod:[{id:"bamboo",ko:"\uB300\uB098\uBB34 \uB09A\uC2EF\uB300",en:"Bamboo Pole",price:0,cast:10,str:1,sens:1,lure:.6,big:.9,col:13148240,len:2.6,icon:"\u{1F38B}"},{id:"carbon",ko:"\uCE74\uBCF8 \uBBFC\uC7A5\uB300 3.6\uCE78",en:"Carbon Pole 6.5 m",price:600,cast:12,str:1.15,sens:1.35,lure:.6,big:1,col:2763310,len:3.4,icon:"\u{1F3A3}"},{id:"spinning",ko:"\uC2A4\uD53C\uB2DD \uB8E8\uC5B4\uB300",en:"Spinning Lure Rod",price:1200,cast:22,str:1.25,sens:1.1,lure:1.6,big:1.05,col:2375786,len:2.4,icon:"\u{1F3A3}"},{id:"iso",ko:"\uAC2F\uBC14\uC704 \uB9B4\uB300 1.5\uD638",en:"Rock Float Rod",price:1800,cast:22,str:1.4,sens:1.25,lure:.9,big:1.15,col:6954538,len:3.2,icon:"\u{1F3A3}"},{id:"surf",ko:"\uC6D0\uD22C \uB09A\uC2EF\uB300",en:"Surf Casting Rod",price:2200,cast:32,str:1.5,sens:.95,lure:.8,big:1.25,col:1989178,len:3.4,icon:"\u{1F3A3}"},{id:"jigging",ko:"\uC9C0\uAE45 \uB85C\uB4DC",en:"Jigging Rod",price:4500,cast:20,str:2.2,sens:.85,lure:1.5,big:1.6,col:1118481,len:1.9,icon:"\u{1F3A3}"},{id:"goldrod",ko:"\uD669\uAE08 \uB09A\uC2EF\uB300",en:"Golden Rod",price:3e4,cast:32,str:2.6,sens:1.5,lure:1.6,big:2,col:14725168,len:3,icon:"\u2728"}],float:[{id:"stick",ko:"\uB9C9\uB300\uCC0C (\uBBFC\uBB3C \uB098\uB178)",en:"Stick Float",price:0,sens:1.35,depth:"mid",vis:1,stick:1,icon:"\u{1F4CD}"},{id:"round",ko:"\uAD6C\uBA4D\uCC0C 0.8\uD638",en:"Round Float",price:300,sens:1.1,depth:"mid",vis:1.2,icon:"\u{1F534}"},{id:"shallow",ko:"\uACE0\uCD94\uCC0C (\uC595\uC740 \uC218\uC2EC)",en:"Pepper Float",price:250,sens:1.2,depth:"top",vis:1,stick:1,icon:"\u{1F336}\uFE0F"},{id:"glow",ko:"\uC804\uC790\uCC0C (\uC57C\uAD11)",en:"Glow Float",price:900,sens:1.25,depth:"mid",vis:1.5,stick:1,glow:1,icon:"\u{1F4A1}"},{id:"bigfloat",ko:"\uB300\uBB3C\uCC0C",en:"Big Game Float",price:700,sens:.9,depth:"mid",vis:1.4,big:1.25,icon:"\u{1F7E0}"},{id:"sinker",ko:"\uC6D0\uD22C \uBD09\uB3CC (\uBC14\uB2E5)",en:"Bottom Sinker",price:200,sens:.95,depth:"bot",vis:0,bell:1,icon:"\u26AB"}],hook:[{id:"h3",ko:"\uBD95\uC5B4\uBC14\uB298 3\uD638",en:"Hook #3 (small)",price:0,size:-1,str:4,hookup:1.15,icon:"\u{1FA9D}"},{id:"h7",ko:"\uC911\uD615\uBC14\uB298 7\uD638",en:"Hook #7 (medium)",price:150,size:0,str:12,hookup:1,icon:"\u{1FA9D}"},{id:"h12",ko:"\uB300\uBB3C\uBC14\uB298 12\uD638",en:"Hook #12 (large)",price:400,size:1,str:40,hookup:.85,icon:"\u{1FA9D}"},{id:"circle",ko:"\uC11C\uD074\uD6C5 16\uD638",en:"Circle Hook 16",price:1500,size:2,str:300,hookup:.8,icon:"\u2B55"},{id:"treble",ko:"\uD2B8\uB808\uBE14\uD6C5 (\uB8E8\uC5B4\uC6A9)",en:"Treble Hook",price:500,size:0,str:15,hookup:1,lureHook:1.35,icon:"\u2693"}],chum:[{id:"none",ko:"\uC5C6\uC74C",en:"None",price:0,uses:0,wait:1,boost:{},icon:"\u2014"},{id:"barley",ko:"\uBCF4\uB9AC \uB5A1\uBC25",en:"Barley Groundbait",price:120,uses:15,wait:.75,boost:{crucian:2.2,carp:2,mirrorcarp:2,grasscarp:1.6,palechub:1.6,koi:1.8,golden:1.6,tilapia:1.6},icon:"\u{1F33E}"},{id:"fishmeal",ko:"\uC5B4\uBD84 \uB5A1\uBC25",en:"Fishmeal Groundbait",price:220,uses:15,wait:.65,boost:{carp:2.2,catfish:1.6,crucian:1.6,mirrorcarp:1.8,barbel:1.8,big:1.3},icon:"\u{1F41F}"},{id:"krillchum",ko:"\uD06C\uB9B4 \uBC11\uBC25",en:"Krill Chum",price:200,uses:15,wait:.7,boost:{blackporgy:2.4,opaleye:2.6,seabream:1.8,mackerel:2,horsemackerel:2,sardine:2,mullet:1.6,goldenbream:1.6},icon:"\u{1F990}"},{id:"baitball",ko:"\uC9D1\uC5B4\uC81C (\uACE0\uB4F1\uC5B4 \uBC11\uBC25)",en:"Fish Oil Chum",price:320,uses:12,wait:.7,boost:{yellowtail:2,amberjack:2,tuna:2.2,gt:1.8,mahi:1.8,salmon:1.6,big:1.4},icon:"\u{1F6E2}\uFE0F"}],bait:[{id:"worm",ko:"\uC9C0\uB801\uC774",en:"Earthworm",price:0,pack:0,type:"nat",icon:"\u{1FAB1}"},{id:"corn",ko:"\uC625\uC218\uC218",en:"Sweet Corn",price:60,pack:30,type:"nat",icon:"\u{1F33D}"},{id:"paste",ko:"\uAE00\uB8E8\uD150 \uB5A1\uBC25",en:"Gluten Paste",price:80,pack:30,type:"nat",icon:"\u{1F359}"},{id:"shrimp",ko:"\uBBFC\uBB3C\uC0C8\uC6B0",en:"Live Shrimp",price:120,pack:20,type:"nat",icon:"\u{1F990}"},{id:"krill",ko:"\uD06C\uB9B4",en:"Krill",price:90,pack:30,type:"nat",icon:"\u{1F990}"},{id:"lugworm",ko:"\uAC2F\uC9C0\uB801\uC774",en:"Lugworm",price:100,pack:25,type:"nat",icon:"\u{1FAB1}"},{id:"squid",ko:"\uC624\uC9D5\uC5B4 \uC0B4",en:"Squid Strip",price:110,pack:25,type:"nat",icon:"\u{1F991}"},{id:"minnow",ko:"\uBBF8\uB178\uC6B0 (\uB8E8\uC5B4)",en:"Minnow Lure",price:400,pack:0,type:"lure",icon:"\u{1F420}"},{id:"softworm",ko:"\uC18C\uD504\uD2B8 \uC6DC (\uB8E8\uC5B4)",en:"Soft Plastic Worm",price:250,pack:0,type:"lure",icon:"\u{1FAB1}"},{id:"popper",ko:"\uD3EC\uD37C (\uC218\uBA74 \uB8E8\uC5B4)",en:"Popper",price:500,pack:0,type:"lure",icon:"\u{1FAE7}"},{id:"jig",ko:"\uBA54\uD0C8\uC9C0\uADF8",en:"Metal Jig",price:600,pack:0,type:"lure",icon:"\u{1F529}"}]},qf=["rod","float","hook","chum","bait"],vo=(i,t)=>sl[i].find(e=>e.id===t)||sl[i][0],kb={carp:16e-6,crucian:19e-6,perch:15e-6,disc:16e-6,torpedo:1e-5,salmon:11e-6,slim:8e-6,tuna:19e-6,jack:13e-6,mackerel:9e-6,pike:65e-7,snakehead:8e-6,eel:18e-7,ribbon:12e-7,needle:25e-7,cat:9e-6,rock:16e-6,goby:9e-6,flat:13e-6,puffer:2e-5,mullet:1e-5,cod:1e-5,mahi:9e-6,marlin:75e-7,sturgeon:6e-6,arapaima:75e-7,arowana:7e-6},Xf=(i,t)=>+((kb[i.body]||12e-6)*t**3).toFixed(2);function Yf(i,t){let e=i.w<=2?3:i.w<=6?2:i.w<=14?1:0,n=(t-i.min)/(i.max-i.min);return Math.min(5,1+e+(n>.8?1:0))}function bo(i,t,e){return Math.max(5,Math.round(i.price*Math.max(.2,t)*(.7+.15*e)))}var Ub={all:()=>1,warm:i=>i==="cold"?.25:1,cold:i=>i==="cold"?1.6:i==="tropical"?.1:.55,trop:i=>i==="tropical"?1.8:i==="cold"?0:.15};function Zf({water:i,biome:t,rod:e,float:n,hook:s,chum:r,bait:o,castFrac:a,depthZone:l}){let c=on[i]||on.fresh,h=o.type==="lure";return c.map(u=>{let d=u.w*Ub[u.zone](t),f=u.baits.indexOf(o.id);d*=f===0?4:f>0?2.6:h?.04:.25;let g=h?o.id==="popper"?"top":o.id==="jig"?"mid":u.depth:n.bell?"bot":l||n.depth;d*=u.depth===g?1.6:u.depth==="mid"||g==="mid"?.75:.35,d*=(r.boost[u.id]||1)*(u.max>80&&r.boost.big||1);let x=u.max>120?2:u.max>70?1:u.max>35?0:-1;return d*=Math.max(.15,1-.32*Math.abs(x-s.size)),h&&(d*=e.lure*(s.lureHook||1)),u.max>80&&(d*=(.6+a*.8)*e.big*(n.big||1)),[u,Math.max(0,d)]}).filter(([,u])=>u>0)}function Kf(i,t=Math.random){let e=t()*i.reduce((n,[,s])=>n+s,0);for(let[n,s]of i)if((e-=s)<=0)return n;return i[0][0]}function $n(i,t){let e=i.eel?1:.8,n=Math.min(1,t/e),s=i.hx,r=i.h/2,o=i.ped/i.h,a;if(n<s){let h=(s-n)/s;a=Math.pow(Math.max(0,1-h*h),.5*i.sn)}else{let h=(n-s)/(1-s);a=i.taper?Math.max(.02,1-h)*(1-o)+o:o+(1-o)*Math.pow(Math.cos(h*Math.PI/2),1.25)}let l=r*a*(1-(i.belly||0)),c=r*a*(1+(i.belly||0));return[l,c]}var xo=i=>"#"+i.toString(16).padStart(6,"0");function rl(i,t,e){let n=(i>>16&255)*(1-e)+(t>>16&255)*e,s=(i>>8&255)*(1-e)+(t>>8&255)*e,r=(i&255)*(1-e)+(t&255)*e;return`rgb(${n|0},${s|0},${r|0})`}function Nb(i,t){return t<1?rl(i,0,1-t):rl(i,16777215,t-1)}function zb(i){let t=i>>>0||1;return()=>((t=Math.imul(t^t>>>15,2246822519)^Math.imul(t^t>>>13,3266489917))>>>0)/4294967296}function Fb(i){let t=7;for(let e of i)t=Math.imul(t^e.charCodeAt(0),16777619);return t}function Bb(i){var n;let t=yo[i.body],e=Math.max(((n=t.dorsal)==null?void 0:n[2])||0,t.sail?.22:0);return t.h/2+e+.04}function su(i,t,e,n,s,r=!1){let o=yo[t.body],a=zb(Fb(t.id)),l=(_,b)=>[e+_*s,n-b*s],c=o.eel?1:.8,h=40,u=r?"#26303c":t.pat==="gold"?"rgba(255,214,90,0.9)":rl(t.back,t.acc,.35).replace("rgb","rgba").replace(")",",0.85)"),d=r?"rgba(0,0,0,0)":"rgba(0,0,0,0.18)";i.save(),i.lineJoin="round";let f=([_,b,R],L,D,N)=>{i.beginPath();let[W,k]=l(_,(L?1:-1)*$n(o,_)[L?0:1]*.92);i.moveTo(W,k);let q=10;for(let Q=0;Q<=q;Q++){let at=_+(b-_)*Q/q,Ct=$n(o,at)[L?0:1],qt=R*(N?Math.sin(Math.min(1,Q/q*1.4)*Math.PI*.55)*(1-Q/q*.6)*1.6:D?1-.35*Q/q:Math.sin(Q/q*Math.PI*.85+.25));D&&Q%2===1&&(qt*=.72);let[Y,et]=l(at-R*.15*(Q/q),(L?1:-1)*(Ct+Math.max(.01,qt)));i.lineTo(Y,et)}let[H,K]=l(b,(L?1:-1)*$n(o,b)[L?0:1]*.92);if(i.lineTo(H,K),i.closePath(),i.fillStyle=u,i.fill(),!r){i.strokeStyle=d,i.lineWidth=Math.max(.6,s*.003);for(let Q=1;Q<8;Q++){let at=_+(b-_)*Q/8,Ct=$n(o,at)[L?0:1],[qt,Y]=l(at,(L?1:-1)*Ct),[et,vt]=l(at-R*.15,(L?1:-1)*(Ct+R*.8));i.beginPath(),i.moveTo(qt,Y),i.lineTo(et,vt),i.stroke()}}};if(o.fringe&&(f([.12,.78,.07],!0,!1),f([.22,.78,.06],!1,!1)),o.dorsal&&f(o.dorsal,!0,o.spiny,o.sail),o.dorsal2&&f(o.dorsal2,!0,!1),o.anal&&f(o.anal,!1,!1),o.eel&&(f([.4,.995,.035],!0,!1),f([.5,.995,.03],!1,!1)),o.adipose){let b=$n(o,.72)[0],[R,L]=l(.72,b);i.beginPath(),i.ellipse(R,L-s*.012,s*.02,s*.016,0,0,Math.PI*2),i.fillStyle=u,i.fill()}if(o.finlets){i.fillStyle=r?"#26303c":xo(t.acc);for(let _=0;_<6;_++){let b=.62+_*.028;for(let R of[1,-1]){let L=$n(o,b)[R>0?0:1],[D,N]=l(b,R*L);i.beginPath(),i.moveTo(D-s*.008,N),i.lineTo(D+s*.008,N),i.lineTo(D+s*.01,N-R*s*.018),i.fill()}}}if(!o.eel){let[_]=$n(o,c),[b,R]=l(c-.01,_*.95),[L,D]=l(c-.01,-_*.95),N=o.h*(t.tail==="lunate"?.95:t.tail==="hetero"?.6:.62)+.03;if(i.beginPath(),i.moveTo(b,R),t.tail==="fork"||t.tail==="lunate"){let W=t.tail==="lunate"?.06:.1,[k,q]=l(1,N*.55),[H,K]=l(1-W,0),[Q,at]=l(1,-N*.55),[Ct,qt]=l(c+.08,N*.3),[Y,et]=l(c+.08,-N*.3);i.quadraticCurveTo(Ct,qt,k,q),i.quadraticCurveTo(...l(1-W*.4,N*.15),H,K),i.quadraticCurveTo(...l(1-W*.4,-N*.15),Q,at),i.quadraticCurveTo(Y,et,L,D)}else t.tail==="round"?(i.bezierCurveTo(...l(c+.12,N*.62),...l(1,N*.35),...l(1,0)),i.bezierCurveTo(...l(1,-N*.35),...l(c+.12,-N*.62),L,D)):t.tail==="hetero"?(i.quadraticCurveTo(...l(c+.1,N*.25),...l(1,N*.75)),i.quadraticCurveTo(...l(.92,0),...l(.95,-N*.35)),i.quadraticCurveTo(...l(c+.06,-N*.25),L,D)):(i.quadraticCurveTo(...l(c+.08,N*.4),...l(.98,N*.55)),i.quadraticCurveTo(...l(.96,0),...l(.98,-N*.55)),i.quadraticCurveTo(...l(c+.08,-N*.4),L,D));if(i.closePath(),i.fillStyle=u,i.fill(),!r){i.save(),i.clip(),i.strokeStyle=d,i.lineWidth=Math.max(.6,s*.003);for(let W=-4;W<=4;W++){let[k,q]=l(c,0),[H,K]=l(1.02,W/4*N*.6);i.beginPath(),i.moveTo(k,q),i.lineTo(H,K),i.stroke()}i.restore()}}let g=new Path2D,x=[],m=[];for(let _=0;_<=h;_++){let b=_/h*(o.eel?1:c),[R,L]=$n(o,b);x.push(l(b,R)),m.push(l(b,-L))}g.moveTo(...x[0]);for(let _ of x)g.lineTo(..._);for(let _=m.length-1;_>=0;_--)g.lineTo(...m[_]);g.closePath();let[,,p]=[0,0,o.h/2];if(r){i.fillStyle="#26303c",i.fill(g),o.beak&&(i.beginPath(),i.moveTo(...l(.02,-.01)),i.lineTo(...l(-.12,-.012)),i.lineTo(...l(.02,-.025)),i.fill()),o.bill&&(i.beginPath(),i.moveTo(...l(.02,.012)),i.lineTo(...l(-.2,0)),i.lineTo(...l(.02,-.004)),i.fill()),i.restore();return}let M=i.createLinearGradient(0,n-p*s*1.05,0,n+p*s*1.05);t.pat==="gold"?(M.addColorStop(0,"#d89010"),M.addColorStop(.4,"#ffd040"),M.addColorStop(.55,"#fff0a0"),M.addColorStop(1,"#ffe080")):t.pat==="silver"?(M.addColorStop(0,"#9fb0bc"),M.addColorStop(.45,"#f4f8fb"),M.addColorStop(.55,"#ffffff"),M.addColorStop(1,"#c8d2da")):(M.addColorStop(0,xo(t.back)),M.addColorStop(.38,xo(t.side)),M.addColorStop(.62,rl(t.side,t.belly,.5)),M.addColorStop(1,xo(t.belly))),i.fillStyle=M,i.fill(g),i.save(),i.clip(g);let v=(_,b)=>{let[R,L]=$n(o,_);return b>=0?R*b:L*b},y=_=>`rgba(${t.acc>>16&255},${t.acc>>8&255},${t.acc&255},${_})`,w=_=>`rgba(10,12,10,${_})`;switch(t.pat){case"bars":case"bars7":case"barspink":{let _=t.pat==="bars7"||t.body==="disc"?7:6;for(let b=0;b<_;b++){let R=.16+b*(c-.2)/_;i.fillStyle=t.pat==="barspink"?"rgba(90,110,150,0.45)":t.pat==="bars7"?w(.75):w(.3),i.beginPath(),i.moveTo(...l(R,.4)),i.lineTo(...l(R+.045,.4)),i.lineTo(...l(R+.03+(t.pat==="bars7"?.02:0),-.4)),i.lineTo(...l(R-.015,-.4)),i.fill()}t.pat==="barspink"&&(i.fillStyle="rgba(240,110,140,0.35)",i.fillRect(...l(.1,-.005),s*.7,s*o.h*.25));break}case"lateral":i.fillStyle=w(.42);for(let _=0;_<9;_++){let b=.14+_*.075,[R,L]=l(b,(a()-.5)*.02);i.beginPath(),i.ellipse(R,L,s*.04,s*.022,0,0,7),i.fill()}break;case"spots":case"redspots":for(let _=0;_<70;_++){let b=.08+a()*(c-.06),R=a()*1.6-.45;if(R<-.3&&t.pat!=="redspots")continue;let[L,D]=l(b,v(b,Math.min(.92,R)));i.fillStyle=t.pat==="redspots"?a()<.7?"rgba(220,60,40,0.85)":"rgba(250,230,200,0.8)":w(.42),i.beginPath(),i.arc(L,D,s*(.006+a()*.007),0,7),i.fill()}break;case"marble":for(let _=0;_<22;_++){let b=.06+a()*(c-.04),R=a()*1.6-.6,[L,D]=l(b,v(b,R));i.fillStyle=w(.18+a()*.22),i.beginPath(),i.ellipse(L,D,s*(.025+a()*.04),s*(.012+a()*.03),a()*3,0,7),i.fill()}break;case"blotch":for(let _=0;_<9;_++){let b=.15+_*.075;for(let R of[.45,-.1]){let[L,D]=l(b+(R<0?.035:0),v(b,R));i.fillStyle=w(.5),i.beginPath(),i.ellipse(L,D,s*.03,s*.02,.3,0,7),i.fill()}}break;case"wavy":i.strokeStyle="rgba(10,25,40,0.65)",i.lineWidth=s*.006;for(let _=0;_<16;_++){let b=.14+_*.04;i.beginPath(),i.moveTo(...l(b,v(b,1))),i.quadraticCurveTo(...l(b+.03,v(b,.6)),...l(b-.005,v(b,.15))),i.stroke()}break;case"lines":i.strokeStyle="rgba(30,40,50,0.35)",i.lineWidth=s*.004;for(let _ of[.75,.5,.25,0]){i.beginPath();for(let b=0;b<=20;b++){let R=.12+b*(c-.14)/20,L=l(R,v(R,_));b?i.lineTo(...L):i.moveTo(...L)}i.stroke()}break;case"yellowline":i.strokeStyle="rgba(245,210,60,0.9)",i.lineWidth=s*o.h*.07,i.beginPath();for(let _=0;_<=20;_++){let b=.05+_*(c-.03)/20,R=l(b,v(b,.05));_?i.lineTo(...R):i.moveTo(...R)}i.stroke();break;case"pinkband":i.strokeStyle="rgba(232,96,122,0.55)",i.lineWidth=s*o.h*.22,i.beginPath();for(let _=0;_<=20;_++){let b=.12+_*(c-.12)/20,R=l(b,v(b,-.05));_?i.lineTo(...R):i.moveTo(...R)}i.stroke();for(let _=0;_<60;_++){let b=.1+a()*(c-.04),R=a()*1.1-.1,[L,D]=l(b,v(b,R));i.fillStyle=w(.45),i.beginPath(),i.arc(L,D,s*.005,0,7),i.fill()}break;case"parr":for(let _=0;_<8;_++){let b=.18+_*.07,[R,L]=l(b,0);i.fillStyle="rgba(40,50,80,0.4)",i.beginPath(),i.ellipse(R,L,s*.022,s*o.h*.32,0,0,7),i.fill()}break;case"bluedots":for(let _=0;_<40;_++){let b=.1+a()*(c-.1),R=a()*1.2-.2,[L,D]=l(b,v(b,R));i.fillStyle="rgba(80,190,255,0.9)",i.beginPath(),i.arc(L,D,s*.006,0,7),i.fill()}break;case"koi":for(let _=0;_<4;_++){let b=.1+_*.17+a()*.05,[R,L]=l(b,v(b,.5-a()*.4));i.fillStyle=_===2?"rgba(20,20,20,0.85)":"rgba(226,72,42,0.92)",i.beginPath(),i.ellipse(R,L,s*(.06+a()*.04),s*(.04+a()*.04),a(),0,7),i.fill()}break;case"mirror":for(let _=0;_<9;_++){let b=.2+_*.065,[R,L]=l(b,v(b,.75));i.fillStyle="rgba(255,240,200,0.35)",i.strokeStyle="rgba(60,50,20,0.35)",i.lineWidth=s*.003,i.beginPath(),i.ellipse(R,L,s*.03,s*.024,0,0,7),i.fill(),i.stroke()}break;case"redtail":{let _=i.createLinearGradient(...l(.45,0),...l(c,0));_.addColorStop(0,"rgba(200,58,42,0)"),_.addColorStop(1,"rgba(200,58,42,0.85)"),i.fillStyle=_,i.fillRect(...l(.45,.5),s*.4,s);break}case"scutes":for(let _ of[.85,.2,-.6])for(let b=0;b<12;b++){let R=.18+b*.05,[L,D]=l(R,v(R,_));i.fillStyle="rgba(240,236,220,0.8)",i.beginPath(),i.moveTo(L-s*.01,D),i.lineTo(L,D-s*.01),i.lineTo(L+s*.01,D),i.lineTo(L,D+s*.01),i.fill()}break;case"tuna":i.fillStyle="rgba(70,110,180,0.35)",i.fillRect(...l(.1,v(.4,.35)),s*.7,s*o.h*.12);break;case"mahi":for(let _=0;_<40;_++){let b=.1+a()*.65,R=a()*1.4-.4,[L,D]=l(b,v(b,R));i.fillStyle="rgba(40,110,200,0.7)",i.beginPath(),i.arc(L,D,s*.006,0,7),i.fill()}break;case"marlin":for(let _=0;_<12;_++){let b=.2+_*.05;i.strokeStyle="rgba(140,200,255,0.55)",i.lineWidth=s*.006,i.beginPath(),i.moveTo(...l(b,v(b,.9))),i.lineTo(...l(b+.01,v(b,-.4))),i.stroke()}break}if(o.scales||t.pat==="gold"){i.strokeStyle=t.pat==="gold"?"rgba(160,100,0,0.25)":"rgba(0,0,0,0.12)",i.lineWidth=Math.max(.5,s*.0025);let _=.028;for(let b=.18;b<c;b+=_)for(let R=-1;R<=1;R+=.16){let[L,D]=l(b+(Math.round(R/.16)%2?_/2:0),v(b,R));i.beginPath(),i.arc(L,D,s*_*.55,-1.2,1.2),i.stroke()}}let S=i.createLinearGradient(0,n-p*s,0,n+p*s*.2);S.addColorStop(0,"rgba(255,255,255,0)"),S.addColorStop(.55,"rgba(255,255,255,0.18)"),S.addColorStop(.8,"rgba(255,255,255,0)"),i.fillStyle=S,i.fill(g),i.strokeStyle="rgba(0,0,0,0.18)",i.lineWidth=Math.max(.6,s*.003),i.beginPath();for(let _=0;_<=20;_++){let b=.2+_*(c-.22)/20,R=l(b,v(b,.42-_/20*.4));_?i.lineTo(...R):i.moveTo(...R)}i.stroke();let A=.2+(o.sn<.7?.02:0);i.strokeStyle="rgba(0,0,0,0.28)",i.lineWidth=Math.max(.8,s*.006),i.beginPath(),i.moveTo(...l(A-.02,v(A,.85))),i.quadraticCurveTo(...l(A+.035,0),...l(A-.02,v(A,-.85))),i.stroke(),i.restore(),i.strokeStyle="rgba(0,0,0,0.25)",i.lineWidth=Math.max(.6,s*.004),i.stroke(g);{let[_,b]=l(.24,-o.h*.08);i.save(),i.translate(_,b),i.rotate(.5),i.beginPath(),i.ellipse(s*.04,0,s*.055,s*Math.max(.012,o.h*.1),0,0,7),i.fillStyle=u,i.fill(),i.restore()}i.strokeStyle="rgba(40,20,20,0.55)",i.lineWidth=Math.max(.8,s*.005);let P=o.bigMouth?.075:.03;if(i.beginPath(),i.moveTo(...l(.005,-o.h*.06)),i.quadraticCurveTo(...l(P*.6,-o.h*.12),...l(P,-o.h*.05)),i.stroke(),o.hookJaw&&(i.beginPath(),i.moveTo(...l(0,-o.h*.04)),i.quadraticCurveTo(...l(-.015,o.h*.02),...l(.01,o.h*.05)),i.stroke()),o.beak&&(i.fillStyle="#e86a3a",i.beginPath(),i.moveTo(...l(.02,-.006)),i.lineTo(...l(-.12,-.012)),i.lineTo(...l(.02,-.022)),i.fill()),o.bill&&(i.fillStyle=xo(t.back),i.beginPath(),i.moveTo(...l(.03,.014)),i.lineTo(...l(-.2,.002)),i.lineTo(...l(.03,-.006)),i.fill()),o.barbel||o.whisker){i.strokeStyle=Nb(t.back,.8),i.lineWidth=Math.max(.8,s*.004),i.lineCap="round";let _=o.barbel===2?3:1,b=o.barbel===2?.16:o.whisker?.05:.04;for(let R=0;R<_;R++)i.beginPath(),i.moveTo(...l(.03,-o.h*.08-R*.004)),i.quadraticCurveTo(...l(.04+b*.3,-o.h*.2-R*.02),...l(.03+b*(.6+R*.25),-o.h*.38-R*.04)),i.stroke()}{let _=o.sn<.7?.075:o.sn>1.3?.12:.085,b=Math.max(.012,o.h*.09)*(t.body==="tuna"||t.body==="disc"?1.15:1),[R,L]=l(_,o.h*.12);i.fillStyle=t.pat==="gold"?"#fff3c0":"#f4e7b8",i.beginPath(),i.arc(R,L,s*b,0,7),i.fill(),i.fillStyle="#111",i.beginPath(),i.arc(R-s*b*.1,L,s*b*.66,0,7),i.fill(),i.fillStyle="rgba(255,255,255,0.9)",i.beginPath(),i.arc(R-s*b*.35,L-s*b*.3,s*b*.22,0,7),i.fill()}i.restore()}function ol(i,t,e,n,s,r,o=!1){let a=Bb(t),l=yo[t.body],c=l.bill?.2:l.beak?.12:0,h=Math.min(s/(1.02+c),r/(2*a)),u=e+(s-h*(1+c))/2+h*c;su(i,t,u,n+r/2,h,o)}var ru=20,jf="taeil-lounge.fishing.v2",ni=.02,yt=(i,t)=>rn()==="ko"?i:t;function Ob(){let i=null;try{i=JSON.parse(localStorage.getItem(jf))}catch{}if(!i){let t=null;try{t=JSON.parse(localStorage.getItem("taeil-lounge.fishing.v1"))}catch{}i={coins:800,dex:(t==null?void 0:t.dex)||{},net:(t==null?void 0:t.net)||[]}}i.coins??=800,i.own||={rod:["bamboo"],float:["stick"],hook:["h3"],chum:["none"],bait:["worm"]},i.eq||={rod:"bamboo",float:"stick",hook:"h3",chum:"none",bait:"worm"},i.inv||={},i.net=(i.net||[]).filter(t=>qn[t.id]);for(let t of Object.keys(i.dex||{}))qn[t]||delete i.dex[t];return i}function qi(i){try{localStorage.setItem(jf,JSON.stringify(i))}catch{}}var ou=new Map,al=512,ll=384,Ts=440,au=40,lu=192;function Hb(i){if(ou.has(i.id))return ou.get(i.id);let t=document.createElement("canvas");t.width=al,t.height=ll,su(t.getContext("2d"),i,au,lu,Ts);let e=new Je(t);e.colorSpace=me,e.anisotropy=4;let n=yo[i.body],s=n.eel?1:.8,r=30,o=16,a=[],l=[],c=[];for(let m=0;m<=r;m++){let p=m/r*s,[M,v]=$n(n,p),y=(M-v)/2,w=Math.max(5e-4,(M+v)/2),S=w*n.w*(.75+.25*Math.min(1,p*5));for(let A=0;A<=o;A++){let P=A/o*Math.PI*2,_=y+Math.cos(P)*w,b=Math.sin(P)*S;a.push(p-.5,_,b),l.push((au+p*Ts)/al,1-(lu-_*Ts)/ll)}}for(let m=0;m<r;m++)for(let p=0;p<o;p++){let M=m*(o+1)+p,v=M+o+1;c.push(M,v,M+1,v,v+1,M+1)}let h=new ae;h.setAttribute("position",new Ot(a,3)),h.setAttribute("uv",new Ot(l,2)),h.setIndex(c),h.computeVertexNormals();let u=i.pat==="gold"||i.pat==="silver",d=wn(new ye({map:e,roughness:.32,metalness:u?.55:.12})),f=new Mn(al/Ts,ll/Ts);f.translate((al/2-au)/Ts-.5,(lu-ll/2)/Ts,0);let g=wn(new ye({map:e,alphaTest:.45,side:Te,roughness:.5})),x={body:h,bodyMat:d,fins:f,finMat:g,tex:e};return ou.set(i.id,x),x}function cu(i,t){let e=Hb(i),n=new Jt,s=new nt(e.body,e.bodyMat),r=new nt(e.fins,e.finMat);return s.castShadow=!0,n.add(s,r),n.scale.setScalar(t),n}function Vb(i){let t=new Jt;t.position.set(0,-.06,.05),t.rotation.x=1.86;let e=Tt(i.col,{roughness:.28,metalness:i.id==="goldrod"?.8:.35}),n=Tt(12159573,{roughness:.9}),s=new nt(new Ut(.024,.028,.42,8),n);s.position.y=-.12;let r=new nt(new Ut(.055,.055,.05,14),Tt(12633290,{metalness:.9,roughness:.25}));r.rotation.z=Math.PI/2,r.position.set(0,0,-.07);let o=new nt(new $t(.012,.012,.07),Tt(2236962));o.position.set(.04,0,-.07),t.add(s,r,o);let a=4,l=(i.len-.3)/a,c=[],h=t,u=.02;for(let g=0;g<a;g++){let x=Math.max(.004,u*.62),m=new Ut(x,u,l,6);m.translate(0,l/2,0);let p=new Jt;p.position.y=g===0?.09:l;let M=new nt(m,e);M.castShadow=!0,p.add(M);let v=new nt(new gs(u+.012,.003,4,10),Tt(14540253,{metalness:.8}));v.position.set(0,l*.5,-(u+.012)),v.rotation.y=Math.PI/2,p.add(v),h.add(p),c.push(p),h=p,u=x}let d=new nt(new Ce(.009,6,4),Tt(16734778,{emissive:5574912}));d.position.y=l,h.add(d);let f=new Oe;return f.position.y=l,h.add(f),{root:t,sections:c,tip:f}}function Gb(){let i=document.createElement("canvas");i.width=8,i.height=64;let t=i.getContext("2d");["#ff2d1a","#ffd400","#ff2d1a","#2ee06a","#ff2d1a","#ffd400","#ff2d1a","#ffffff"].forEach((s,r)=>{t.fillStyle=s,t.fillRect(0,r*8,8,8)});let n=new Je(i);return n.colorSpace=me,n}var hu=null;function Wb(i,t){let e=new Jt;if(t.type==="lure"){if(t.id==="popper"){let d=new nt(new Ut(.035,.02,.12,10),Tt(16179274,{roughness:.3}));d.rotation.z=Math.PI/2,e.add(d)}else if(t.id==="jig"){let d=new nt(new $t(.14,.03,.015),Tt(12634320,{metalness:.95,roughness:.15}));e.add(d)}else if(t.id==="softworm"){let d=new nt(new Gn(.01,.1,3,6),Tt(6961802,{roughness:.5}));d.rotation.z=Math.PI/2,e.add(d)}else{let d=new nt(new Gn(.02,.08,4,8),Tt(6987976,{metalness:.6,roughness:.25}));d.rotation.z=Math.PI/2;let f=new nt(new $t(.03,.002,.025),Tt(15658734,{transparent:!0,opacity:.7}));f.position.set(-.07,-.01,0),e.add(d,f)}return e.userData.top=.02,e}if(i.id==="sinker"){let d=new nt(new Ce(.03,8,6),Tt(3355443,{metalness:.6}));return e.add(d),e.userData.top=0,e.userData.hidden=!0,e}hu||=Gb();let s=Tt(16726815,{emissive:3344384,roughness:.4}),r=Tt(16053488,{roughness:.4});if(i.id==="round"||i.id==="bigfloat"){let d=i.id==="bigfloat"?.07:.05,f=new nt(new Ce(d,16,8,0,Math.PI*2,0,Math.PI/2),s),g=new nt(new Ce(d,16,8,0,Math.PI*2,Math.PI/2,Math.PI/2),r),x=new nt(new Ut(.005,.005,.12,6),new ye({map:hu}));return x.position.y=d+.05,e.add(f,g,x),e.userData.top=d+.11,e}let o=i.id==="shallow",a=o?.1:.2,l=o?.12:.3,c=new nt(new Gn(o?.022:.016,a,4,10),o?s:Tt(16747034,{roughness:.35}));c.position.y=-a/2-.01;let h=new nt(new Ut(.006,.008,l,8),i.glow?new ye({color:10354554,emissive:7012160,emissiveIntensity:1.6}):new ye({map:hu,roughness:.4}));h.position.y=l/2;let u=new nt(new Ut(.003,.003,.1,4),r);return u.position.y=-a-.07,e.add(c,h,u),e.userData.top=l,e}var cl=class{constructor(t){this.ctx=t,this.store=Ob(),this.rodHolder=new Jt,this.bobber=new Jt,this.bobber.visible=!1,t.scene.add(this.bobber),this.line=new Ln(new ae().setFromPoints([new C,new C]),wn(new bi({color:16185078,transparent:!0,opacity:.85}))),this.line.frustumCulled=!1,this.line.visible=!1,t.scene.add(this.line),this.ripples=[0,1,2,3].map(()=>{let e=new nt(new fn(.15,.2,32),wn(new Le({color:16777215,transparent:!0,opacity:0,depthWrite:!1})));return e.rotation.x=-Math.PI/2,t.scene.add(e),{m:e,t:9}}),this.marker=new nt(new fn(.5,.75,40),wn(new Le({color:16769354,transparent:!0,opacity:.85,depthWrite:!1}))),this.marker.rotation.x=-Math.PI/2,this.marker.visible=!1,t.scene.add(this.marker),this.shadow=new nt(new je(.5,16),wn(new Le({color:660504,transparent:!0,opacity:0,depthWrite:!1}))),this.shadow.rotation.x=-Math.PI/2,this.shadow.scale.set(1,.35,1),t.scene.add(this.shadow),this.pip={on:!1,el:null,cam:new Be(28,4/3,.03,400)},this.buildNet(),this.buildUI(),this.equip(),this.state="idle",this.lean=0}get water(){return this.ctx.venue.water||"fresh"}gear(t){return vo(t,this.store.eq[t])}equip(){var e;let t=this.gear("rod");this.rod&&this.rodHolder.remove(this.rod.root),this.rod=Vb(t),this.rodHolder.add(this.rod.root),this.bobber.clear(),this.floatMesh=Wb(this.gear("float"),this.gear("bait")),this.bobber.add(this.floatMesh),(e=this.updateGearBar)==null||e.call(this)}buildNet(){let t=this.netGroup=new Jt,e=Kt.pier;t.position.set(-50.2,0,e.hw+.55);let n=new nt(new Ut(.4,.34,1.2,18,5,!0),new ye({color:2046762,wireframe:!0,transparent:!0,opacity:.75}));n.position.y=-.25;let s=new nt(new gs(.4,.02,6,24),Tt(2976335));s.rotation.x=Math.PI/2,s.position.y=.35,t.add(n,s),this.netFish=[],this.ctx.scene.add(t),this.refreshNet3D()}refreshNet3D(){for(let t of this.netFish)this.netGroup.remove(t);this.netFish=this.store.net.slice(-8).map((t,e)=>{let n=cu(qn[t.id],.14+Math.min(.24,t.cm/380));return n.userData.phase=e*1.3,this.netGroup.add(n),n})}buildUI(){this.uiLang=rn();let t=this.ui={};t.bar=De("gp-fish",`
      <div class="mid" id="fStatus" style="text-align:center"></div>
      <div id="fBars" style="margin-top:8px">
        <div class="row" style="justify-content:space-between"><span class="dim" id="fBar1L"></span><span id="fBar1V"></span></div>
        <div class="gp-meter" id="fBar1" style="margin-top:3px"><span class="zone"></span><i></i><span class="mark" hidden></span></div>
        <div id="fFight" hidden>
          <div class="row" style="justify-content:space-between;margin-top:6px"><span class="dim">${U("fishStamina")}</span><span id="fHpV"></span></div>
          <div class="gp-meter" id="fHp" style="margin-top:3px;height:10px"><i style="background:linear-gradient(90deg,#60a5fa,#a78bfa)"></i></div>
          <div class="row" style="justify-content:center;gap:16px;margin-top:6px;font-size:22px"><span id="fL">\u25C0</span><span id="fRod" style="font-size:14px" class="dim"></span><span id="fR">\u25B6</span></div>
        </div>
      </div>
      <div id="fSet" class="row" style="justify-content:center;margin-top:7px;font-size:12px;gap:4px 6px;align-items:center">
        <span id="fDepthW"><span class="dim">${yt("\uC218\uC2EC","Depth")}</span> <button data-d="-1" class="sm">\u2212</button> <b id="fDepth"></b> <button data-d="1" class="sm">\uFF0B</button> <span class="dim" id="fBottom"></span></span>
        <span class="dim">\xB7</span>
        <span><span class="dim">${yt("\uB4DC\uB799","Drag")}</span> <button data-g="-1" class="sm">\u2212</button> <b id="fDrag"></b> <button data-g="1" class="sm">\uFF0B</button></span>
      </div>
      <div id="fGear" class="row" style="justify-content:center;margin-top:7px;font-size:12px;gap:4px 10px"></div>
      <div class="dim" id="fHelp" style="margin-top:5px;text-align:center;font-size:11px"></div>`),t.bar.style.cssText="left:50%;transform:translateX(-50%);bottom:max(14px, env(safe-area-inset-bottom));padding:10px 14px;width:min(500px, calc(100vw - 150px))",t.btns=De("gp-fish-btns",`<div class="row" style="flex-direction:column;align-items:stretch">
      <div class="mid" style="text-align:center;color:#fde047" id="fCoins"></div>
      <button data-a="tackle">\u{1F392} ${yt("\uC7A5\uBE44\xB7\uC0C1\uC810","Tackle shop")}</button>
      <button data-a="net">\u{1F9FA} <span>${U("keepNet")}</span> <b id="fNetN"></b></button>
      <button data-a="dex">\u{1F4D6} ${U("dex")} <b id="fDexN"></b></button>
      <button data-a="exit">${U("exit")}</button></div>`),t.btns.style.cssText="right:10px;top:calc(max(10px, env(safe-area-inset-top)) + 54px);padding:8px",t.btns.querySelector("[data-a=tackle]").onclick=()=>this.toggle("tackle"),t.btns.querySelector("[data-a=net]").onclick=()=>this.toggle("net"),t.btns.querySelector("[data-a=dex]").onclick=()=>this.toggle("dex"),t.btns.querySelector("[data-a=exit]").onclick=()=>this.ctx.exit(),t.pip=De("gp-fish-pip",`<div class="pipLabel">\u{1F50D} ${yt("\uCC0C \uD655\uB300","Float close-up")}</div><div class="pipHint" id="fPipHint"></div>`),t.pip.style.cssText="left:10px;top:calc(max(10px, env(safe-area-inset-top)) + 110px);width:min(300px, 34vw);height:min(225px, 26vw);padding:0;background:transparent;pointer-events:none;border:2px solid rgba(255,255,255,.75);overflow:hidden",this.pip.el=t.pip,t.card=De("gp-fish-card",""),t.card.style.cssText="left:12px;top:50%;transform:translateY(-50%);padding:16px;width:min(320px, calc(100vw - 24px));text-align:center",t.list=De("gp-fish-list",""),t.list.style.cssText="left:50%;top:50%;transform:translate(-50%,-50%);padding:14px;width:min(640px, calc(100vw - 24px));max-height:80vh;overflow:auto",t.status=t.bar.querySelector("#fStatus"),t.bar.querySelectorAll("[data-d]").forEach(e=>e.onclick=()=>this.setDepth(+e.dataset.d)),t.bar.querySelectorAll("[data-g]").forEach(e=>e.onclick=()=>this.setDrag(+e.dataset.g)),this.updateGearBar()}setDepth(t){if(this.state!=="idle"&&this.state!=="returning"){this.ctx.toast(yt("\uB358\uC9C0\uAE30 \uC804\uC5D0 \uC870\uC808\uD558\uC138\uC694","Set it before casting"));return}this.store.depthM=Math.round(Math.max(.3,Math.min(5,(this.store.depthM??1.2)+t*.1))*10)/10,qi(this.store),this.updateSetRow()}setDrag(t){this.store.drag=Math.max(1,Math.min(10,(this.store.drag??7)+t)),qi(this.store),this.updateSetRow()}bottomAt(t){return Math.round((.8+Math.min(1,t/22)*3.4)*10)/10}dragLimit(){return .45+(this.store.drag??7)*.07}updateSetRow(){var s;let t=(s=this.ui)==null?void 0:s.bar.querySelector("#fSet");if(!t)return;let e=this.gear("float"),n=this.gear("bait").type==="lure";t.querySelector("#fDepthW").style.display=n?"none":"",t.querySelector("#fDepth").textContent=e.bell?yt("\uBC14\uB2E5","bottom"):`${(this.store.depthM??1.2).toFixed(1)} m`,t.querySelectorAll("[data-d]").forEach(r=>r.hidden=!!e.bell),t.querySelector("#fBottom").textContent=this.castDist&&this.state!=="idle"?`(${yt("\uBC14\uB2E5","bottom")} ${this.bottomAt(this.castDist).toFixed(1)} m)`:"",t.querySelector("#fDrag").textContent=this.store.drag??7}updateGearBar(){if(!this.ui)return;this.updateSetRow();let t=r=>this.gear(r),e=t("bait"),n=t("chum"),s=e.pack?this.store.inv[e.id]||0:"\u221E";this.ui.bar.querySelector("#fGear").innerHTML=`<span>${t("rod").icon} ${Pe(Ss(t("rod")))}</span><span>${t("float").icon} ${Pe(Ss(t("float")))}</span><span>${t("hook").icon} ${Pe(Ss(t("hook")))}</span><span>${e.icon} ${Pe(Ss(e))} <b>${s}</b></span>`+(n.id!=="none"?`<span>${n.icon} ${Pe(Ss(n))} <b>${this.store.inv[n.id]||0}</b></span>`:""),this.ui.bar.querySelector("#fHelp").textContent=e.type==="lure"?yt("\uC2A4\uD398\uC774\uC2A4(\uBC84\uD2BC) \uB204\uB978 \uCC44 \uB193\uAE30: \uCE90\uC2A4\uD305 \xB7 \uB204\uB974\uACE0 \uC788\uC73C\uBA74 \uB8E8\uC5B4 \uAC10\uAE30 \xB7 \uB35C\uCEE5! \uD558\uBA74 \uD0ED \xB7 \u2190\u2192 \uBC29\uD5A5","Hold & release to cast \xB7 hold to retrieve the lure \xB7 tap when it thumps \xB7 \u2190\u2192 aim"):yt("\uC2A4\uD398\uC774\uC2A4(\uBC84\uD2BC) \uB20C\uB7EC \uAC8C\uC774\uC9C0 \u2192 \uC6D0\uD558\uB294 \uD798\uC5D0\uC11C \uB193\uAE30 \xB7 \uCC0C\uAC00 \uC62C\uB77C\uC624\uAC70\uB098 \uC7A0\uAE30\uBA74 \uD0ED(\uCC54\uC9C8) \xB7 \uD30C\uC774\uD305: \uB204\uB974\uACE0 \uAC10\uAE30 + \u2190\u2192\uB85C \uBC84\uD2F0\uAE30 \xB7 [ ] \uC218\uC2EC \xB7 \u2191\u2193 \uB4DC\uB799","Hold, release at the power you want \xB7 strike when the float rises or dives \xB7 fight: hold to reel, lean \u2190\u2192 \xB7 [ ] depth \xB7 \u2191\u2193 drag"),this.ui.btns&&(this.ui.btns.querySelector("#fCoins").textContent=`\u{1F4B0} ${this.store.coins.toLocaleString()}`)}toggle(t){let e=this.ui.list;if(!e.hidden&&this.listMode===t){e.hidden=!0;return}this.listMode=t,e.hidden=!1,t==="net"?this.renderNet():t==="dex"?this.renderDex():this.renderTackle()}renderNet(){var o;let t=this.ui.list,e=this.store.net,n=e.reduce((a,l)=>a+l.kg,0),s=e.reduce((a,l)=>a+bo(qn[l.id],l.kg,l.st),0),r=`<h3>\u{1F9FA} ${U("keepNet")} ${e.length}/${ru} \xB7 ${U("totalWeight")} ${n.toFixed(2)} kg \xB7 \u{1F4B0} ${s.toLocaleString()}</h3>`;e.length||(r+=`<div class="dim" style="padding:20px;text-align:center">${U("emptyNet")}</div>`),r+='<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px">',e.forEach((a,l)=>{let c=qn[a.id];r+=`<div class="slot" style="flex-direction:column;align-items:stretch"><canvas data-i="${l}" width="280" height="112" style="width:100%"></canvas>
        <b>${Pe(wi(a.id))}</b><span class="dim">${a.cm} cm \xB7 ${a.kg} kg \xB7 <span style="color:#fde047">${"\u2605".repeat(a.st)}</span></span>
        <div class="row" style="margin-top:4px"><button data-sell="${l}" style="flex:1">\u{1F4B0} ${bo(c,a.kg,a.st)}</button><button data-rel="${l}">${U("release")}</button></div></div>`}),r+=`</div><div class="row" style="justify-content:flex-end;margin-top:10px">${e.length?`<button data-a="all" class="go">\u{1F4B0} ${yt("\uBAA8\uB450 \uD310\uB9E4","Sell all")} +${s.toLocaleString()}</button>`:""}<button data-a="close">\u2715</button></div>`,t.innerHTML=r,t.querySelectorAll("canvas[data-i]").forEach(a=>ol(a.getContext("2d"),qn[e[+a.dataset.i].id],6,4,268,104)),t.querySelectorAll("[data-rel]").forEach(a=>a.onclick=()=>{e.splice(+a.dataset.rel,1),this.afterNet(),this.renderNet()}),t.querySelectorAll("[data-sell]").forEach(a=>a.onclick=()=>{let l=e.splice(+a.dataset.sell,1)[0];this.earn(bo(qn[l.id],l.kg,l.st)),this.afterNet(),this.renderNet()}),(o=t.querySelector("[data-a=all]"))==null||o.addEventListener("click",()=>{e.length=0,this.earn(s),this.afterNet(),this.renderNet()}),t.querySelector("[data-a=close]").onclick=()=>{t.hidden=!0}}earn(t){var e,n;t&&(this.store.coins+=t,(n=(e=this.ctx.audio)==null?void 0:e.coin)==null||n.call(e),this.ctx.toast(`\u{1F4B0} +${t.toLocaleString()}`),qi(this.store),this.updateGearBar())}renderDex(t=this.dexWater||this.water){this.dexWater=t;let e=this.ui.list,n=this.store.dex,s=on[t],r=s.filter(h=>n[h.id]).length,o=on.fresh.length+on.sea.length,a=[...on.fresh,...on.sea].filter(h=>n[h.id]).length,l=`<div class="row" style="justify-content:space-between"><h3 style="margin:0">\u{1F4D6} ${U("dex")} ${a}/${o}</h3>
      <div class="row"><button data-w="fresh" class="${t==="fresh"?"on":""}">${U("freshWater")} ${on.fresh.filter(h=>n[h.id]).length}/${on.fresh.length}</button>
      <button data-w="sea" class="${t==="sea"?"on":""}">${U("seaWater")} ${on.sea.filter(h=>n[h.id]).length}/${on.sea.length}</button></div></div>
      <div class="dim" style="margin:4px 0 8px">${r}/${s.length} \xB7 ${yt("\uC7A1\uC740 \uC5B4\uC885\uC740 \uC88B\uC544\uD558\uB294 \uBBF8\uB07C\uAC00 \uD45C\uC2DC\uB3FC\uC694","Caught species show their favourite baits")}</div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:8px">`,c=h=>h.w<=1?"\u{1F31F}":h.w<=2?"\u{1F48E}":h.w<=6?"\u2B50":"";s.forEach((h,u)=>{let d=n[h.id],f=h.baits.slice(0,2).map(g=>vo("bait",g).icon).join(" ");l+=`<div class="slot" style="flex-direction:column;align-items:stretch;text-align:center;gap:2px"><canvas data-i="${u}" width="260" height="110" style="width:100%"></canvas>
        <b>${c(h)} ${d?Pe(wi(h.id)):U("unknown")}</b><span class="dim" style="font-size:11px">${d?`${U("best")} ${d.cm} cm \xB7 \xD7${d.n} \xB7 ${f} \xB7 ${{top:yt("\uD45C\uCE35","top"),mid:yt("\uC911\uCE35","mid"),bot:yt("\uBC14\uB2E5","bottom")}[h.depth]}`:`${h.min}\u2013${h.max} cm`}</span></div>`}),l+='</div><div class="row" style="justify-content:flex-end;margin-top:10px"><button data-a="close">\u2715</button></div>',e.innerHTML=l,e.querySelectorAll("canvas[data-i]").forEach(h=>{let u=s[+h.dataset.i];ol(h.getContext("2d"),u,6,4,248,102,!n[u.id])}),e.querySelectorAll("[data-w]").forEach(h=>h.onclick=()=>this.renderDex(h.dataset.w)),e.querySelector("[data-a=close]").onclick=()=>{e.hidden=!0}}renderTackle(t=this.tackleTab||"rod"){this.tackleTab=t;let e=this.ui.list,n=this.store,s={rod:yt("\uB09A\uC2EF\uB300","Rods"),float:yt("\uCC0C\xB7\uCC44\uBE44","Floats"),hook:yt("\uBC14\uB298","Hooks"),chum:yt("\uB5A1\uBC25\xB7\uBC11\uBC25","Groundbait"),bait:yt("\uBBF8\uB07C\xB7\uB8E8\uC5B4","Bait & lures")},r=`<div class="row" style="justify-content:space-between"><h3 style="margin:0">\u{1F392} ${yt("\uC7A5\uBE44\xB7\uC0C1\uC810","Tackle shop")}</h3><span class="mid" style="color:#fde047">\u{1F4B0} ${n.coins.toLocaleString()}</span></div>
      <div class="row" style="margin:8px 0">${qf.map(l=>`<button data-tab="${l}" class="${l===t?"on":""}">${s[l]}</button>`).join("")}</div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:8px">`,o=l=>on[this.water].filter(c=>c.baits[0]===l||c.baits[1]===l).slice(0,4).map(c=>wi(c.id)).join(", "),a={top:yt("\uC595\uC740 \uC218\uC2EC","shallow"),mid:yt("\uC911\uCE35","mid-water"),bot:yt("\uBC14\uB2E5","bottom")};for(let l of sl[t]){let c=n.own[t].includes(l.id),h=n.eq[t]===l.id,u=t==="bait"&&l.pack||t==="chum"&&l.uses?n.inv[l.id]||0:null,d="";t==="rod"&&(d=`${yt("\uCD5C\uB300","max")} ${l.cast} m \xB7 ${yt("\uAC15\uB3C4","power")} \xD7${l.str} \xB7 ${yt("\uAC10\uB3C4","feel")} \xD7${l.sens}${l.lure>1?` \xB7 ${yt("\uB8E8\uC5B4","lures")} \xD7${l.lure}`:""}`),t==="float"&&(d=`${yt("\uAC10\uB3C4","feel")} \xD7${l.sens} \xB7 ${a[l.depth]}${l.stick?yt(" \xB7 \uCC0C\uC62C\uB9BC"," \xB7 rises on bites"):""}${l.bell?yt(" \xB7 \uCD08\uB9BF\uB300 \uBC29\uC6B8"," \xB7 rod-tip bell"):""}${l.glow?yt(" \xB7 \uC57C\uAD11"," \xB7 glow"):""}`),t==="hook"&&(d=`${yt("\uD06C\uAE30","size")} ${["S","M","L","XL"][l.size+1]} \xB7 ${yt("\uCD5C\uB300","holds")} ${l.str} kg${l.lureHook?yt(" \xB7 \uB8E8\uC5B4 \uAC78\uB9BC\u2191"," \xB7 better lure hook-ups"):""}`),t==="chum"&&(d=l.id==="none"?yt("\uBC11\uBC25 \uC5C6\uC774 \uB09A\uC2DC","No groundbait"):`${yt("\uC785\uC9C8 \uB300\uAE30","wait")} \u2212${Math.round((1-l.wait)*100)}% \xB7 ${Object.keys(l.boost).filter(g=>g!=="big").slice(0,3).map(g=>wi(g)).join(", ")}\u2191 \xB7 ${l.uses}${yt("\uD68C"," casts")}`),t==="bait"&&(d=`${l.type==="lure"?yt("\uB8E8\uC5B4 \xB7 \uBB34\uC81C\uD55C","Lure \xB7 reusable"):`${l.pack?l.pack+yt("\uAC1C"," pcs"):yt("\uBB34\uC81C\uD55C","unlimited")}`} \xB7 ${Pe(o(l.id)||yt("\uC774 \uBB3C\uC5D4 \uC798 \uC548 \uBB34\uB294 \uBBF8\uB07C","few takers here"))}`);let f=!c||u!==null;r+=`<div class="slot" style="flex-direction:column;align-items:stretch;gap:4px;${h?"outline:2px solid #ffcc33":""}">
        <div class="row" style="justify-content:space-between"><b>${l.icon} ${Pe(Ss(l))}</b>${u!==null?`<span class="dim">\xD7${u}</span>`:""}</div>
        <span class="dim" style="font-size:11px;line-height:1.35">${d}</span>
        <div class="row">${c?`<button data-eq="${l.id}" class="${h?"on":""}" style="flex:1">${h?yt("\uC7A5\uCC29 \uC911","Equipped"):yt("\uC7A5\uCC29","Equip")}</button>`:""}
        ${f&&l.price?`<button data-buy="${l.id}" class="go" ${n.coins<l.price?"disabled":""} style="flex:1">\u{1F4B0} ${l.price.toLocaleString()}${u!==null?` (+${l.pack||l.uses})`:""}</button>`:""}</div></div>`}r+='</div><div class="row" style="justify-content:flex-end;margin-top:10px"><button data-a="close">\u2715</button></div>',e.innerHTML=r,e.querySelectorAll("[data-tab]").forEach(l=>l.onclick=()=>this.renderTackle(l.dataset.tab)),e.querySelectorAll("[data-eq]").forEach(l=>l.onclick=()=>{if(this.state!=="idle"){this.ctx.toast(yt("\uB09A\uC2EF\uB300\uB97C \uAC70\uB454 \uB4A4\uC5D0 \uBC14\uAFC0 \uC218 \uC788\uC5B4\uC694","Reel in first"));return}n.eq[t]=l.dataset.eq,qi(n),this.equip(),this.renderTackle(t)}),e.querySelectorAll("[data-buy]").forEach(l=>l.onclick=()=>{var h,u;let c=vo(t,l.dataset.buy);n.coins<c.price||(n.coins-=c.price,n.own[t].includes(c.id)||n.own[t].push(c.id),(c.pack||c.uses)&&(n.inv[c.id]=(n.inv[c.id]||0)+(c.pack||c.uses)),(u=(h=this.ctx.audio)==null?void 0:h.coin)==null||u.call(h),qi(n),this.updateGearBar(),this.renderTackle(t))}),e.querySelector("[data-a=close]").onclick=()=>{e.hidden=!0}}afterNet(){qi(this.store),this.refreshNet3D(),this.updateCounts()}updateCounts(){this.ui.btns.querySelector("#fNetN").textContent=`${this.store.net.length}/${ru}`;let t=on[this.water];this.ui.btns.querySelector("#fDexN").textContent=`${t.filter(e=>this.store.dex[e.id]).length}/${t.length}`,this.updateGearBar()}enter(){if(this.active=!0,this.state="idle",this.aim=Math.PI,this.dexWater=null,this.ctx.hud.hide(),this.uiLang!==rn()){for(let t of["bar","btns","card","list","pip"])this.ui[t].remove();this.buildUI()}this.equip(),this.ctx.avatar.setProp(this.rodHolder),this.ui.bar.hidden=this.ui.btns.hidden=!1,Jf("#btnPower").hidden=!ft.touch,this.updateCounts(),this.setStatus(`\u{1F3A3} ${U("cast")}`)}exit(){var t;this.active=!1,this.state="idle",this.bobber.visible=this.line.visible=this.marker.visible=!1,this.pip.on=!1,this.shadow.material.opacity=0,this.dropHooked(),this.held&&((t=this.held.parent)==null||t.remove(this.held),this.held=null),this.ctx.avatar.armLOverride=null,this.ctx.avatar.setProp(null);for(let e of["bar","btns","card","list","pip"])this.ui[e].hidden=!0;Jf("#btnPower").hidden=!0}setStatus(t){this.statusText!==t&&(this.statusText=t,this.ui.status.textContent=t)}powerDown(){switch(this.state){case"idle":{this.ui.list.hidden||(this.ui.list.hidden=!0);let t=this.gear("bait");t.pack&&!(this.store.inv[t.id]>0)&&(this.store.eq.bait="worm",this.equip(),this.ctx.toast(yt("\uBBF8\uB07C\uAC00 \uB5A8\uC5B4\uC838\uC11C \uC9C0\uB801\uC774\uB85C \uBC14\uAFE8\uC5B4\uC694","Out of bait, switched to worms"))),this.state="charging",this.chargePhase=0,this.charge=0;break}case"bite":this.strike();break;case"waiting":if(this.isLure)break;this.nibbleT>0?this.reelIn(U("tooEarly")):this.reelIn();break;case"landed":this.decide(!0);break}}powerUp(){this.state==="charging"&&this.release()}castTarget(t){let e=this.gear("rod"),n=this.gear("float"),s=e.cast*(n.id==="sinker"?1.15:1),r=2.5+t*(s-2.5),o=new C(Math.cos(this.aim),0,Math.sin(this.aim)),a=this.ctx.player.pos,l=new C(a.x,ni,a.z).addScaledVector(o,r+.8),c=Kt.lake,h=l.x-c.x,u=l.z-c.z,d=Math.hypot(h,u);return d>c.r-1&&l.set(c.x+h/d*(c.r-1),ni,c.z+u/d*(c.r-1)),l}release(){var t;this.state="casting",this.castT=0,this.castTo=this.castTarget(this.charge),this.castCharge=this.charge,this.marker.visible=!1,(t=this.ctx.audio)==null||t.whoosh()}launch(){let t=this.tipWorld(),e=Math.hypot(this.castTo.x-t.x,this.castTo.z-t.z);this.flight={from:t,to:this.castTo.clone(),t:0,dur:.45+e*.04,peak:1.2+e*.16},this.bobber.position.copy(t),this.state="flying",this.bobber.visible=!this.floatMesh.userData.hidden||!0,this.line.visible=!0;let n=this.gear("bait"),s=this.gear("chum");n.pack&&(this.store.inv[n.id]=Math.max(0,(this.store.inv[n.id]||0)-1)),this.chumOn=s.id!=="none"&&(this.store.inv[s.id]||0)>0,this.chumOn?this.store.inv[s.id]--:s.id!=="none"&&(this.store.eq.chum="none"),qi(this.store),this.updateGearBar()}viewPivot(){return(this._piv||=new C).copy(this.ctx.player.pos).setY(this.ctx.player.pos.y+1.2)}tipWorld(){return this.rod.tip.getWorldPosition(new C)}startWait(){var d;let t=this.gear("bait"),e=this.gear("float"),n=this.gear("rod"),s=this.gear("hook"),r=this.chumOn?this.gear("chum"):vo("chum","none");this.isLure=t.type==="lure",this.state=this.isLure?"waiting":"settling",this.settleT=0;let o=this.ctx.player.pos;this.castDist=Math.hypot(this.bobber.position.x-o.x,this.bobber.position.z-o.z);let a=this.bottomAt(this.castDist),l=this.store.depthM??1.2,c=l/a,h=c>.75?"bot":c<.35?"top":"mid";this.floatFlat=!this.isLure&&!e.bell&&l>a+.15;let u=Zf({water:this.water,biome:this.ctx.venue.biome,rod:n,float:e,hook:s,chum:r,bait:t,castFrac:Math.min(1,this.castDist/22),depthZone:h});this.sp=Kf(u),this.updateSetRow(),this.waitT=(3+Math.random()*6+(this.sp.w<=2?4:0))*r.wait*(this.isLure?.8:1)*(this.floatFlat?1.8:1),this.nibbles=this.isLure?[]:Array.from({length:Math.floor(Math.random()*3)+1},()=>Math.random()*(this.waitT-1.2)+.4).sort((f,g)=>g-f),this.nibbleT=0,this.biteKind=this.isLure?"thump":e.id==="sinker"?"bell":e.stick&&["carp","crucian","slim"].includes(this.sp.body)?"rise":"sink",this.shadow.position.set(this.bobber.position.x+4,-.05,this.bobber.position.z+2),this.setStatus(U("waiting")),(d=this.ctx.audio)==null||d.splash(.5),this.splash(this.bobber.position,.9)}strike(){let t=this.gear("float"),e=this.gear("hook"),n=this.gear("rod"),s=1;this.biteKind==="rise"?s=Math.min(1,.35+this.biteP*.9):s=Math.max(.4,1-this.biteP*.5);let r=Math.min(.97,(.5+.45*s)*e.hookup*(.9+.1*n.sens));if(Math.random()>r){this.reelIn(`\u{1F4A8} ${yt("\uD5DB\uCC54\uC9C8! \uBC14\uB298\uC5D0 \uC548 \uAC78\uB838\uC5B4\uC694","Missed the strike")}`);return}this.hook()}hook(){var c,h;let t=this.sp,e=this.gear("rod"),s=1.9-this.gear("hook").size*.25-(e.big-1)*.6,r=Math.min(1,Math.pow(Math.random(),Math.max(.8,s))+(this.castDist>14?.06:0)),o=Math.round(t.min+r*(t.max-t.min)),a=Xf(t,o),l=(o-t.min)/(t.max-t.min);this.fish={sp:t,cm:o,kg:a,stamina:1,big:l,power:t.fight*(.55+.45*l)*(1+Math.log10(1+a)*.35)/e.str,dist:Math.max(4,this.castDist),ang:0,dir:0,runT:.6,restT:0,jumpT:0},this.tension=.3,this.slackT=0,this.overT=0,this.hookStrain=0,this.state="fight",this.shadow.material.opacity=0,(c=this.ctx.audio)==null||c.click(1),(h=navigator.vibrate)==null||h.call(navigator,60),this.ctx.toast(`\u{1F3A3} ${U("hooked")}`),this.ui.bar.querySelector("#fFight").hidden=!1,this.dropHooked(),this.hooked=cu(t,Math.min(1.6,o/100)),this.ctx.scene.add(this.hooked)}dropHooked(){this.hooked&&(this.ctx.scene.remove(this.hooked),this.hooked=null)}reelIn(t){this.state="returning",this.retT=0,this.shadow.material.opacity=0,this.dropHooked(),this.ui.bar.querySelector("#fFight").hidden=!0,t&&this.ctx.toast(t)}splash(t,e=1){let n=this.ripples.find(s=>s.t>1)||this.ripples[0];n.t=0,n.k=e,n.m.position.set(t.x,.035,t.z)}update(t){var x,m,p,M,v,y;let e=Wi(),n=performance.now()/1e3;["idle","charging"].includes(this.state)&&(this.aim+=vr(t)-e.x*.004),this.aim=Math.max(Math.PI-1.1,Math.min(Math.PI+1.1,this.aim));{let w=this.ctx.input.keys;this.setKeyT=Math.max(0,(this.setKeyT||0)-t),this.setKeyT||(w.has("BracketLeft")?(this.setDepth(-1),this.setKeyT=.15):w.has("BracketRight")?(this.setDepth(1),this.setKeyT=.15):w.has("Minus")?(this.setDrag(-1),this.setKeyT=.2):w.has("Equal")&&(this.setDrag(1),this.setKeyT=.2))}this.camPitch=Math.max(-.5,Math.min(.7,(this.camPitch||0)+e.y*.004)),this.lastLookX=e.x*.012;let s=this.ctx.player;s.pos.set(-50.8,0,0),s.yaw=Math.atan2(Math.cos(this.aim),Math.sin(this.aim)),s.speed=0;let r=this.ctx.avatar,o=r.armR,a=this.ui.bar.querySelector("#fBar1"),l=(w,S,A,P)=>{this.ui.bar.querySelector("#fBar1L").textContent=w,this.ui.bar.querySelector("#fBar1V").textContent=A;let _=a.querySelector("i");_.style.width=`${Math.min(100,S*100)}%`,_.style.background=P?S>.88?"#f87171":S<.12?"#94a3b8":"linear-gradient(90deg,#6ee7b7,#34d399)":"";let b=a.querySelector(".zone");b.hidden=!P,P&&(b.style.left="40%",b.style.width="45%",b.style.background="rgba(110,231,183,.25)")},c=this.floatMesh,h=-.5;switch(this.pip.on=!1,this.state){case"idle":o.rotation.x=-.9,l(U("cast"),0,"",!1),this.setStatus(`\u{1F3A3} ${U("cast")}`);break;case"charging":{this.chargePhase+=t*.85;let w=this.chargePhase%2;this.charge=w<1?w:2-w;let S=this.castTarget(this.charge);l(U("cast"),this.charge,`${Math.round(Math.hypot(S.x-s.pos.x,S.z-s.pos.z))} m`,!1),o.rotation.x+=(-3.15-o.rotation.x)*Math.min(1,t*10),h=-1.3,this.marker.visible=!0,this.marker.position.set(S.x,.05,S.z),this.marker.scale.setScalar(1+Math.sin(n*6)*.08);break}case"casting":{this.castT+=t/.24;let w=Math.min(1,this.castT);o.rotation.x=-3.15+(3.15-.55)*(1-Math.pow(1-w,2.2)),h=-1.3+w*.8,w>.45&&!((x=this.flight)!=null&&x.live)&&(this.launch(),this.flight.live=!0),w>=1&&(this.state="flying"),l(U("cast"),this.castCharge,"",!1);break}case"flying":{let w=this.flight;w.t+=t/w.dur;let S=Math.min(1,w.t);this.bobber.position.lerpVectors(w.from,w.to,S),this.bobber.position.y=w.from.y+(w.to.y-w.from.y)*S+Math.sin(S*Math.PI)*w.peak,this.bobber.rotation.set(0,0,Math.PI/2*S),o.rotation.x+=(-.75-o.rotation.x)*Math.min(1,t*6),S>=1&&(this.flight=null,this.startWait());break}case"settling":{this.settleT+=t/.9;let w=Math.min(1,this.settleT);this.bobber.rotation.z=Math.PI/2*(1-w*w),this.bobber.position.y=ni+(1-w)*.02-w*0,o.rotation.x=-.9,this.pip.on=!c.userData.hidden,this.floatFlat&&(this.bobber.rotation.z=Math.max(this.bobber.rotation.z,1.35)),w>=1&&(this.state="waiting",this.bobber.rotation.z=this.floatFlat?1.35:0,this.floatFlat&&this.ctx.toast(`\u2198 ${yt("\uCC0C\uAC00 \uB204\uC6E0\uC5B4\uC694: \uC218\uC2EC\uC774 \uBC14\uB2E5\uBCF4\uB2E4 \uAE4A\uC5B4\uC694. \uC218\uC2EC\uC744 \uC904\uC5EC \uBCF4\uC138\uC694","The float is lying flat: deeper than the bottom. Reduce the depth")}`)),l(U("waiting"),0,"",!1);break}case"waiting":{if(this.waitT-=t*(this.isLure&&!ft.power?.35:1),this.nibbleT=Math.max(0,this.nibbleT-t),this.nibbles.length&&this.waitT<this.nibbles[0]&&(this.nibbles.shift(),this.nibbleT=.35,this.splash(this.bobber.position,.3),this.setStatus(`\u{1F4A7} ${U("nibble")}`),this.biteKind==="bell"&&((m=this.ctx.audio)==null||m.click(.4))),this.isLure){let S=s.pos,A=this.bobber.position,P=Math.hypot(A.x-S.x,A.z-S.z);if(ft.power){let _=1.6*t;A.x+=(S.x-A.x)/P*_,A.z+=(S.z-A.z)/P*_,Math.random()<t*4&&((p=this.ctx.audio)==null||p.reel())}if(A.y=this.gear("bait").id==="popper"?ni+Math.abs(Math.sin(n*6))*.01:-.03+Math.sin(n*3)*.01,this.bobber.rotation.set(0,Math.atan2(-(S.z-A.z),S.x-A.x)+Math.PI,Math.sin(n*9)*(ft.power?.25:.05)),P<2.2){this.reelIn(yt("\uC785\uC9C8 \uC5C6\uC774 \uB8E8\uC5B4\uB97C \uD68C\uC218\uD588\uC5B4\uC694","No takers, lure retrieved"));break}this.setStatus(ft.power?`\u{1F300} ${yt("\uB8E8\uC5B4 \uAC10\uB294 \uC911\u2026","Retrieving\u2026")}`:`\u23F8 ${yt("\uB204\uB974\uACE0 \uC788\uC73C\uBA74 \uB8E8\uC5B4\uB97C \uAC10\uC544\uC694","Hold to retrieve")}`)}else{let S=Math.sin(n*1.7)*.006,A=this.nibbleT>0?Math.sin((.35-this.nibbleT)/.35*Math.PI)*.045:0;this.bobber.position.y=ni+S-A,this.biteKind==="bell"&&(this.tipShake=A*6),this.nibbleT||this.setStatus(U("waiting"))}let w=Math.max(0,1-this.waitT/3);if(this.shadow.material.opacity=w*.4,this.shadow.position.lerp(new C(this.bobber.position.x+.3,-.05,this.bobber.position.z),t*.9),this.shadow.rotation.z=Math.atan2(this.bobber.position.z-this.shadow.position.z,this.bobber.position.x-this.shadow.position.x),this.shadow.scale.setScalar(.5+this.sp.max/160),this.waitT<0){this.state="bite",this.biteT=0;let S=this.gear("float"),A=this.gear("rod"),P=this.biteKind==="rise"?1.5:this.biteKind==="thump"?.7:.8;this.biteDur=P*S.sens*A.sens*(this.sp.w<=4?.8:1),this.setStatus(this.biteKind==="rise"?`\u2B06\uFE0F ${yt("\uCC0C\uC62C\uB9BC! \uC62C\uB77C\uC62C \uB54C \uCC54\uC9C8!","The float is rising! Strike!")}`:this.biteKind==="thump"?`\u{1F4A5} ${yt("\uB35C\uCEE5! \uC9C0\uAE08 \uCC54\uC9C8!","Thump! Strike!")}`:this.biteKind==="bell"?`\u{1F514} ${yt("\uBC29\uC6B8\uC774 \uC6B8\uB824\uC694! \uCC54\uC9C8!","The bell rings! Strike!")}`:`\u2757 ${U("biteNow")}`),this.splash(this.bobber.position,this.biteKind==="rise"?.5:1.2),this.biteKind==="bell"?(M=this.ctx.audio)==null||M.bell():(v=this.ctx.audio)==null||v.plop(),(y=navigator.vibrate)==null||y.call(navigator,100)}o.rotation.x=this.isLure?-.7+Math.sin(n*9)*(ft.power?.06:0):-.9,this.pip.on=!c.userData.hidden||this.biteKind==="bell"||this.isLure,l(U("waiting"),0,"",!1);break}case"bite":{this.biteT+=t,this.biteP=Math.min(1,this.biteT/this.biteDur);let w=this.biteP;this.biteKind==="rise"?this.bobber.position.y=ni+Math.sin(w*Math.PI/2)*.14+Math.sin(n*20)*.003:this.biteKind==="sink"?this.bobber.position.y=ni-Math.min(1,w*4)*.4+Math.sin(n*30)*.01:this.biteKind==="bell"?this.tipShake=Math.sin(n*40)*.6:this.tipShake=Math.max(0,1-w*3)*1.2,o.rotation.x=-.9,this.pip.on=!0,l(yt("\uCC54\uC9C8 \uD0C0\uC774\uBC0D","Strike timing"),this.biteKind==="rise"?w:1-w,"",!1),this.biteT>this.biteDur&&this.reelIn(U("missed"));break}case"fight":this.updateFight(t,n,l,o),this.pip.on=!0;break;case"landed":o.rotation.x=-2.4;break;case"returning":{this.retT+=t*2.5,this.bobber.position.lerp(this.tipWorld(),Math.min(1,this.retT)),this.retT>=1&&(this.state="idle",this.bobber.visible=this.line.visible=!1,this.bobber.rotation.set(0,0,0));break}}this.state!=="charging"&&(this.marker.visible=!1),r.armLOverride=this.held?-1.25:h,c.visible=!c.userData.hidden;for(let w of this.ripples){if(w.t>1){w.m.material.opacity=0;continue}w.t+=t*.9,w.m.scale.setScalar(1+w.t*6*(w.k||1)),w.m.material.opacity=(1-w.t)*.7}this.netFish.forEach((w,S)=>{let A=n*.6+w.userData.phase;w.position.set(Math.cos(A)*.2,-.15-S%4*.13,Math.sin(A)*.2),w.rotation.set(0,-A+Math.PI/2+Math.sin(n*6+S)*.15,0)}),this.tipShake=(this.tipShake||0)*Math.pow(.02,t);let u=this.state==="fight"?this.tension:0;if(this.rod.sections.forEach((w,S)=>{w.rotation.x=-u*(.08+S*.07)-(this.tipShake||0)*.05*(S+1)*Math.sin(n*35),w.rotation.z=this.state==="fight"?this.lean*.04*(S+1):0}),this.line.visible){let w=this.tipWorld(),S=this.bobber.position,A=w.clone().lerp(S,.5);A.y-=this.state==="fight"?.05*(1-Math.min(1,this.tension)):this.state==="flying"||this.state==="casting"?.1:.6,this.line.geometry.setFromPoints(new io(w,A,S).getPoints(16))}let d=this.ctx.camTarget,f=new C(Math.cos(this.aim),0,Math.sin(this.aim)),g=new C(-f.z,0,f.x);if(this.state==="landed"){let w=new C(Math.sin(s.yaw),0,Math.cos(s.yaw));d.pos.set(s.pos.x,1.8,s.pos.z).addScaledVector(w,3.2).add(new C(w.z*.6,0,-w.x*.6)),d.look.set(s.pos.x,1.3,s.pos.z)}else{let w=this.state==="charging"?this.marker.position:["flying","settling","waiting","bite","fight"].includes(this.state)?this.bobber.position:null;d.pos.set(s.pos.x,0,s.pos.z).addScaledVector(f,-3.6).addScaledVector(g,-1.9),d.pos.y=4+this.camPitch*3,w?d.look.set(w.x,0,w.z).lerp(new C(s.pos.x,.6,s.pos.z),.2):d.look.set(s.pos.x,.4,s.pos.z).addScaledVector(f,9),d.look.y-=this.camPitch*2}if(this.ui.pip.hidden=!this.pip.on,this.pip.on){let w=this.pip.cam,S=this.bobber.position,A=new C(s.pos.x-S.x,0,s.pos.z-S.z).normalize();if(this.biteKind==="bell"&&this.state!=="fight"){let P=this.tipWorld();w.position.copy(P).addScaledVector(g,1.1).add(new C(0,.15,0)).addScaledVector(f,-.3),w.lookAt(P.x,P.y-.1,P.z),this.ui.pip.querySelector(".pipLabel").textContent=`\u{1F514} ${yt("\uCD08\uB9BF\uB300","Rod tip")}`}else{let P=this.state==="fight"?.8:this.isLure?.9:.32,_=this.state==="fight"?2.4:this.isLure?2.2:1.25;w.position.set(S.x,ni+P,S.z).addScaledVector(A,_).addScaledVector(g,.15),w.lookAt(S.x,this.isLure||this.state==="fight"?ni:ni+(c.userData.top||.1)*.45,S.z),this.ui.pip.querySelector(".pipLabel").textContent=`\u{1F50D} ${this.isLure?yt("\uB8E8\uC5B4","Lure"):yt("\uCC0C \uD655\uB300","Float close-up")}`}this.ui.pip.querySelector("#fPipHint").textContent=this.state==="bite"?"\u2757":""}}updateFight(t,e,n,s){var b,R,L,D,N,W;let r=this.fish,o=this.gear("hook"),a=this.ctx.input.keys,l=0;(a.has("ArrowLeft")||a.has("KeyA"))&&(l-=1),(a.has("ArrowRight")||a.has("KeyD"))&&(l+=1),this.dragLean=Math.max(-1,Math.min(1,(this.dragLean||0)*Math.pow(.2,t)+(this.lastLookX||0))),this.lastLookX=0,l===0&&(l=this.dragLean),this.lean+=(l-this.lean)*Math.min(1,t*8),r.runT-=t,r.runT<=0&&(r.dir!==0||Math.random()<.3?(r.dir=0,r.runT=.8+Math.random()*1.4*r.stamina):(r.dir=Math.random()<.5?-1:1,r.runT=.8+Math.random()*2*r.stamina,(b=this.ctx.audio)==null||b.click(.2),(r.sp.depth==="top"||r.sp.fight>.75)&&Math.random()<.4&&r.dist>3&&(r.jumpT=.9)));let c=r.dir!==0,h=c?-r.dir*this.lean:0,u=r.power*(c?1:.35)*(.45+.55*r.stamina)*(.85+.3*Math.sin(e*5.3));u*=1-.55*Math.max(0,h)+.6*Math.max(0,-h);let d=this.ctx.input.power;d&&Math.random()<t*6&&((R=this.ctx.audio)==null||R.reel());let f=Math.min(1.3,(d?.38:.04)+u*.85),g=this.dragLimit(),x=0;f>g&&(x=f-g,f=g+x*.2),this.tension+=(f-this.tension)*Math.min(1,t*2.6),x>.02&&(r.dist+=x*3.2*t,Math.random()<t*14&&((L=this.ctx.audio)==null||L.reel())),this.dragSlip=x,a.has("ArrowUp")||a.has("KeyW")?(this.dragKeyT||this.setDrag(1),this.dragKeyT=.25):(a.has("ArrowDown")||a.has("KeyS"))&&(this.dragKeyT||this.setDrag(-1),this.dragKeyT=.25),this.dragKeyT=Math.max(0,(this.dragKeyT||0)-t),r.dist+=(d?-(1.7-u*1.6)*(x>.02?.3:1):u*1.3)*t,r.ang+=r.dir*t*.18*(1-Math.max(0,h)*.7),r.ang=Math.max(-.9,Math.min(.9,r.ang*(1-t*.15)));let m=this.tension>.4&&this.tension<.85;r.stamina=Math.max(0,r.stamina-t*(.03+(m?.075:.012)*(d?1:.4)+Math.max(0,h)*.03)/(.7+r.kg/25)),this.overT=this.tension>1?this.overT+t:Math.max(0,this.overT-t),this.slackT=this.tension<.1?this.slackT+t:0,r.kg>o.str&&this.tension>.7&&(this.hookStrain+=t*(r.kg/o.str)*.4);let p=this.ctx.player,M=this.aim+r.ang,v=Kt.lake,y=p.pos.x+Math.cos(M)*r.dist,w=p.pos.z+Math.sin(M)*r.dist,S=y-v.x,A=w-v.z,P=Math.hypot(S,A);if(P>v.r-.8&&(y=v.x+S/P*(v.r-.8),w=v.z+A/P*(v.r-.8)),this.bobber.position.set(y,-.04+Math.sin(e*14)*.03,w),Math.random()<t*(c?6:2)&&this.splash(this.bobber.position,.35+u*.4),this.hooked){r.jumpT=Math.max(0,r.jumpT-t);let k=new C(y-p.pos.x,0,w-p.pos.z).normalize(),q=new C(-k.z*r.dir,0,k.x*r.dir).addScaledVector(k,c?.5:.2).normalize(),H=this.hooked.scale.x,K=r.jumpT>0?Math.sin((1-r.jumpT/.9)*Math.PI):0;this.hooked.position.set(y+k.x*H*.5,-.12-H*.08+K*(.5+H*.6),w+k.z*H*.5),this.hooked.rotation.set(0,Math.atan2(q.z,-q.x),K*.9*(r.dir||1)),this.hooked.rotation.x=Math.sin(e*14)*.12,r.jumpT>0&&r.jumpT<t*1.5&&(this.splash(this.hooked.position,1.4),(D=this.ctx.audio)==null||D.splash(1))}s.rotation.x=-1.1-this.tension*.6+Math.sin(e*22)*.04*this.tension,n(U("tension"),this.tension/1.1,`${this.dragSlip>.02?`\u{1F300} ${yt("\uB4DC\uB799 \uD480\uB9BC","drag slipping")} \xB7 `:""}${Math.round(this.tension*100)}% \xB7 ${U("lineLeft")} ${Math.max(0,r.dist).toFixed(1)} m`,!0);let _=this.ui.bar;_.querySelector("#fHp i").style.width=`${r.stamina*100}%`,_.querySelector("#fHpV").textContent=`${Math.round(r.stamina*100)}%`,_.querySelector("#fL").style.opacity=r.dir===1?1:.25,_.querySelector("#fR").style.opacity=r.dir===-1?1:.25,_.querySelector("#fL").style.color=r.dir===1?"#fde047":"",_.querySelector("#fR").style.color=r.dir===-1?"#fde047":"",_.querySelector("#fRod").textContent=c?r.dir===1?U("pullLeft"):U("pullRight"):"",this.setStatus(r.jumpT>0?`\u{1F41F}\u203C\uFE0F ${yt("\uC810\uD504!","Jump!")}`:c?`\u{1F41F}\u{1F4A8} ${U("running")}`:`\u{1F3A3} ${U("reel")}\u2026`),this.overT>.55||r.dist>40?((N=navigator.vibrate)==null||N.call(navigator,200),(W=this.ctx.audio)==null||W.snap(),this.reelIn(r.dist>40?`\u{1F4A5} ${yt("\uC904\uC774 \uB2E4 \uD480\uB824 \uB04A\uC5B4\uC84C\uC5B4\uC694! \uB4DC\uB799\uC744 \uC870\uAE08 \uC870\uC5EC \uBCF4\uC138\uC694","Spooled! Tighten the drag a little")}`:`\u{1F4A5} ${U("snapped")}`)):this.hookStrain>1?this.reelIn(`\u{1FA9D} ${yt("\uBC14\uB298\uC774 \uD3B4\uC84C\uC5B4\uC694! \uB354 \uD070 \uBC14\uB298\uC774 \uD544\uC694\uD574\uC694","The hook straightened! Use a bigger hook")}`):this.slackT>2.4?this.reelIn(U("escaped")):r.dist<=1.3&&(r.stamina<.3?this.land():(r.dist=1.3,r.dir=Math.random()<.5?-1:1,r.runT=1.2))}land(){var c,h,u;let t=this.fish,e=t.sp;this.state="landed",this.dropHooked(),this.bobber.visible=this.line.visible=!1,this.ui.bar.querySelector("#fFight").hidden=!0,(c=this.ctx.audio)==null||c.chime(),(u=(h=this.ctx).snap)==null||u.call(h);let n=this.store.dex[e.id],s=!n,r=n&&t.cm>n.cm;this.store.dex[e.id]={cm:Math.max((n==null?void 0:n.cm)||0,t.cm),n:((n==null?void 0:n.n)||0)+1},qi(this.store),this.updateCounts();let o=Math.max(.45,Math.min(1.3,t.cm/100));this.held=cu(e,o),this.held.rotation.set(0,0,.35),this.held.position.set(-.05,.78+o*.12,.34),this.ctx.avatar.body.add(this.held),t.st=Yf(e,t.cm),this.ctx.net.event({type:"catch",fish:e.id,kg:t.kg});let a=this.ui.card,l=bo(e,t.kg,t.st);a.innerHTML=`${s?`<div class="mid" style="color:#fde047">\u2728 ${U("newSpecies")}</div>`:r?`<div class="mid" style="color:#7dd3fc">\u{1F3C5} ${U("newRecord")}</div>`:""}
      <canvas width="560" height="240" style="width:100%;max-width:290px"></canvas>
      <div class="big" style="margin-top:4px">${Pe(wi(e.id))}</div>
      <div style="color:#fde047;font-size:18px;margin:4px 0">${"\u2605".repeat(t.st)}<span style="opacity:.25">${"\u2605".repeat(5-t.st)}</span></div>
      <div class="kv" style="justify-content:center"><span>${U("length")}</span><b>${t.cm} cm</b><span>${U("weight")}</span><b>${t.kg} kg</b><span>\u{1F4B0}</span><b>${l.toLocaleString()}</b></div>
      <div class="row" style="justify-content:center;margin-top:12px"><button class="go" data-a="keep">\u{1F9FA} ${U("keep")}</button><button data-a="sell">\u{1F4B0} ${yt("\uBC14\uB85C \uD310\uB9E4","Sell")}</button><button data-a="rel">${U("release")}</button></div>`,ol(a.querySelector("canvas").getContext("2d"),e,14,10,532,220),a.querySelector("[data-a=keep]").onclick=()=>this.decide(!0),a.querySelector("[data-a=sell]").onclick=()=>{this.earn(l),this.decide(!1,!0)},a.querySelector("[data-a=rel]").onclick=()=>this.decide(!1),a.hidden=!1,this.setStatus(`\u{1F41F} ${wi(e.id)} ${t.cm} cm`)}decide(t,e=!1){var s,r;if(this.state!=="landed")return;let n=this.fish;if(t){if(this.store.net.length>=ru){this.ctx.toast(U("netFull"));return}this.store.net.push({id:n.sp.id,cm:n.cm,kg:n.kg,st:n.st}),this.afterNet()}else e||(this.ctx.toast(`\u{1F30A} ${U("released")}`),this.splash(new C(this.ctx.player.pos.x-1.5,0,this.ctx.player.pos.z),.6),(s=this.ctx.audio)==null||s.splash(.6));this.held&&((r=this.held.parent)==null||r.remove(this.held),this.held=null),this.ui.card.hidden=!0,this.state="idle"}},Jf=i=>document.querySelector(i);var $b=(i,t)=>rn()==="ko"?i:t,ii={pool:{L:2.24,W:1.12,R:.028575,cloth:2062925,rail:5977120,pockets:!0,cushE:.74,roll:.3,drag:.1,vmax:6.5},carom:{L:2.844,W:1.422,R:.03075,cloth:2051471,rail:7029800,pockets:!1,cushE:.8,roll:.22,drag:.075,vmax:7.5}},_o={carom3:"carom",carom4:"carom",pool8:"pool"},qb=1/600,Xb=.94,Yb=[16777215,16106776,2052049,14034984,6958225,16219904,2792779,9117214,1118481,16106776,2052049,14034984,6958225,16219904,2792779,9117214],Zb=[16448250,16241214,14100014,14100014];function Kb(i,t,e){let n=document.createElement("canvas");n.width=256,n.height=128;let s=n.getContext("2d"),r="#"+i.toString(16).padStart(6,"0");if(!e&&t>=9?(s.fillStyle="#f8f8f4",s.fillRect(0,0,256,128),s.fillStyle=r,s.fillRect(0,36,256,56)):(s.fillStyle=r,s.fillRect(0,0,256,128)),!e&&t>0)for(let a of[64,192])s.fillStyle="#fff",s.beginPath(),s.arc(a,64,22,0,Math.PI*2),s.fill(),s.fillStyle="#111",s.font="bold 26px sans-serif",s.textAlign="center",s.textBaseline="middle",s.fillText(String(t),a,66);if(e||t===0){s.fillStyle=t===0&&!e?"#d33":"rgba(0,0,0,.35)";for(let[a,l]of[[64,64],[192,64],[128,10],[128,118]])s.beginPath(),s.arc(a,l,5,0,7),s.fill()}let o=new Je(n);return o.colorSpace=me,o.anisotropy=4,o}function Qf(i){let t=ii[_o[i]],e=t.L,n=t.R,s=(l,c,h)=>[l,+c.toFixed(4),+h.toFixed(4),0];if(i==="carom3")return[s(0,-e/4,.152),s(1,-e/4,0),s(2,e/4,0)];if(i==="carom4")return[s(0,-e/4,.152),s(1,-e/4,0),s(2,e/4,0),s(3,0,0)];let r=[s(0,-e/4,0)],o=[1,9,2,10,8,3,11,4,12,5,13,6,14,7,15],a=0;for(let l=0;l<5;l++)for(let c=0;c<=l;c++)r.push(s(o[a++],e/4+l*n*1.74,(c-l/2)*n*2.01));return r}function tp(i){return[[-i.L/2,-i.W/2,.07],[0,-i.W/2-.012,.06],[i.L/2,-i.W/2,.07],[-i.L/2,i.W/2,.07],[0,i.W/2+.012,.06],[i.L/2,i.W/2,.07]]}var uu=class{constructor(t,e,n){this.T=ii[t],this.P=this.T.pockets?tp(this.T):[],this.balls=e.map(([s,r,o,a])=>({n:s,x:r,z:o,vx:0,vz:0,in:!!a,top:0,side:0,rot:new Re})),this.cueN=n,this.ev={seq:[],cushions:{},first:null,pocketed:[],railAfter:!1}}ball(t){return this.balls.find(e=>e.n===t)}moving(){return this.balls.some(t=>!t.in&&t.vx*t.vx+t.vz*t.vz>1e-6)}strike(t,e,n,s,r=0){let o=this.ball(this.cueN),a=r*Math.PI/180;o.masse=n*e*Math.sin(a)*1.15,s-=Math.sin(a)*.25;let l=t-n*.03;o.vx=Math.cos(l)*e,o.vz=Math.sin(l)*e,o.top=s*e*.8,o.side=n*e*.65,o.preHit=!0}step(t){let e=Math.ceil(t/qb),n=t/e;for(;e-- >0;)this.sub(n)}sub(t){let e=this.T,n=e.R,s=e.L/2-n,r=e.W/2-n,o=this.balls.filter(a=>!a.in);for(let a of o){let l=Math.hypot(a.vx,a.vz);if(l>0){let u=Math.max(0,l-(e.roll+e.drag*l)*t);u<.004?a.vx=a.vz=0:(a.vx*=u/l,a.vz*=u/l),a.x+=a.vx*t,a.z+=a.vz*t;let d=u*t/n;d>0&&a.rot.premultiply(new Re().setFromAxisAngle(new C(a.vz,0,-a.vx).normalize(),d))}if(a.masse&&l>.02){let u=-a.vz/l,d=a.vx/l;a.vx+=u*a.masse*t,a.vz+=d*a.masse*t,a.masse*=Math.exp(-t*1.1)}a.top*=Math.exp(-t*.9),a.side*=Math.exp(-t*.25);let c=!1;for(let[u,d,f]of this.P){let g=Math.hypot(a.x-u,a.z-d);if(g<f){a.in=!0,a.vx=a.vz=0,this.ev.pocketed.push(a.n),this.ev.seq.push(["p",a.n,l]);break}g<f+.05&&(c=!0)}if(a.in||c)continue;let h=(u,d)=>{let f=u==="x"?a.vx:a.vz;if(f*d<=0)return;u==="x"?(a.x=d*s,a.vx=-a.vx*e.cushE):(a.z=d*r,a.vz=-a.vz*e.cushE),a.vx*=.97,a.vz*=.97;let g=Math.hypot(a.vx,a.vz)||1,x=-a.vz/g,m=a.vx/g,p=a.side*.32*Math.min(1,Math.abs(f)/2);u==="x"?a.vz+=m*p*2:a.vx+=x*p*2,a.side*=.55,a.top*=.6,this.ev.cushions[a.n]=(this.ev.cushions[a.n]||0)+1,this.ev.seq.push(["c",a.n,Math.abs(f)]),this.ev.first!=null&&(this.ev.railAfter=!0)};a.x>s?h("x",1):a.x<-s&&h("x",-1),a.z>r?h("z",1):a.z<-r&&h("z",-1)}for(let a=0;a<o.length;a++)for(let l=a+1;l<o.length;l++){let c=o[a],h=o[l];if(c.in||h.in)continue;let u=h.x-c.x,d=h.z-c.z,f=u*u+d*d,g=2*n;if(f>=g*g||f<1e-12)continue;let x=Math.sqrt(f),m=u/x,p=d/x,M=(c.vx-h.vx)*m+(c.vz-h.vz)*p,v=(g-x)/2;if(c.x-=m*v,c.z-=p*v,h.x+=m*v,h.z+=p*v,M<=0)continue;let y=[c,h].map(S=>[S.vx,S.vz]),w=M*(1+Xb)/2;c.vx-=w*m,c.vz-=w*p,h.vx+=w*m,h.vz+=w*p;for(let[S,A]of[[0,c],[1,h]]){if(A.preHit&&A.top){let[P,_]=y[S],b=Math.hypot(P,_)||1;A.vx+=P/b*A.top*.55,A.vz+=_/b*A.top*.55,A.top*=.3}A.preHit=!1}(c.n===this.cueN||h.n===this.cueN)&&this.ev.first==null&&(this.ev.first=c.n===this.cueN?h.n:c.n),this.ev.seq.push(["b",c.n,h.n,M])}}pack(){return this.balls.map(t=>[t.n,+t.x.toFixed(4),+t.z.toFixed(4),t.in?1:0])}},hl=class{constructor(t){this.ctx=t,this.hideAvatar=!0,this.group=new Jt;let e=Kt.table;this.group.position.set(e.x,e.y,e.z),t.scene.add(this.group),this.focus=new C(e.x,0,e.z),this.tableKey=null,this.mode="pool8",this.meshes={},this.view="top",this.fpPitch=.32,this.fpDist=.95,addEventListener("wheel",n=>{!this.active||this.view!=="cue"||(this.fpDist=Math.max(.35,Math.min(2.6,this.fpDist*(n.deltaY>0?1.1:.9))))},{passive:!0}),this.guideOn=!0,this.ox=0,this.oy=0,this.chalk=1,this.aim=0,this.power=0,this.sim=null,this.appliedSeq=-1,this.buildCue(),this.buildTable("pool"),this.party=new _r(t,"billiards",{onChange:n=>this.onParty(n),onMsg:n=>this.onPartyMsg(n)}),this.buildUI(),this.raycaster=new Wa,ws("pointerDown",()=>this.onPointer(!0)),ws("pointerUp",()=>this.onPointer(!1)),addEventListener("keydown",n=>{var r;if(!this.active||/INPUT|SELECT|TEXTAREA/.test((r=document.activeElement)==null?void 0:r.tagName))return;let s=.12;n.code==="ArrowUp"&&this.setTip(this.ox,this.oy+s),n.code==="ArrowDown"&&this.setTip(this.ox,this.oy-s),n.code==="KeyZ"&&this.setTip(this.ox-s,this.oy),n.code==="KeyX"&&this.setTip(this.ox+s,this.oy),n.code==="KeyC"&&this.doChalk(),n.code==="BracketLeft"&&this.setElev(-5),n.code==="BracketRight"&&this.setElev(5),n.code==="KeyV"&&this.toggleView(),n.code==="KeyG"&&(this.guideOn=!this.guideOn),n.code==="Comma"&&this.nudge(-1),n.code==="Period"&&this.nudge(1)})}buildTable(t){if(this.tableKey===t)return;this.tableKey=t,this.table&&this.group.remove(this.table);let e=ii[t],n=Kt.pavilion,s=this.table=new Jt,r=.05,o=.12,a=e.L+2*(r+o),l=e.W+2*(r+o),c=Lt("wood",e.rail,{roughness:.35}),h=Lt("felt",e.cloth),d=Kt.table.y-n.y-.16;s.add(mn(new $t(a-.06,.2,l-.06),c,0,-.13,0));for(let[v,y]of[[-1,-1],[1,-1],[-1,1],[1,1],[0,-1],[0,1]])v===0&&t==="pool"||s.add(mn(new $t(.17,d,.17),c,v*(a/2-.22),-.23-d/2,y*(l/2-.22)));s.add(mn(new $t(e.L+2*r,.03,e.W+2*r),h,0,-.015,0,!1));let f=e.R*1.3,g=Lt("felt",new bt(e.cloth).multiplyScalar(.85).getHex());s.add(mn(new $t(e.L,f,r),g,0,f/2,-e.W/2-r/2)),s.add(mn(new $t(e.L,f,r),g,0,f/2,e.W/2+r/2)),s.add(mn(new $t(r,f,e.W),g,-e.L/2-r/2,f/2,0)),s.add(mn(new $t(r,f,e.W),g,e.L/2+r/2,f/2,0));let x=f+.012;s.add(mn(new $t(a,x,o),c,0,x/2,-l/2+o/2)),s.add(mn(new $t(a,x,o),c,0,x/2,l/2-o/2)),s.add(mn(new $t(o,x,l),c,-a/2+o/2,x/2,0)),s.add(mn(new $t(o,x,l),c,a/2-o/2,x/2,0));let m=Tt(16052194,{roughness:.3,metalness:.3}),p=new Ut(.009,.009,.004,4);for(let v=1;v<8;v++){if(v===4&&t==="pool")continue;let y=-e.L/2+e.L/8*v;for(let w of[-1,1])s.add(mn(p,m,y,x+.002,w*(l/2-o/2),!1))}for(let v=1;v<4;v++){let y=-e.W/2+e.W/4*v;for(let w of[-1,1])s.add(mn(p,m,w*(a/2-o/2),x+.002,y,!1))}let M=new nt(new je(.006,10),new Le({color:16777215}));for(let v of[-e.L/4,0,e.L/4]){let y=M.clone();y.rotation.x=-Math.PI/2,y.position.set(v,.0012,0),s.add(y)}if(e.pockets){let v=new Le({color:657930});for(let[y,w,S]of tp(e)){let A=new nt(new je(S*1.05,20),v);A.rotation.x=-Math.PI/2,A.position.set(y,.002,w),s.add(A);let P=mn(new Ut(S*1.05,S*.9,x+.004,20,1,!0),Tt(1118481,{side:Te}),y,x/2-.002,w,!1);s.add(P)}}this.group.add(s),this.makeBalls(t)}makeBalls(t){for(let o of Object.values(this.meshes))this.group.remove(o);this.meshes={};let e=ii[t],n=t==="carom",s=new Ce(e.R,28,18),r=n?4:16;for(let o=0;o<r;o++){let a=new nt(s,new Fa({map:Kb(n?Zb[o]:Yb[o],o,n),roughness:.12,clearcoat:1,clearcoatRoughness:.04}));a.castShadow=!0,a.visible=!1,this.group.add(a),this.meshes[o]=a}}buildCue(){let t=this.cue=new Jt,e=1.45,n=new nt(new Ut(.0065,.0145,e,14),Lt("wood",15321504,{roughness:.3}));n.rotation.z=Math.PI/2,n.position.x=-e/2;let s=new nt(new Ut(.0145,.016,.5,14),Tt(1842210,{roughness:.35,metalness:.2}));s.rotation.z=Math.PI/2,s.position.x=-e+.25;let r=new nt(new Ut(.0065,.0065,.02,12),Tt(16052712));r.rotation.z=Math.PI/2,r.position.x=-.012,this.tipMat=new ye({color:3829720,roughness:.9});let o=new nt(new Ut(.0062,.0065,.008,12),this.tipMat);o.rotation.z=Math.PI/2,o.position.x=-.002,t.add(n,s,r,o),t.traverse(l=>{l.castShadow=!0}),t.visible=!1,this.group.add(t),this.chalkCube=new nt(new $t(.022,.022,.022),Tt(3043286,{roughness:.9})),this.chalkCube.visible=!1,this.group.add(this.chalkCube);let a=new ur({color:16777215,dashSize:.02,gapSize:.014,transparent:!0,opacity:.85});this.guide=new Ln(new ae().setFromPoints([new C,new C(1,0,0)]),a),this.guide2=new Ln(new ae().setFromPoints([new C,new C(1,0,0)]),a.clone()),this.guide2.material.color.set(16769126),this.guide3=new Ln(new ae().setFromPoints([new C,new C(1,0,0)]),a.clone()),this.guide3.material.opacity=.45,this.ghost=new nt(new fn(.026,.03,24),new Le({color:16777215,transparent:!0,opacity:.8})),this.ghost.rotation.x=-Math.PI/2;for(let l of[this.guide,this.guide2,this.guide3,this.ghost])l.visible=!1,l.frustumCulled=!1,this.group.add(l)}buildUI(){var r,o;if(this.uiLang=rn(),this.ui)for(let a of Object.values(this.ui))(r=a.classList)!=null&&r.contains("gp")&&a.remove();(o=this.lobby)==null||o.el.remove(),this.lobby=new Mr({title:`\u{1F3B1} ${U("billiards")}`,modes:[["carom3",U("carom3"),U("carom3s")],["carom4",U("carom4"),U("carom4s")],["pool8",U("pool8"),U("pool8s")]],onStart:a=>this.start(a),onExit:()=>this.ctx.exit()});let t=this.ui={};t.board=De("gp-bill-board",""),t.board.style.cssText="left:50%;transform:translateX(-50%);top:calc(max(10px, env(safe-area-inset-top)) + 52px);padding:8px 12px;min-width:min(420px, calc(100vw - 24px))",t.left=De("gp-bill-left",`
      <h3>${U("tipOffset")}</h3>
      <canvas id="bTip" width="120" height="120" style="display:block;margin:0 auto;touch-action:none;cursor:crosshair"></canvas>
      <div class="dim" id="bTipTxt" style="text-align:center;margin:4px 0;font-size:11px"></div>
      <div class="row" style="justify-content:center">
        <button data-a="chalk">\u{1F9CA} ${U("chalk")} <b id="bChalk"></b></button>
        <button data-a="center">\u2299</button>
      </div>
      <div class="row" style="justify-content:center;align-items:center;margin-top:6px;gap:3px;flex-wrap:nowrap;white-space:nowrap">
        <span class="dim" style="font-size:11px">${$b("\uAC01\uB3C4","Angle")}</span>
        <button data-a="el-" class="sm">\u2212</button><b id="bEl" style="min-width:30px;text-align:center"></b><button data-a="el+" class="sm">\uFF0B</button>
      </div>
      <div class="row" style="justify-content:center;margin-top:6px">
        <button data-a="view">\u{1F3A5} <span id="bView"></span></button>
        <button data-a="guide">\u{1F4D0}</button>
      </div>`),t.left.style.cssText="left:10px;bottom:max(14px, env(safe-area-inset-bottom));padding:10px;width:156px",t.right=De("gp-bill-right",`
      <h3 style="text-align:center">${U("power")}</h3>
      <div id="bGauge" style="position:relative;width:54px;height:200px;margin:0 auto;border-radius:12px;background:rgba(255,255,255,.1);touch-action:none;cursor:ns-resize;overflow:hidden">
        <i style="position:absolute;left:0;right:0;top:0;height:0;background:linear-gradient(#6ee7b7,#fde047,#f87171)"></i>
        <span style="position:absolute;left:0;right:0;bottom:6px;text-align:center;font-size:11px;opacity:.7">\u25BC ${U("pullBack")}</span>
      </div>
      <div class="mid" id="bPow" style="text-align:center;margin:4px 0">0%</div>
      <div class="row" style="justify-content:center;gap:4px">
        <button data-a="l2">\u23EA</button><button data-a="l1">\u25C0</button><button data-a="r1">\u25B6</button><button data-a="r2">\u23E9</button>
      </div>`),t.right.style.cssText="right:10px;bottom:max(14px, env(safe-area-inset-bottom));padding:10px",t.top=De("gp-bill-top",`<div class="row"><button data-a="exit">${U("exit")}</button><button data-a="rack">\u21BA ${U("rack")}</button></div>`),t.top.style.cssText="left:10px;top:calc(max(10px, env(safe-area-inset-top)) + 52px);padding:6px;background:transparent;border:0;box-shadow:none;backdrop-filter:none",t.help=De("gp-bill-help",""),t.help.style.cssText="left:50%;transform:translateX(-50%);bottom:max(14px, env(safe-area-inset-bottom));padding:6px 12px;font-size:11px;max-width:calc(100vw - 380px);text-align:center",t.tip=t.left.querySelector("#bTip");let e=a=>{let l=t.tip.getBoundingClientRect(),c=(a.clientX-l.left)/l.width*2-1,h=-((a.clientY-l.top)/l.height*2-1);this.setTip(c/.82,h/.82)};t.tip.addEventListener("pointerdown",a=>{t.tip.setPointerCapture(a.pointerId),this.tipDrag=!0,e(a)}),t.tip.addEventListener("pointermove",a=>{this.tipDrag&&e(a)}),t.tip.addEventListener("pointerup",()=>{this.tipDrag=!1}),t.left.querySelector("[data-a=chalk]").onclick=()=>this.doChalk(),t.left.querySelector("[data-a=center]").onclick=()=>this.setTip(0,0),t.left.querySelector('[data-a="el-"]').onclick=()=>this.setElev(-5),t.left.querySelector('[data-a="el+"]').onclick=()=>this.setElev(5),this.setElev(0),t.left.querySelector("[data-a=view]").onclick=()=>this.toggleView(),t.left.querySelector("[data-a=guide]").onclick=()=>{this.guideOn=!this.guideOn},t.top.querySelector("[data-a=exit]").onclick=()=>this.ctx.exit(),t.top.querySelector("[data-a=rack]").onclick=()=>{this.party.joined&&this.party.clear()};let n=t.right.querySelector("#bGauge");n.addEventListener("pointerdown",a=>{this.canShoot()&&(n.setPointerCapture(a.pointerId),this.gaugeDrag={y0:a.clientY,h:n.getBoundingClientRect().height})}),n.addEventListener("pointermove",a=>{this.gaugeDrag&&(this.power=Math.max(0,Math.min(1,(a.clientY-this.gaugeDrag.y0)/(this.gaugeDrag.h*.85))))});let s=()=>{this.gaugeDrag&&(this.gaugeDrag=null,this.power>.02?this.shoot():this.power=0)};n.addEventListener("pointerup",s),n.addEventListener("pointercancel",()=>{this.gaugeDrag=null,this.power=0});for(let[a,l]of[["l2",-5],["l1",-1],["r1",1],["r2",5]]){let c=t.right.querySelector(`[data-a=${a}]`),h=null,u=()=>{clearInterval(h),h=null};c.addEventListener("pointerdown",()=>{this.nudge(l),u(),h=setInterval(()=>this.nudge(l),90)}),c.addEventListener("pointerup",u),c.addEventListener("pointerleave",u),c.addEventListener("pointercancel",u)}this.drawTip()}showUI(t){for(let e of["board","left","right","top","help"])this.ui[e].hidden=!t}setTip(t,e){let n=Math.hypot(t,e),s=.9;n>s&&(t*=s/n,e*=s/n),this.ox=Math.round(t*100)/100,this.oy=Math.round(e*100)/100,this.drawTip()}drawTip(){let t=this.ui.tip,e=t.getContext("2d"),n=t.width,s=n/2,r=n*.41;e.clearRect(0,0,n,n);let o=e.createRadialGradient(s-r*.3,s-r*.3,r*.1,s,s,r);o.addColorStop(0,"#ffffff"),o.addColorStop(1,"#cfcfc8"),e.fillStyle=o,e.beginPath(),e.arc(s,s,r,0,7),e.fill(),e.strokeStyle="rgba(0,0,0,.25)",e.lineWidth=1;for(let h of[.33,.66])e.beginPath(),e.arc(s,s,r*h,0,7),e.stroke();e.beginPath(),e.moveTo(s-r,s),e.lineTo(s+r,s),e.moveTo(s,s-r),e.lineTo(s,s+r),e.stroke(),e.strokeStyle="rgba(239,68,68,.6)",e.setLineDash([3,3]),e.beginPath(),e.arc(s,s,r*.72,0,7),e.stroke(),e.setLineDash([]);let a=s+this.ox*r*.82/.82*.82,l=s-this.oy*r*.82/.82*.82;e.fillStyle="#ef4444",e.beginPath(),e.arc(a,l,7,0,7),e.fill(),e.strokeStyle="#fff",e.lineWidth=2,e.stroke();let c=[];this.oy>.08&&c.push(`${U("follow")} ${Math.round(this.oy*100)}`),this.oy<-.08&&c.push(`${U("draw")} ${Math.round(-this.oy*100)}`),this.ox>.08&&c.push(`${U("rightEng")} ${Math.round(this.ox*100)}`),this.ox<-.08&&c.push(`${U("leftEng")} ${Math.round(-this.ox*100)}`),this.ui.left.querySelector("#bTipTxt").textContent=c.join(" \xB7 ")||U("centerBall")}doChalk(){var t,e;this.chalkAnim>0||(this.chalkAnim=1.1,(e=(t=this.ctx.audio)==null?void 0:t.chalk)==null||e.call(t))}setElev(t){var n;this.elev=Math.max(0,Math.min(60,(this.elev||0)+t));let e=(n=this.ui)==null?void 0:n.left.querySelector("#bEl");e&&(e.textContent=`${this.elev}\xB0`)}toggleView(){var t,e,n,s;this.view=this.view==="top"?"cue":"top",(e=(t=this.ctx).resetView)==null||e.call(t),(s=(n=this.ctx).snap)==null||s.call(n)}nudge(t){this.canAim()&&(this.aim+=t*.0012)}enter(){var t,e;this.active=!0,this.ctx.hud.hide(),this.uiLang!==rn()&&this.buildUI(),this.cue.visible=!1;for(let n of[this.ctx.world.lamp,this.ctx.world.pavilionRoof])n&&(n.visible=!1);this.ctx.player.pos.set(Kt.table.x,0,Kt.table.z+1.4),!this.party.joined&&this.party.slots.length<4&&!this.party.state&&this.party.join(),this.onParty(this.party.state),(e=(t=this.ctx).snap)==null||e.call(t)}exit(){this.active=!1,this.party.leave(),this.lobby.hide(),this.showUI(!1),this.cue.visible=this.chalkCube.visible=!1;for(let t of[this.guide,this.guide2,this.guide3,this.ghost])t.visible=!1;this.ctx.camTarget.up.set(0,1,0);for(let t of[this.ctx.world.lamp,this.ctx.world.pavilionRoof])t&&(t.visible=!0);this.sim=null}start(t){let e=this.party.slots.length;if(!e)return;let n={phase:"play",mode:t,balls:Qf(t),turn:0,scores:Array(e).fill(0),innings:Array(e).fill(0),runs:Array(e).fill(0),high:Array(e).fill(0),target:t==="pool8"?0:e>2?8:10,groups:null,ballInHand:t==="pool8",winner:null,msg:"",last:null};n.innings[0]=1,this.party.setState(n),this.onParty(n)}onParty(t){var e,n;if(!this.active){t&&(this.buildTable(_o[t.mode]),this.showBalls(t.balls));return}if(!t){this.showUI(!1),this.lobby.show(this.party),this.buildTable("pool"),this.showBalls(Qf("pool8"));return}if(this.lobby.hide(),this.ui.board.hidden&&((n=(e=this.ctx).snap)==null||n.call(e)),this.showUI(!0),t.seq===this.appliedSeq){this.renderBoard();return}this.appliedSeq=t.seq,this.buildTable(_o[t.mode]),(!this.sim||!this.sim.mine)&&(this.sim=null,this.showBalls(t.balls)),(this.prevTurn!==t.turn||this.prevMode!==t.mode)&&(this.aimAtTarget(t),this.setTip(0,0)),this.prevTurn=t.turn,this.prevMode=t.mode,this.renderBoard()}onPartyMsg(t){if(!this.active)return;let e=t.d;e.k==="shot"&&this.runShot(e,!1)}cueN(t=this.party.state){return t?t.mode==="pool8"?0:t.turn%2:0}team(t){return t%2}canAim(){let t=this.party.state;return!!t&&t.phase==="play"&&!this.sim&&this.party.mine(t.turn)}canShoot(){return this.canAim()&&!this.chalkAnim}aimAtTarget(t){let e=t.balls.find(r=>r[0]===this.cueN(t)),n=null,s=1e9;for(let r of t.balls)if(r[0]!==e[0]&&!r[3]){let o=Math.hypot(r[1]-e[1],r[2]-e[2]);o<s&&(s=o,n=r)}n&&(this.aim=Math.atan2(n[2]-e[2],n[1]-e[1]))}shoot(){if(!this.canShoot())return;let t=this.party.state,e=Math.hypot(this.ox,this.oy),n=Math.max(0,e-.55)*2.2*(1.3-this.chalk)+(e>.72?.35:0),s=Math.random()<n,r={k:"shot",slot:t.turn,aim:this.aim,power:this.power,ox:this.ox,oy:this.oy,el:this.elev||0,miscue:s,balls:this.currentBalls()};this.chalk=Math.max(0,this.chalk-.18-e*.15),this.party.msg(r),this.runShot(r,!0),this.power=0}currentBalls(){return this.party.state.balls.map(t=>[...t])}runShot(t,e){var h,u;let n=this.party.state,s=ii[_o[n.mode]],r=n.mode==="pool8"?0:t.slot%2;this.sim=new uu(_o[n.mode],t.balls,r),this.sim.mine=e,this.sim.slot=t.slot;let o=.35+Math.pow(t.power,1.25)*(s.vmax-.35),a=t.aim,l=t.ox,c=t.oy;t.miscue&&(o*=.2,a+=(Math.random()-.5)*.25,l=c=0,this.ctx.toast(`\u{1F4A5} ${U("miscue")}`)),this.strikeAnim={t:0,aim:t.aim,el:t.el||0,cue:t.balls.find(d=>d[0]===r)};{let d=t.balls.find(f=>f[0]===r);this.fpAnchor={x:d[1],z:d[2],aim:t.aim}}this.sim.strike(a,o,l,c,t.miscue?0:t.el||0),(u=(h=this.ctx.audio)==null?void 0:h.cue)==null||u.call(h,.35+t.power*.65),this.restT=0}finishShot(){let t=this.sim,e=structuredClone(this.party.state);e.balls=t.pack(),e.ballInHand=!1;let n=this.party.slots.length,s=t.slot,r=t.ev,o=t.cueN,a=!1,l="";if(e.mode==="carom3"||e.mode==="carom4"){let c=e.balls.map(g=>g[0]).filter(g=>g!==o),h=e.mode==="carom4"?1-o:null,u=[],d=0,f=-1;for(let g of r.seq)if(g[0]==="c"&&g[1]===o&&d++,g[0]==="b"&&(g[1]===o||g[2]===o)){let x=g[1]===o?g[2]:g[1];u.includes(x)||(u.push(x),u.length===2&&(f=d))}if(e.mode==="carom3")u.length>=2&&f>=3?(e.scores[s]++,a=!0,l=`\u{1F3AF} ${U("point")}!`):l=u.length>=2?U("needCush",{n:f}):U("miss");else{let g=c.filter(m=>m!==h);u.includes(h)?(e.scores[s]=e.scores[s]-1,l=`\u26A0\uFE0F ${U("foulOpp")} \u22121`):u.length?g.every(m=>u.includes(m))?(e.scores[s]++,a=!0,l=`\u{1F3AF} ${U("point")}!`):l=U("miss"):(e.scores[s]=e.scores[s]-1,l=`\u26A0\uFE0F ${U("foulNone")} \u22121`)}e.scores[s]>=e.target&&(e.winner=s,e.phase="done",l=`\u{1F3C6} ${this.party.name(s)} ${U("wins")}`)}else{let c=this.team(s),h=p=>p>=1&&p<=7,u=p=>p>=9,d=r.pocketed,f=d.includes(0),g=e.groups?e.groups[c]:null,x=p=>e.balls.filter(M=>!M[3]&&(p==="solid"?h(M[0]):u(M[0]))).length,m="";if(f?m=U("scratch"):r.first==null?m=U("foulNone"):g&&r.first!==8&&g==="solid"!==h(r.first)?m=U("foulWrong"):g&&r.first===8&&x(g)+d.filter(p=>g==="solid"?h(p):u(p)).length>0?m=U("foulWrong"):!g&&r.first===8?m=U("foulWrong"):!d.length&&!r.railAfter&&(m=U("foulRail")),d.includes(8)){let p=g&&x(g)===0,M=p&&!m?c:1-c;e.phase="done",e.winner=n===1?M===c?s:-1:M,e.winnerTeam=M,l=M===c&&n>0&&p&&!m?`\u{1F3C6} ${U("eightWin")}`:`\u{1F480} ${U("eightLose")}`}else{let p=d.filter(v=>v!==0&&v!==8);if(!m&&!e.groups&&p.length){let v=h(p[0])?"solid":"stripe";e.groups={},e.groups[c]=v,e.groups[1-c]=v==="solid"?"stripe":"solid",l=`${U(v)} ${U("assigned")}`}let M=e.groups?p.filter(v=>e.groups[c]==="solid"===h(v)):p;if(e.scores[s]+=p.length?M.length:0,m){if(l=`\u26A0\uFE0F ${U("foul")}: ${m} \xB7 ${U("ballInHand")}`,e.ballInHand=!0,f){let v=e.balls.find(y=>y[0]===0);v[1]=-ii.pool.L/4,v[2]=0,v[3]=0,this.unblock(e,v)}}else M.length?(a=!0,l=l||`\u{1F3AF} ${U("potted",{n:M.length})}`):l||(l=U("miss"))}}a&&e.phase==="play"?(e.runs[s]++,e.high[s]=Math.max(e.high[s],e.runs[s])):(e.runs[s]=0,e.phase==="play"&&n>1?(e.turn=(s+1)%n,e.innings[e.turn]++):e.phase==="play"&&e.innings[s]++),e.msg=l,e.last=s,this.sim=null,this.party.setState(e),this.onParty(e),l&&this.ctx.toast(l)}unblock(t,e){let n=ii.pool.R;for(let s=0;s<40;s++){if(!t.balls.some(r=>r!==e&&!r[3]&&Math.hypot(r[1]-e[1],r[2]-e[2])<2.05*n))return;e[1]-=n}}tablePoint(){let t=ft.pointer;this.raycaster.setFromCamera(new rt(t.x,t.y),this.ctx.camera);let e=new bn(new C(0,1,0),-(Kt.table.y+ii[this.tableKey].R)),n=new C;return this.raycaster.ray.intersectPlane(e,n)?{x:n.x-this.group.position.x,z:n.z-this.group.position.z}:null}onPointer(t){if(!this.active||this.view!=="top"){this.dragBall=!1;return}if(!t){this.dragBall=!1;return}if(!this.canAim())return;let e=this.party.state,n=this.tablePoint();if(!n)return;let s=e.balls.find(r=>r[0]===this.cueN(e));e.ballInHand&&Math.hypot(n.x-s[1],n.z-s[2])<.09&&(this.dragBall=!0)}update(t){let e=this.party.state,n=Wi(),s=ii[this.tableKey];if(e&&e.phase!=="lobby"&&this.sim&&(this.sim.step(t),this.playSounds(),this.showBalls(this.sim.balls),this.sim.moving()||(this.restT+=t,this.restT>.35&&(this.sim.mine?this.finishShot():(this.sim=null,e&&this.showBalls(e.balls))))),this.chalkAnim>0&&(this.chalkAnim-=t,this.chalkAnim<=0&&(this.chalk=1,this.chalkAnim=0)),this.canAim()){let o=e.balls.find(a=>a[0]===this.cueN(e));if(this.dragBall&&ft.pointer.down){let a=this.tablePoint();if(a){let l=s.R,c=s.L/2-l,h=s.W/2-l,u=Math.max(-c,Math.min(c,a.x)),d=Math.max(-h,Math.min(h,a.z));e.balls.some(f=>f!==o&&!f[3]&&Math.hypot(f[1]-u,f[2]-d)<2.02*l)||(o[1]=+u.toFixed(4),o[2]=+d.toFixed(4)),this.showBalls(e.balls)}}else if(this.view==="top"&&ft.pointer.down&&!this.gaugeDrag&&!this.tipDrag){let a=this.tablePoint();a&&Math.hypot(a.x-o[1],a.z-o[2])>.03&&(this.aim=Math.atan2(a.z-o[2],a.x-o[1]))}else this.view==="cue"&&(this.aim-=n.x*.0018*(ft.keys.has("ShiftLeft")?.25:1));this.aim+=vr(t)*.12*(ft.keys.has("ShiftLeft")?.25:1)*-1,ft.power&&!this.gaugeDrag&&(this.power=Math.min(1,(this.power||0)+t/1.6))}this.view==="cue"&&(this.fpPitch=Math.max(.04,Math.min(1.35,this.fpPitch+n.y*.004))),this.updateCue(t,e,s),this.updateCamera(e,s),this.updateHud(e);let r=this.ctx.player;if(e){let o=e.balls.find(a=>a[0]===this.cueN(e));if(o&&this.party.mine(e.turn)){let a=o[1],l=o[2];for(let c=0;c<60&&Math.abs(a)<s.L/2+.5&&Math.abs(l)<s.W/2+.5;c++)a-=Math.cos(this.aim)*.05,l-=Math.sin(this.aim)*.05;r.pos.set(this.group.position.x+a,0,this.group.position.z+l),r.yaw=Math.atan2(Math.cos(this.aim),Math.sin(this.aim))}}r.speed=0}playSounds(){var n,s,r;let t=this.sim.ev.seq,e=this.ctx.audio;if(e){for(let o=this.sim.sndIdx||0;o<t.length;o++){let a=t[o];a[0]==="b"?(n=e.clack)==null||n.call(e,Math.min(1,(a[3]||1)/2.2)):a[0]==="c"?(s=e.cushion)==null||s.call(e,Math.min(1,(a[2]||1)/2.5)):a[0]==="p"&&((r=e.pocket)==null||r.call(e))}this.sim.sndIdx=t.length}}powerDown(){}powerUp(){this.power>.02&&!this.gaugeDrag&&this.shoot()}showBalls(t){let e=ii[this.tableKey];for(let n of Object.values(this.meshes))n.visible=!1;for(let n of t){let s=Array.isArray(n)?n[0]:n.n,r=Array.isArray(n)?n[1]:n.x,o=Array.isArray(n)?n[2]:n.z,a=Array.isArray(n)?n[3]:n.in,l=this.meshes[s];l&&(l.visible=!a,l.position.set(r,e.R,o),Array.isArray(n)||l.quaternion.copy(n.rot))}}updateCue(t,e,n){var W;let s=!!e&&e.phase==="play"&&(this.canAim()||this.strikeAnim);this.cue.visible=s;let r=[this.guide,this.guide2,this.guide3,this.ghost];if(!s){r.forEach(k=>k.visible=!1),this.chalkCube.visible=!1;return}let o,a,l=this.aim,c;if(this.strikeAnim){let k=this.strikeAnim;k.t+=t,o=k.cue[1],a=k.cue[2],l=k.aim,c=Math.max(-.02,.01+(.08-k.t*1.2)),k.t>.6&&(this.strikeAnim=null)}else{let k=e.balls.find(q=>q[0]===this.cueN(e));o=k[1],a=k[2],c=.012+this.power*.28+(this.chalkAnim?.12:0)}let h=Math.cos(l),u=Math.sin(l),d=-u,f=h,g=(((W=this.strikeAnim)==null?void 0:W.el)??this.elev??0)*Math.PI/180,x=Math.cos(g),m=Math.sin(g),p=o-h*(n.R+c)*x+d*this.ox*n.R*.8,M=a-u*(n.R+c)*x+f*this.ox*n.R*.8,v=n.R+this.oy*n.R*.8+(n.R*.6+c)*m;if(this.cue.position.set(p,v,M),this.cue.rotation.set(0,-l,0),this.cue.rotateZ(-.09-g),this.tipMat.color.setHSL(.6,.65*this.chalk+.1,.25+.3*(1-this.chalk)),this.chalkAnim>0){let k=1-this.chalkAnim/1.1;this.chalkCube.visible=!0;let q=p,H=M;this.chalkCube.position.set(q+Math.cos(k*30)*.004,v+.012+Math.sin(k*Math.PI)*.05,H+Math.sin(k*30)*.004),this.chalkCube.rotation.set(0,k*18,0)}else this.chalkCube.visible=!1;let y=this.guideOn&&!this.strikeAnim&&this.canAim();if(r.forEach(k=>k.visible=!1),!y)return;let w=n.R,S=n.L/2-w,A=n.W/2-w,P=null,_=1e9;for(let k of e.balls){if(k[3]||k[0]===this.cueN(e))continue;let q=k[1]-o,H=k[2]-a,K=q*h+H*u;if(K<=0)continue;let Q=q*q+H*H-K*K;if(Q>4*w*w)continue;let at=K-Math.sqrt(4*w*w-Q);at<_&&(_=at,P=k)}let b=h>0?(S-o)/h:h<0?(-S-o)/h:1e9,R=u>0?(A-a)/u:u<0?(-A-a)/u:1e9,L=Math.min(b,R),D=.004,N=(k,q)=>{k.geometry.setFromPoints(q.map(([H,K])=>new C(H,D,K))),k.computeLineDistances(),k.visible=!0};if(P&&_<L){let k=o+h*_,q=a+u*_;N(this.guide,[[o,a],[k,q]]),this.ghost.position.set(k,D,q),this.ghost.visible=!0,this.ghost.scale.setScalar(w/.028);let H=P[1]-k,K=P[2]-q,Q=Math.hypot(H,K);N(this.guide2,[[P[1],P[2]],[P[1]+H/Q*.35,P[2]+K/Q*.35]]);let at=h-(h*H+u*K)/Q*H/Q,Ct=u-(h*H+u*K)/Q*K/Q;at+=h*this.oy*.6,Ct+=u*this.oy*.6;let qt=Math.hypot(at,Ct)||1;N(this.guide3,[[k,q],[k+at/qt*.25,q+Ct/qt*.25]])}else{let k=o+h*L,q=a+u*L;N(this.guide,[[o,a],[k,q]]);let H=b<R?-h:h,K=b<R?u:-u;N(this.guide3,[[k,q],[k+H*.4,q+K*.4]])}}updateCamera(t,e){let n=this.ctx.camTarget,s=this.ctx.camera,r=this.group.position;if(this.view==="cue"&&t&&t.phase==="play"){let h=this.sim&&this.fpAnchor?this.fpAnchor:(()=>{let m=t.balls.find(p=>p[0]===this.cueN(t));return{x:m[1],z:m[2],aim:this.aim}})(),u=Math.cos(h.aim),d=Math.sin(h.aim),f=this.fpPitch,g=this.fpDist;n.up.set(0,1,0),n.pos.set(r.x+h.x-u*g*Math.cos(f),r.y+e.R+.05+g*Math.sin(f),r.z+h.z-d*g*Math.cos(f));let x=.15+.75*Math.max(0,1-f/1.3);n.look.set(r.x+h.x+u*x,r.y+e.R,r.z+h.z+d*x);return}let o=Math.tan(pr.degToRad(s.fov/2)),a=s.aspect,l=e.L+.36,c=e.W+.36;if(a>=1){let h=Math.max(l*1.12/(2*o*a)*(1+320/innerWidth),c*1.75/(2*o));n.up.set(0,0,-1),n.pos.set(r.x,r.y+h,r.z+h*.18),n.look.set(r.x,r.y,r.z+h*.03)}else{let h=Math.max(l*1.6/(2*o),c*1.15/(2*o*a));n.up.set(1,0,0),n.pos.set(r.x-h*.15,r.y+h,r.z),n.look.set(r.x-h*.03,r.y,r.z)}}updateHud(t){if(!t)return;let e=this.ui,n=e.right.querySelector("#bGauge i");n.style.height=`${this.power*100}%`,e.right.querySelector("#bPow").textContent=`${Math.round(this.power*100)}%`,e.left.querySelector("#bChalk").textContent=`${Math.round(this.chalk*100)}%`,e.left.querySelector("#bView").textContent=this.view==="top"?U("viewTop"):U("viewCue");let s=this.canAim();e.right.style.opacity=e.left.style.opacity=s||this.sim?1:.45;let r=s?t.ballInHand?U("ballInHandHelp"):this.view==="cue"?U("billCueHelp"):U("billHelp2"):t.phase==="play"?U("waitTurn",{name:this.party.name(t.turn)}):"";e.help.textContent!==r&&(e.help.textContent=r)}renderBoard(){var r,o;let t=this.party.state,e=this.ui.board;if(!t)return;let s=`<div class="row" style="justify-content:space-between"><b>\u{1F3B1} ${{carom3:U("carom3"),carom4:U("carom4"),pool8:U("pool8")}[t.mode]}</b><span class="dim">${t.target?`${U("target")} ${t.target}`:U("pool8s")}</span></div>`;s+=`<table style="margin-top:4px"><tr><th>${U("player")}</th><th>${t.mode==="pool8"?U("group"):U("ball")}</th><th>${U("score")}</th><th>${U("innings")}</th><th>${U("highRun")}</th></tr>`,this.party.slots.forEach((a,l)=>{var u;if(l>=t.scores.length)return;let c;if(t.mode==="pool8"){let d=(u=t.groups)==null?void 0:u[this.team(l)];c=d?U(d):U("open")}else c=`<span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:${l%2?"#f7d23e":"#fafafa"};vertical-align:-2px"></span>`;let h=t.phase==="done"&&(t.mode==="pool8"?t.winnerTeam===this.team(l):t.winner===l);s+=`<tr class="${l===t.turn&&t.phase==="play"?"turn":""}"><td>${h?"\u{1F3C6} ":""}${Pe(a.name)}${t.mode==="pool8"&&this.party.slots.length>2?` <span class="dim">T${this.team(l)+1}</span>`:""}</td><td>${c}</td><td><b class="mid">${t.scores[l]}</b></td><td>${t.innings[l]}</td><td>${t.high[l]}</td></tr>`}),s+="</table>",t.msg&&(s+=`<div style="margin-top:4px;text-align:center">${Pe(t.msg)}</div>`),t.phase==="done"&&(s+=`<div class="row" style="justify-content:center;margin-top:6px"><button class="go" data-a="again">${U("playAgain")}</button><button data-a="lobby">${U("backLobby")}</button></div>`),e.innerHTML=s,(r=e.querySelector("[data-a=again]"))==null||r.addEventListener("click",()=>this.start(t.mode)),(o=e.querySelector("[data-a=lobby]"))==null||o.addEventListener("click",()=>this.party.clear())}netState(){return null}};function mn(i,t,e,n,s,r=!0){let o=new nt(i,t);return o.position.set(e,n,s),o.castShadow=r,o.receiveShadow=!0,o}var wr=.16;function Mo(i,t,e){let n=Math.imul(i|0,374761393)^Math.imul(t|0,668265263)^Math.imul(e,2147483647);return n=Math.imul(n^n>>>13,1274126177),((n^n>>>16)>>>0)/4294967296}var ul=class{constructor(t,e,{count:n,radius:s,tint:r}){this.world=e,this.radius=s,this.max=n;let o=new ae,a=[],l=[],c=[],h=3,u=.022,d=new bt(3099164),f=new bt(10270826).multiply(new bt(r));for(let x=0;x<=h;x++){let m=x/h,p=u*(1-m*.85),M=d.clone().lerp(f,m);if(a.push(-p,m,m*m*.12,p,m,m*m*.12),l.push(M.r,M.g,M.b,M.r,M.g,M.b),x<h){let v=x*2;c.push(v,v+1,v+2,v+1,v+3,v+2)}}o.setAttribute("position",new Ot(a,3)),o.setAttribute("color",new Ot(l,3)),o.setIndex(c),o.computeVertexNormals(),this.time={value:0};let g=new ye({vertexColors:!0,roughness:.85,side:Te});g.onBeforeCompile=x=>{x.uniforms.uTime=this.time,x.uniforms.uBend=bs,x.vertexShader=`uniform float uTime;
uniform float uBend;
`+x.vertexShader.replace("#include <beginnormal_vertex>","vec3 objectNormal = vec3(0.0, 1.0, 0.0);").replace("#include <project_vertex>",`
          vec4 gw = instanceMatrix * vec4(transformed, 1.0);
          gw = modelMatrix * gw;
          float sway = sin(uTime * 1.7 + gw.x * 0.35 + gw.z * 0.25) * 0.5 + sin(uTime * 3.1 + gw.x * 1.3) * 0.2;
          gw.x += sway * position.y * position.y * 0.18;
          gw.z += sway * position.y * position.y * 0.08;
          vec2 dxz = gw.xz - cameraPosition.xz;
          gw.y -= dot(dxz, dxz) * uBend;
          vec4 mvPosition = viewMatrix * gw;
          gl_Position = projectionMatrix * mvPosition;`)},g.customProgramCacheKey=()=>"grass",this.mesh=new sn(o,g,n),this.mesh.frustumCulled=!1,this.mesh.receiveShadow=!0,this.mesh.count=0,t.add(this.mesh),this.center=new rt(1e9,1e9)}scatter(t,e){let n=new Wt,s=new Re,r=new C,o=new C,a=new C(0,1,0),l=this.radius,c=l*l,h=0,u=Math.floor((t-l)/wr),d=Math.ceil((t+l)/wr),f=Math.floor((e-l)/wr),g=Math.ceil((e+l)/wr);for(let x=f;x<=g&&h<this.max;x++)for(let m=u;m<=d&&h<this.max;m++){let p=(m+Mo(m,x,1))*wr,M=(x+Mo(m,x,2))*wr,v=p-t,y=M-e,w=v*v+y*y;if(w>c||Mo(m,x,3)>1.15-w/c||!this.world.isGrass(p,M))continue;let S=.12+Mo(m,x,4)*.22;s.setFromAxisAngle(a,Mo(m,x,5)*Math.PI*2),r.set(1,S,1),o.set(p,0,M),n.compose(o,s,r),this.mesh.setMatrixAt(h++,n)}this.mesh.count=h,this.mesh.instanceMatrix.needsUpdate=!0,this.center.set(t,e)}update(t,e){this.time.value+=t,Math.hypot(e.x-this.center.x,e.z-this.center.y)>this.radius*.3&&this.scatter(e.x,e.z)}};var du={\uC11C\uC6B8:"\uC885\uB85C\uAD6C \uC911\uAD6C \uC6A9\uC0B0\uAD6C \uC131\uB3D9\uAD6C \uAD11\uC9C4\uAD6C \uB3D9\uB300\uBB38\uAD6C \uC911\uB791\uAD6C \uC131\uBD81\uAD6C \uAC15\uBD81\uAD6C \uB3C4\uBD09\uAD6C \uB178\uC6D0\uAD6C \uC740\uD3C9\uAD6C \uC11C\uB300\uBB38\uAD6C \uB9C8\uD3EC\uAD6C \uC591\uCC9C\uAD6C \uAC15\uC11C\uAD6C \uAD6C\uB85C\uAD6C \uAE08\uCC9C\uAD6C \uC601\uB4F1\uD3EC\uAD6C \uB3D9\uC791\uAD6C \uAD00\uC545\uAD6C \uC11C\uCD08\uAD6C \uAC15\uB0A8\uAD6C \uC1A1\uD30C\uAD6C \uAC15\uB3D9\uAD6C",\uBD80\uC0B0:"\uC911\uAD6C \uC11C\uAD6C \uB3D9\uAD6C \uC601\uB3C4\uAD6C \uBD80\uC0B0\uC9C4\uAD6C \uB3D9\uB798\uAD6C \uB0A8\uAD6C \uBD81\uAD6C \uD574\uC6B4\uB300\uAD6C \uC0AC\uD558\uAD6C \uAE08\uC815\uAD6C \uAC15\uC11C\uAD6C \uC5F0\uC81C\uAD6C \uC218\uC601\uAD6C \uC0AC\uC0C1\uAD6C \uAE30\uC7A5\uAD70",\uB300\uAD6C:"\uC911\uAD6C \uB3D9\uAD6C \uC11C\uAD6C \uB0A8\uAD6C \uBD81\uAD6C \uC218\uC131\uAD6C \uB2EC\uC11C\uAD6C \uB2EC\uC131\uAD70 \uAD70\uC704\uAD70",\uC778\uCC9C:"\uC911\uAD6C \uB3D9\uAD6C \uBBF8\uCD94\uD640\uAD6C \uC5F0\uC218\uAD6C \uB0A8\uB3D9\uAD6C \uBD80\uD3C9\uAD6C \uACC4\uC591\uAD6C \uC11C\uAD6C \uAC15\uD654\uAD70 \uC639\uC9C4\uAD70",\uAD11\uC8FC:"\uB3D9\uAD6C \uC11C\uAD6C \uB0A8\uAD6C \uBD81\uAD6C \uAD11\uC0B0\uAD6C",\uB300\uC804:"\uB3D9\uAD6C \uC911\uAD6C \uC11C\uAD6C \uC720\uC131\uAD6C \uB300\uB355\uAD6C",\uC6B8\uC0B0:"\uC911\uAD6C \uB0A8\uAD6C \uB3D9\uAD6C \uBD81\uAD6C \uC6B8\uC8FC\uAD70",\uC138\uC885:"\uC138\uC885\uC2DC",\uACBD\uAE30:"\uC218\uC6D0\uC2DC \uC131\uB0A8\uC2DC \uC758\uC815\uBD80\uC2DC \uC548\uC591\uC2DC \uBD80\uCC9C\uC2DC \uAD11\uBA85\uC2DC \uD3C9\uD0DD\uC2DC \uB3D9\uB450\uCC9C\uC2DC \uC548\uC0B0\uC2DC \uACE0\uC591\uC2DC \uACFC\uCC9C\uC2DC \uAD6C\uB9AC\uC2DC \uB0A8\uC591\uC8FC\uC2DC \uC624\uC0B0\uC2DC \uC2DC\uD765\uC2DC \uAD70\uD3EC\uC2DC \uC758\uC655\uC2DC \uD558\uB0A8\uC2DC \uC6A9\uC778\uC2DC \uD30C\uC8FC\uC2DC \uC774\uCC9C\uC2DC \uC548\uC131\uC2DC \uAE40\uD3EC\uC2DC \uD654\uC131\uC2DC \uAD11\uC8FC\uC2DC \uC591\uC8FC\uC2DC \uD3EC\uCC9C\uC2DC \uC5EC\uC8FC\uC2DC \uC5F0\uCC9C\uAD70 \uAC00\uD3C9\uAD70 \uC591\uD3C9\uAD70",\uAC15\uC6D0:"\uCD98\uCC9C\uC2DC \uC6D0\uC8FC\uC2DC \uAC15\uB989\uC2DC \uB3D9\uD574\uC2DC \uD0DC\uBC31\uC2DC \uC18D\uCD08\uC2DC \uC0BC\uCC99\uC2DC \uD64D\uCC9C\uAD70 \uD6A1\uC131\uAD70 \uC601\uC6D4\uAD70 \uD3C9\uCC3D\uAD70 \uC815\uC120\uAD70 \uCCA0\uC6D0\uAD70 \uD654\uCC9C\uAD70 \uC591\uAD6C\uAD70 \uC778\uC81C\uAD70 \uACE0\uC131\uAD70 \uC591\uC591\uAD70",\uCDA9\uBD81:"\uCCAD\uC8FC\uC2DC \uCDA9\uC8FC\uC2DC \uC81C\uCC9C\uC2DC \uBCF4\uC740\uAD70 \uC625\uCC9C\uAD70 \uC601\uB3D9\uAD70 \uC99D\uD3C9\uAD70 \uC9C4\uCC9C\uAD70 \uAD34\uC0B0\uAD70 \uC74C\uC131\uAD70 \uB2E8\uC591\uAD70",\uCDA9\uB0A8:"\uCC9C\uC548\uC2DC \uACF5\uC8FC\uC2DC \uBCF4\uB839\uC2DC \uC544\uC0B0\uC2DC \uC11C\uC0B0\uC2DC \uB17C\uC0B0\uC2DC \uACC4\uB8E1\uC2DC \uB2F9\uC9C4\uC2DC \uAE08\uC0B0\uAD70 \uBD80\uC5EC\uAD70 \uC11C\uCC9C\uAD70 \uCCAD\uC591\uAD70 \uD64D\uC131\uAD70 \uC608\uC0B0\uAD70 \uD0DC\uC548\uAD70",\uC804\uBD81:"\uC804\uC8FC\uC2DC \uAD70\uC0B0\uC2DC \uC775\uC0B0\uC2DC \uC815\uC74D\uC2DC \uB0A8\uC6D0\uC2DC \uAE40\uC81C\uC2DC \uC644\uC8FC\uAD70 \uC9C4\uC548\uAD70 \uBB34\uC8FC\uAD70 \uC7A5\uC218\uAD70 \uC784\uC2E4\uAD70 \uC21C\uCC3D\uAD70 \uACE0\uCC3D\uAD70 \uBD80\uC548\uAD70",\uC804\uB0A8:"\uBAA9\uD3EC\uC2DC \uC5EC\uC218\uC2DC \uC21C\uCC9C\uC2DC \uB098\uC8FC\uC2DC \uAD11\uC591\uC2DC \uB2F4\uC591\uAD70 \uACE1\uC131\uAD70 \uAD6C\uB840\uAD70 \uACE0\uD765\uAD70 \uBCF4\uC131\uAD70 \uD654\uC21C\uAD70 \uC7A5\uD765\uAD70 \uAC15\uC9C4\uAD70 \uD574\uB0A8\uAD70 \uC601\uC554\uAD70 \uBB34\uC548\uAD70 \uD568\uD3C9\uAD70 \uC601\uAD11\uAD70 \uC7A5\uC131\uAD70 \uC644\uB3C4\uAD70 \uC9C4\uB3C4\uAD70 \uC2E0\uC548\uAD70",\uACBD\uBD81:"\uD3EC\uD56D\uC2DC \uACBD\uC8FC\uC2DC \uAE40\uCC9C\uC2DC \uC548\uB3D9\uC2DC \uAD6C\uBBF8\uC2DC \uC601\uC8FC\uC2DC \uC601\uCC9C\uC2DC \uC0C1\uC8FC\uC2DC \uBB38\uACBD\uC2DC \uACBD\uC0B0\uC2DC \uC758\uC131\uAD70 \uCCAD\uC1A1\uAD70 \uC601\uC591\uAD70 \uC601\uB355\uAD70 \uCCAD\uB3C4\uAD70 \uACE0\uB839\uAD70 \uC131\uC8FC\uAD70 \uCE60\uACE1\uAD70 \uC608\uCC9C\uAD70 \uBD09\uD654\uAD70 \uC6B8\uC9C4\uAD70 \uC6B8\uB989\uAD70",\uACBD\uB0A8:"\uCC3D\uC6D0\uC2DC \uC9C4\uC8FC\uC2DC \uD1B5\uC601\uC2DC \uC0AC\uCC9C\uC2DC \uAE40\uD574\uC2DC \uBC00\uC591\uC2DC \uAC70\uC81C\uC2DC \uC591\uC0B0\uC2DC \uC758\uB839\uAD70 \uD568\uC548\uAD70 \uCC3D\uB155\uAD70 \uACE0\uC131\uAD70 \uB0A8\uD574\uAD70 \uD558\uB3D9\uAD70 \uC0B0\uCCAD\uAD70 \uD568\uC591\uAD70 \uAC70\uCC3D\uAD70 \uD569\uCC9C\uAD70",\uC81C\uC8FC:"\uC81C\uC8FC\uC2DC \uC11C\uADC0\uD3EC\uC2DC"},ep=Object.keys(du),np=i=>(du[i]||"").split(" ").filter(Boolean),ip=(i,t)=>`dong-${i}-${t}`;var fe=(i,t=document)=>t.querySelector(i),Jb=new URLSearchParams(location.search),mu=(Jb.get("server")||window.LOUNGE_API||"https://tigc.co.kr/lounge").replace(/\/$/,""),jb="https://tigc.co.kr/#/signup",Eo="taeil-lounge-token",sp="taeil-lounge-block",Ft=i=>String(i??"").replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]),As={get(i){try{return localStorage.getItem(i)}catch{return null}},set(i,t){try{t==null?localStorage.removeItem(i):localStorage.setItem(i,t)}catch{}}},le={token:As.get(Eo),user:null,profile:null},fu=["#ff8a5c","#4aa3ff","#5cc9a7","#f783ac","#ffd43b","#9775fa","#20c997","#ff6b6b","#868e96","#2b8a3e"];async function En(i,t){let e=await fetch(mu+i,{method:t===void 0?"GET":"POST",headers:{"content-type":"application/json",...le.token?{authorization:"Bearer "+le.token}:{}},body:t===void 0?void 0:JSON.stringify(t)}),n={};try{n=await e.json()}catch{}if(!e.ok)throw Object.assign(new Error(n.error||`\uC11C\uBC84 \uC624\uB958 (${e.status})`),{status:e.status,until:n.until});return n}function ml(){window.parent!==window?window.parent.postMessage({lounge:"close"},"*"):location.href="about:blank"}function Qb(i){window.parent!==window?window.parent.postMessage({lounge:"open",url:i},"*"):window.open(i,"_blank","noopener")}var wo=new Set;try{wo=new Set(JSON.parse(As.get(sp)||"[]"))}catch{}var Sr=i=>!!i&&wo.has(i);function t_(i,t){t?wo.add(i):wo.delete(i),As.set(sp,JSON.stringify([...wo]))}var Ei=fe("#sheet");function Yi(i,t=""){return Ei.className="sheet "+t,Ei.innerHTML=`<div class="card sheet-in"><button class="x" aria-label="\uB2EB\uAE30">\u2715</button>${i}</div>`,Ei.hidden=!1,fe(".x",Ei).onclick=Ai,Ei.onclick=e=>{e.target===Ei&&Ai()},fe(".sheet-in",Ei)}function Ai(){Ei.hidden=!0,Ei.innerHTML=""}var Xi=(i,t)=>{i&&(i.disabled=t,i.dataset.t??=i.textContent,i.textContent=t?"\uC7A0\uC2DC\uB9CC\uC694\u2026":i.dataset.t)},Ti=(i,t)=>{i.textContent=t?t.message||String(t):"",i.hidden=!t};function rp(i,t,e){let n=fe("[name=sido]",i),s=fe("[name=sgg]",i);n.innerHTML='<option value="">\uC2DC\xB7\uB3C4</option>'+ep.map(o=>`<option${o===t?" selected":""}>${o}</option>`).join("");let r=o=>{s.innerHTML='<option value="">\uC2DC\xB7\uAD70\xB7\uAD6C</option>'+np(n.value).map(a=>`<option${a===o?" selected":""}>${a}</option>`).join("")};n.onchange=()=>r(""),r(e)}function fl(i,t){let e=fe("#login .card");e.innerHTML=`
    <img class="logo" src="logo.png" alt="\uD0DC\uC77C\uACE8\uD504">
    <h1>\uD0DC\uC77C\uACE8\uD504 \uB77C\uC6B4\uC9C0</h1>
    <p class="sub">\uD68C\uC6D0\uB07C\uB9AC \uB9CC\uB098\uC11C \uBBF8\uB2C8\uAC8C\uC784 \uD558\uACE0, \uC6B0\uB9AC \uB3D9\uB124 \uACE8\uD504 \uBAA8\uC784\uB3C4 \uCC3E\uB294 \uACF3</p>
    <form id="lf" autocomplete="on">
      <div class="field"><label>\uD0DC\uC77C\uACE8\uD504 \uD68C\uC6D0 \uC774\uBA54\uC77C</label><input name="email" type="email" required autocomplete="username"></div>
      <div class="field"><label>\uBE44\uBC00\uBC88\uD638</label><input name="password" type="password" required autocomplete="current-password"></div>
      <p class="err" hidden></p>
      <button class="btn" type="submit">\uB85C\uADF8\uC778\uD558\uACE0 \uC785\uC7A5</button>
    </form>
    <p class="small">\uC544\uC9C1 \uD68C\uC6D0\uC774 \uC544\uB2C8\uBA74 <a href="#" id="su">tigc.co.kr \uD68C\uC6D0\uAC00\uC785</a> \uD6C4 \uAC19\uC740 \uC774\uBA54\uC77C\uB85C \uB85C\uADF8\uC778\uD558\uC138\uC694.</p>
    <button class="btn ghost back" type="button" id="lb">\u2190 \uC9C0\uAD6C\uBCF8\uC73C\uB85C</button>`;let n=fe("#lf"),s=fe(".err",n);t&&Ti(s,{message:t}),fe("#su").onclick=r=>{r.preventDefault(),Qb(jb)},fe("#lb").onclick=ml,n.onsubmit=async r=>{r.preventDefault();let o=fe("button[type=submit]",n);Xi(o,!0),Ti(s);try{let a=await En("/api/login",{email:n.email.value.trim(),password:n.password.value});le.token=a.token,As.set(Eo,a.token),await op(i)}catch(a){Ti(s,a.status===401?{message:"\uC774\uBA54\uC77C \uB610\uB294 \uBE44\uBC00\uBC88\uD638\uAC00 \uB9DE\uC9C0 \uC54A\uC544\uC694."}:a.message==="Failed to fetch"?{message:"\uB77C\uC6B4\uC9C0 \uC11C\uBC84\uC5D0 \uC5F0\uACB0\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694. \uC778\uD130\uB137 \uC5F0\uACB0\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694."}:a)}Xi(o,!1)}}async function op(i){let t=await En("/api/me");if(le.user=t.user,le.profile=t.profile,t.ban){let e=t.ban.until?new Date(t.ban.until).toLocaleString("ko-KR")+"\uAE4C\uC9C0":"";return le.token=null,As.set(Eo,null),fl(i,`\uB77C\uC6B4\uC9C0 \uC774\uC6A9\uC774 \uC81C\uD55C\uB41C \uACC4\uC815\uC774\uC5D0\uC694 ${e}. \uBB38\uC758\uB294 \uD0DC\uC77C\uACE8\uD504 \uCE74\uCE74\uC624\uD1A1 \uCC44\uB110\uB85C \uD574 \uC8FC\uC138\uC694.`)}if(!le.profile||!le.profile.nick||!le.profile.sgg)return ap(i,!0);i(le.profile)}function ap(i,t){let e=le.profile||{},n=`
    <h2>${t?"\uB77C\uC6B4\uC9C0\uC5D0\uC11C \uC4F8 \uC774\uB984\uACFC \uB3D9\uB124":"\uB0B4 \uC815\uBCF4"}</h2>
    <p class="small">\uB2E4\uB978 \uD68C\uC6D0\uC5D0\uAC8C\uB294 <b>\uB2C9\uB124\uC784\uACFC \uB3D9\uB124(\uC2DC\xB7\uAD70\xB7\uAD6C)</b>\uB9CC \uBCF4\uC5EC\uC694. \uC2E4\uBA85\xB7\uC5F0\uB77D\uCC98\uB294 \uBCF4\uC774\uC9C0 \uC54A\uC544\uC694. \uC704\uCE58(GPS)\uB294 \uC4F0\uC9C0 \uC54A\uC544\uC694.</p>
    <form id="pf">
      <div class="field"><label>\uB2C9\uB124\uC784 (2~12\uC790)</label><input name="nick" maxlength="12" required value="${Ft(e.nick||"")}"></div>
      <div class="field"><label>\uC6B0\uB9AC \uB3D9\uB124</label><div class="two"><select name="sido" required></select><select name="sgg" required></select></div></div>
      <div class="field"><label>\uCE90\uB9AD\uD130 \uC0C9\uC0C1</label><div class="swatches">${fu.map(l=>`<button type="button" data-c="${l}" style="background:${l}" class="${l===(e.color||fu[0])?"on":""}"></button>`).join("")}</div></div>
      <p class="err" hidden></p>
      <button class="btn" type="submit">${t?"\uC800\uC7A5\uD558\uACE0 \uC785\uC7A5":"\uC800\uC7A5"}</button>
      ${t?"":'<button class="btn ghost" type="button" id="lo">\uB85C\uADF8\uC544\uC6C3</button>'}
    </form>`,s=t?fe("#login .card"):Yi(n);t&&(s.innerHTML=n);let r=fe("#pf",s),o=fe(".err",r);rp(r,e.sido,e.sgg);let a=e.color||fu[0];r.querySelectorAll("[data-c]").forEach(l=>l.onclick=()=>{a=l.dataset.c,r.querySelectorAll("[data-c]").forEach(c=>c.classList.toggle("on",c===l))}),t||(fe("#lo",r).onclick=()=>{As.set(Eo,null),le.token=null,location.reload()}),r.onsubmit=async l=>{l.preventDefault();let c=fe("button[type=submit]",r);Xi(c,!0),Ti(o);try{let h=await En("/api/profile",{nick:r.nick.value.trim(),sido:r.sido.value,sgg:r.sgg.value,color:a}),u=le.profile&&(le.profile.sgg!==h.profile.sgg||le.profile.nick!==h.profile.nick||le.profile.color!==h.profile.color);le.profile=h.profile,t?i(le.profile):(Ai(),u&&location.reload())}catch(h){Ti(o,h)}Xi(c,!1)}}var lp=()=>ap(null,!1);async function cp(i){if(!le.token)return fl(i);try{await op(i)}catch(t){if(t.status===401)return le.token=null,As.set(Eo,null),fl(i,"\uB85C\uADF8\uC778\uC774 \uB05D\uB0AC\uC5B4\uC694. \uB2E4\uC2DC \uB85C\uADF8\uC778\uD574 \uC8FC\uC138\uC694.");fl(i,t.message==="Failed to fetch"?"\uB77C\uC6B4\uC9C0 \uC11C\uBC84\uC5D0 \uC5F0\uACB0\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694. \uC778\uD130\uB137 \uC5F0\uACB0\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694.":t.message)}}function gu(i){if(i.startsWith("dong-")){let[,t,...e]=i.split("-");return{id:i,kind:"dong",name:`\u{1F3D8} ${t} ${e.join("-")} \uB3D9\uB124\uBC29`}}return i.startsWith("meet-")?{id:i,kind:"meet",name:"\u{1F4C5} \uBAA8\uC784 \uB300\uD654\uBC29"}:{id:"hub",kind:"hub",name:"\u26F3 \uD0DC\uC77C\uACE8\uD504 \uB77C\uC6B4\uC9C0 \uAD11\uC7A5"}}function pu(i){let t=new URLSearchParams(location.search);t.set("room",i),location.search=t.toString()}var e_=()=>le.profile&&le.profile.sgg?ip(le.profile.sido,le.profile.sgg):null,n_=["\uACE8\uD504","\uC2A4\uD06C\uB9B0\uACE8\uD504","\uC5F0\uC2B5\uC7A5","\uACE8\uD504\uC5EC\uD589","\uB09A\uC2DC","\uB2F9\uAD6C","\uC6B4\uB3D9\xB7\uC0B0\uCC45","\uAE30\uD0C0"],xu='<div class="safety">\u{1F6E1} <b>\uC548\uC804\uD558\uAC8C \uB9CC\uB098\uC694</b> \xB7 \uCC98\uC74C \uB9CC\uB098\uB294 \uBD84\uACFC\uB294 \uC0AC\uB78C\uC774 \uB9CE\uC740 \uACF5\uAC1C\uB41C \uC7A5\uC18C\uC5D0\uC11C \uB9CC\uB098\uC138\uC694. \uB3C8\uC744 \uBE4C\uB824 \uB2EC\uB77C\uAC70\uB098 \uAC1C\uC778 \uACC4\uC88C\uB85C \uC785\uAE08\uC744 \uC694\uAD6C\uD558\uBA74 \uBC14\uB85C \uC2E0\uACE0\uD574 \uC8FC\uC138\uC694. \uD68C\uC6D0\uB07C\uB9AC\uC758 \uBAA8\uC784\uC740 \uCC38\uAC00\uC790 \uC2A4\uC2A4\uB85C \uCC45\uC784\uC9C0\uACE0 \uC9C4\uD589\uD574\uC694.</div>',dl="dong";async function Er(){let i=le.profile||{},t=Yi(`
    <h2>\u{1F4C5} \uB3D9\uB124 \uC18C\uBAA8\uC784</h2>
    <div class="tabs"><button data-s="dong">\uC6B0\uB9AC \uB3D9\uB124 (${Ft(i.sgg||"-")})</button><button data-s="sido">${Ft(i.sido||"\uC2DC\xB7\uB3C4")} \uC804\uCCB4</button><button data-s="all">\uC804\uAD6D</button></div>
    <div class="mt-list"><p class="small">\uBD88\uB7EC\uC624\uB294 \uC911\u2026</p></div>
    <div class="row-end"><button class="btn" id="mtNew">\uFF0B \uBAA8\uC784 \uB9CC\uB4E4\uAE30</button></div>
    ${xu}`,"wide");t.querySelectorAll("[data-s]").forEach(n=>{n.classList.toggle("on",n.dataset.s===dl),n.onclick=()=>{dl=n.dataset.s,Er()}}),fe("#mtNew",t).onclick=()=>i_();let e=fe(".mt-list",t);try{let n=dl==="all"?"":dl==="sido"?`?sido=${encodeURIComponent(i.sido)}`:`?sido=${encodeURIComponent(i.sido)}&sgg=${encodeURIComponent(i.sgg)}`,{meetups:s}=await En("/api/meetups"+n);if(!s.length){e.innerHTML='<p class="empty">\uC544\uC9C1 \uBAA8\uC784\uC774 \uC5C6\uC5B4\uC694.<br>\uCCAB \uBAA8\uC784\uC744 \uB9CC\uB4E4\uC5B4 \uBCF4\uC138\uC694!</p>';return}e.innerHTML=s.map(r=>`
      <button class="mt" data-id="${r.id}">
        <span class="mt-k">${Ft(r.kind)}</span>
        <b>${Ft(r.title)}</b>
        <span class="mt-d">${Ft(r.date.slice(5).replace("-","/"))} ${Ft(r.time||"")} \xB7 ${Ft(r.sgg)} \xB7 ${Ft(r.place)}</span>
        <span class="mt-n ${r.count>=r.max?"full":""}">${r.status!=="open"?"\uB9C8\uAC10":`${r.count}/${r.max}\uBA85`}${r.joined?" \xB7 \uCC38\uAC00 \uC911":""}</span>
      </button>`).join(""),e.querySelectorAll("[data-id]").forEach(r=>r.onclick=()=>yu(+r.dataset.id))}catch(n){e.innerHTML=`<p class="err">${Ft(n.message)}</p>`}}function i_(){let i=le.profile||{},t=new Date(Date.now()+9*36e5).toISOString().slice(0,10),e=Yi(`
    <h2>\uBAA8\uC784 \uB9CC\uB4E4\uAE30</h2>
    <form id="mf">
      <div class="field"><label>\uBAA8\uC784 \uC774\uB984</label><input name="title" maxlength="40" required placeholder="\uC608: \uD1A0\uC694\uC77C \uC544\uCE68 \uC2A4\uD06C\uB9B0 \uD55C\uD310"></div>
      <div class="field"><label>\uC885\uB958</label><select name="kind">${n_.map(r=>`<option>${r}</option>`).join("")}</select></div>
      <div class="field"><label>\uB3D9\uB124</label><div class="two"><select name="sido" required></select><select name="sgg" required></select></div></div>
      <div class="two"><div class="field"><label>\uB0A0\uC9DC</label><input name="date" type="date" min="${t}" required></div><div class="field"><label>\uC2DC\uAC04</label><input name="time" type="time"></div></div>
      <div class="two"><div class="field"><label>\uB9CC\uB0A0 \uACF3 (\uACF5\uAC1C \uC7A5\uC18C)</label><input name="place" maxlength="60" required placeholder="\uC608: \u25CB\u25CB\uC5ED \uC55E \uC2A4\uD06C\uB9B0\uACE8\uD504"></div><div class="field"><label>\uC778\uC6D0 (\uB098 \uD3EC\uD568)</label><input name="max" type="number" min="2" max="50" value="4"></div></div>
      <div class="field"><label>\uC18C\uAC1C (\uC120\uD0DD)</label><textarea name="body" maxlength="500" rows="3" placeholder="\uC2E4\uB825, \uC900\uBE44\uBB3C, \uBE44\uC6A9 \uB098\uB204\uB294 \uBC29\uBC95 \uB4F1. \uC804\uD654\uBC88\uD638\xB7\uACC4\uC88C\uB294 \uC801\uC9C0 \uB9C8\uC138\uC694."></textarea></div>
      <p class="err" hidden></p>
      <button class="btn" type="submit">\uBAA8\uC784 \uC62C\uB9AC\uAE30</button>
      <button class="btn ghost" type="button" id="mb">\u2190 \uBAA9\uB85D</button>
    </form>${xu}`,"wide"),n=fe("#mf",e),s=fe(".err",n);rp(n,i.sido,i.sgg),fe("#mb",n).onclick=Er,n.onsubmit=async r=>{r.preventDefault();let o=fe("button[type=submit]",n);Xi(o,!0),Ti(s);try{let a=Object.fromEntries(new FormData(n)),l=await En("/api/meetups",a);yu(l.meetup.id)}catch(a){Ti(s,a),Xi(o,!1)}}}async function yu(i){let t=Yi('<p class="small">\uBD88\uB7EC\uC624\uB294 \uC911\u2026</p>',"wide"),e;try{e=(await En("/api/meetups/"+i)).meetup}catch(r){t.innerHTML+=`<p class="err">${Ft(r.message)}</p>`;return}if(!e){t.innerHTML+='<p class="err">\uC9C0\uC6CC\uC9C4 \uBAA8\uC784\uC774\uC5D0\uC694.</p>';return}let n=le.user&&/admin|staff/.test(le.user.role);t.innerHTML=`<button class="x" aria-label="\uB2EB\uAE30">\u2715</button>
    <span class="mt-k">${Ft(e.kind)}</span>${e.status!=="open"?' <span class="mt-k gray">\uB9C8\uAC10</span>':""}
    <h2>${Ft(e.title)}</h2>
    <dl class="mt-info">
      <dt>\uC5B8\uC81C</dt><dd>${Ft(e.date)} ${Ft(e.time||"")}</dd>
      <dt>\uC5B4\uB514\uC11C</dt><dd>${Ft(e.sido)} ${Ft(e.sgg)} \xB7 ${Ft(e.place)}</dd>
      <dt>\uBAA8\uC784\uC7A5</dt><dd>${Ft(e.hostNick)}</dd>
      <dt>\uC778\uC6D0</dt><dd>${e.count}/${e.max}\uBA85 \xB7 ${(e.members||[]).map(Ft).join(", ")}</dd>
    </dl>
    ${e.body?`<p class="mt-body">${Ft(e.body)}</p>`:""}
    <p class="err" hidden></p>
    <div class="row-end">
      ${e.joined?'<button class="btn green" data-a="room">\u{1F4AC} \uBAA8\uC784 \uB300\uD654\uBC29 \uC785\uC7A5</button>':""}
      ${!e.joined&&e.status==="open"&&e.count<e.max?'<button class="btn" data-a="join">\uCC38\uAC00\uD558\uAE30</button>':""}
      ${e.joined&&!e.mine?'<button class="btn ghost" data-a="leave">\uCC38\uAC00 \uCDE8\uC18C</button>':""}
      ${e.mine||n?`<button class="btn ghost" data-a="close">${e.status==="open"?"\uBAA8\uC9D1 \uB9C8\uAC10":"\uB2E4\uC2DC \uBAA8\uC9D1"}</button><button class="btn ghost" data-a="delete">\uBAA8\uC784 \uC9C0\uC6B0\uAE30</button>`:""}
      ${e.mine?"":'<button class="btn ghost" data-a="report">\u{1F6A8} \uC2E0\uACE0</button>'}
      <button class="btn ghost" data-a="back">\u2190 \uBAA9\uB85D</button>
    </div>${xu}`,fe(".x",t).onclick=Ai;let s=fe(".err",t);t.querySelectorAll("[data-a]").forEach(r=>r.onclick=async()=>{let o=r.dataset.a;if(o==="back")return Er();if(o==="room")return pu("meet-"+e.id);if(o==="report")return up({meetup:e.id,nick:e.hostNick});if(!(o==="delete"&&!confirm("\uC774 \uBAA8\uC784\uC744 \uC9C0\uC6B8\uAE4C\uC694?"))){Xi(r,!0);try{await En(`/api/meetups/${e.id}/${o}`,{}),o==="delete"?Er():yu(e.id)}catch(a){Ti(s,a),Xi(r,!1)}}})}function hp(i,t,e){Yi(`
    <h2>${Ft(i.name)}</h2>
    <p class="small">${Ft(i.dong||"")}${i.staff?" \xB7 \uD0DC\uC77C\uACE8\uD504 \uC9C1\uC6D0":""}</p>
    <div class="col">
      <button class="btn ghost" data-a="block">${Sr(i.uid)?"\uCC28\uB2E8 \uD480\uAE30":"\u{1F648} \uCC28\uB2E8 (\uB0B4 \uD654\uBA74\uC5D0\uC11C \uC228\uAE30\uAE30)"}</button>
      <button class="btn ghost" data-a="report">\u{1F6A8} \uC2E0\uACE0\uD558\uAE30</button>
      ${e?'<hr><b>\uC9C1\uC6D0 \uBA54\uB274</b><button class="btn ghost" data-a="kick">\uB0B4\uBCF4\uB0B4\uAE30</button><button class="btn ghost" data-a="ban1">\uB0B4\uBCF4\uB0B4\uACE0 \uD558\uB8E8 \uC81C\uD55C</button><button class="btn ghost" data-a="ban0">\uB0B4\uBCF4\uB0B4\uACE0 \uC601\uAD6C \uC81C\uD55C</button>':""}
    </div>`).querySelectorAll("[data-a]").forEach(s=>s.onclick=()=>{let r=s.dataset.a;if(r==="block"){t_(i.uid,!Sr(i.uid)),Ai(),window.dispatchEvent(new Event("lounge-block"));return}if(r==="report")return up({id:i.id,uid:i.uid,nick:i.name},t);r==="kick"&&t.send({t:"kick",id:i.id}),r==="ban1"&&t.send({t:"kick",id:i.id,ban:!0,hours:24}),r==="ban0"&&confirm("\uC601\uAD6C \uC81C\uD55C\uD560\uAE4C\uC694?")&&t.send({t:"kick",id:i.id,ban:!0,hours:0}),Ai()})}function up(i,t){let e=Yi(`
    <h2>\u{1F6A8} ${Ft(i.nick||"")} \uC2E0\uACE0</h2>
    <p class="small">\uD0DC\uC77C\uACE8\uD504 \uC9C1\uC6D0\uC774 \uD655\uC778\uD558\uACE0 \uC870\uCE58\uD574\uC694. \uBC29 \uC548\uC758 \uC2E0\uACE0\uB294 \uCD5C\uADFC \uB300\uD654\uAC00 \uD568\uAED8 \uC804\uB2EC\uB3FC\uC694.</p>
    <form id="rf">
      <div class="col">${["\uC695\uC124\xB7\uBE44\uD558","\uC131\uD76C\uB871\xB7\uBD88\uCF8C\uD55C \uB9D0","\uAD11\uACE0\xB7\uB3C4\uBC30","\uB3C8\xB7\uACC4\uC88C \uC694\uAD6C (\uC0AC\uAE30 \uC758\uC2EC)","\uBAA8\uC784\uC5D0\uC11C \uBB38\uC81C \uD589\uB3D9","\uAE30\uD0C0"].map((r,o)=>`<label class="rd"><input type="radio" name="r" value="${r}" ${o?"":"checked"}> ${r}</label>`).join("")}</div>
      <div class="field"><label>\uC790\uC138\uD788 (\uC120\uD0DD)</label><textarea name="d" maxlength="250" rows="2"></textarea></div>
      <p class="err" hidden></p>
      <button class="btn" type="submit">\uC2E0\uACE0\uD558\uAE30</button>
    </form>`),n=fe("#rf",e),s=fe(".err",n);n.onsubmit=async r=>{r.preventDefault();let o=n.r.value+(n.d.value.trim()?" \u2014 "+n.d.value.trim():"");if(t&&i.id){t.send({t:"report",id:i.id,uid:i.uid,nick:i.nick,reason:o}),Ai();return}try{await En("/api/report",{meetup:i.meetup,target:i.uid,targetNick:i.nick,reason:o}),Ai(),pl==null||pl("\uC2E0\uACE0\uD588\uC5B4\uC694. \uD655\uC778 \uD6C4 \uC870\uCE58\uD560\uAC8C\uC694.")}catch(a){Ti(s,a)}}}var pl=null,dp=i=>{pl=i};async function So(){let i=Yi('<h2>\u{1F6E1} \uB77C\uC6B4\uC9C0 \uAD00\uB9AC</h2><p class="small">\uBD88\uB7EC\uC624\uB294 \uC911\u2026</p>',"wide"),t;try{t=await En("/api/admin/reports")}catch(n){i.innerHTML+=`<p class="err">${Ft(n.message)}</p>`;return}let e=n=>new Date(n).toLocaleString("ko-KR",{month:"numeric",day:"numeric",hour:"2-digit",minute:"2-digit"});i.innerHTML=`<button class="x" aria-label="\uB2EB\uAE30">\u2715</button><h2>\u{1F6E1} \uB77C\uC6B4\uC9C0 \uAD00\uB9AC</h2>
    <h3>\uC2E0\uACE0 (${t.reports.filter(n=>n.status==="new").length}\uAC74 \uC0C8\uB85C)</h3>
    <div class="adm">${t.reports.map(n=>`<div class="ar ${n.status}">
      <div><b>${Ft(n.target_nick||"(\uBAA8\uC784)")}</b> \u2190 ${Ft(n.reporter_nick)} \xB7 ${e(n.at)} \xB7 ${Ft(n.room)}</div>
      <div>${Ft(n.reason)}</div>${n.log?`<pre>${Ft(n.log)}</pre>`:""}
      <div class="row-end">${n.target?`<button class="btn ghost" data-ban="${Ft(n.target)}" data-h="24">\uD558\uB8E8 \uC81C\uD55C</button><button class="btn ghost" data-ban="${Ft(n.target)}" data-h="168">7\uC77C \uC81C\uD55C</button><button class="btn ghost" data-ban="${Ft(n.target)}" data-h="0">\uC601\uAD6C \uC81C\uD55C</button>`:""}${n.status==="new"?`<button class="btn ghost" data-done="${n.id}">\uCC98\uB9AC \uC644\uB8CC</button>`:""}</div>
    </div>`).join("")||'<p class="empty">\uC2E0\uACE0\uAC00 \uC5C6\uC5B4\uC694.</p>'}</div>
    <h3>\uC774\uC6A9 \uC81C\uD55C</h3>
    <div class="adm">${t.bans.map(n=>`<div class="ar"><b>${Ft(n.nick||n.uid)}</b> \xB7 ${n.until?e(n.until)+"\uAE4C\uC9C0":"\uC601\uAD6C"} \xB7 ${Ft(n.reason)} <button class="btn ghost" data-unban="${Ft(n.uid)}">\uD480\uAE30</button></div>`).join("")||'<p class="empty">\uC5C6\uC5B4\uC694.</p>'}</div>`,fe(".x",i).onclick=Ai,i.querySelectorAll("[data-ban]").forEach(n=>n.onclick=async()=>{await En("/api/admin/ban",{uid:n.dataset.ban,hours:+n.dataset.h,reason:"\uC2E0\uACE0 \uD655\uC778"}).catch(s=>alert(s.message)),So()}),i.querySelectorAll("[data-unban]").forEach(n=>n.onclick=async()=>{await En("/api/admin/unban",{uid:n.dataset.unban}).catch(s=>alert(s.message)),So()}),i.querySelectorAll("[data-done]").forEach(n=>n.onclick=async()=>{await En("/api/admin/report-done",{id:+n.dataset.done}).catch(s=>alert(s.message)),So()})}async function fp(i){let t=e_(),e=Yi(`<h2>\u{1F6AA} \uBC29 \uBC14\uAFB8\uAE30</h2><div class="col">
    <button class="btn ${i==="hub"?"green":"ghost"}" data-r="hub">\u26F3 \uB77C\uC6B4\uC9C0 \uAD11\uC7A5 (\uC804\uAD6D \uD68C\uC6D0) <span class="n" data-n="hub"></span></button>
    ${t?`<button class="btn ${i===t?"green":"ghost"}" data-r="${Ft(t)}">\u{1F3D8} \uC6B0\uB9AC \uB3D9\uB124\uBC29 \xB7 ${Ft(le.profile.sido)} ${Ft(le.profile.sgg)} <span class="n" data-n="${Ft(t)}"></span></button>`:""}
    </div><h3>\uC9C0\uAE08 \uC0AC\uB78C\uC774 \uC788\uB294 \uB3D9\uB124\uBC29</h3><div class="col" id="busy"><p class="small">\uBD88\uB7EC\uC624\uB294 \uC911\u2026</p></div>`);e.querySelectorAll("[data-r]").forEach(n=>n.onclick=()=>pu(n.dataset.r));try{let{rooms:n}=await En("/api/rooms");for(let r of n){let o=e.querySelector(`[data-n="${CSS.escape(r.room)}"]`);o&&(o.textContent=`${r.n}\uBA85`)}let s=n.filter(r=>r.room.startsWith("dong-")&&r.room!==t);fe("#busy",e).innerHTML=s.map(r=>`<button class="btn ghost" data-r="${Ft(r.room)}">${Ft(gu(r.room).name)} \xB7 ${r.n}\uBA85</button>`).join("")||'<p class="empty">\uB2E4\uB978 \uB3D9\uB124\uBC29\uC5D4 \uC544\uC9C1 \uC544\uBB34\uB3C4 \uC5C6\uC5B4\uC694.</p>',e.querySelectorAll("#busy [data-r]").forEach(r=>r.onclick=()=>pu(r.dataset.r))}catch(n){fe("#busy",e).innerHTML=`<p class="err">${Ft(n.message)}</p>`}}var To=null;function vu(){if(!To)try{To=new(window.AudioContext||window.webkitAudioContext)}catch{return null}return To.state==="suspended"&&To.resume(),To}function qe(i,t,e="sine",n=.2,s=0){let r=vu();if(!r)return;let o=r.createOscillator(),a=r.createGain();o.type=e,o.frequency.setValueAtTime(i,r.currentTime),s&&o.frequency.exponentialRampToValueAtTime(Math.max(30,i+s),r.currentTime+t),a.gain.setValueAtTime(n,r.currentTime),a.gain.exponentialRampToValueAtTime(1e-4,r.currentTime+t),o.connect(a).connect(r.destination),o.start(),o.stop(r.currentTime+t)}var gl=null;function si(i,{type:t="bandpass",freq:e=2e3,q:n=1,vol:s=.3,attack:r=.002,at:o=0}={}){let a=vu();if(!a)return;if(!gl){gl=a.createBuffer(1,a.sampleRate,a.sampleRate);let d=gl.getChannelData(0);for(let f=0;f<d.length;f++)d[f]=Math.random()*2-1}let l=a.currentTime+o,c=a.createBufferSource();c.buffer=gl;let h=a.createBiquadFilter();h.type=t,h.frequency.value=e,h.Q.value=n;let u=a.createGain();u.gain.setValueAtTime(1e-4,l),u.gain.exponentialRampToValueAtTime(s,l+r),u.gain.exponentialRampToValueAtTime(1e-4,l+i),c.connect(h).connect(u).connect(a.destination),c.start(l,Math.random()*.5),c.stop(l+i+.02)}var pp=0,Tr={clack:(i=1)=>{let t=performance.now();t-pp<25||(pp=t,i=Math.min(1,Math.max(.08,i)),si(.05,{freq:3800,q:2.5,vol:.9*i}),qe(2350+Math.random()*300,.06,"sine",.35*i),qe(4200,.03,"triangle",.12*i))},cue:(i=1)=>{i=Math.min(1,Math.max(.15,i)),si(.04,{freq:1600,q:1.4,vol:.7*i}),qe(780,.07,"triangle",.3*i,-200)},cushion:(i=1)=>{i=Math.min(1,Math.max(.05,i)),qe(150,.12,"sine",.4*i,-60),si(.06,{type:"lowpass",freq:600,vol:.35*i})},pocket:()=>{qe(110,.25,"sine",.35,-40),si(.18,{type:"lowpass",freq:400,vol:.3,at:.03}),si(.05,{freq:2500,vol:.15,at:.12})},chalk:()=>si(.18,{type:"highpass",freq:3e3,vol:.12,attack:.02}),splash:(i=1)=>{si(.35*i+.1,{type:"lowpass",freq:1200,vol:.35*i}),si(.15,{freq:3e3,q:.7,vol:.12*i,at:.02})},reel:()=>{for(let i=0;i<3;i++)si(.012,{freq:4500,q:4,vol:.12,at:i*.03})},bell:()=>{qe(2637,.4,"sine",.15),setTimeout(()=>qe(2637,.4,"sine",.12),140)},snap:()=>{si(.08,{type:"highpass",freq:2500,vol:.5}),qe(1200,.15,"square",.08,-900)},coin:()=>{qe(1568,.08,"square",.06),setTimeout(()=>qe(2093,.2,"square",.06),70)},unlock:vu,click:(i=.5)=>qe(900,.06,"triangle",.25*i),plop:()=>qe(500,.18,"sine",.25,-350),whoosh:()=>qe(300,.35,"sawtooth",.04,500),chime:()=>{qe(784,.25,"triangle",.18),setTimeout(()=>qe(1047,.35,"triangle",.18),120),setTimeout(()=>qe(1319,.5,"triangle",.15),240)},pop:()=>qe(660,.08,"sine",.12,200)};var At=i=>document.querySelector(i),Qi=new URLSearchParams(location.search);function r_(){let i=Qi.get("room")||"hub",t=gu(/^(hub|dong-[0-9A-Za-z가-힣_-]{1,40}|meet-\d{1,9})$/.test(i)?i:"hub");return{...Pf,id:t.id,kind:t.kind,name:t.name,country:"KR"}}var ts=r_(),o_=ft.touch||/Android|iPhone|iPad/i.test(navigator.userAgent),mp={low:{shadows:!1,shadowMap:512,trees:90,flowers:200,maxDpr:1,reflect:!1,grass:0,grassR:0},mid:{shadows:!0,shadowMap:1024,trees:160,flowers:400,maxDpr:1.5,reflect:!1,grass:18e3,grassR:11},high:{shadows:!0,shadowMap:2048,trees:240,flowers:700,maxDpr:2,reflect:!0,grass:4e4,grassR:16}},a_=Qi.get("q")||location.hash.slice(1)||"mid",Ps={...mp[a_]||mp.mid};for(let i of["grass","shadows","reflect","trees"])Qi.has(i)&&(Ps[i]=i==="shadows"||i==="reflect"?Qi.get(i)!=="0":+Qi.get(i));var Mp=At("#game"),Se=new Ea({canvas:Mp,antialias:!o_,powerPreference:"high-performance"});Se.outputColorSpace=me;Se.toneMapping=Ih;Se.toneMappingExposure=.62;Se.shadowMap.enabled=Ps.shadows;Se.shadowMap.type=Ph;var Ki=1;function bl(){Se.setPixelRatio(Math.min(devicePixelRatio,Ps.maxDpr)*Ki),Se.setSize(innerWidth,innerHeight,!1),Qe.aspect=innerWidth/innerHeight,Qe.updateProjectionMatrix()}var ri=new hr,Qe=new Be(55,innerWidth/innerHeight,.05,1200);addEventListener("resize",bl);bl();var Xn=new Ja(ri,ts,Ps,Se),Ro=Ps.grass?new ul(ri,Xn,{count:Ps.grass,radius:Ps.grassR,tint:Xn.biome.tint}):null;Ro&&Xn.noReflect&&Xn.noReflect.push(Ro.mesh);var Ji=m_(),re={pos:new C,yaw:0,speed:0},ln=null,gp={hub:[0,0,13],golf:[44,0,3],fishing:[-35,0,2.5]}[ts.type]||[0,0,6];re.pos.set(gp[0]+(Math.random()-.5)*3,0,gp[2]+(Math.random()-.5)*3);var Tn={yaw:Math.PI,pitch:.38,dist:7.5},tn={pos:new C,look:new C,up:new C(0,1,0)},_l=new C,wp={show({title:i,help:t,power:e,powerLabel:n,tension:s,extra:r=[]}){At("#hud").hidden=!1,At("#hudTitle").textContent=i,At("#hudHelp").textContent=t,At("#hudInfo").textContent="",At("#powerBar").hidden=!e,At("#tensionBar").hidden=!0,At("#btnPower").hidden=!e,At("#btnPower").textContent=n||U("power");let o=At("#hudRow");o.innerHTML="";for(let[l,c]of r){let h=document.createElement("button");h.className="btn ghost",h.textContent=l,h.onclick=c,o.append(h)}let a=document.createElement("button");a.className="btn",a.textContent=U("exit"),a.onclick=()=>Ar("hub"),o.append(a),this.tensionOn=s},hide(){At("#hud").hidden=!0,At("#btnPower").hidden=!0},info(i){At("#hudInfo").textContent=i},power(i,t){At("#powerBar i").style.width=`${Math.round(i*100)}%`,t&&(At("#btnPower").textContent=t)},tension(i,t){let e=At("#tensionBar");if(i===null){e.hidden=!0,At("#powerBar").hidden=!1;return}e.hidden=!1,At("#powerBar").hidden=!0,e.querySelector("i").style.width=`${Math.min(100,i*100)}%`,e.classList.toggle("hot",i>.7),this.info(`${U("tension")} ${Math.round(i*100)}% \xB7 ${U("distance")} ${t.toFixed(1)}m`)}},xp=0;function Sp(i){let t=At("#toast");t.textContent=i,t.classList.add("on"),clearTimeout(xp),xp=setTimeout(()=>t.classList.remove("on"),2400)}var kn=new Map,Ao=new Map,An;function yp(i){var s;if(i.id===An.id||kn.has(i.id))return;let t=new mo({name:i.name,color:i.color,flag:""});ri.add(t.root),t.root.userData.hiddenByBlock=Sr(i.uid);let e=new nt(new Ce(.06,10,8),new ye({color:16777215,roughness:.35,emissive:i.color,emissiveIntensity:.15}));e.visible=!1,ri.add(e);let n={info:i,avatar:t,target:new C,yaw:0,ball:e,speed:0};(s=i.s)!=null&&s.p&&(n.target.fromArray(i.s.p),t.root.position.copy(n.target)),kn.set(i.id,n)}function l_(i){let t=kn.get(i);t&&(ri.remove(t.avatar.root,t.ball),t.avatar.dispose(),kn.delete(i))}function Ep(i){var t;return i===An.id?Ji.name:(t=kn.get(i))==null?void 0:t.info.name}function vl(){At("#statusText").textContent=An.offline?U("offline"):`${kn.size+1} ${U("players")}`,At("#status").classList.toggle("off",An.offline)}var Su={scene:ri,world:Xn,venue:ts,player:re,camTarget:tn,hud:wp,toast:Sp,audio:Tr,input:ft,get avatar(){return ln},get net(){return An},remoteName:Ep,camera:Qe,exit:()=>Ar("hub"),snap:()=>{wl=!0},resetView:()=>Ml()};function c_(i){var t,e,n,s,r,o,a;switch(i.t){case"welcome":for(let l of i.players)yp(l);for(let l of i.parties||[])(e=(t=gn[l.game])==null?void 0:t.party)==null||e.onInfo(l);vl(),i.offline?ji("\u{1F310} \uB77C\uC6B4\uC9C0 \uC11C\uBC84\uC5D0 \uC5F0\uACB0\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694 \xB7 \uD63C\uC790 \uC5F0\uC2B5 \uBAA8\uB4DC (\uAC8C\uC2A4\uD2B8\uC640 \uAC19\uC774 \uD558\uAE30\uB294 \uB3FC\uC694)"):(wu=!!((n=i.me)!=null&&n.staff),At("#btnAdmin").hidden=!wu,ji(`${ts.name}\uC5D0 \uB4E4\uC5B4\uC654\uC5B4\uC694. \uC774\uB984\uC744 \uB204\uB974\uBA74 \uCC28\uB2E8\xB7\uC2E0\uACE0\uD560 \uC218 \uC788\uC5B4\uC694.`));break;case"join":yp(i.p),vl(),ji(U("joined",{name:i.p.name}));break;case"leave":{let l=Ep(i.id);l_(i.id),vl(),l&&ji(U("left",{name:l}));break}case"plang":{let l=kn.get(i.id);l&&(l.info.lang=i.lang);break}case"states":for(let[l,c]of i.s){let h=kn.get(l);!h||!c||(h.target.fromArray(c.p),h.yaw=c.r,h.activity=c.a,c.b?(h.ball.visible=!0,h.ball.position.set(c.b[0],Kt.green.y+.06,c.b[1])):h.ball.visible=!1)}break;case"chat":h_(i);break;case"chat_tr":{let l=Ao.get(i.id);l&&(l.tr=i.tr,Eu(l));break}case"event":u_(i);break;case"sys":ji(i.text||(i.key==="reported"?"\uC2E0\uACE0\uD588\uC5B4\uC694. \uC9C1\uC6D0\uC774 \uD655\uC778 \uD6C4 \uC870\uCE58\uD560\uAC8C\uC694.":U(i.key)));break;case"kicked":alert("\uC6B4\uC601 \uC815\uCC45 \uC704\uBC18\uC73C\uB85C \uB77C\uC6B4\uC9C0\uC5D0\uC11C \uB098\uAC00\uAC8C \uB418\uC5C8\uC5B4\uC694. \uBB38\uC758\uB294 \uD0DC\uC77C\uACE8\uD504 \uCE74\uCE74\uC624\uD1A1 \uCC44\uB110\uB85C \uD574 \uC8FC\uC138\uC694."),ml();break;case"party":(r=(s=gn[i.game])==null?void 0:s.party)==null||r.onInfo(i);break;case"party_msg":(a=(o=gn[i.game])==null?void 0:o.party)==null||a.onMsg(i);break}}var Zi=At("#log");function Tp(i){let t=Zi.scrollTop+Zi.clientHeight>=Zi.scrollHeight-30;for(Zi.append(i);Zi.children.length>80;)Zi.firstChild.remove();t&&(Zi.scrollTop=Zi.scrollHeight)}function ji(i){let t=document.createElement("div");t.className="msg sys",t.textContent=i,Tp(t)}function h_(i){var n;if(i.from!==An.id&&Sr((n=kn.get(i.from))==null?void 0:n.info.uid))return;let t=document.createElement("div");t.className="msg";let e={m:i,el:t,tr:null,showOrig:!1};Ao.set(i.id,e),Ao.size>120&&Ao.delete(Ao.keys().next().value),Eu(e),Tp(t)}function Eu(i){var h;let{m:t}=i,e=t.from===An.id,n=!e&&t.lang!==rn(),s=n?(h=i.tr)==null?void 0:h[rn()]:null,r=s&&!i.showOrig?s:t.text,o=kn.get(t.from),a=o!=null&&o.info.staff?"\u{1F3F7}":"";i.el.innerHTML="";let l=document.createElement("b");if(l.textContent=`${a} ${t.name}: `,l.style.color=e?Ji.color:(o==null?void 0:o.info.color)||"#555",l.style.filter="brightness(0.75)",!e&&o&&(l.className="who",l.title="\uCC28\uB2E8\xB7\uC2E0\uACE0",l.onclick=()=>hp({...o.info,id:t.from},An,wu)),i.el.append(l,document.createTextNode(r)),n){let u=document.createElement("span");u.className="tag",u.textContent=s?i.showOrig?U("translated"):`${t.lang.toUpperCase()} \u2192 ${U("showOrig")}`:"\u2026",u.onclick=()=>{i.showOrig=!i.showOrig,Eu(i)},i.el.append(u)}let c=e?ln:o==null?void 0:o.avatar;e||Tr.pop(),c&&(s||!n||!i.bubbled)&&(c.say(r,performance.now()),i.bubbled=!0)}function u_(i){let t=i.e||{},e="";t.type==="catch"?e=`\u{1F41F} ${U("evCatch",{name:i.name,fish:wi(t.fish),kg:t.kg})}`:t.type==="sink"?e=`\u26F3 ${U("evSink",{name:i.name,hole:t.hole,n:t.n})}`:t.type==="pot"&&(e=`\u{1F3B1} ${U("evPot",{name:i.name,n:t.n})}`),e&&ji(e)}At("#chatForm").addEventListener("submit",i=>{i.preventDefault();let t=At("#chatIn").value.trim();t&&(An.chat(t),At("#chatIn").value="",ft.touch&&At("#chatIn").blur())});At("#chatToggle").onclick=()=>{At("#chat").classList.toggle("collapsed"),At("#chat").classList.toggle("open")};addEventListener("keydown",i=>{i.key==="Enter"&&document.activeElement!==At("#chatIn")&&!At("#top").hidden&&(i.preventDefault(),At("#chatIn").focus()),i.key==="Escape"&&(document.activeElement===At("#chatIn")?At("#chatIn").blur():ze!=="hub"&&Ar("hub"))});var Tu=new il(Su),Ap=new cl(Su),Co=new hl(Su),gn={golf:Tu,fishing:Ap,billiards:Co},ze="hub",an={yaw:0,pitch:0,zoom:1},Ri={x:0,y:0,z:0};function Ml(){an.yaw=an.pitch=0,an.zoom=1}(function(){let t=document.createElement("div");t.id="viewPad",t.hidden=!0,t.innerHTML=`<button data-v="zi" title="zoom in (O)">\uFF0B</button><button data-v="u" title="up (I)">\u25B2</button><button data-v="zo" title="zoom out (U)">\uFF0D</button>
    <button data-v="l" title="left (J)">\u25C0</button><button data-v="reset" title="reset (H)">\u27F2</button><button data-v="r" title="right (L)">\u25B6</button>
    <span></span><button data-v="d" title="down (K)">\u25BC</button><span></span>`,document.body.appendChild(t);let e=(n,s)=>{let r=s?1:0;n==="l"&&(Ri.x=r),n==="r"&&(Ri.x=-r),n==="u"&&(Ri.y=r),n==="d"&&(Ri.y=-r),n==="zi"&&(Ri.z=-r),n==="zo"&&(Ri.z=r)};t.querySelectorAll("button").forEach(n=>{let s=n.dataset.v;n.addEventListener("pointerdown",o=>{if(o.preventDefault(),s==="reset"){Ml();return}n.setPointerCapture(o.pointerId),e(s,!0)});let r=()=>e(s,!1);n.addEventListener("pointerup",r),n.addEventListener("pointercancel",r),n.addEventListener("lostpointercapture",r)}),addEventListener("keydown",n=>{var s;n.code==="KeyH"&&ze!=="hub"&&!/INPUT|TEXTAREA|SELECT/.test((s=document.activeElement)==null?void 0:s.tagName)&&Ml()})})();var Rs=new C,bu=new C,Cs=new C,xl=new Re,vp=new Re,bp=new C(0,1,0),_p=document.getElementById("viewPad");function d_(i){var c;let t=((c=gn[ze])==null?void 0:c.lobby)&&!gn[ze].lobby.el.hidden;_p.hidden!==!!t&&(_p.hidden=!!t);let e=Nf(),n=ft.keys,s=(h,u)=>(n.has(h)?1:0)-(n.has(u)?1:0);if(an.yaw+=-e.x*.006+(s("KeyJ","KeyL")+Ri.x)*1.5*i,an.pitch+=e.y*.004+(s("KeyI","KeyK")+Ri.y)*.9*i,an.zoom=Math.max(.3,Math.min(3,an.zoom*e.zoom*Math.pow(2,(s("KeyO","KeyU")+Ri.z)*i))),!an.yaw&&!an.pitch&&an.zoom===1)return;let r=gn[ze],o=r!=null&&r.viewPivot?r.viewPivot():tn.look;Rs.copy(tn.pos).sub(o),bu.copy(tn.look).sub(o);let a=Rs.length();if(a<1e-4)return;let l=Math.asin(Math.max(-1,Math.min(1,Rs.y/a)));an.pitch=Math.max(.06-l,Math.min(1.45-l,an.pitch)),Cs.subVectors(tn.look,tn.pos).setY(0),Cs.lengthSq()<1e-8&&Cs.set(Rs.x,0,Rs.z).negate(),Cs.lengthSq()<1e-8&&Cs.set(0,0,-1),Cs.normalize().cross(bp).normalize(),xl.setFromAxisAngle(Cs,-an.pitch),vp.setFromAxisAngle(bp,an.yaw),xl.premultiply(vp),Rs.applyQuaternion(xl).multiplyScalar(an.zoom),bu.applyQuaternion(xl),tn.pos.copy(o).add(Rs),tn.look.copy(o).add(bu),tn.up.set(0,1,0)}var wl=!1,Ci=null;function Ar(i){var t;if(i!==ze)if(wl=!0,(t=gn[ze])==null||t.exit(),ze=i,Ml(),document.body.classList.toggle("ingame",i!=="hub"),document.body.dataset.mode=i,At("#viewPad").hidden=i==="hub",i==="hub"){wp.hide(),At("#joy").hidden=!ft.touch;let e=fo.find(n=>n.id===(Ci==null?void 0:Ci.id))||fo[0];e.id==="golf"&&re.pos.set(e.x-3,0,e.z+1),e.id==="fishing"&&re.pos.set(e.x+4,0,0),e.id==="billiards"&&re.pos.set(e.x,0,e.z+2.5),Tn.yaw=Math.atan2(-(Qe.position.x-re.pos.x),-(Qe.position.z-re.pos.z))+Math.PI}else At("#btnAction").hidden=!0,At("#joy").hidden=!0,gn[i].enter()}ws("action",()=>{ze==="hub"&&Ci&&(Tr.unlock(),Ar(Ci.id))});ws("powerDown",()=>{var i;Tr.unlock(),(i=gn[ze])==null||i.powerDown()});ws("powerUp",()=>{var i;return(i=gn[ze])==null?void 0:i.powerUp()});var Mu=new C;function f_(i){let t=Wi();Tn.yaw-=t.x*.006,Tn.pitch=Math.max(.08,Math.min(1.1,Tn.pitch+t.y*.004));let e=Uf(),n=e.run?6:3.6,s=-Math.sin(Tn.yaw),r=-Math.cos(Tn.yaw),o=-r,a=s,l=s*e.y+o*e.x,c=r*e.y+a*e.x,h=Math.hypot(l,c);if(re.speed=h*n,h>.01){re.pos.x+=l/Math.max(1,h)*n*i,re.pos.z+=c/Math.max(1,h)*n*i;let f=Math.atan2(l,c)-re.yaw;f=Math.atan2(Math.sin(f),Math.cos(f)),re.yaw+=f*Math.min(1,i*12)}Xn.resolve(re.pos);let u=null;for(let d of fo)Math.hypot(re.pos.x-d.x,re.pos.z-d.z)<d.r&&(u=d);if(u!==Ci){Ci=u;let d=At("#btnAction");d.hidden=!u,u&&(d.textContent=`${{golf:"\u26F3",fishing:"\u{1F3A3}",billiards:"\u{1F3B1}"}[u.id]} ${U(u.id)} ${U("play")}${ft.touch?"":" (E)"}`)}Mu.set(Math.sin(Tn.yaw)*Math.cos(Tn.pitch),Math.sin(Tn.pitch),Math.cos(Tn.yaw)*Math.cos(Tn.pitch)).multiplyScalar(Tn.dist),tn.pos.copy(re.pos).add(Mu),tn.pos.y=Math.max(tn.pos.y,.6),tn.look.copy(re.pos).add(new C(0,1.3,0))}var Au=new Ga,yl=0,_u=0,p_=Qi.has("fps");function Ru(){var s,r,o,a;let i=Math.min(Au.getDelta(),.05),t=performance.now(),e=t/1e3;if(ln){ze==="hub"?f_(i):(gn[ze].update(i),d_(i)),re.pos.y=Xn.groundHeight(re.pos.x,re.pos.z),ln.root.position.copy(re.pos),ln.root.rotation.y=re.yaw,ln.root.visible=!((s=gn[ze])!=null&&s.hideAvatar),ln.tag&&(ln.tag.visible=ze==="hub"),ln.animate(i,re.speed,t);let l=1-Math.pow(5e-4,i),c=wl?1:ze==="hub"?Math.min(1,l*2):l;wl=!1,Qe.position.lerp(tn.pos,c),_l.lerp(tn.look,c),Qe.up.copy(tn.up),Qe.lookAt(_l),Xn.follow(((r=gn[ze])==null?void 0:r.focus)||re.pos),Xn.sky.position.set(Qe.position.x,0,Qe.position.z),Ro==null||Ro.update(i,re.pos),An.state({p:[+re.pos.x.toFixed(2),+re.pos.y.toFixed(2),+re.pos.z.toFixed(2)],r:+re.yaw.toFixed(2),a:ze,b:Tu.netState()},t)}(o=Co.tick)==null||o.call(Co,i);for(let l of kn.values()){let c=l.avatar.root.position,h=Mu.copy(c),u=h.x,d=h.z;c.lerp(l.target,1-Math.pow(1e-4,i)),c.distanceToSquared(l.target)>400&&c.copy(l.target);let f=Math.hypot(c.x-u,c.z-d)/Math.max(i,.001);l.speed+=(f-l.speed)*Math.min(1,i*8);let g=l.yaw-l.avatar.root.rotation.y;g=Math.atan2(Math.sin(g),Math.cos(g)),l.avatar.root.rotation.y+=g*Math.min(1,i*10),l.avatar.root.visible=!l.avatar.root.userData.hiddenByBlock,l.avatar.animate(i,l.speed,t),l.avatar.curveFix(Qe.position,bs.value)}ln==null||ln.curveFix(Qe.position,bs.value),Xn.update(e,i),Se.render(ri,Qe);let n=(a=gn[ze])==null?void 0:a.pip;if(n!=null&&n.on&&n.el&&!n.el.hidden){let l=n.el.getBoundingClientRect(),c=Se.domElement,h=c.clientHeight;if(l.width>10&&l.height>10){n.cam.aspect=l.width/l.height,n.cam.updateProjectionMatrix(),Se.setScissorTest(!0),Se.setScissor(l.left,h-l.bottom,l.width,l.height),Se.setViewport(l.left,h-l.bottom,l.width,l.height);let u=Se.shadowMap.autoUpdate;Se.shadowMap.autoUpdate=!1,Se.render(ri,n.cam),Se.shadowMap.autoUpdate=u,Se.setScissorTest(!1),Se.setViewport(0,0,c.clientWidth,h)}}if(yl+=i,_u++,yl>2){let l=_u/yl;l<45&&Ki>.6?(Ki=Math.max(.6,Ki-.1),bl()):l>58&&Ki<1&&(Ki=Math.min(1,Ki+.05),bl()),p_&&(At("#fps").textContent=`${l.toFixed(0)} fps \xB7 x${Ki.toFixed(2)} \xB7 ${Se.info.render.calls} calls`),yl=0,_u=0}}Se.setAnimationLoop(Ru);document.addEventListener("visibilitychange",()=>{Se.setAnimationLoop(document.hidden?null:Ru),Au.getDelta()});function m_(){return{name:"",lang:"ko",color:Rf.shirts[0],country:""}}function Rp(){document.documentElement.lang=rn(),document.querySelectorAll("[data-i18n]").forEach(i=>{i.textContent=U(i.dataset.i18n)}),At("#chatIn").placeholder="\uBA54\uC2DC\uC9C0 \uC785\uB825 \xB7 \uC774\uB984\uC744 \uB204\uB974\uBA74 \uCC28\uB2E8/\uC2E0\uACE0",At("#venueName").textContent=ts.name,An&&vl(),Ci=null}Ff("ko");Rp();Qe.position.set(14,7,14);_l.set(0,1,0);Qe.lookAt(_l);var wu=!1;function g_(i){Ji.name=i.nick,Ji.color=i.color||Ji.color,Tr.unlock(),At("#login").hidden=!0,At("#top").hidden=!1,At("#chat").hidden=!1,At("#joy").hidden=!ft.touch,ft.touch&&At("#chat").classList.add("collapsed"),ln=new mo({name:Ji.name,color:Ji.color,flag:""}),ri.add(ln.root),Tn.yaw=Math.atan2(re.pos.x,re.pos.z),An=new ja({message:c_,disconnected:e=>{if(At("#status").classList.add("off"),e===4e3){ji("\u26A0\uFE0F \uB2E4\uB978 \uCC3D\uC5D0\uC11C \uB77C\uC6B4\uC9C0\uC5D0 \uB4E4\uC5B4\uC640\uC11C \uC5EC\uAE30\uB294 \uC5F0\uACB0\uC744 \uB04A\uC5C8\uC5B4\uC694.");return}e!==4003&&(ji("\u26A0\uFE0F \uC5F0\uACB0\uC774 \uB04A\uACBC\uC5B4\uC694. \uB2E4\uC2DC \uC5F0\uACB0\uD558\uB294 \uC911\u2026"),setTimeout(()=>location.reload(),3e3))}}),An.connect(Ji,ts,mu,le.token),Rp();let t=Qi.get("play");t&&setTimeout(()=>Cp(t),300)}function Cp(i){let t=fo.find(e=>e.id===i);!t||!ln||(ze!=="hub"&&Ar("hub"),re.pos.set(t.x,0,t.z),Ci=t,Ar(i))}dp(Sp);cp(g_);kf(Mp);At("#btnRooms").onclick=()=>fp(ts.id);At("#btnMeet").onclick=()=>Er();At("#btnMe").onclick=()=>lp();At("#btnAdmin").onclick=()=>So();At("#btnExit").onclick=()=>ml();addEventListener("lounge-block",()=>{for(let i of kn.values())i.avatar.root.userData.hiddenByBlock=Sr(i.info.uid)});window.addEventListener("message",i=>{let t=i.data;t&&t.lounge==="pause"&&Se.setAnimationLoop(null),t&&t.lounge==="resume"&&(Au.getDelta(),Se.setAnimationLoop(Ru))});window.TaeilLounge={play:Cp,get venue(){return ts}};Qi.has("debug")&&(window.TaeilLounge._dbg={golf:Tu,fishing:Ap,billiards:Co,player:re,world:Xn,camera:Qe,scene:ri});})();

/* 태일골프 환율 — 회원용(index.html)·관리자용(admin.html) 공통 데이터와 그래프
   출처: fawazahmed0 Currency API (무료, 키 없음, 하루 1번 갱신). 원화(KRW) 기준 값만 받고 나머지는 교차 계산.
   지난 날짜 값은 바뀌지 않으므로 기기에 저장해 두고(taeil-fx-days), 다음부터는 오늘 값 1건만 새로 받는다. */
"use strict";
const DAYS = 14;
const COUNTRIES = [ // 나라 → 통화
  ["KR","KRW"],["US","USD"],["JP","JPY"],["CN","CNY"],["VN","VND"],["TH","THB"],["TW","TWD"],["HK","HKD"],["SG","SGD"],["PH","PHP"],["ID","IDR"],["MY","MYR"],["IN","INR"],
  ["GB","GBP"],["FR","EUR"],["DE","EUR"],["IT","EUR"],["ES","EUR"],["CH","CHF"],["SE","SEK"],["NO","NOK"],["DK","DKK"],["PL","PLN"],["CZ","CZK"],["HU","HUF"],["TR","TRY"],
  ["AU","AUD"],["NZ","NZD"],["CA","CAD"],["MX","MXN"],["BR","BRL"],["CL","CLP"],["PE","PEN"],["CO","COP"],["ZA","ZAR"],["EG","EGP"],["KE","KES"],
  ["AE","AED"],["SA","SAR"],["QA","QAR"],["KW","KWD"],["IL","ILS"],["MN","MNT"],["KZ","KZT"],["KH","KHR"],["LA","LAK"],["NP","NPR"],["MO","MOP"],["PK","PKR"],["BD","BDT"],
  ["GU","USD"],["MV","MVR"],["LK","LKR"],["FJ","FJD"]
];
const POOL = ["USD","EUR","JPY","CNY","GBP","HKD","AUD","CAD","CHF","SGD","THB","TWD","VND","PHP","IDR","INR","MXN","BRL","TRY","ZAR"];
const NEED = new Set([...COUNTRIES.map(c => c[1]), ...POOL].map(c => c.toLowerCase()));
const KO_FIX = { GU: "괌" };
const regionName = (() => { try { const d = new Intl.DisplayNames(["ko"], { type: "region" }); return r => KO_FIX[r] || d.of(r); } catch { return r => KO_FIX[r] || r; } })();
const curName = (() => { try { const d = new Intl.DisplayNames(["ko"], { type: "currency" }); return c => d.of(c); } catch { return c => c; } })();
const flagOf = r => String.fromCodePoint(...[...r].map(ch => 0x1F1A5 + ch.charCodeAt(0)));
const curFlag = c => c === "EUR" ? "🇪🇺" : /^[A-W]/.test(c) ? flagOf(c.slice(0, 2)) : "🏳️";
const fmt = (n, d = 2) => n.toLocaleString("ko-KR", { minimumFractionDigits: d, maximumFractionDigits: d });
const iso = d => d.toISOString().slice(0, 10);
const md = s => s.slice(5).replace("-", "/");
const esc = s => String(s).replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[ch]);
const curOf = r => (COUNTRIES.find(c => c[0] === r) || ["KR", "KRW"])[1];
const lsGet = (k, d) => { try { const v = JSON.parse(localStorage.getItem(k)); return v ?? d; } catch { return d; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} };

/* ---------- 데이터 ---------- */
const FX = { dates: [], krwPer: {}, stale: false, error: "" };
const CACHE_K = "taeil-fx-days", LATEST_K = "taeil-fx-latest-at";
const slim = krw => { const o = {}; for (const k in krw) if (NEED.has(k) && krw[k] > 0) o[k] = +krw[k].toPrecision(8); return o; };
async function fetchDay(tag) {
  for (const u of [`https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@${tag}/v1/currencies/krw.min.json`, `https://${tag}.currency-api.pages.dev/v1/currencies/krw.min.json`]) {
    try {
      const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), 9000);
      const r = await fetch(u, { signal: ctl.signal, cache: "no-cache" }); clearTimeout(t);
      if (r.ok) { const j = await r.json(); if (j && j.krw && j.date) return j; }
    } catch {}
  }
  return null;
}
async function loadFX(force) {
  const cache = lsGet(CACHE_K, {});
  const today = new Date(), want = [];
  for (let i = DAYS; i >= 1; i--) want.push(iso(new Date(today - i * 864e5)));
  const miss = want.filter(d => !cache[d]);
  const lastAt = +lsGet(LATEST_K, 0), fresh = !force && Date.now() - lastAt < 3 * 3600e3 && Object.keys(cache).length;
  const jobs = miss.map(fetchDay);
  if (!fresh) jobs.push(fetchDay("latest"));
  const res = await Promise.all(jobs);
  let got = 0;
  for (const d of res) if (d) { cache[d.date] = slim(d.krw); got++; }
  if (!fresh && res.at(-1)) lsSet(LATEST_K, Date.now());
  // 20일 넘은 날짜는 지워서 저장 공간을 작게
  const keep = Object.keys(cache).sort().slice(-(DAYS + 6)); const pruned = {}; keep.forEach(k => pruned[k] = cache[k]);
  lsSet(CACHE_K, pruned);
  const all = Object.keys(pruned).sort().filter(d => d >= want[0]);
  FX.stale = !fresh && !res.at(-1); // 오늘 값을 못 받음 → 마지막으로 받은 값
  if (all.length < 2) { FX.dates = []; FX.krwPer = {}; FX.error = got || all.length ? "data" : "net"; return FX; }
  FX.error = "";
  FX.dates = all;
  const last = pruned[all.at(-1)];
  FX.krwPer = { KRW: all.map(() => 1) };
  for (const k of Object.keys(last)) {
    const c = k.toUpperCase(); if (c.length !== 3 || c === "KRW") continue;
    const s = all.map(d => { const v = pruned[d][k]; return v > 0 ? 1 / v : null; });
    let lastV = null; let arr = s.map(v => lastV = v ?? lastV); // 빠진 날은 전날 값
    if (arr[0] == null) { const f = arr.find(v => v != null); arr = arr.map(v => v ?? f); }
    FX.krwPer[c] = arr;
  }
  return FX;
}
const has = c => !!FX.krwPer[c];
const cross = (a, b) => FX.krwPer[a].map((v, i) => v / FX.krwPer[b][i]); // a 1단위 = ? b
const now = (a, b) => FX.krwPer[a].at(-1) / FX.krwPer[b].at(-1);
const change = (a, b, n = DAYS + 1) => { const s = cross(a, b).slice(-n); return (s.at(-1) - s[0]) / s[0] * 100; };
const chgTxt = (p, cls = true) => `<span class="${cls ? (Math.abs(p) < .005 ? "flat" : p > 0 ? "up" : "down") : ""}">${p > 0 ? "▲" : p < 0 ? "▼" : ""}${Math.abs(p).toFixed(2)}%</span>`;

/* ---------- 화면 공통 ---------- */
function shell(title, sub) {
  document.body.innerHTML = `<header class="bar"><button class="back" id="fxBack" aria-label="뒤로 가기 (메인화면)">← 뒤로</button><img src="logo.png" alt="태일골프" class="logo"><div class="ttl"><b>${title}</b><span>${sub}</span></div><button class="close" id="fxClose" aria-label="닫기">✕ 닫기</button></header>
    <main id="fxMain" class="main"><div class="loading">환율을 불러오는 중…</div></main>`;
  const close = () => { try { parent.postMessage({ fx: "close" }, "*"); } catch {} };
  document.getElementById("fxBack").onclick = close; document.getElementById("fxClose").onclick = close;
  addEventListener("keydown", e => { if (e.key === "Escape") { const s = document.querySelector(".sheet"); s ? s.remove() : close(); } });
  return document.getElementById("fxMain");
}
function statusBar() {
  if (FX.stale) return `<div class="notice">인터넷 연결이 불안정해 마지막으로 받은 환율(${md(FX.dates.at(-1))})을 보여 드려요. <button data-act="retry">다시 받기</button></div>`;
  return "";
}
function errorView(main, retry) {
  main.innerHTML = `<div class="err"><b>환율을 받아오지 못했어요</b><p>${FX.error === "net" ? "인터넷 연결을 확인한 뒤 다시 시도해 주세요." : "환율 서버 응답이 올바르지 않아요. 잠시 뒤 다시 시도해 주세요."}</p><button class="btn primary" id="fxRetry">다시 시도</button></div>`;
  main.querySelector("#fxRetry").onclick = retry;
}
const sourceNote = () => `<p class="src">환율 출처: Currency API (fawazahmed0) · 하루 한 번 갱신되는 시장 기준값이에요. 은행 송금·현찰 환율과는 수수료만큼 달라요. 마지막 기준일 ${FX.dates.length ? FX.dates.at(-1) : "-"}</p>`;

function countrySheet(title, onPick, filter = () => true) {
  const el = document.createElement("div");
  el.className = "sheet";
  el.innerHTML = `<div class="panel" role="dialog" aria-label="${title}"><div class="head"><b>${title}</b><button class="x" aria-label="닫기">×</button><input placeholder="나라 이름이나 통화(예: 태국, THB)" aria-label="나라 검색"></div><div class="body"></div></div>`;
  const body = el.querySelector(".body"), input = el.querySelector("input");
  const fill = () => {
    const q = input.value.trim();
    body.innerHTML = COUNTRIES.filter(([r, c]) => has(c) && filter(r) && (!q || regionName(r).includes(q) || c.includes(q.toUpperCase())))
      .map(([r, c]) => `<button class="row" data-r="${r}"><span class="f">${flagOf(r)}</span><span>${regionName(r)}</span><span class="c">${c}</span></button>`).join("") || `<p class="empty">찾는 나라가 없어요.</p>`;
  };
  fill(); input.addEventListener("input", fill);
  el.addEventListener("click", e => { if (e.target === el || e.target.closest(".x")) return el.remove(); const b = e.target.closest("[data-r]"); if (b) { el.remove(); onPick(b.dataset.r); } });
  document.body.appendChild(el); input.focus();
}
function chartSVG(series, labels, W, H) {
  const lo = Math.min(...series), hi = Math.max(...series), pad = (hi - lo) * .15 || hi * .01;
  const PL = 6, PR = 6, PT = 16, PB = 20;
  const x = i => PL + i / (series.length - 1) * (W - PL - PR), y = v => PT + (1 - (v - (lo - pad)) / (hi - lo + 2 * pad)) * (H - PT - PB);
  const pts = series.map((v, i) => ({ x: x(i), y: y(v), v, d: labels[i] }));
  const col = series.at(-1) >= series[0] ? "var(--up)" : "var(--down)";
  const line = pts.map(p => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ");
  const loP = pts.reduce((a, b) => b.v < a.v ? b : a);
  let g = `<path d="M${pts[0].x},${H - PB} L${line.replace(/ /g, " L")} L${pts.at(-1).x},${H - PB} Z" fill="${col}" opacity=".12"/>
    <polyline points="${line}" fill="none" stroke="${col}" stroke-width="2" stroke-linejoin="round"/>
    <circle cx="${pts.at(-1).x}" cy="${pts.at(-1).y}" r="3.5" fill="${col}"/>
    <circle cx="${loP.x}" cy="${loP.y}" r="4.5" fill="none" stroke="var(--down)" stroke-width="1.8"/>
    <text class="lo" x="${Math.min(Math.max(loP.x, 16), W - 16)}" y="${Math.min(loP.y + 15, H - PB - 2)}" text-anchor="middle">최저</text>`;
  const step = Math.ceil(pts.length / 5);
  pts.forEach((p, i) => { if (i % step === 0 || i === pts.length - 1) g += `<text x="${Math.min(Math.max(p.x, 14), W - 14)}" y="${H - 5}" text-anchor="middle">${md(p.d)}</text>`; });
  g += `<line class="cross" y1="${PT}" y2="${H - PB}" stroke="currentColor" stroke-opacity=".4" stroke-dasharray="3 3" visibility="hidden"/><circle class="dot" r="5" fill="none" stroke="${col}" stroke-width="2" visibility="hidden"/>`;
  return { svg: `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="환율 그래프">${g}</svg>`, pts };
}
function wireChart(root, pts, W, onHover) {
  const svg = root.querySelector("svg.chart"); if (!svg) return;
  const c = svg.querySelector(".cross"), d = svg.querySelector(".dot");
  const move = e => {
    const r = svg.getBoundingClientRect(), mx = (e.clientX - r.left) / r.width * W;
    const p = pts.reduce((a, b) => Math.abs(b.x - mx) < Math.abs(a.x - mx) ? b : a);
    c.setAttribute("x1", p.x); c.setAttribute("x2", p.x); c.setAttribute("visibility", "visible");
    d.setAttribute("cx", p.x); d.setAttribute("cy", p.y); d.setAttribute("visibility", "visible");
    onHover(p);
  };
  svg.addEventListener("pointerdown", move); svg.addEventListener("pointermove", move);
}
/* 자주 쓰는 금액: 원화로 약 5천~30만 원이 되도록 1·2·5 단위로 맞춤 */
function quickAmounts(cur, rateKRW) {
  const fixed = { JPY: [1000, 3000, 5000, 10000, 30000, 50000], VND: [50000, 100000, 200000, 500000, 1000000, 2000000], THB: [100, 300, 500, 1000, 3000, 5000] };
  if (fixed[cur]) return fixed[cur];
  const nice = v => { const e = 10 ** Math.floor(Math.log10(v)), m = v / e; return (m < 1.5 ? 1 : m < 3.5 ? 2 : m < 7.5 ? 5 : 10) * e; };
  return [...new Set([5000, 10000, 30000, 50000, 100000, 300000].map(k => nice(k / rateKRW)))];
}
